"use client";

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";

export interface CurrentUser {
  id: number;
  username: string;
  displayName: string;
  email: string | null;
  avatar: string | null;
  coverImage: string | null;
  bio: string | null;
  isVerifiedStar: boolean;
  isBrand: boolean;
  badge: string | null;
  paysiteUrl: string | null;
  paysiteLabel: string | null;
  
  // Role & Contact details
  accountType: string;
  genderRole: string | null;
  agencyType: string | null;
  phone: string | null;
  allowWhatsapp: boolean;
  allowCalls: boolean;
  allowSms: boolean;
  locationArea: string | null;
  serviceType: string | null;
  servicesOffered: string | null;
  rates: string | null;
  advertMediaUrl: string | null;
  advertMediaType: string | null;
  subscriptionStatus: string;
  subscriptionPlan: string | null;
  subscriptionExpiresAt: string | null;
  isAdmin: boolean;
  isBanned: boolean;

  // Stripchat Tokens & Statuses
  tokensBalance: number;
  userLevel: number;
  userXp: number;
  isUltimateMember: boolean;
  isKnight: boolean;
  vipTier: string;
  
  // Cheelee attention & flames
  flamesBalance: number;
  flamesReceived: number;
  leeBalance: string;
  cheelBalance: string;
  usdtBalance: string;
  
  attentionMinutesLeft: number;
  attentionMaxMinutes: number;
  activeGlassesId: number | null;
  selectedStrategy: string;

  followersCount: number;
  followingCount: number;
  friendsCount: number;
  location: string | null;
  website: string | null;
}

export interface TipTarget {
  id: number;
  username: string;
  displayName: string;
  avatar: string | null;
  postId?: number;
}

export interface ContactTarget {
  id: number;
  displayName: string;
  username: string;
  avatar?: string | null;
  maskedPhone?: string;
  phone?: string;
  locationArea?: string;
  serviceType?: string;
  servicesList?: string[];
  ratesList?: { duration: string; priceKsh: number }[];
  genderRole?: string;
  agencyType?: string;
  allowWhatsapp?: boolean;
  allowCalls?: boolean;
  allowSms?: boolean;
}

interface AppContextType {
  currentUser: CurrentUser | null;
  loadingUser: boolean;
  unreadNotifications: number;
  refreshUser: () => Promise<void>;
  
  // Modals
  openTipModal: (target: TipTarget) => void;
  closeTipModal: () => void;
  tipTarget: TipTarget | null;

  openTipMenuModal: (modelId: number, modelName?: string) => void;
  closeTipMenuModal: () => void;
  tipMenuTarget: { modelId: number; modelName?: string } | null;

  openWheelModal: (modelId: number, modelName?: string) => void;
  closeWheelModal: () => void;
  wheelTarget: { modelId: number; modelName?: string } | null;

  openToyModal: (modelId: number, modelName?: string) => void;
  closeToyModal: () => void;
  toyTarget: { modelId: number; modelName?: string } | null;

  openFanClubModal: (modelId: number, modelName?: string) => void;
  closeFanClubModal: () => void;
  fanClubTarget: { modelId: number; modelName?: string } | null;

  openWishlistModal: (modelId: number, modelName?: string) => void;
  closeWishlistModal: () => void;
  wishlistTarget: { modelId: number; modelName?: string } | null;

  openTokensModal: () => void;
  closeTokensModal: () => void;
  isTokensOpen: boolean;

  openContactModal: (target: ContactTarget) => void;
  closeContactModal: () => void;
  contactTarget: ContactTarget | null;

  openAuthModal: (mode?: "login" | "join_free" | "register_creator" | "register_agency") => void;
  closeAuthModal: () => void;
  isAuthOpen: boolean;
  authMode: "login" | "join_free" | "register_creator" | "register_agency";

  openUpgradeModal: (initialMode?: "creator" | "agency") => void;
  closeUpgradeModal: () => void;
  isUpgradeOpen: boolean;
  upgradeInitialMode: "creator" | "agency";

  openCreateProfileModal: () => void;
  closeCreateProfileModal: () => void;
  isCreateProfileOpen: boolean;

  openCreateStoryModal: () => void;
  closeCreateStoryModal: () => void;
  isCreateStoryOpen: boolean;

  openCreateQuickieModal: () => void;
  closeCreateQuickieModal: () => void;
  isCreateQuickieOpen: boolean;

  openCreateAdModal: () => void;
  closeCreateAdModal: () => void;
  isCreateAdOpen: boolean;

  openCreatePostModal: (topicId?: number) => void;
  closeCreatePostModal: () => void;
  isCreatePostOpen: boolean;
  createPostInitialTopicId?: number;

  openWalletModal: () => void;
  closeWalletModal: () => void;
  isWalletOpen: boolean;

  openStoryViewer: (storiesGroup: any[], startIndex?: number) => void;
  closeStoryViewer: () => void;
  activeStoryGroup: any[] | null;
  activeStoryIndex: number;

  ageVerified: boolean;
  verifyAge: () => void;

  triggerPostRefresh: () => void;
  postRefreshCounter: number;

  colorTheme: "flame" | "fb_blue" | "gittr_gold" | "pink";
  setColorTheme: (theme: "flame" | "fb_blue" | "gittr_gold" | "pink") => void;

  lastDroppedBox: any | null;
  dismissDroppedBox: () => void;
  triggerWatchTick: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  // Modal target states
  const [tipTarget, setTipTarget] = useState<TipTarget | null>(null);
  const [tipMenuTarget, setTipMenuTarget] = useState<{ modelId: number; modelName?: string } | null>(null);
  const [wheelTarget, setWheelTarget] = useState<{ modelId: number; modelName?: string } | null>(null);
  const [toyTarget, setToyTarget] = useState<{ modelId: number; modelName?: string } | null>(null);
  const [fanClubTarget, setFanClubTarget] = useState<{ modelId: number; modelName?: string } | null>(null);
  const [wishlistTarget, setWishlistTarget] = useState<{ modelId: number; modelName?: string } | null>(null);
  const [isTokensOpen, setIsTokensOpen] = useState(false);

  const [contactTarget, setContactTarget] = useState<ContactTarget | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "join_free" | "register_creator" | "register_agency">("join_free");

  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);
  const [upgradeInitialMode, setUpgradeInitialMode] = useState<"creator" | "agency">("creator");

  const [isCreateProfileOpen, setIsCreateProfileOpen] = useState(false);
  const [isCreateStoryOpen, setIsCreateStoryOpen] = useState(false);
  const [isCreateQuickieOpen, setIsCreateQuickieOpen] = useState(false);
  const [isCreateAdOpen, setIsCreateAdOpen] = useState(false);

  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [createPostInitialTopicId, setCreatePostInitialTopicId] = useState<number | undefined>(undefined);
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [activeStoryGroup, setActiveStoryGroup] = useState<any[] | null>(null);
  const [activeStoryIndex, setActiveStoryIndex] = useState(0);
  const [ageVerified, setAgeVerified] = useState<boolean>(true);
  const [postRefreshCounter, setPostRefreshCounter] = useState(0);
  const [lastDroppedBox, setLastDroppedBox] = useState<any | null>(null);
  const [colorTheme, setColorThemeState] = useState<"flame" | "fb_blue" | "gittr_gold" | "pink">("flame");

  const setColorTheme = (theme: "flame" | "fb_blue" | "gittr_gold" | "pink") => {
    setColorThemeState(theme);
    localStorage.setItem("hotcheelee_color_theme", theme);
    document.documentElement.setAttribute("data-theme", theme);
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem("hotcheelee_color_theme") as any;
    if (savedTheme && ["flame", "fb_blue", "gittr_gold", "pink"].includes(savedTheme)) {
      setColorThemeState(savedTheme);
      document.documentElement.setAttribute("data-theme", savedTheme);
    }
  }, []);

  const fetchUser = useCallback(async () => {
    try {
      const res = await fetch("/api/currentUser");
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        setUnreadNotifications(data.unreadNotificationsCount || 0);
      }
    } catch (e) {
      console.error("Failed to load user:", e);
    } finally {
      setLoadingUser(false);
    }
  }, []);

  useEffect(() => {
    fetchUser();
    const verified = localStorage.getItem("hotcheelee_age_verified");
    if (!verified) {
      setAgeVerified(false);
    }
  }, [fetchUser]);

  const verifyAge = () => {
    localStorage.setItem("hotcheelee_age_verified", "true");
    setAgeVerified(true);
  };

  const openTipModal = (target: TipTarget) => setTipTarget(target);
  const closeTipModal = () => setTipTarget(null);

  const openTipMenuModal = (modelId: number, modelName?: string) => setTipMenuTarget({ modelId, modelName });
  const closeTipMenuModal = () => setTipMenuTarget(null);

  const openWheelModal = (modelId: number, modelName?: string) => setWheelTarget({ modelId, modelName });
  const closeWheelModal = () => setWheelTarget(null);

  const openToyModal = (modelId: number, modelName?: string) => setToyTarget({ modelId, modelName });
  const closeToyModal = () => setToyTarget(null);

  const openFanClubModal = (modelId: number, modelName?: string) => setFanClubTarget({ modelId, modelName });
  const closeFanClubModal = () => setFanClubTarget(null);

  const openWishlistModal = (modelId: number, modelName?: string) => setWishlistTarget({ modelId, modelName });
  const closeWishlistModal = () => setWishlistTarget(null);

  const openTokensModal = () => setIsTokensOpen(true);
  const closeTokensModal = () => setIsTokensOpen(false);

  const openContactModal = (target: ContactTarget) => setContactTarget(target);
  const closeContactModal = () => setContactTarget(null);

  const openAuthModal = (m: "login" | "join_free" | "register_creator" | "register_agency" = "join_free") => {
    setAuthMode(m);
    setIsAuthOpen(true);
  };
  const closeAuthModal = () => setIsAuthOpen(false);

  const openUpgradeModal = (initial: "creator" | "agency" = "creator") => {
    setUpgradeInitialMode(initial);
    setIsUpgradeOpen(true);
  };
  const closeUpgradeModal = () => setIsUpgradeOpen(false);

  const openCreateProfileModal = () => setIsCreateProfileOpen(true);
  const closeCreateProfileModal = () => setIsCreateProfileOpen(false);

  const openCreateStoryModal = () => setIsCreateStoryOpen(true);
  const closeCreateStoryModal = () => setIsCreateStoryOpen(false);

  const openCreateQuickieModal = () => setIsCreateQuickieOpen(true);
  const closeCreateQuickieModal = () => setIsCreateQuickieOpen(false);

  const openCreateAdModal = () => setIsCreateAdOpen(true);
  const closeCreateAdModal = () => setIsCreateAdOpen(false);

  const openCreatePostModal = (topicId?: number) => {
    if (currentUser && currentUser.accountType === "browsing") {
      openUpgradeModal("creator");
      return;
    }
    if (currentUser && (currentUser.subscriptionStatus === "inactive" || currentUser.subscriptionStatus === "expired")) {
      openUpgradeModal("creator");
      return;
    }
    setCreatePostInitialTopicId(topicId);
    setIsCreatePostOpen(true);
  };
  const closeCreatePostModal = () => {
    setIsCreatePostOpen(false);
    setCreatePostInitialTopicId(undefined);
  };

  const openWalletModal = () => setIsWalletOpen(true);
  const closeWalletModal = () => setIsWalletOpen(false);

  const openStoryViewer = (storiesGroup: any[], startIndex = 0) => {
    setActiveStoryGroup(storiesGroup);
    setActiveStoryIndex(startIndex);
  };
  const closeStoryViewer = () => {
    setActiveStoryGroup(null);
    setActiveStoryIndex(0);
  };

  const triggerPostRefresh = () => setPostRefreshCounter((c) => c + 1);

  const triggerWatchTick = async () => {
    try {
      const res = await fetch("/api/boxes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "watch_tick", minutesWatched: 1 }),
      });
      const data = await res.json();
      if (data.boxDropped) {
        setLastDroppedBox(data.boxDropped);
      }
      await fetchUser();
    } catch (e) {
      console.error("Watch tick error:", e);
    }
  };

  const dismissDroppedBox = () => setLastDroppedBox(null);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        loadingUser,
        unreadNotifications,
        refreshUser: fetchUser,
        openTipModal,
        closeTipModal,
        tipTarget,

        openTipMenuModal,
        closeTipMenuModal,
        tipMenuTarget,

        openWheelModal,
        closeWheelModal,
        wheelTarget,

        openToyModal,
        closeToyModal,
        toyTarget,

        openFanClubModal,
        closeFanClubModal,
        fanClubTarget,

        openWishlistModal,
        closeWishlistModal,
        wishlistTarget,

        openTokensModal,
        closeTokensModal,
        isTokensOpen,

        openContactModal,
        closeContactModal,
        contactTarget,

        openAuthModal,
        closeAuthModal,
        isAuthOpen,
        authMode,

        openUpgradeModal,
        closeUpgradeModal,
        isUpgradeOpen,
        upgradeInitialMode,

        openCreateProfileModal,
        closeCreateProfileModal,
        isCreateProfileOpen,

        openCreateStoryModal,
        closeCreateStoryModal,
        isCreateStoryOpen,

        openCreateQuickieModal,
        closeCreateQuickieModal,
        isCreateQuickieOpen,

        openCreateAdModal,
        closeCreateAdModal,
        isCreateAdOpen,

        openCreatePostModal,
        closeCreatePostModal,
        isCreatePostOpen,
        createPostInitialTopicId,
        openWalletModal,
        closeWalletModal,
        isWalletOpen,
        openStoryViewer,
        closeStoryViewer,
        activeStoryGroup,
        activeStoryIndex,
        ageVerified,
        verifyAge,
        triggerPostRefresh,
        postRefreshCounter,
        colorTheme,
        setColorTheme,
        lastDroppedBox,
        dismissDroppedBox,
        triggerWatchTick,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
