import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { cookies } from "next/headers";

export const DEFAULT_USER_USERNAME = "alex_member";

export async function getCurrentUser() {
  try {
    const cookieStore = await cookies();
    const sessionUsername = cookieStore.get("hotcheelee_session")?.value;

    if (sessionUsername) {
      const result = await db
        .select()
        .from(users)
        .where(or(eq(users.username, sessionUsername), eq(users.email, sessionUsername)))
        .limit(1);

      if (result.length > 0 && !result[0].isBanned) {
        return result[0];
      }
    }

    // Fallback to default user (Alex Rivers)
    const fallback = await db
      .select()
      .from(users)
      .where(eq(users.username, DEFAULT_USER_USERNAME))
      .limit(1);

    if (fallback.length > 0) {
      return fallback[0];
    }

    const first = await db.select().from(users).limit(1);
    return first[0] || null;
  } catch (e) {
    console.error("getCurrentUser error:", e);
    const first = await db.select().from(users).limit(1);
    return first[0] || null;
  }
}
