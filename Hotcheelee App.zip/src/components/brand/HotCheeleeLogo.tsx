import React from "react";

export interface ChilyLogoProps {
  className?: string;
  size?: number;
}

export function HotCheeleeLogo({ className = "w-7 h-7", size = 28 }: ChilyLogoProps) {
  return (
    <div className={`relative flex items-center justify-center shrink-0 ${className}`} style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="animate-flame"
      >
        <defs>
          <linearGradient id="chiliBodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ff1a40" />
            <stop offset="50%" stopColor="#ff401a" />
            <stop offset="100%" stopColor="#ff9900" />
          </linearGradient>
          <linearGradient id="chiliStemGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
          <filter id="chiliGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Stem of the chili pepper */}
        <path
          d="M34 8C35 4 41 3 45 4C43 8 39 12 37 14"
          stroke="url(#chiliStemGrad)"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M31 13C33 11 39 12 40 14"
          stroke="url(#chiliStemGrad)"
          strokeWidth="2.5"
          strokeLinecap="round"
        />

        {/* Spicy Hot Chili Pepper Curve */}
        <path
          d="M36 14C44 20 48 31 43 43C39 52 28 58 17 56C19 51 22 47 24 43C28 35 29 27 28 17C30 14 34 13 36 14Z"
          fill="url(#chiliBodyGrad)"
          filter="url(#chiliGlow)"
        />

        {/* Chili gloss shine */}
        <path
          d="M34 20C38 25 39 33 37 40C36 43 33 46 30 47"
          stroke="white"
          strokeWidth="2"
          strokeLinecap="round"
          strokeOpacity="0.75"
        />

        {/* Flame sparkle accents */}
        <path
          d="M48 24L51 21L50 26L54 27L49 29L51 34L47 31L45 35L45 30L40 28L45 26L45 21L48 24Z"
          fill="#ffea00"
          className="animate-pulse"
        />
        <circle cx="21" cy="27" r="2" fill="#fff" opacity="0.9" />
      </svg>
    </div>
  );
}

export default HotCheeleeLogo;
