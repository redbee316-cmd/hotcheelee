import React from "react";

export interface ChilyLogoProps {
  className?: string;
  size?: number;
}

// Cheelee Glasses logo adapted for Chily
export function ChilyLogoMark({ className = "w-6 h-6", size = 24 }: ChilyLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="chilyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff3358" />
          <stop offset="60%" stopColor="#ff6536" />
          <stop offset="100%" stopColor="#ffaa00" />
        </linearGradient>
        <linearGradient id="lensGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff3358" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#7928ca" stopOpacity="0.8" />
        </linearGradient>
      </defs>

      {/* Futuristic NFT Glasses Frame */}
      {/* Left frame */}
      <rect
        x="4"
        y="14"
        width="17"
        height="18"
        rx="6"
        fill="url(#lensGrad)"
        stroke="url(#chilyGrad)"
        strokeWidth="3.5"
      />
      {/* Right frame */}
      <rect
        x="27"
        y="14"
        width="17"
        height="18"
        rx="6"
        fill="url(#lensGrad)"
        stroke="url(#chilyGrad)"
        strokeWidth="3.5"
      />
      {/* Bridge connector */}
      <path
        d="M21 21H27"
        stroke="url(#chilyGrad)"
        strokeWidth="4"
        strokeLinecap="round"
      />
      {/* Side temples */}
      <path
        d="M4 19L1 18"
        stroke="url(#chilyGrad)"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <path
        d="M44 19L47 18"
        stroke="url(#chilyGrad)"
        strokeWidth="3"
        strokeLinecap="round"
      />

      {/* Cyber Glare highlight */}
      <path
        d="M8 18L14 18"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeOpacity="0.9"
      />
      <path
        d="M31 18L37 18"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeOpacity="0.9"
      />
    </svg>
  );
}

export default ChilyLogoMark;
