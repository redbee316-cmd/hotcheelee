"use client";

import React, { useState } from "react";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  Edit3,
  MapPin,
  Phone,
  Sparkles,
  Camera,
  CheckCircle2,
  DollarSign,
} from "lucide-react";

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  onSave: (updatedData: any) => Promise<void>;
}

export default function EditProfileModal({
  isOpen,
  onClose,
  user,
  onSave,
}: EditProfileModalProps) {
  const [displayName, setDisplayName] = useState(user?.displayName || "");
  const [bio, setBio] = useState(user?.bio || "");
  const [location, setLocation] = useState(user?.location || "Nairobi");
  const [locationArea, setLocationArea] = useState(user?.locationArea || "Kilimani");
  const [phone, setPhone] = useState(user?.phone || "+254 7");
  const [serviceType, setServiceType] = useState(user?.serviceType || "Both Incall & Outcall");
  const [oneHourPrice, setOneHourPrice] = useState(user?.ratesList?.[0]?.priceKsh || "4000");
  const [overnightPrice, setOvernightPrice] = useState(user?.ratesList?.[1]?.priceKsh || "15000");
  const [genderRole, setGenderRole] = useState(user?.genderRole || "straight");
  const [agencyType, setAgencyType] = useState(user?.agencyType || "Massage Parlour");
  const [website, setWebsite] = useState(user?.website || "");
  const [servicesOffered, setServicesOffered] = useState(
    user?.servicesList?.join(", ") || "Sensual Massage, Companionship, Overnight Stays, GFE"
  );
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const servicesArray = servicesOffered.split(",").map((s: string) => s.trim()).filter(Boolean);
      const ratesArray = [
        { duration: "1 Hour Incall", priceKsh: Number(oneHourPrice) || 4000 },
        { duration: "Overnight Incall", priceKsh: Number(overnightPrice) || 15000 },
      ];

      await onSave({
        displayName: displayName.trim(),
        bio: bio.trim(),
        location,
        locationArea,
        phone,
        serviceType,
        genderRole,
        agencyType: user.accountType === "agency" ? agencyType : null,
        website: website.trim() || null,
        servicesOffered: JSON.stringify(servicesArray),
        rates: JSON.stringify(ratesArray),
      });

      setNotice("Profile updated successfully!");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (e: any) {
      alert(e.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-xl w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95 space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white">
            <Edit3 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">Edit Profile & Details</h2>
            <p className="text-xs text-zinc-400">
              Cloned from Facebook profile editor &bull; Manage rates, services, and contacts
            </p>
          </div>
        </div>

        {notice && (
          <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{notice}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 max-h-[60vh] overflow-y-auto pr-1">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Display Name *</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Location Area *</label>
              <input
                type="text"
                placeholder="Kilimani, Westlands, Nyali"
                value={locationArea}
                onChange={(e) => setLocationArea(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">Bio / About *</label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Mobile Contact Phone *</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Service Mode</label>
              <select
                value={serviceType}
                onChange={(e) => setServiceType(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="Both Incall & Outcall">Both Incall & Outcall</option>
                <option value="Incall">Incall Only</option>
                <option value="Outcall">Outcall Only</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">1 Hour Rate (KSh) *</label>
              <input
                type="number"
                value={oneHourPrice}
                onChange={(e) => setOneHourPrice(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Overnight Rate (KSh) *</label>
              <input
                type="number"
                value={overnightPrice}
                onChange={(e) => setOvernightPrice(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">
              Services Offered (Comma Separated)
            </label>
            <input
              type="text"
              value={servicesOffered}
              onChange={(e) => setServicesOffered(e.target.value)}
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white bg-[#191e2b]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
            >
              {saving ? "Saving Changes..." : "Save Profile Details"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
