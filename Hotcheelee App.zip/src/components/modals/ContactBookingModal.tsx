"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import {
  X,
  Phone,
  MessageCircle,
  PhoneCall,
  Calendar,
  Check,
  ShieldCheck,
  MapPin,
  Clock,
  Sparkles,
  ExternalLink,
} from "lucide-react";

export interface ContactTarget {
  id: number;
  displayName: string;
  username: string;
  avatar?: string | null;
  maskedPhone?: string;
  phone?: string;
  locationArea?: string;
  serviceType?: string;
  servicesList?: string[];
  ratesList?: { duration: string; priceKsh: number }[];
  genderRole?: string;
  agencyType?: string;
  allowWhatsapp?: boolean;
  allowCalls?: boolean;
  allowSms?: boolean;
}

interface ContactBookingModalProps {
  target: ContactTarget | null;
  onClose: () => void;
}

export default function ContactBookingModal({ target, onClose }: ContactBookingModalProps) {
  const { currentUser } = useApp();
  const [activeTab, setActiveTab] = useState<"contact" | "book">("contact");
  const [revealed, setRevealed] = useState(false);
  const [revealedPhone, setRevealedPhone] = useState<string | null>(null);
  const [whatsappUrl, setWhatsappUrl] = useState<string | null>(null);
  const [callUrl, setCallUrl] = useState<string | null>(null);
  const [smsUrl, setSmsUrl] = useState<string | null>(null);

  // Booking states
  const [selectedService, setSelectedService] = useState("");
  const [selectedDuration, setSelectedDuration] = useState("1 Hour");
  const [priceKsh, setPriceKsh] = useState(4000);
  const [preferredDate, setPreferredDate] = useState("Today Evening");
  const [bookingPhone, setBookingPhone] = useState(currentUser?.phone || "+254 7");
  const [clientNote, setClientNote] = useState("");
  const [submittingBooking, setSubmittingBooking] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (target) {
      setRevealed(false);
      setRevealedPhone(null);
      setBookingSuccess(null);
      if (target.ratesList && target.ratesList.length > 0) {
        setSelectedDuration(target.ratesList[0].duration);
        setPriceKsh(target.ratesList[0].priceKsh);
      }
      if (target.servicesList && target.servicesList.length > 0) {
        setSelectedService(target.servicesList[0]);
      }
    }
  }, [target]);

  if (!target) return null;

  const handleRevealContact = async () => {
    try {
      const res = await fetch("/api/contact/reveal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ modelId: target.id }),
      });
      const data = await res.json();
      if (res.ok) {
        setRevealed(true);
        setRevealedPhone(data.phone);
        setWhatsappUrl(data.whatsappUrl);
        setCallUrl(data.callUrl);
        setSmsUrl(data.smsUrl);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSendBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingBooking(true);
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          modelId: target.id,
          serviceRequested: selectedService || "Sensual Companionship",
          serviceType: target.serviceType || "Incall",
          duration: selectedDuration,
          totalPriceKsh: priceKsh,
          preferredDate,
          clientPhone: bookingPhone,
          clientNote,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setBookingSuccess(data.message);
      } else {
        alert(data.error || "Booking failed");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmittingBooking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Profile preview */}
        <div className="flex items-center gap-3.5 mb-4">
          <img
            src={target.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
            alt={target.displayName}
            className="w-14 h-14 rounded-2xl object-cover ring-2 ring-[#ff3358]"
          />
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-bold text-white">{target.displayName}</h3>
              {target.genderRole && (
                <span className="text-[10px] font-black uppercase bg-[#ff3358]/20 text-[#ff3358] border border-[#ff3358]/30 px-1.5 py-0.2 rounded">
                  {target.genderRole}
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400 mt-0.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#ff3358]" />
              <span>{target.locationArea || "Nairobi, Kenya"}</span>
              <span>&bull;</span>
              <span className="text-amber-400 font-bold">{target.serviceType || "Incall & Outcall"}</span>
            </p>
          </div>
        </div>

        {/* Tab Selector: Direct Contact vs Book Appointment */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-[#0e1118] border border-[#212738] rounded-xl mb-4 text-xs font-bold text-center">
          <button
            onClick={() => setActiveTab("contact")}
            className={`py-2 rounded-lg transition ${
              activeTab === "contact" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            Direct Contact Options
          </button>
          <button
            onClick={() => setActiveTab("book")}
            className={`py-2 rounded-lg transition ${
              activeTab === "book" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            Book Appointment (KSh)
          </button>
        </div>

        {/* TAB 1: Direct Contact Reveal */}
        {activeTab === "contact" && (
          <div className="space-y-4">
            {/* Hidden / Revealed Mobile Phone */}
            <div className="bg-[#0e1118] border border-[#232938] p-4 rounded-xl text-center space-y-3">
              <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block">
                Creator Contact Number
              </span>

              {revealed ? (
                <div className="space-y-2">
                  <div className="text-xl sm:text-2xl font-black text-emerald-400 tracking-wider font-mono">
                    {revealedPhone}
                  </div>
                  <span className="text-[11px] text-emerald-400 flex items-center justify-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Verified Kenyan Mobile Number
                  </span>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="text-lg sm:text-xl font-black text-zinc-400 tracking-wider font-mono">
                    {target.maskedPhone || "+254 7•• ••• •••"}
                  </div>

                  <button
                    onClick={handleRevealContact}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white font-bold text-xs uppercase tracking-wider transition shadow-lg shadow-[#ff3358]/20 cursor-pointer"
                  >
                    Click to Reveal Mobile Number & WhatsApp Link
                  </button>
                </div>
              )}
            </div>

            {/* Contact Action Buttons (WhatsApp, Call, SMS) */}
            {revealed && (
              <div className="grid grid-cols-3 gap-2">
                <a
                  href={whatsappUrl || "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex flex-col items-center justify-center gap-1 transition shadow cursor-pointer text-center"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>WhatsApp</span>
                </a>

                <a
                  href={callUrl || "#"}
                  className="p-3 rounded-xl bg-[#1d2433] hover:bg-[#283246] text-white font-bold text-xs flex flex-col items-center justify-center gap-1 transition shadow cursor-pointer text-center"
                >
                  <PhoneCall className="w-5 h-5 text-amber-400" />
                  <span>Call Now</span>
                </a>

                <a
                  href={smsUrl || "#"}
                  className="p-3 rounded-xl bg-[#1d2433] hover:bg-[#283246] text-white font-bold text-xs flex flex-col items-center justify-center gap-1 transition shadow cursor-pointer text-center"
                >
                  <Phone className="w-5 h-5 text-purple-400" />
                  <span>SMS</span>
                </a>
              </div>
            )}

            {/* Services Offered list */}
            {target.servicesList && target.servicesList.length > 0 && (
              <div className="bg-[#0e1118] border border-[#212738] p-3.5 rounded-xl space-y-2">
                <h4 className="text-xs font-bold uppercase text-amber-400 tracking-wider">
                  Services Offered:
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {target.servicesList.map((s, i) => (
                    <span key={i} className="text-[11px] bg-[#171d2b] text-zinc-200 px-2.5 py-1 rounded-lg">
                      &bull; {s}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Rates in KSh */}
            {target.ratesList && target.ratesList.length > 0 && (
              <div className="bg-[#0e1118] border border-[#212738] p-3.5 rounded-xl space-y-2">
                <h4 className="text-xs font-bold uppercase text-white tracking-wider">
                  Rates & Pricing (KSh):
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  {target.ratesList.map((r, i) => (
                    <div key={i} className="bg-[#141822] p-2 rounded-lg flex items-center justify-between text-xs">
                      <span className="text-zinc-400">{r.duration}</span>
                      <strong className="text-amber-400">KSh {r.priceKsh.toLocaleString()}</strong>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: Book Appointment in KSh */}
        {activeTab === "book" && (
          <div>
            {bookingSuccess ? (
              <div className="py-6 text-center space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="text-base font-bold text-white">Booking Request Sent!</h4>
                <p className="text-xs text-zinc-300">{bookingSuccess}</p>
                <button
                  onClick={onClose}
                  className="mt-3 px-4 py-2 rounded-xl bg-[#ff3358] text-white text-xs font-bold"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleSendBooking} className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Select Desired Service
                  </label>
                  <select
                    value={selectedService}
                    onChange={(e) => setSelectedService(e.target.value)}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                  >
                    {(target.servicesList || ["Sensual Massage", "Companionship", "Overnight Stays"]).map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Duration & Rate</label>
                    <select
                      value={selectedDuration}
                      onChange={(e) => {
                        setSelectedDuration(e.target.value);
                        const match = target.ratesList?.find((r) => r.duration === e.target.value);
                        if (match) setPriceKsh(match.priceKsh);
                      }}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    >
                      {(target.ratesList || [{ duration: "1 Hour", priceKsh: 4000 }, { duration: "Overnight", priceKsh: 15000 }]).map((r) => (
                        <option key={r.duration} value={r.duration}>
                          {r.duration} - KSh {r.priceKsh.toLocaleString()}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Preferred Time / Date</label>
                    <input
                      type="text"
                      placeholder="e.g. Today 8 PM"
                      value={preferredDate}
                      onChange={(e) => setPreferredDate(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Your Contact Phone for Confirmation *
                  </label>
                  <input
                    type="text"
                    placeholder="+254 712 345678"
                    value={bookingPhone}
                    onChange={(e) => setBookingPhone(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Notes / Hotel Room / Preferences (Optional)
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Provide any specific location or preferences..."
                    value={clientNote}
                    onChange={(e) => setClientNote(e.target.value)}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
                  />
                </div>

                <div className="bg-[#161a25] p-3 rounded-xl flex items-center justify-between text-xs">
                  <span className="text-zinc-400">Total Rate (Payment on meet):</span>
                  <strong className="text-amber-400 font-black text-sm">KSh {priceKsh.toLocaleString()}</strong>
                </div>

                <button
                  type="submit"
                  disabled={submittingBooking}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
                >
                  {submittingBooking ? "Sending Request..." : `Request Appointment (KSh ${priceKsh.toLocaleString()})`}
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
