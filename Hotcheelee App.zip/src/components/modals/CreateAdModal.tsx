"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  Sparkles,
  Link as LinkIcon,
  DollarSign,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Eye,
  Coins,
  ShieldCheck,
} from "lucide-react";

interface CreateAdModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateAdModal({ isOpen, onClose }: CreateAdModalProps) {
  const { currentUser, refreshUser, openTokensModal } = useApp();
  const [brandName, setBrandName] = useState(currentUser?.displayName || "");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [mediaUrl, setMediaUrl] = useState("");
  const [ctaText, setCtaText] = useState("Book Appointment");
  const [targetUrl, setTargetUrl] = useState(`https://hotcheelee.com/profile/${currentUser?.username || "creator"}`);
  const [budgetKsh, setBudgetKsh] = useState("3000");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const sampleAdImages = [
    { label: "VIP Penthouse Suite", url: "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg" },
    { label: "Executive Parlour & Spa", url: "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg" },
    { label: "Glamour Satin & Lingerie", url: "https://images.pexels.com/photos/33282388/pexels-photo-33282388.jpeg" },
    { label: "Nightclub Vibe & Luxury", url: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg" },
  ];

  const budget = Number(budgetKsh) || 3000;
  const coinsRequired = Math.floor(budget / 10);
  const userCoins = currentUser?.tokensBalance || 0;
  const hasEnoughCoins = userCoins >= coinsRequired;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim() || !mediaUrl.trim()) {
      setError("Please fill in ad title, copy description, and banner image URL.");
      return;
    }

    if (!hasEnoughCoins) {
      openTokensModal();
      return;
    }

    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/sponsored", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          brandName,
          title,
          content,
          mediaUrl,
          mediaType: "image",
          ctaText,
          targetUrl,
          budgetKsh: budget,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create ad");

      setSuccess(data.message);
      await refreshUser();
      setTimeout(() => {
        onClose();
        window.location.reload();
      }, 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95 space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white p-1 shadow-lg shadow-[#ff3358]/20">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">Create Paid Sponsored Ad</h2>
            <p className="text-xs text-zinc-400">
              Paid with Coins from your wallet &bull; Moderated and approved by Admin
            </p>
          </div>
        </div>

        {/* Wallet Balance vs Required Cost */}
        <div className="bg-[#0e1118] border border-[#232938] p-3.5 rounded-xl flex items-center justify-between text-xs">
          <div>
            <span className="text-zinc-400 block">Your Wallet Balance:</span>
            <strong className="text-amber-400 font-black text-sm flex items-center gap-1">
              <Coins className="w-3.5 h-3.5" />
              {userCoins.toLocaleString()} Coins
            </strong>
          </div>

          <div className="text-right">
            <span className="text-zinc-400 block">Campaign Cost:</span>
            <strong className="text-white font-black text-sm">
              🪙 {coinsRequired} Coins (KSh {budget.toLocaleString()})
            </strong>
          </div>
        </div>

        {error && (
          <div className="p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 max-h-[55vh] overflow-y-auto pr-1">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Advertiser Brand *</label>
              <input
                type="text"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Campaign Headline *</label>
              <input
                type="text"
                placeholder="e.g. VIP Kilimani Penthouse Suite"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">Campaign Description *</label>
            <textarea
              rows={2}
              placeholder="Highlight services, rates, private rooms, sauna..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">Banner Image URL *</label>
            <input
              type="url"
              placeholder="https://images.pexels.com/...jpg"
              value={mediaUrl}
              onChange={(e) => setMediaUrl(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
            />
          </div>

          <div>
            <span className="text-[11px] text-zinc-400 block mb-1">Quick stock banner samples:</span>
            <div className="grid grid-cols-2 gap-1.5">
              {sampleAdImages.map((s) => (
                <button
                  key={s.label}
                  type="button"
                  onClick={() => setMediaUrl(s.url)}
                  className="p-1.5 rounded-lg bg-[#0e1118] hover:bg-[#1a202c] border border-[#252c3c] text-left text-[11px] text-zinc-300 truncate"
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Call To Action (CTA)</label>
              <select
                value={ctaText}
                onChange={(e) => setCtaText(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="Book Appointment">Book Appointment</option>
                <option value="Reveal Contact">Reveal Contact</option>
                <option value="Visit Parlour">Visit Parlour</option>
                <option value="WhatsApp Now">WhatsApp Now</option>
                <option value="Learn More">Learn More</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Campaign Budget (KSh)</label>
              <input
                type="number"
                min={500}
                step={500}
                value={budgetKsh}
                onChange={(e) => setBudgetKsh(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          {/* Dynamic Action Button */}
          {hasEnoughCoins ? (
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
            >
              {submitting ? "Submitting Campaign..." : `Pay 🪙 ${coinsRequired} Coins & Submit for Moderation`}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                onClose();
                openTokensModal();
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-[#ff3358] text-white font-bold text-xs shadow-md cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Need {coinsRequired} Coins &bull; Buy Coins First</span>
            </button>
          )}

          <div className="flex items-center justify-center gap-1 text-[11px] text-zinc-500 pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Admin moderates all ads before going live. Rejected ads are 100% refunded.</span>
          </div>
        </form>
      </div>
    </div>
  );
}
