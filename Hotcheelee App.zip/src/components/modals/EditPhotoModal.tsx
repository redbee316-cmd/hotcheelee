"use client";

import React, { useState } from "react";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  Camera,
  Check,
  Eye,
  Sparkles,
  Upload,
  AlertCircle,
} from "lucide-react";

interface EditPhotoModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: "avatar" | "cover";
  currentUrl?: string;
  onSave: (newUrl: string) => Promise<void>;
  title?: string;
}

export default function EditPhotoModal({
  isOpen,
  onClose,
  type,
  currentUrl,
  onSave,
  title,
}: EditPhotoModalProps) {
  const [photoUrl, setPhotoUrl] = useState(currentUrl || "");
  const [saving, setSaving] = useState(false);
  const [viewFull, setViewFull] = useState(false);

  if (!isOpen) return null;

  const stockPresets =
    type === "avatar"
      ? [
          { label: "Glamour Portrait 1", url: "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg" },
          { label: "Glamour Portrait 2", url: "https://images.pexels.com/photos/29271917/pexels-photo-29271917.jpeg" },
          { label: "Sensual Model 3", url: "https://images.pexels.com/photos/29057433/pexels-photo-29057433.jpeg" },
          { label: "Athletic Fitness 4", url: "https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg" },
          { label: "Alt Vibe 5", url: "https://images.pexels.com/photos/17509326/pexels-photo-17509326.jpeg" },
          { label: "Luxury Blonde 6", url: "https://images.pexels.com/photos/31130286/pexels-photo-31130286.jpeg" },
        ]
      : [
          { label: "Penthouse Suite", url: "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg" },
          { label: "Nightclub VIP", url: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg" },
          { label: "Satin Silk Bedroom", url: "https://images.pexels.com/photos/33282388/pexels-photo-33282388.jpeg" },
          { label: "Executive Lounge", url: "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg" },
          { label: "Neon Cyber Aesthetic", url: "https://images.pexels.com/photos/18570527/pexels-photo-18570527.jpeg" },
        ];

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoUrl.trim()) return;
    setSaving(true);
    try {
      await onSave(photoUrl.trim());
      onClose();
    } catch (e: any) {
      alert(e.message || "Failed to update photo");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95 space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white">
            <Camera className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-black text-white">
              {title || (type === "avatar" ? "Edit Profile Picture" : "Edit Cover Photo")}
            </h3>
            <p className="text-xs text-zinc-400">
              See profile picture, preview, and choose or upload a new photo
            </p>
          </div>
        </div>

        {/* Current / Selected Image Preview (See Profile Picture Mechanics) */}
        <div className="bg-[#0e1118] border border-[#212738] p-3 rounded-2xl text-center space-y-2">
          <div className="relative inline-block mx-auto group">
            {type === "avatar" ? (
              <img
                src={photoUrl || currentUrl || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                alt="Profile Preview"
                className="w-32 h-32 rounded-full object-cover ring-4 ring-[#ff3358]/50 shadow-xl mx-auto"
              />
            ) : (
              <img
                src={photoUrl || currentUrl || "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg"}
                alt="Cover Preview"
                className="w-full h-40 rounded-xl object-cover ring-2 ring-white/10 shadow-xl"
              />
            )}

            <button
              type="button"
              onClick={() => setViewFull(!viewFull)}
              className="absolute bottom-2 right-2 p-1.5 rounded-full bg-black/70 hover:bg-[#ff3358] text-white text-xs transition cursor-pointer shadow"
              title="See Full Profile Picture"
            >
              <Eye className="w-4 h-4" />
            </button>
          </div>
          <span className="text-[11px] text-zinc-400 block">Preview of chosen photo</span>
        </div>

        {viewFull && (
          <div
            className="fixed inset-0 z-60 bg-black/95 flex items-center justify-center p-4 cursor-pointer"
            onClick={() => setViewFull(false)}
          >
            <img
              src={photoUrl || currentUrl}
              alt="Full View"
              className="max-w-full max-h-[90vh] object-contain rounded-2xl shadow-2xl"
            />
          </div>
        )}

        {/* Choose or Input New Photo */}
        <form onSubmit={handleSave} className="space-y-3.5">
          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">
              Enter New Image URL (or pick from below)
            </label>
            <input
              type="url"
              placeholder="https://images.pexels.com/...jpg"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
            />
          </div>

          <div>
            <span className="text-[11px] font-bold text-zinc-400 block mb-1.5">
              Choose from HotCheelee Verified Stock Presets:
            </span>
            <div className="grid grid-cols-3 gap-2">
              {stockPresets.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => setPhotoUrl(p.url)}
                  className={`p-1.5 rounded-xl border text-left transition group ${
                    photoUrl === p.url ? "border-[#ff3358] bg-[#ff3358]/10" : "border-[#212738] bg-[#0e1118]"
                  }`}
                >
                  <img
                    src={p.url}
                    alt={p.label}
                    className="w-full h-14 object-cover rounded-lg mb-1"
                  />
                  <span className="text-[10px] font-bold text-zinc-300 group-hover:text-white truncate block">
                    {p.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white bg-[#191e2b]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving || !photoUrl}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
            >
              {saving ? "Saving..." : "Save Photo"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
