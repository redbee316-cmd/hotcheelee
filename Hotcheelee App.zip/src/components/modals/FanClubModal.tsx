"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { X, Crown, Check, Coins, ShieldCheck, Sparkles } from "lucide-react";

export default function FanClubModal() {
  const { fanClubTarget, closeFanClubModal, currentUser, refreshUser, openTokensModal } = useApp();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (fanClubTarget) {
      setLoading(true);
      fetch(`/api/fan-club?modelId=${fanClubTarget.modelId}`)
        .then((r) => r.json())
        .then((d) => setData(d))
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [fanClubTarget]);

  if (!fanClubTarget) return null;

  const cost = data?.fanClubPriceMonthly || 50;

  const handleJoin = async () => {
    if ((currentUser?.tokensBalance || 0) < cost) {
      alert(`You need ${cost} tokens to join ${fanClubTarget.modelName}'s VIP Fan Club.`);
      openTokensModal();
      return;
    }

    setSubscribing(true);
    try {
      const res = await fetch("/api/fan-club", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ modelId: fanClubTarget.modelId }),
      });
      const resData = await res.json();
      if (res.ok) {
        setNotice(resData.message);
        await refreshUser();
        fetch(`/api/fan-club?modelId=${fanClubTarget.modelId}`).then((r) => r.json()).then(setData);
      } else {
        alert(resData.error || "Failed to join Fan Club");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubscribing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative max-w-md w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={closeFanClubModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-5">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white shadow-lg shadow-[#ff3358]/25 mb-2">
            <Crown className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-black text-white">
            {fanClubTarget.modelName || "Performer"}'s VIP Fan Club
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Official Stripchat Fan Club membership with continuous monthly perks
          </p>
        </div>

        {notice && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
            {notice}
          </div>
        )}

        {/* Perks list from Stripchat */}
        <div className="bg-[#0e1118] border border-[#212738] rounded-xl p-4 mb-5 space-y-2.5">
          <h3 className="text-xs font-black uppercase text-amber-400 tracking-wider mb-2">
            Fan Club Member Benefits:
          </h3>
          {(data?.perks || [
            "10% off entire performer tip menu actions",
            "Exclusive access to Fan-Club only photos & 4K clips",
            "Direct offline messaging priority with Star badge",
            "Special highlighted chat name & VIP badge",
          ]).map((perk: string, i: number) => (
            <div key={i} className="flex items-start gap-2 text-xs text-zinc-300">
              <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{perk}</span>
            </div>
          ))}
        </div>

        {/* Status card */}
        <div className="flex items-center justify-between bg-[#161a25] border border-[#2a3347] rounded-xl p-3.5 mb-5 text-xs">
          <div>
            <span className="text-zinc-400 block text-[11px]">Monthly Membership</span>
            <span className="text-base font-black text-white">{cost} Tokens / Month</span>
          </div>

          <div>
            {data?.isMember ? (
              <span className="bg-emerald-500/20 text-emerald-400 font-bold px-3 py-1 rounded-full text-xs">
                Active Member ✓
              </span>
            ) : (
              <span className="text-zinc-500 text-[11px]">{data?.totalClubMembers || 12} members joined</span>
            )}
          </div>
        </div>

        <button
          disabled={subscribing || data?.isMember}
          onClick={handleJoin}
          className={`w-full py-3 rounded-xl font-black text-xs uppercase tracking-wider transition shadow-lg shadow-[#ff3358]/25 cursor-pointer ${
            data?.isMember
              ? "bg-[#1d2332] text-zinc-400 cursor-default"
              : "bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white"
          }`}
        >
          {data?.isMember ? "You are a VIP Member" : subscribing ? "Joining..." : `Subscribe for ${cost} Tokens`}
        </button>
      </div>
    </div>
  );
}
