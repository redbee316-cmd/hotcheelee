"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { X, Sparkles, Check, Zap, Coins, Flame, Award, ShieldCheck } from "lucide-react";

export default function TipMenuModal() {
  const { tipMenuTarget, closeTipMenuModal, currentUser, refreshUser, openTokensModal } = useApp();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasDiscount, setHasDiscount] = useState(false);
  const [executingId, setExecutingId] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (tipMenuTarget) {
      setLoading(true);
      fetch(`/api/tip-menu?modelId=${tipMenuTarget.modelId}`)
        .then((r) => r.json())
        .then((d) => {
          setItems(d.items || []);
          setHasDiscount(Boolean(d.hasFanClubDiscount));
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [tipMenuTarget]);

  if (!tipMenuTarget) return null;

  const handleExecute = async (action: any) => {
    setExecutingId(action.id);
    try {
      const res = await fetch("/api/tip-menu", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ actionId: action.id }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(data.message);
        await refreshUser();
        setTimeout(() => setNotice(null), 3500);
      } else {
        alert(data.error || "Action failed");
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setExecutingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={closeTipMenuModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center justify-between mb-4 pr-6">
          <div>
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#ff3358]" />
              {tipMenuTarget.modelName || "Performer"}'s Tip Menu
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Choose an action for the model to execute. Vibrates interactive toys & grants XP!
            </p>
          </div>
        </div>

        {/* Fan Club 10% Discount Banner from Stripchat */}
        <div className="bg-[#181d28] border border-[#2d3648] rounded-xl p-3 mb-4 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-zinc-300">
              Your Tokens: <strong className="text-white">{currentUser?.tokensBalance || 0} tk</strong>
            </span>
          </div>

          {hasDiscount ? (
            <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded text-[11px]">
              ✓ 10% Fan Club Discount Active
            </span>
          ) : (
            <button
              onClick={openTokensModal}
              className="text-[#ff3358] font-bold hover:underline cursor-pointer"
            >
              Get More Tokens +
            </button>
          )}
        </div>

        {notice && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
            <span>{notice}</span>
            <button onClick={() => setNotice(null)}>✕</button>
          </div>
        )}

        {/* Tip Menu Action Items */}
        {loading ? (
          <div className="py-8 text-center text-xs text-zinc-500">Loading tip menu...</div>
        ) : items.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500">No actions listed for this model.</div>
        ) : (
          <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
            {items.map((item) => {
              const discounted = hasDiscount ? Math.max(1, Math.round(item.tokensCost * 0.9)) : item.tokensCost;
              return (
                <div
                  key={item.id}
                  className="bg-[#0e1118] border border-[#212738] hover:border-[#ff3358]/60 p-3.5 rounded-xl flex items-center justify-between gap-3 transition group"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white group-hover:text-[#ff3358] transition truncate">
                        {item.actionName}
                      </span>
                      {item.toyIntensity > 0 && (
                        <span className="text-[10px] bg-[#ff3358]/20 text-[#ff3358] border border-[#ff3358]/30 px-1.5 py-0.2 rounded font-black uppercase">
                          Vibe Lvl {item.toyIntensity}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-zinc-400 mt-0.5 truncate">
                      {item.description || `${item.durationSeconds}s duration`}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <div className="text-right">
                      <span className="text-xs font-black text-amber-400 block">
                        {discounted} tk
                      </span>
                      {hasDiscount && (
                        <span className="text-[10px] line-through text-zinc-600 block">
                          {item.tokensCost} tk
                        </span>
                      )}
                    </div>

                    <button
                      disabled={executingId === item.id}
                      onClick={() => handleExecute(item)}
                      className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white text-xs font-bold transition shadow-sm cursor-pointer disabled:opacity-50"
                    >
                      {executingId === item.id ? "Sending..." : "Tip Action"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-4 pt-3 border-t border-[#1e2330] flex items-center justify-between text-[11px] text-zinc-500">
          <span>Tip menu actions notify the performer in real-time</span>
          <button onClick={openTokensModal} className="text-amber-400 font-bold hover:underline">
            Buy Tokens
          </button>
        </div>
      </div>
    </div>
  );
}
