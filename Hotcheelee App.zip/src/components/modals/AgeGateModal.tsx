"use client";

import React from "react";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import { ShieldAlert, Check } from "lucide-react";

export default function AgeGateModal() {
  const { ageVerified, verifyAge } = useApp();

  if (ageVerified) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="max-w-md w-full bg-[#151922] border border-[#262c3b] rounded-2xl p-6 sm:p-8 shadow-2xl text-center animate-in fade-in zoom-in-95 duration-200">
        <div className="mx-auto w-16 h-16 rounded-2xl bg-[#141722] border-2 border-[#ff3358] flex items-center justify-center mb-5 shadow-lg shadow-[#ff3358]/20 p-2">
          <HotCheeleeLogo size={36} />
        </div>

        <h2 className="text-2xl font-black tracking-tight text-white mb-2">
          Welcome to <span className="text-[#ff3358]">HotCheelee</span>
        </h2>

        <p className="text-xs uppercase font-bold tracking-widest text-amber-500 mb-3 flex items-center justify-center gap-1.5">
          <ShieldAlert className="w-4 h-4" />
          Adult Social & Stripchat Tokens (18+)
        </p>

        <p className="text-xs text-zinc-300 leading-relaxed mb-5">
          HotCheelee connects you with verified Straight, Gay, Transgender, Shemale & Queer companions, plus massage parlours and lodgings in Kenya. M-Pesa Buy Goods Till: <strong>8923411</strong>.
        </p>

        <div className="bg-[#0e1117] border border-[#232938] rounded-xl p-3.5 text-xs text-zinc-400 text-left mb-6 space-y-1.5">
          <div className="flex items-start gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>I am at least 18 years old or legal age of majority.</span>
          </div>
          <div className="flex items-start gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>All performers depicted are consenting adults 18+ (18 U.S.C. § 2257).</span>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button
            onClick={verifyAge}
            className="w-full py-3.5 px-6 rounded-xl font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] transition shadow-lg shadow-[#ff3358]/25 cursor-pointer flex items-center justify-center gap-2"
          >
            <span>I am 18 or Older &mdash; Enter HotCheelee</span>
          </button>

          <a
            href="https://google.com"
            className="text-xs text-zinc-500 hover:text-zinc-300 py-1 transition"
          >
            I am under 18 &mdash; Exit
          </a>
        </div>
      </div>
    </div>
  );
}
