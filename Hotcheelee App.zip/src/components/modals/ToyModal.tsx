"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { X, Sparkles, Coins, Zap, ShieldCheck, HeartHandshake } from "lucide-react";

export default function ToyModal() {
  const { toyTarget, closeToyModal, currentUser, refreshUser, openTokensModal } = useApp();
  const [intensity, setIntensity] = useState<number>(10);
  const [duration, setDuration] = useState<number>(15);
  const [tokens, setTokens] = useState<number>(20);
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [recentTriggers, setRecentTriggers] = useState<any[]>([]);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (toyTarget) {
      fetch(`/api/toy-control?modelId=${toyTarget.modelId}`)
        .then((r) => r.json())
        .then((d) => setRecentTriggers(d.triggers || []))
        .catch(console.error);
    }
  }, [toyTarget]);

  if (!toyTarget) return null;

  const presets = [
    { label: "Gentle Pulse", tokens: 10, intensity: 5, duration: 10 },
    { label: "Medium Buzz", tokens: 25, intensity: 12, duration: 15 },
    { label: "Intense Shockwave", tokens: 50, intensity: 18, duration: 25 },
    { label: "Max Earthquake 🔥", tokens: 100, intensity: 20, duration: 40 },
  ];

  const handleSendTrigger = async () => {
    if ((currentUser?.tokensBalance || 0) < tokens) {
      alert(`You need ${tokens} tokens to buzz this toy. You have ${currentUser?.tokensBalance || 0} tokens.`);
      openTokensModal();
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/toy-control", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          modelId: toyTarget.modelId,
          intensity,
          durationSeconds: duration,
          tokensTipped: tokens,
          message: message.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(data.message);
        await refreshUser();
        setTimeout(() => setNotice(null), 3500);
      } else {
        alert(data.error || "Failed to trigger toy");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={closeToyModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white shadow-lg shadow-[#ff3358]/20">
            <Zap className="w-6 h-6 fill-white" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              Interactive Toy Control &bull; Lovense Lush 3
            </h2>
            <p className="text-xs text-zinc-400">
              Direct tactile vibrations triggered via token tips to {toyTarget.modelName || "Model"}
            </p>
          </div>
        </div>

        {notice && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
            {notice}
          </div>
        )}

        {/* Preset Vibrations from Stripchat */}
        <div className="grid grid-cols-2 gap-2.5 mb-4">
          {presets.map((p) => (
            <button
              key={p.label}
              onClick={() => {
                setTokens(p.tokens);
                setIntensity(p.intensity);
                setDuration(p.duration);
              }}
              className={`p-3 rounded-xl border text-left transition ${
                tokens === p.tokens && intensity === p.intensity
                  ? "border-[#ff3358] bg-[#ff3358]/10 text-white"
                  : "border-[#212738] bg-[#0e1118] text-zinc-300 hover:border-zinc-700"
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold">{p.label}</span>
                <span className="text-xs font-black text-amber-400">{p.tokens} tk</span>
              </div>
              <span className="text-[10px] text-zinc-400 block">
                Level {p.intensity} &bull; {p.duration}s vibration
              </span>
            </button>
          ))}
        </div>

        {/* Custom Intensity Slider */}
        <div className="bg-[#0e1118] border border-[#212738] rounded-xl p-4 mb-4 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-300 font-bold">Vibration Intensity: Level {intensity}/20</span>
            <span className="text-amber-400 font-black">{tokens} Tokens</span>
          </div>
          <input
            type="range"
            min={1}
            max={20}
            value={intensity}
            onChange={(e) => {
              const val = Number(e.target.value);
              setIntensity(val);
              setTokens(Math.max(5, val * 3));
            }}
            className="w-full accent-[#ff3358] cursor-pointer"
          />

          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-zinc-400">Duration: {duration} seconds</span>
            <input
              type="range"
              min={5}
              max={60}
              step={5}
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-1/2 accent-amber-400 cursor-pointer"
            />
          </div>
        </div>

        {/* Message */}
        <div className="mb-4">
          <input
            type="text"
            placeholder="Add an affectionate message with this buzz... (optional)"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full bg-[#0e1118] border border-[#232938] rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
          />
        </div>

        <button
          disabled={submitting}
          onClick={handleSendTrigger}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white font-black text-xs uppercase tracking-wider transition shadow-lg shadow-[#ff3358]/25 cursor-pointer disabled:opacity-50"
        >
          {submitting ? "Vibrating Toy..." : `Send ${tokens} Tokens & Vibrate Toy (Lvl ${intensity})`}
        </button>
      </div>
    </div>
  );
}
