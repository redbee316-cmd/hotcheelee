"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  Plus,
  Video,
  Image as ImageIcon,
  Clock,
  Sparkles,
  Upload,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

interface CreateStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateStoryModal({ isOpen, onClose }: CreateStoryModalProps) {
  const { currentUser, refreshUser, openUpgradeModal } = useApp();
  const [mediaUrl, setMediaUrl] = useState("");
  const [mediaType, setMediaType] = useState<"image" | "video">("image");
  const [durationSeconds, setDurationSeconds] = useState(15);
  const [caption, setCaption] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const samplePresets = [
    { label: "Boudoir Photo", url: "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg", type: "image" as const, sec: 15 },
    { label: "Nightlife Glamour", url: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg", type: "image" as const, sec: 15 },
    { label: "Sensual Dance Video (10s)", url: "https://videos.pexels.com/video-files/7845993/7845993-hd_1080_1920_30fps.mp4", type: "video" as const, sec: 10 },
    { label: "Workout Tease Video (16s)", url: "https://videos.pexels.com/video-files/8039133/8039133-uhd_2160_4096_25fps.mp4", type: "video" as const, sec: 16 },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaUrl.trim()) {
      setError("Please provide a media URL or select a preset.");
      return;
    }

    if (durationSeconds > 60) {
      setError("Story duration cannot exceed 60 seconds.");
      return;
    }

    // Free browsing check
    if (currentUser?.accountType === "browsing") {
      onClose();
      openUpgradeModal("creator");
      return;
    }

    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/stories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mediaUrl: mediaUrl.trim(),
          mediaType,
          durationSeconds,
          caption: caption.trim() || null,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to post story");

      setSuccess(data.message);
      await refreshUser();
      setTimeout(() => {
        onClose();
        window.location.reload();
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white p-1">
            <Plus className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">Create 24h Story</h2>
            <p className="text-xs text-zinc-400">
              Post photo or video story. Auto-expires after 24h &bull; <strong className="text-amber-400">Max 60 seconds</strong>
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Media Type Picker */}
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-zinc-300">Select Media Type:</span>
            <div className="flex items-center gap-1 bg-[#1a1f2b] p-0.5 rounded-lg border border-[#2a3142]">
              <button
                type="button"
                onClick={() => setMediaType("image")}
                className={`px-3 py-1 rounded text-xs font-bold ${
                  mediaType === "image" ? "bg-[#ff3358] text-white" : "text-zinc-400 hover:text-white"
                }`}
              >
                Photo
              </button>
              <button
                type="button"
                onClick={() => setMediaType("video")}
                className={`px-3 py-1 rounded text-xs font-bold ${
                  mediaType === "video" ? "bg-[#ff3358] text-white" : "text-zinc-400 hover:text-white"
                }`}
              >
                Video (Max 60s)
              </button>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">
              Story Media URL (Photo or Video) *
            </label>
            <input
              type="url"
              placeholder={mediaType === "video" ? "https://videos.pexels.com/...mp4" : "https://images.pexels.com/...jpg"}
              value={mediaUrl}
              onChange={(e) => setMediaUrl(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
            />
          </div>

          {/* Quick Preset Buttons */}
          <div>
            <span className="text-[11px] text-zinc-400 block mb-1.5">Or pick sample story preset:</span>
            <div className="grid grid-cols-2 gap-2">
              {samplePresets.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => {
                    setMediaUrl(p.url);
                    setMediaType(p.type);
                    setDurationSeconds(p.sec);
                  }}
                  className="p-2 rounded-xl bg-[#0e1118] hover:bg-[#181d28] border border-[#232938] text-left text-xs text-zinc-300"
                >
                  <span className="font-bold block text-white">{p.label}</span>
                  <span className="text-[10px] text-zinc-500">{p.type} &bull; {p.sec}s</span>
                </button>
              ))}
            </div>
          </div>

          {/* Duration Slider (Strictly max 60s) */}
          <div className="bg-[#0e1118] border border-[#212738] p-3 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-300 font-bold flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                Duration: {durationSeconds} seconds
              </span>
              <span className="text-[10px] font-black uppercase text-amber-400">Max 60s Enforced</span>
            </div>
            <input
              type="range"
              min={5}
              max={60}
              step={5}
              value={durationSeconds}
              onChange={(e) => setDurationSeconds(Number(e.target.value))}
              className="w-full accent-[#ff3358] cursor-pointer"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">Caption Overlay (Optional)</label>
            <input
              type="text"
              placeholder="e.g. Behind the scenes in Kilimani penthouse 🥂"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
          >
            {submitting ? "Uploading Story..." : `Post Story (${durationSeconds}s max &bull; Live 24h)`}
          </button>
        </form>
      </div>
    </div>
  );
}
