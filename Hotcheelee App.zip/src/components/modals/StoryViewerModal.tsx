"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { X, ChevronLeft, ChevronRight, Flame, Heart, Send, CheckCircle2 } from "lucide-react";

export default function StoryViewerModal() {
  const { activeStoryGroup, activeStoryIndex, closeStoryViewer, openTipModal } = useApp();
  const [currentGroupIdx, setCurrentGroupIdx] = useState(0);
  const [currentStoryIdx, setCurrentStoryIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [flamed, setFlamed] = useState(false);
  const [replyText, setReplyText] = useState("");
  const [replySent, setReplySent] = useState(false);

  useEffect(() => {
    if (activeStoryGroup && activeStoryGroup.length > 0) {
      setCurrentGroupIdx(activeStoryIndex || 0);
      setCurrentStoryIdx(0);
      setProgress(0);
    }
  }, [activeStoryGroup, activeStoryIndex]);

  useEffect(() => {
    if (!activeStoryGroup || isPaused) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNextStory();
          return 0;
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [activeStoryGroup, currentGroupIdx, currentStoryIdx, isPaused]);

  if (!activeStoryGroup || activeStoryGroup.length === 0) return null;

  const currentGroup = activeStoryGroup[currentGroupIdx];
  if (!currentGroup) return null;

  const stories = currentGroup.stories || [];
  const activeStory = stories[currentStoryIdx];
  const user = currentGroup.user;

  const handleNextStory = () => {
    setProgress(0);
    if (currentStoryIdx < stories.length - 1) {
      setCurrentStoryIdx((c) => c + 1);
    } else if (currentGroupIdx < activeStoryGroup.length - 1) {
      setCurrentGroupIdx((g) => g + 1);
      setCurrentStoryIdx(0);
    } else {
      closeStoryViewer();
    }
  };

  const handlePrevStory = () => {
    setProgress(0);
    if (currentStoryIdx > 0) {
      setCurrentStoryIdx((c) => c - 1);
    } else if (currentGroupIdx > 0) {
      setCurrentGroupIdx((g) => g - 1);
      const prevStories = activeStoryGroup[currentGroupIdx - 1]?.stories || [];
      setCurrentStoryIdx(Math.max(0, prevStories.length - 1));
    }
  };

  const handleSendReply = async () => {
    if (!replyText.trim()) return;
    try {
      await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          receiverId: user.id,
          content: `Replying to your story: "${replyText.trim()}"`,
        }),
      });
      setReplySent(true);
      setReplyText("");
      setTimeout(() => setReplySent(false), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md select-none"
      onMouseDown={() => setIsPaused(true)}
      onMouseUp={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      {/* Top Close button */}
      <button
        onClick={closeStoryViewer}
        className="absolute top-5 right-5 z-50 text-white/80 hover:text-white p-2 rounded-full bg-black/40 backdrop-blur-md transition cursor-pointer"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Navigation arrows */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          handlePrevStory();
        }}
        className="absolute left-4 md:left-12 top-1/2 -translate-y-1/2 z-40 text-white/70 hover:text-white p-3 rounded-full bg-black/40 backdrop-blur-md transition hover:scale-110 hidden sm:flex cursor-pointer"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={(e) => {
          e.stopPropagation();
          handleNextStory();
        }}
        className="absolute right-4 md:right-12 top-1/2 -translate-y-1/2 z-40 text-white/70 hover:text-white p-3 rounded-full bg-black/40 backdrop-blur-md transition hover:scale-110 hidden sm:flex cursor-pointer"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Main Story Container */}
      <div className="relative w-full max-w-sm h-full max-h-[85vh] bg-[#0c0e12] rounded-2xl overflow-hidden shadow-2xl flex flex-col justify-between border border-[#232838]">
        {/* Story Progress Indicators */}
        <div className="absolute top-3 inset-x-3 z-30 flex items-center gap-1.5">
          {stories.map((_: any, idx: number) => {
            const isCompleted = idx < currentStoryIdx;
            const isCurrent = idx === currentStoryIdx;
            return (
              <div
                key={idx}
                className="h-1 flex-1 bg-white/25 rounded-full overflow-hidden"
              >
                <div
                  className={`h-full bg-white transition-all duration-100 ${
                    isCompleted ? "w-full" : isCurrent ? "" : "w-0"
                  }`}
                  style={{ width: isCurrent ? `${progress}%` : undefined }}
                />
              </div>
            );
          })}
        </div>

        {/* User Info Header */}
        <div className="absolute top-7 inset-x-3 z-30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <img
              src={user.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
              alt={user.displayName}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-[#ff3358]"
            />
            <div>
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-white drop-shadow">
                  {user.displayName}
                </span>
                <span className="text-[10px] bg-[#ff3358] text-white px-1.5 py-0.2 rounded font-black">
                  STAR
                </span>
              </div>
              <span className="text-[10px] text-zinc-300 drop-shadow block">
                @{user.username} &bull; 24h Story
              </span>
            </div>
          </div>

          <button
            onClick={() => openTipModal({ id: user.id, username: user.username, displayName: user.displayName, avatar: user.avatar })}
            className="px-2.5 py-1 rounded-full bg-gradient-to-r from-[#ff3358] to-[#ff7700] text-[11px] font-bold text-white flex items-center gap-1 shadow-md cursor-pointer hover:scale-105 transition"
          >
            <Flame className="w-3.5 h-3.5 fill-white" />
            <span>Tip</span>
          </button>
        </div>

        {/* Media content */}
        <div className="relative w-full h-full flex items-center justify-center bg-black">
          {activeStory ? (
            activeStory.mediaType === "video" ? (
              <video
                src={activeStory.mediaUrl}
                autoPlay
                playsInline
                loop
                className="w-full h-full object-cover"
              />
            ) : (
              <img
                src={activeStory.mediaUrl}
                alt="Story"
                className="w-full h-full object-cover"
              />
            )
          ) : (
            <div className="text-zinc-500 text-xs">No media</div>
          )}

          {/* Click areas for tap forward/back on mobile */}
          <div
            className="absolute inset-y-0 left-0 w-1/3 z-20 cursor-pointer"
            onClick={handlePrevStory}
          />
          <div
            className="absolute inset-y-0 right-0 w-2/3 z-20 cursor-pointer"
            onClick={handleNextStory}
          />

          {/* Caption overlay if present */}
          {activeStory?.caption && (
            <div className="absolute bottom-20 inset-x-4 z-30 bg-black/60 backdrop-blur-md p-3 rounded-xl text-center border border-white/10">
              <p className="text-xs text-white font-medium">{activeStory.caption}</p>
            </div>
          )}
        </div>

        {/* Story Bottom Actions Bar */}
        <div className="absolute bottom-3 inset-x-3 z-30 flex items-center gap-2">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder={replySent ? "Reply sent! ✨" : "Send direct message..."}
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendReply()}
              className="w-full bg-black/60 backdrop-blur-md border border-white/20 rounded-full px-4 py-2 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-[#ff3358]"
            />
            {replyText && (
              <button
                onClick={handleSendReply}
                className="absolute right-2 top-1.5 p-1 text-white hover:text-[#ff3358] transition"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            onClick={() => setFlamed(!flamed)}
            className={`p-2.5 rounded-full backdrop-blur-md border transition cursor-pointer ${
              flamed
                ? "bg-[#ff3358] text-white border-[#ff3358] scale-110 shadow-lg shadow-[#ff3358]/50"
                : "bg-black/60 text-white/90 border-white/20 hover:text-[#ff3358]"
            }`}
          >
            <Flame className={`w-4 h-4 ${flamed ? "fill-white" : ""}`} />
          </button>
        </div>
      </div>
    </div>
  );
}
