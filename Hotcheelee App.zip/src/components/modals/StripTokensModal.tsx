"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { X, Coins, ShieldCheck, CheckCircle2, Phone } from "lucide-react";

export default function StripTokensModal() {
  const { isTokensOpen, closeTokensModal, currentUser, refreshUser } = useApp();
  const [buyingCount, setBuyingCount] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  if (!isTokensOpen) return null;

  const packages = [
    { tokens: 45, priceKsh: 450, badge: "Starter" },
    { tokens: 90, priceKsh: 850, badge: "Basic" },
    { tokens: 200, priceKsh: 1800, badge: "Most Popular", popular: true },
    { tokens: 540, priceKsh: 4500, badge: "+7 Days Ultimate" },
    { tokens: 765, priceKsh: 6200, badge: "Silver Fan" },
    { tokens: 1350, priceKsh: 10500, badge: "Gold Fan" },
    { tokens: 2350, priceKsh: 18000, badge: "High Roller VIP" },
  ];

  const handlePurchase = async (pkg: typeof packages[0]) => {
    setBuyingCount(pkg.tokens);
    try {
      const res = await fetch("/api/strip-tokens", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tokenCount: pkg.tokens, paymentMethod: "M-Pesa Buy Goods Till 8923411" }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(`Added ${pkg.tokens} Tokens to your HotCheelee account! Level updated to ${data.userLevel}.`);
        await refreshUser();
        setTimeout(() => setNotice(null), 3500);
      } else {
        alert(data.error || "Purchase failed");
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setBuyingCount(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={closeTokensModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white shadow-lg shadow-[#ff3358]/20">
            <Coins className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">Buy HotCheelee Tokens (KSh)</h2>
            <p className="text-xs text-zinc-400">
              Tokens for tip menus, interactive Lovense toys, wheel spins & VIP fan clubs
            </p>
          </div>
        </div>

        {/* User Current Level & Token Balance */}
        <div className="bg-[#0e1118] border border-[#212738] rounded-xl p-3.5 mb-5 flex items-center justify-between">
          <div>
            <span className="text-[11px] text-zinc-400 block">Available Balance</span>
            <div className="text-xl font-black text-amber-400 flex items-center gap-1.5">
              <Coins className="w-5 h-5" />
              <span>{currentUser?.tokensBalance || 0} Tokens</span>
            </div>
            <span className="text-[10px] text-zinc-500">≈ KSh {((currentUser?.tokensBalance || 0) * 10).toLocaleString()}</span>
          </div>

          <div className="text-right">
            <span className="text-[11px] text-zinc-400 block">Status Tier</span>
            <span className="text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] px-2.5 py-0.5 rounded-full">
              Level {currentUser?.userLevel || 1} &bull; {currentUser?.vipTier || "Diamond"}
            </span>
          </div>
        </div>

        {notice && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
            {notice}
          </div>
        )}

        {/* Packages Grid in KSh */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-5">
          {packages.map((pkg) => (
            <div
              key={pkg.tokens}
              className={`bg-[#0e1118] border p-3 rounded-xl flex flex-col justify-between transition ${
                pkg.popular
                  ? "border-[#ff3358] ring-1 ring-[#ff3358]/40"
                  : "border-[#212738] hover:border-zinc-700"
              }`}
            >
              <div>
                <span className="text-[10px] font-black uppercase text-amber-400 block mb-1">
                  {pkg.badge}
                </span>
                <span className="text-lg font-black text-white block">
                  {pkg.tokens} tk
                </span>
                <span className="text-xs font-bold text-emerald-400 block mb-2">
                  KSh {pkg.priceKsh.toLocaleString()}
                </span>
              </div>

              <button
                disabled={buyingCount === pkg.tokens}
                onClick={() => handlePurchase(pkg)}
                className={`w-full py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  pkg.popular
                    ? "bg-[#ff3358] hover:bg-[#e11d48] text-white"
                    : "bg-[#1c2230] hover:bg-[#273044] text-zinc-200"
                }`}
              >
                {buyingCount === pkg.tokens ? "Processing..." : "Buy (M-Pesa)"}
              </button>
            </div>
          ))}
        </div>

        <div className="border-t border-[#1e2330] pt-3 flex items-center justify-between text-[11px] text-zinc-400">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            M-Pesa Buy Goods Till: <strong className="text-white">8923411</strong>
          </span>
          <span className="text-amber-400 font-bold">1 Token = 10 KSh</span>
        </div>
      </div>
    </div>
  );
}
