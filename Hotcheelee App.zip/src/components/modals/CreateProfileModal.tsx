"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  UserPlus,
  Star,
  Building2,
  Users,
  Check,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

interface CreateProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateProfileModal({ isOpen, onClose }: CreateProfileModalProps) {
  const { refreshUser } = useApp();
  const [accountType, setAccountType] = useState<"browsing" | "creator" | "agency">("browsing");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [genderRole, setGenderRole] = useState("straight");
  const [agencyType, setAgencyType] = useState("Massage Parlour");
  const [location, setLocation] = useState("Nairobi");
  const [locationArea, setLocationArea] = useState("Kilimani");
  const [phone, setPhone] = useState("+254 7");
  const [serviceType, setServiceType] = useState("Both Incall & Outcall");
  const [mpesaCode, setMpesaCode] = useState("");
  const [bio, setBio] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const costKsh = accountType === "agency" ? 1500 : accountType === "creator" ? 500 : 0;

  const handleCreateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !displayName.trim()) {
      setError("Please provide username and profile display name");
      return;
    }

    if (accountType !== "browsing" && !mpesaCode.trim()) {
      setError("Please provide M-Pesa transaction code for your 30-day subscription");
      return;
    }

    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/profiles/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          displayName,
          accountType,
          genderRole: accountType === "creator" ? genderRole : null,
          agencyType: accountType === "agency" ? agencyType : null,
          location,
          locationArea,
          phone,
          serviceType,
          mpesaCode: mpesaCode.trim().toUpperCase(),
          bio,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Profile creation failed");

      setSuccess(data.message);
      await refreshUser();
      setTimeout(() => {
        onClose();
        window.location.reload();
      }, 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-4">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white mb-2 p-1">
            <UserPlus className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-black text-white">Create a New Profile</h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Users can have more than 5 profiles on HotCheelee. Create a Free Browsing profile, a Creator profile, or an Agency profile.
          </p>
        </div>

        {/* Profile Mode Tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#0e1118] border border-[#212738] rounded-xl mb-4 text-xs font-bold text-center">
          <button
            type="button"
            onClick={() => setAccountType("browsing")}
            className={`py-2 rounded-lg transition ${
              accountType === "browsing" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            Free (Browse)
          </button>
          <button
            type="button"
            onClick={() => setAccountType("creator")}
            className={`py-2 rounded-lg transition ${
              accountType === "creator" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            Creator (KSh 500)
          </button>
          <button
            type="button"
            onClick={() => setAccountType("agency")}
            className={`py-2 rounded-lg transition ${
              accountType === "agency" ? "bg-amber-400 text-black shadow font-black" : "text-zinc-400 hover:text-white"
            }`}
          >
            Agency (KSh 1,500)
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
            {success}
          </div>
        )}

        <form onSubmit={handleCreateProfile} className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Username *</label>
              <input
                type="text"
                placeholder="e.g. sasha_nairobi"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Display Name *</label>
              <input
                type="text"
                placeholder="e.g. Sasha VIP"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          {accountType === "creator" && (
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Category / Orientation *</label>
              <select
                value={genderRole}
                onChange={(e) => setGenderRole(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="straight">Straight Model</option>
                <option value="gay">Gay Performer</option>
                <option value="transgender">Transgender</option>
                <option value="shemale">Shemale (TS)</option>
                <option value="queer">Queer / Non-Binary</option>
              </select>
            </div>
          )}

          {accountType === "agency" && (
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Agency Type *</label>
              <select
                value={agencyType}
                onChange={(e) => setAgencyType(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="Massage Parlour">Massage Parlour</option>
                <option value="Lodging">Lodging & Rooms</option>
                <option value="Brothel">Brothel / Club</option>
                <option value="Agency">Escort Agency</option>
              </select>
            </div>
          )}

          {accountType !== "browsing" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">Area / Location *</label>
                  <input
                    type="text"
                    placeholder="Kilimani, Westlands, Nyali"
                    value={locationArea}
                    onChange={(e) => setLocationArea(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">Mobile Contact *</label>
                  <input
                    type="text"
                    placeholder="+254 722 000000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-amber-400 block mb-1">
                  M-Pesa Code (Send KSh {costKsh} to Till: 8923411) *
                </label>
                <input
                  type="text"
                  placeholder="e.g. SHB492X1KL"
                  value={mpesaCode}
                  onChange={(e) => setMpesaCode(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-amber-400/50 rounded-xl px-3.5 py-2 text-xs text-white font-mono uppercase"
                />
              </div>
            </>
          )}

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">Short Bio</label>
            <textarea
              rows={2}
              placeholder="Tell fans what you offer..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
          >
            {submitting ? "Creating Profile..." : `Create Profile ${costKsh > 0 ? `(KSh ${costKsh})` : "(Free)"}`}
          </button>
        </form>
      </div>
    </div>
  );
}
