"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  Crown,
  Check,
  Star,
  Building2,
  Sparkles,
  Phone,
  ShieldCheck,
  AlertCircle,
  Upload,
} from "lucide-react";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: "creator" | "agency";
}

export default function UpgradeModal({ isOpen, onClose, initialMode = "creator" }: UpgradeModalProps) {
  const { currentUser, refreshUser } = useApp();
  const [targetMode, setTargetMode] = useState<"creator" | "agency">(initialMode);
  const [genderRole, setGenderRole] = useState(currentUser?.genderRole || "straight");
  const [agencyType, setAgencyType] = useState(currentUser?.agencyType || "Massage Parlour");
  const [location, setLocation] = useState(currentUser?.location || "Nairobi");
  const [locationArea, setLocationArea] = useState(currentUser?.locationArea || "Kilimani");
  const [phone, setPhone] = useState(currentUser?.phone || "+254 7");
  const [serviceType, setServiceType] = useState(currentUser?.serviceType || "Both Incall & Outcall");
  const [allowWhatsapp, setAllowWhatsapp] = useState(true);
  const [allowCalls, setAllowCalls] = useState(true);
  const [allowSms, setAllowSms] = useState(true);
  const [mpesaCode, setMpesaCode] = useState("");
  const [advertMediaUrl, setAdvertMediaUrl] = useState(currentUser?.advertMediaUrl || "");
  const [advertMediaType, setAdvertMediaType] = useState<"image" | "video">("image");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const costKsh = targetMode === "agency" ? 1500 : 500;

  const handleUpgrade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mpesaCode.trim()) {
      setError("Please enter the M-Pesa transaction code received via SMS");
      return;
    }

    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/upgrade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetMode,
          genderRole,
          agencyType: targetMode === "agency" ? agencyType : null,
          location,
          locationArea,
          phone,
          allowWhatsapp,
          allowCalls,
          allowSms,
          serviceType,
          mpesaCode: mpesaCode.trim().toUpperCase(),
          advertMediaUrl: advertMediaUrl || null,
          advertMediaType,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upgrade failed");

      setSuccess(data.message);
      await refreshUser();
      setTimeout(() => {
        onClose();
        window.location.reload();
      }, 2500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-4">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white mb-2 shadow-lg shadow-[#ff3358]/20 p-1">
            <HotCheeleeLogo size={28} />
          </div>
          <h2 className="text-xl font-black text-white">
            Upgrade Account to Premium Listing
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Free users can upgrade to Creator or Agency mode. Creators can upgrade to Agency mode.
          </p>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-[#0e1118] border border-[#212738] rounded-xl mb-4 text-xs font-bold text-center">
          <button
            type="button"
            onClick={() => setTargetMode("creator")}
            className={`py-2 rounded-lg transition flex items-center justify-center gap-1.5 ${
              targetMode === "creator" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Star className="w-3.5 h-3.5" />
            <span>Creator Mode (KSh 500)</span>
          </button>

          <button
            type="button"
            onClick={() => setTargetMode("agency")}
            className={`py-2 rounded-lg transition flex items-center justify-center gap-1.5 ${
              targetMode === "agency" ? "bg-amber-400 text-black shadow font-black" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Agency Mode (KSh 1,500)</span>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
            {success}
          </div>
        )}

        {/* Till Payment Banner */}
        <div className="bg-[#181324] border border-[#3e2448] p-3 rounded-xl mb-4 text-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="font-bold text-amber-400">
              {targetMode === "agency" ? "Agency / Parlour / Lodging" : "Creator Listing"}: KSh {costKsh} / 30 Days
            </span>
            <span className="text-[10px] bg-[#ff3358] text-white px-1.5 py-0.2 rounded font-black">
              Enforced 30 Days
            </span>
          </div>
          <p className="text-zinc-300 text-[11px]">
            Send KSh {costKsh} to M-Pesa Buy Goods Till: <strong className="text-white">8923411</strong>, then enter code below.
          </p>
        </div>

        <form onSubmit={handleUpgrade} className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
          {targetMode === "creator" ? (
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">
                Your Community Category *
              </label>
              <select
                value={genderRole}
                onChange={(e) => setGenderRole(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="straight">Straight Model</option>
                <option value="gay">Gay Performer</option>
                <option value="transgender">Transgender</option>
                <option value="shemale">Shemale (TS)</option>
                <option value="queer">Queer / Non-Binary</option>
              </select>
            </div>
          ) : (
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">
                Agency Category *
              </label>
              <select
                value={agencyType}
                onChange={(e) => setAgencyType(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="Massage Parlour">Massage Parlour</option>
                <option value="Lodging">Lodging & Rooms</option>
                <option value="Brothel">Brothel / Club</option>
                <option value="Agency">Escort Agency</option>
              </select>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">City *</label>
              <input
                type="text"
                placeholder="Nairobi, Mombasa"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Area *</label>
              <input
                type="text"
                placeholder="Kilimani, Westlands, Nyali"
                value={locationArea}
                onChange={(e) => setLocationArea(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">
              Mobile Contact (Hidden, revealed on 1 click) *
            </label>
            <input
              type="text"
              placeholder="+254 722 123456"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">Service Mode</label>
            <select
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
            >
              <option value="Both Incall & Outcall">Both Incall & Outcall</option>
              <option value="Incall">Incall Only</option>
              <option value="Outcall">Outcall Only</option>
            </select>
          </div>

          {targetMode === "agency" && (
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">
                Advert Media URL (Image or Video)
              </label>
              <input
                type="url"
                placeholder="https://images.pexels.com/...jpg"
                value={advertMediaUrl}
                onChange={(e) => setAdvertMediaUrl(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          )}

          <div>
            <label className="text-xs font-bold text-amber-400 block mb-1">
              M-Pesa Transaction Code (Send KSh {costKsh} to Till: 8923411) *
            </label>
            <input
              type="text"
              placeholder="e.g. SHB492X1KL"
              value={mpesaCode}
              onChange={(e) => setMpesaCode(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-amber-400/50 rounded-xl px-3.5 py-2 text-xs text-white font-mono uppercase"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
          >
            {submitting ? "Upgrading..." : `Upgrade Now & Activate for 30 Days (KSh ${costKsh})`}
          </button>
        </form>
      </div>
    </div>
  );
}
