"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { X, Gift, Check, Coins, Sparkles, Heart } from "lucide-react";

export default function WishlistModal() {
  const { wishlistTarget, closeWishlistModal, currentUser, refreshUser, openTokensModal } = useApp();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [buyingId, setBuyingId] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (wishlistTarget) {
      setLoading(true);
      fetch(`/api/wishlist?modelId=${wishlistTarget.modelId}`)
        .then((r) => r.json())
        .then((d) => setItems(d.items || []))
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [wishlistTarget]);

  if (!wishlistTarget) return null;

  const handleBuyGift = async (item: any) => {
    if ((currentUser?.tokensBalance || 0) < item.tokenCost) {
      alert(`You need ${item.tokenCost} tokens to buy this gift.`);
      openTokensModal();
      return;
    }

    setBuyingId(item.id);
    try {
      const res = await fetch("/api/wishlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemId: item.id }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(data.message);
        await refreshUser();
        fetch(`/api/wishlist?modelId=${wishlistTarget.modelId}`).then((r) => r.json()).then((d) => setItems(d.items || []));
      } else {
        alert(data.error || "Failed to buy gift");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setBuyingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={closeWishlistModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <Gift className="w-5 h-5 text-[#ff3358]" />
          <h2 className="text-lg font-black text-white">
            {wishlistTarget.modelName || "Performer"}'s Wishlist
          </h2>
        </div>
        <p className="text-xs text-zinc-400 mb-4">
          Fulfill a gift with tokens. Performer receives real item delivery & your username is prominently pinned!
        </p>

        {notice && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
            {notice}
          </div>
        )}

        {loading ? (
          <div className="py-8 text-center text-xs text-zinc-500">Loading wishlist...</div>
        ) : items.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500">No items on wishlist yet.</div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
            {items.map((item) => (
              <div
                key={item.id}
                className="bg-[#0e1118] border border-[#212738] p-3 rounded-xl flex items-center gap-3.5 justify-between"
              >
                <img
                  src={item.image || "https://images.pexels.com/photos/33282388/pexels-photo-33282388.jpeg"}
                  alt={item.title}
                  className="w-14 h-14 rounded-xl object-cover shrink-0 border border-white/10"
                />

                <div className="min-w-0 flex-1">
                  <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider">
                    {item.category}
                  </span>
                  <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                  <div className="text-[11px] text-zinc-400 mt-0.5">
                    {item.isFulfilled ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <Check className="w-3 h-3" /> Fulfilled by @{item.fulfilledBy?.username || "fan"}
                      </span>
                    ) : (
                      <span>Cost: <strong className="text-amber-400">{item.tokenCost} Tokens</strong></span>
                    )}
                  </div>
                </div>

                <button
                  disabled={item.isFulfilled || buyingId === item.id}
                  onClick={() => handleBuyGift(item)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 ${
                    item.isFulfilled
                      ? "bg-[#1d2332] text-zinc-500 cursor-default"
                      : "bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white cursor-pointer"
                  }`}
                >
                  {item.isFulfilled ? "Gifted" : buyingId === item.id ? "Sending..." : "Buy Gift"}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
