"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  Sparkles,
  ShieldCheck,
  Check,
  CreditCard,
  Phone,
  MessageCircle,
  MapPin,
  Building2,
  Users,
  Lock,
  ArrowRight,
  Upload,
  Image as ImageIcon,
  Video,
} from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: "login" | "join_free" | "register_creator" | "register_agency";
}

export default function AuthModal({ isOpen, onClose, initialMode = "login" }: AuthModalProps) {
  const { refreshUser } = useApp();
  const [mode, setMode] = useState<"login" | "join_free" | "register_creator" | "register_agency">(initialMode);

  // Login inputs
  const [loginInput, setLoginInput] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  // Registration inputs
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [genderRole, setGenderRole] = useState("straight"); // straight, gay, transgender, shemale, queer
  const [agencyType, setAgencyType] = useState("Massage Parlour"); // Massage Parlour, Lodging, Brothel, Agency, Club
  const [location, setLocation] = useState("Nairobi");
  const [locationArea, setLocationArea] = useState("Kilimani");
  const [serviceType, setServiceType] = useState("Both Incall & Outcall");
  const [phone, setPhone] = useState("+254 7");
  const [allowWhatsapp, setAllowWhatsapp] = useState(true);
  const [allowCalls, setAllowCalls] = useState(true);
  const [allowSms, setAllowSms] = useState(true);

  const [oneHourPrice, setOneHourPrice] = useState("4000");
  const [overnightPrice, setOvernightPrice] = useState("15000");
  const [servicesSelected, setServicesSelected] = useState<string[]>([
    "Sensual Massage",
    "Companionship",
    "Overnight Stays",
  ]);

  const [advertMediaUrl, setAdvertMediaUrl] = useState("");
  const [advertMediaType, setAdvertMediaType] = useState<"image" | "video">("image");
  const [galleryCount, setGalleryCount] = useState(10); // meets minimum requirement

  const [mpesaCode, setMpesaCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickRoles = [
    { id: "straight", label: "Straight Model" },
    { id: "gay", label: "Gay Performer" },
    { id: "transgender", label: "Transgender" },
    { id: "shemale", label: "Shemale (TS)" },
    { id: "queer", label: "Queer / Non-Binary" },
  ];

  const quickAgencies = [
    "Massage Parlour",
    "Lodging",
    "Brothel",
    "Escort Agency",
    "Adult Club",
  ];

  const samplePersonas = [
    { username: "admin", label: "Admin 🛡️", role: "Superadmin" },
    { username: "elena_lux", label: "Elena (Straight Star)", role: "Creator KSh 500" },
    { username: "liam_fitness", label: "Liam (Gay Star)", role: "Creator KSh 500" },
    { username: "sasha_vixen", label: "Sasha (Trans Star)", role: "Creator KSh 500" },
    { username: "nikki_exotic", label: "Nikki (Shemale)", role: "Creator KSh 500" },
    { username: "kai_queer", label: "Kai (Queer)", role: "Creator KSh 500" },
    { username: "serenity_spa", label: "Serenity (Spa Parlour)", role: "Agency KSh 1,500" },
    { username: "alex_member", label: "Alex (Free Member)", role: "Browsing" },
  ];

  const handleSwitchPersona = async (uname: string) => {
    try {
      await fetch("/api/auth/switch-account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: uname }),
      });
      await refreshUser();
      onClose();
      window.location.reload();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usernameOrEmail: loginInput, password: loginPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");

      await refreshUser();
      onClose();
      window.location.reload();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const accountType =
        mode === "join_free"
          ? "browsing"
          : mode === "register_creator"
          ? "creator"
          : "agency";

      const ratesList = [
        { duration: "1 Hour", priceKsh: Number(oneHourPrice) || 3000 },
        { duration: "Overnight", priceKsh: Number(overnightPrice) || 12000 },
      ];

      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          displayName,
          email,
          password,
          accountType,
          genderRole,
          agencyType: mode === "register_agency" ? agencyType : null,
          location,
          locationArea,
          phone,
          allowWhatsapp,
          allowCalls,
          allowSms,
          serviceType,
          servicesOffered: servicesSelected,
          rates: ratesList,
          advertMediaUrl: advertMediaUrl || null,
          advertMediaType,
          mpesaCode: mpesaCode.trim().toUpperCase(),
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Registration failed");

      setSuccessMsg(data.message);
      await refreshUser();
      setTimeout(() => {
        onClose();
        window.location.reload();
      }, 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-xl w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-[#171d2c] border-2 border-[#ff3358] flex items-center justify-center p-1.5">
            <HotCheeleeLogo size={32} />
          </div>
          <div>
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              Hot<span className="text-[#ff3358]">Cheelee</span> Kenya
            </h2>
            <p className="text-xs text-zinc-400">
              Join free to browse &bull; Creators KSh 500/mo &bull; Agencies KSh 1,500/mo
            </p>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-4 gap-1 p-1 bg-[#0e1118] border border-[#212738] rounded-xl mb-4 text-xs font-bold text-center">
          <button
            onClick={() => { setMode("join_free"); setError(null); }}
            className={`py-2 rounded-lg transition ${mode === "join_free" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"}`}
          >
            Join Free
          </button>
          <button
            onClick={() => { setMode("register_creator"); setError(null); }}
            className={`py-2 rounded-lg transition ${mode === "register_creator" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"}`}
          >
            Creator
          </button>
          <button
            onClick={() => { setMode("register_agency"); setError(null); }}
            className={`py-2 rounded-lg transition ${mode === "register_agency" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"}`}
          >
            Agency
          </button>
          <button
            onClick={() => { setMode("login"); setError(null); }}
            className={`py-2 rounded-lg transition ${mode === "login" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"}`}
          >
            Login
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400">
            {error}
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
            {successMsg}
          </div>
        )}

        {/* 1-Click Persona Switcher for Quick Review & Admin testing */}
        <div className="bg-[#0e1118] border border-[#232938] p-3 rounded-xl mb-4 text-xs">
          <span className="text-[10px] font-black uppercase text-amber-400 block mb-1.5">
            ⚡ Quick 1-Click Login Personas (Demo Testing):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {samplePersonas.map((p) => (
              <button
                key={p.username}
                type="button"
                onClick={() => handleSwitchPersona(p.username)}
                className="px-2 py-1 rounded bg-[#181d28] hover:bg-[#ff3358] hover:text-white text-zinc-300 text-[11px] font-semibold border border-[#2b3345] transition cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* MODE: Login (Facebook-style mechanic & exact prompt layout) */}
        {mode === "login" && (
          <div className="space-y-4">
            <div className="text-center space-y-1 pb-1">
              <h3 className="text-xl font-black text-white">Welcome back</h3>
              <p className="text-xs text-zinc-400">
                Log in with your username — that's all we ever asked for.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">
                  Username
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-zinc-500 font-bold text-xs">@</span>
                  <input
                    type="text"
                    placeholder="yourname"
                    value={loginInput}
                    onChange={(e) => setLoginInput(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl pl-8 pr-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">
                  Password (Optional if saved)
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
              >
                {submitting ? "Logging in..." : "Log in"}
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => setMode("join_free")}
                  className="text-xs text-zinc-400 hover:text-white"
                >
                  New here? <span className="text-[#ff3358] font-bold hover:underline">Join free</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* MODE: Join Free (Browsing) */}
        {mode === "join_free" && (
          <form onSubmit={handleRegister} className="space-y-3">
            {/* Strict 18+ Disclaimer Specified in Phase 3 */}
            <div className="bg-[#121622] border-2 border-[#ff3358]/50 p-3.5 rounded-xl text-xs space-y-2">
              <span className="font-black text-[#ff3358] uppercase tracking-wider block text-[11px]">
                HOTCHEELEE — STRICT 18+ ADULT-ONLY PLATFORM
              </span>
              <p className="text-[11px] text-zinc-300 leading-relaxed">
                HotCheelee is exclusively for adults aged 18 years and older. Anyone under 18 is strictly prohibited from registering, accessing adult-restricted features, uploading content or using this platform. HotCheelee does not permit child sexual exploitation, grooming, trafficking, coercion, sexual abuse, non-consensual intimate imagery or content involving sexual exploitation of minors.
              </p>
              <div className="flex items-center gap-2 text-[10px] text-emerald-400 font-semibold pt-1">
                <Check className="w-3.5 h-3.5 shrink-0" />
                <span>By proceeding, you confirm that you are at least 18 years old and agree to comply with HotCheelee's age restrictions.</span>
              </div>
            </div>

            <div className="bg-[#181d28] p-2 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Joining is 100% Free to browse models, contact creators & watch feeds!</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Choose Username *</label>
                <input
                  type="text"
                  placeholder="e.g. john_nairobi"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Display Name *</label>
                <input
                  type="text"
                  placeholder="e.g. John Doe"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Email Address</label>
              <input
                type="email"
                placeholder="john@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Your Mobile Phone (Optional)</label>
              <input
                type="text"
                placeholder="+254 712 345678"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer"
            >
              {submitting ? "Creating Free Account..." : "Join Free & Browse Now"}
            </button>
          </form>
        )}

        {/* MODE: Creator Registration (KSh 500/mo) */}
        {mode === "register_creator" && (
          <form onSubmit={handleRegister} className="space-y-3 max-h-[65vh] overflow-y-auto pr-1">
            <div className="bg-[#1a1424] border border-[#3e2448] p-3 rounded-xl text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-400">Creator Subscription: KSh 500 / Month</span>
                <span className="text-[10px] bg-[#ff3358] text-white px-1.5 py-0.2 rounded font-black">30 Days</span>
              </div>
              <p className="text-zinc-300 text-[11px]">
                Pay to M-Pesa Buy Goods Till: <strong className="text-white">8923411</strong>, then enter the M-Pesa confirmation code below.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Profile Name / Nickname *</label>
                <input
                  type="text"
                  placeholder="e.g. Bella Glamour"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Username *</label>
                <input
                  type="text"
                  placeholder="bella_glam"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            {/* Diversity Orientation selection */}
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">
                Your Role / Community Category *
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                {quickRoles.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setGenderRole(r.id)}
                    className={`p-2 rounded-xl text-[11px] font-bold border transition ${
                      genderRole === r.id
                        ? "bg-[#ff3358] text-white border-[#ff3358]"
                        : "bg-[#0e1118] border-[#252c3c] text-zinc-300 hover:border-zinc-700"
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Location & Service Type */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">City / Town *</label>
                <input
                  type="text"
                  placeholder="e.g. Nairobi, Mombasa"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Specific Area *</label>
                <input
                  type="text"
                  placeholder="e.g. Kilimani, Westlands, Nyali"
                  value={locationArea}
                  onChange={(e) => setLocationArea(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Service Type</label>
                <select
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                >
                  <option value="Both Incall & Outcall">Both Incall & Outcall</option>
                  <option value="Incall">Incall Only</option>
                  <option value="Outcall">Outcall Only</option>
                </select>
              </div>
            </div>

            {/* Mobile Contact & Preferences */}
            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">
                Mobile Number (Hidden by default, revealed on 1 click) *
              </label>
              <input
                type="text"
                placeholder="+254 722 123456"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
              />

              <div className="flex items-center gap-4 mt-2 text-xs text-zinc-300">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowWhatsapp}
                    onChange={(e) => setAllowWhatsapp(e.target.checked)}
                    className="accent-[#ff3358]"
                  />
                  <span>WhatsApp</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowCalls}
                    onChange={(e) => setAllowCalls(e.target.checked)}
                    className="accent-[#ff3358]"
                  />
                  <span>Phone Calls</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowSms}
                    onChange={(e) => setAllowSms(e.target.checked)}
                    className="accent-[#ff3358]"
                  />
                  <span>SMS</span>
                </label>
              </div>
            </div>

            {/* Rates in KSh */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">1 Hour Rate (KSh) *</label>
                <input
                  type="number"
                  placeholder="4000"
                  value={oneHourPrice}
                  onChange={(e) => setOneHourPrice(e.target.value)}
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Overnight Rate (KSh)</label>
                <input
                  type="number"
                  placeholder="15000"
                  value={overnightPrice}
                  onChange={(e) => setOvernightPrice(e.target.value)}
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            {/* Minimum 10 photos or 5 videos upload prompt */}
            <div className="bg-[#0e1118] border border-[#222837] p-3 rounded-xl text-xs space-y-2">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-emerald-400" />
                Upload Portfolio (Min 10 Photos or 5 Videos/Shorts)
              </span>
              <p className="text-[11px] text-zinc-400">
                Uploaded {galleryCount} items to verify profile authenticity.
              </p>
            </div>

            {/* M-Pesa Code for KSh 500 */}
            <div>
              <label className="text-xs font-bold text-amber-400 block mb-1">
                M-Pesa Transaction Code (Send KSh 500 to Till: 8923411) *
              </label>
              <input
                type="text"
                placeholder="e.g. SHB492X1KL"
                value={mpesaCode}
                onChange={(e) => setMpesaCode(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-amber-400/50 rounded-xl px-3.5 py-2 text-xs text-white font-mono uppercase"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer"
            >
              {submitting ? "Registering..." : "Submit Profile & KSh 500 M-Pesa Payment"}
            </button>
          </form>
        )}

        {/* MODE: Agency Registration (KSh 1,500/mo) */}
        {mode === "register_agency" && (
          <form onSubmit={handleRegister} className="space-y-3 max-h-[65vh] overflow-y-auto pr-1">
            <div className="bg-[#1c1825] border border-[#4a2e58] p-3 rounded-xl text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-400">Agency Subscription: KSh 1,500 / Month</span>
                <span className="text-[10px] bg-[#ff3358] text-white px-1.5 py-0.2 rounded font-black">30 Days</span>
              </div>
              <p className="text-zinc-300 text-[11px]">
                Massage Parlours, Lodgings, Brothels & Clubs. Pay to M-Pesa Buy Goods Till: <strong className="text-white">8923411</strong>.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Agency / Business Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Serenity Executive Spa"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Username Handle *</label>
                <input
                  type="text"
                  placeholder="serenity_spa"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">Agency Category *</label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                {quickAgencies.map((a) => (
                  <button
                    key={a}
                    type="button"
                    onClick={() => setAgencyType(a)}
                    className={`p-2 rounded-xl text-[11px] font-bold border transition ${
                      agencyType === a
                        ? "bg-amber-400 text-black border-amber-400"
                        : "bg-[#0e1118] border-[#252c3c] text-zinc-300 hover:border-zinc-700"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Location / Area *</label>
                <input
                  type="text"
                  placeholder="Nairobi - Westlands Mpaka Road"
                  value={locationArea}
                  onChange={(e) => setLocationArea(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Reception Phone / WhatsApp *</label>
                <input
                  type="text"
                  placeholder="+254 700 123456"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-300 block mb-1">
                Advert Video or Image URL *
              </label>
              <input
                type="url"
                placeholder="https://images.pexels.com/...jpg"
                value={advertMediaUrl}
                onChange={(e) => setAdvertMediaUrl(e.target.value)}
                className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            {/* M-Pesa Code for KSh 1,500 */}
            <div>
              <label className="text-xs font-bold text-amber-400 block mb-1">
                M-Pesa Transaction Code (Send KSh 1,500 to Till: 8923411) *
              </label>
              <input
                type="text"
                placeholder="e.g. MPR982M1AA"
                value={mpesaCode}
                onChange={(e) => setMpesaCode(e.target.value)}
                required
                className="w-full bg-[#0e1118] border border-amber-400/50 rounded-xl px-3.5 py-2 text-xs text-white font-mono uppercase"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer"
            >
              {submitting ? "Submitting..." : "Submit Agency Listing & KSh 1,500 M-Pesa Payment"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
