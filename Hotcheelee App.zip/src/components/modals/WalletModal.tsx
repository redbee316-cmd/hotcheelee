"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { Flame, X, Sparkles, CheckCircle2, CreditCard, ShieldCheck, Zap, Coins } from "lucide-react";
import Link from "next/link";

export default function WalletModal() {
  const { isWalletOpen, closeWalletModal, currentUser, refreshUser } = useApp();
  const [buying, setBuying] = useState<number | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isWalletOpen) return null;

  const bundles = [
    { flames: 100, price: "$4.99", bonus: "Starter Pack", icon: "🔥" },
    { flames: 500, price: "$19.99", bonus: "+50 Bonus Flames", icon: "⚡", popular: true },
    { flames: 1500, price: "$49.99", bonus: "+250 Bonus Flames", icon: "💎" },
    { flames: 3500, price: "$99.99", bonus: "+800 Bonus Flames", icon: "👑" },
  ];

  const handlePurchase = async (bundle: typeof bundles[0]) => {
    setBuying(bundle.flames);
    try {
      const res = await fetch("/api/wallet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ flamesAmount: bundle.flames }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to refill wallet");

      await refreshUser();
      setSuccessMessage(`Successfully added ${bundle.flames} Flames to your wallet!`);
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setBuying(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="relative max-w-lg w-full bg-[#151922] border border-[#262c3b] rounded-2xl p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={closeWalletModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center shadow-lg shadow-[#ff3358]/20">
            <Coins className="w-7 h-7 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Chily Crypto Wallet</h3>
            <p className="text-xs text-zinc-400">Manage $LEE tokens, $CHEEL, USDT & Flames</p>
          </div>
        </div>

        {/* Cheelee Dual Token Cards */}
        <div className="grid grid-cols-3 gap-2.5 mb-6">
          <div className="bg-[#0f1218] border border-[#232938] rounded-xl p-3">
            <span className="text-[10px] text-zinc-400 block font-medium">$LEE Token</span>
            <div className="text-base font-black text-amber-400 flex items-center gap-1">
              <span>{currentUser?.leeBalance || "0.00"}</span>
            </div>
            <span className="text-[9px] text-zinc-500">Watch & Earn</span>
          </div>

          <div className="bg-[#0f1218] border border-[#232938] rounded-xl p-3">
            <span className="text-[10px] text-zinc-400 block font-medium">$CHEEL Token</span>
            <div className="text-base font-black text-purple-400 flex items-center gap-1">
              <span>{currentUser?.cheelBalance || "0.00"}</span>
            </div>
            <span className="text-[9px] text-zinc-500">Governance</span>
          </div>

          <div className="bg-[#0f1218] border border-[#232938] rounded-xl p-3">
            <span className="text-[10px] text-zinc-400 block font-medium">USDT Balance</span>
            <div className="text-base font-black text-emerald-400 flex items-center gap-1">
              <span>${currentUser?.usdtBalance || "0.00"}</span>
            </div>
            <span className="text-[9px] text-zinc-500">NFT Market</span>
          </div>
        </div>

        {successMessage && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-300">
              Refill Flame Credits (Tips & Boosts)
            </h4>
            <span className="text-[11px] text-zinc-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Instant & Discrete
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {bundles.map((b) => (
              <div
                key={b.flames}
                className={`relative bg-[#0e1219] border rounded-xl p-3.5 transition flex flex-col justify-between ${
                  b.popular
                    ? "border-[#ff3358] ring-1 ring-[#ff3358]/40"
                    : "border-[#222837] hover:border-zinc-700"
                }`}
              >
                {b.popular && (
                  <span className="absolute -top-2.5 right-3 bg-[#ff3358] text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow">
                    Most Popular
                  </span>
                )}
                <div className="mb-3">
                  <div className="flex items-center gap-1.5 text-sm font-black text-white mb-0.5">
                    <span>{b.icon}</span>
                    <span>{b.flames.toLocaleString()} Flames</span>
                  </div>
                  <span className="text-[11px] text-amber-400 font-medium">{b.bonus}</span>
                </div>

                <button
                  type="button"
                  disabled={buying !== null}
                  onClick={() => handlePurchase(b)}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    b.popular
                      ? "bg-[#ff3358] hover:bg-[#e11d48] text-white shadow-md shadow-[#ff3358]/30"
                      : "bg-[#1d2332] hover:bg-[#283042] text-zinc-200"
                  }`}
                >
                  {buying === b.flames ? (
                    <span className="text-zinc-400">Processing...</span>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5" />
                      <span>Buy for {b.price}</span>
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-[#232938] pt-4 flex items-center justify-between text-xs text-zinc-400">
          <Link
            href="/wallet"
            onClick={closeWalletModal}
            className="text-amber-400 hover:underline font-bold flex items-center gap-1"
          >
            <span>Open Full Crypto Wallet & Withdrawals &rarr;</span>
          </Link>
          <span className="text-[11px] text-zinc-500">BNB Smart Chain (BEP20)</span>
        </div>
      </div>
    </div>
  );
}
