"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import {
  X,
  Image as ImageIcon,
  Video,
  Link as LinkIcon,
  Hash,
  Flame,
  Sparkles,
  AlertCircle,
  FolderPlus,
} from "lucide-react";

interface TopicOption {
  id: number;
  slug: string;
  name: string;
  icon: string;
}

export default function CreatePostModal() {
  const { isCreatePostOpen, closeCreatePostModal, createPostInitialTopicId, currentUser, triggerPostRefresh } = useApp();

  const [content, setContent] = useState("");
  const [selectedTopicId, setSelectedTopicId] = useState<string>("");
  const [mediaUrl, setMediaUrl] = useState("");
  const [mediaType, setMediaType] = useState<"image" | "video">("image");
  const [promoLinkUrl, setPromoLinkUrl] = useState("");
  const [promoLinkLabel, setPromoLinkLabel] = useState("");
  const [tagsInput, setTagsInput] = useState("");
  const [priceKsh, setPriceKsh] = useState("");
  const [unlockFeeTokens, setUnlockFeeTokens] = useState("");
  const [isQuickie, setIsQuickie] = useState(false);
  const [isFanClubOnly, setIsFanClubOnly] = useState(false);
  const [topicsList, setTopicsList] = useState<TopicOption[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isCreatePostOpen) {
      fetch("/api/topics")
        .then((res) => res.json())
        .then((data) => {
          if (data.topics) setTopicsList(data.topics);
        })
        .catch(console.error);

      if (createPostInitialTopicId) {
        setSelectedTopicId(String(createPostInitialTopicId));
      } else {
        setSelectedTopicId("");
      }

      if (currentUser?.paysiteUrl) {
        setPromoLinkUrl(currentUser.paysiteUrl);
      }
      if (currentUser?.paysiteLabel) {
        setPromoLinkLabel(currentUser.paysiteLabel);
      }
    }
  }, [isCreatePostOpen, createPostInitialTopicId, currentUser]);

  if (!isCreatePostOpen) return null;

  const sampleMediaPresets = [
    {
      label: "Glamour Portrait",
      url: "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800",
      type: "image" as const,
    },
    {
      label: "Sensual Lace",
      url: "https://images.pexels.com/photos/31130286/pexels-photo-31130286.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800",
      type: "image" as const,
    },
    {
      label: "Dance Reel (Video)",
      url: "https://videos.pexels.com/video-files/7845993/7845993-hd_1080_1920_30fps.mp4",
      type: "video" as const,
    },
    {
      label: "Fitness Clip (Video)",
      url: "https://videos.pexels.com/video-files/7845994/7845994-hd_1080_1920_30fps.mp4",
      type: "video" as const,
    },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !mediaUrl) {
      setError("Please write some content or provide a media URL");
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const media = mediaUrl
        ? [{ url: mediaUrl.trim(), type: mediaType }]
        : [];

      const tags = tagsInput
        ? tagsInput
            .split(/[,\s]+/)
            .map((t) => t.replace(/^#/, "").trim())
            .filter(Boolean)
        : [];

      const res = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: content.trim(),
          topicId: selectedTopicId ? Number(selectedTopicId) : null,
          media,
          promoLinkUrl: promoLinkUrl.trim() || null,
          promoLinkLabel: promoLinkLabel.trim() || null,
          tags,
          isQuickie: isQuickie || mediaType === "video",
          videoUrl: mediaType === "video" ? mediaUrl.trim() : null,
          priceKsh: priceKsh ? Number(priceKsh) : null,
          unlockFeeTokens: unlockFeeTokens ? Number(unlockFeeTokens) : 0,
          previewVideoUrl: mediaType === "video" && unlockFeeTokens ? mediaUrl.trim() : null,
          fullVideoUrl: mediaType === "video" ? mediaUrl.trim() : null,
          isFanClubOnly,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to publish post");

      triggerPostRefresh();
      closeCreatePostModal();
      setContent("");
      setMediaUrl("");
      setTagsInput("");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative max-w-xl w-full bg-[#151922] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-8 animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={closeCreatePostModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <img
            src={currentUser?.avatar || "https://images.pexels.com/photos/27236833/pexels-photo-27236833.jpeg"}
            alt="User avatar"
            className="w-11 h-11 rounded-full object-cover ring-2 ring-[#ff3358]"
          />
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-1.5">
              Create New Chily Post
            </h3>
            <p className="text-xs text-zinc-400">Post to timeline or pick an adult topic</p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-zinc-300 block mb-1 flex items-center gap-1.5">
              <FolderPlus className="w-3.5 h-3.5 text-[#ff3358]" />
              Select Topic / Community (Optional)
            </label>
            <select
              value={selectedTopicId}
              onChange={(e) => setSelectedTopicId(e.target.value)}
              className="w-full bg-[#0f1218] border border-[#262c3b] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#ff3358]"
            >
              <option value="">Personal Timeline (All Followers)</option>
              {topicsList.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.icon} #{t.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's hot today? Share your thoughts, tease upcoming content, or describe your shoot..."
              rows={4}
              className="w-full bg-[#0f1218] border border-[#262c3b] rounded-xl p-3.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358] resize-none"
            />
          </div>

          <div className="bg-[#0f1218] border border-[#242b3b] rounded-xl p-3.5 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-300 flex items-center gap-1.5">
                {mediaType === "video" ? <Video className="w-4 h-4 text-[#ff3358]" /> : <ImageIcon className="w-4 h-4 text-[#ff3358]" />}
                Media Attachment (Photo or Video URL)
              </span>
              <div className="flex items-center gap-1 bg-[#1a1f2b] p-0.5 rounded-lg border border-[#2a3142]">
                <button
                  type="button"
                  onClick={() => setMediaType("image")}
                  className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                    mediaType === "image" ? "bg-[#ff3358] text-white" : "text-zinc-400 hover:text-white"
                  }`}
                >
                  Image
                </button>
                <button
                  type="button"
                  onClick={() => setMediaType("video")}
                  className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                    mediaType === "video" ? "bg-[#ff3358] text-white" : "text-zinc-400 hover:text-white"
                  }`}
                >
                  Video
                </button>
              </div>
            </div>

            <input
              type="url"
              placeholder={mediaType === "video" ? "https://videos.pexels.com/...mp4" : "https://images.pexels.com/...jpg"}
              value={mediaUrl}
              onChange={(e) => setMediaUrl(e.target.value)}
              className="w-full bg-[#141822] border border-[#2b3344] rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
            />

            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] text-zinc-500">Quick Samples:</span>
              {sampleMediaPresets.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => {
                    setMediaUrl(p.url);
                    setMediaType(p.type);
                    if (p.type === "video") setIsQuickie(true);
                  }}
                  className="px-2 py-0.5 rounded bg-[#1a1f2c] hover:bg-[#252c3e] text-[10px] text-zinc-300 font-medium border border-[#283042]"
                >
                  {p.label}
                </button>
              ))}
            </div>

            {mediaUrl && (
              <div className="mt-2 rounded-lg overflow-hidden border border-[#2e374a] max-h-48 flex items-center justify-center bg-black">
                {mediaType === "video" ? (
                  <video src={mediaUrl} controls className="max-h-48 w-auto object-contain" />
                ) : (
                  <img src={mediaUrl} alt="Preview" className="max-h-48 w-auto object-contain" />
                )}
              </div>
            )}
          </div>

          <div className="bg-[#0f1218] border border-[#242b3b] rounded-xl p-3.5 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-300 flex items-center gap-1.5">
                <LinkIcon className="w-3.5 h-3.5 text-amber-400" />
                Promoted Link / Paysite (Direct Fan Traffic)
              </span>
              <span className="text-[10px] text-amber-400 uppercase font-bold tracking-wider">Zero Censorship</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="url"
                placeholder="https://onlyfans.com/yourhandle"
                value={promoLinkUrl}
                onChange={(e) => setPromoLinkUrl(e.target.value)}
                className="bg-[#141822] border border-[#2b3344] rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
              <input
                type="text"
                placeholder="Button Label: e.g. 💋 OnlyFans VIP 50% Off"
                value={promoLinkLabel}
                onChange={(e) => setPromoLinkLabel(e.target.value)}
                className="bg-[#141822] border border-[#2b3344] rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="w-full relative">
              <Hash className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Tags: glamour, massage, kilimani, cosplay"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                className="w-full bg-[#0f1218] border border-[#262c3b] rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
            </div>

            <div>
              <input
                type="number"
                placeholder="Service Rate / Price in KSh (Optional)"
                value={priceKsh}
                onChange={(e) => setPriceKsh(e.target.value)}
                className="w-full bg-[#0f1218] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
            </div>
          </div>

          {/* SHARESOME PAY-TO-UNLOCK FULL VIDEO FEE SET BY CREATOR */}
          {mediaType === "video" && (
            <div className="bg-[#14121e] border border-amber-400/40 p-3 rounded-xl space-y-1.5 text-xs">
              <span className="font-bold text-amber-300 block flex items-center gap-1.5">
                <span>🔒 Sharesome Pay-to-Unlock Video Fee (Tokens)</span>
              </span>
              <p className="text-[11px] text-zinc-400">
                You decide the unlock fee! Viewers must pay this token fee to unlock and watch your full uncut video (90% credited to your wallet). Leave blank for free video.
              </p>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  step={5}
                  placeholder="e.g. 25 Tokens (KSh 250)"
                  value={unlockFeeTokens}
                  onChange={(e) => setUnlockFeeTokens(e.target.value)}
                  className="w-48 bg-[#0e1118] border border-amber-400/50 rounded-lg px-3 py-1.5 text-xs text-white font-bold"
                />
                <span className="text-zinc-500 text-[11px]">
                  {unlockFeeTokens ? `= KSh ${Number(unlockFeeTokens) * 10} unlock fee` : "Free to view"}
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-4 text-xs text-zinc-300">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={isQuickie}
                onChange={(e) => setIsQuickie(e.target.checked)}
                className="rounded accent-[#ff3358] w-4 h-4 cursor-pointer"
              />
              <span className="flex items-center gap-1 font-semibold">
                <Flame className="w-3.5 h-3.5 text-[#ff3358] fill-[#ff3358]" />
                Quickies Reel
              </span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={isFanClubOnly}
                onChange={(e) => setIsFanClubOnly(e.target.checked)}
                className="rounded accent-amber-400 w-4 h-4 cursor-pointer"
              />
              <span className="text-amber-300 font-semibold">VIP Fan Club Only Content</span>
            </label>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={closeCreatePostModal}
              className="py-2.5 px-4 rounded-xl text-xs font-bold text-zinc-400 hover:text-white bg-[#191e2b] hover:bg-[#232a3d] transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="py-2.5 px-6 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] disabled:opacity-50 transition shadow-lg shadow-[#ff3358]/25 flex items-center gap-1.5 cursor-pointer"
            >
              {submitting ? (
                <span>Publishing...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Publish to Chily</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
