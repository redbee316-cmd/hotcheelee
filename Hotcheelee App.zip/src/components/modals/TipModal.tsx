"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { Flame, X, Sparkles, AlertCircle, CheckCircle2, Coins } from "lucide-react";

export default function TipModal() {
  const { tipTarget, closeTipModal, currentUser, refreshUser } = useApp();
  const [tipType, setTipType] = useState<"FLAME" | "LEE">("FLAME");
  const [selectedAmount, setSelectedAmount] = useState<number>(50);
  const [customAmount, setCustomAmount] = useState<string>("");
  const [message, setMessage] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!tipTarget) return null;

  const effectiveAmount = customAmount ? Number(customAmount) : selectedAmount;
  const flameBalance = currentUser?.flamesBalance || 0;
  const leeBalance = Number(currentUser?.leeBalance || 0);

  const isBalanceEnough =
    tipType === "FLAME" ? flameBalance >= effectiveAmount : leeBalance >= effectiveAmount;

  const handleTip = async () => {
    if (effectiveAmount <= 0) {
      setError("Please choose a valid tip amount");
      return;
    }
    if (!isBalanceEnough) {
      setError(
        `Insufficient ${tipType} balance. You have ${
          tipType === "FLAME" ? flameBalance + " Flames" : leeBalance + " $LEE"
        }.`
      );
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const res = await fetch("/api/tips", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          receiverId: tipTarget.id,
          postId: tipTarget.postId,
          amount: effectiveAmount,
          tokenType: tipType,
          message: message.trim() || `Tipped you ${effectiveAmount} ${tipType}! 🔥`,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to send tip");
      }

      setSuccess(true);
      await refreshUser();
      setTimeout(() => {
        setSuccess(false);
        closeTipModal();
      }, 1600);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  const presetAmounts = tipType === "FLAME" ? [20, 50, 100, 250, 500] : [1, 5, 10, 25, 50];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="relative max-w-md w-full bg-[#151922] border border-[#262c3b] rounded-2xl p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={closeTipModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg transition"
        >
          <X className="w-5 h-5" />
        </button>

        {success ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-white">Tip Delivered! ⚡</h3>
            <p className="text-sm text-zinc-400">
              You sent {effectiveAmount} {tipType} to @{tipTarget.username}.
            </p>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="relative">
                <img
                  src={tipTarget.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                  alt={tipTarget.displayName}
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-[#ff3358]"
                />
                <span className="absolute -bottom-1 -right-1 bg-[#ff3358] p-1 rounded-full text-white">
                  <Flame className="w-3 h-3 fill-white" />
                </span>
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                  Tip {tipTarget.displayName}
                </h3>
                <p className="text-xs text-zinc-400">@{tipTarget.username}</p>
              </div>
            </div>

            {/* Currency Toggle: Flames vs $LEE Token */}
            <div className="bg-[#0f1218] p-1 rounded-xl flex items-center gap-1 mb-4 border border-[#222836]">
              <button
                type="button"
                onClick={() => {
                  setTipType("FLAME");
                  setSelectedAmount(50);
                  setCustomAmount("");
                }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  tipType === "FLAME"
                    ? "bg-[#ff3358] text-white shadow-sm"
                    : "text-zinc-400 hover:text-white"
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Flames ({flameBalance})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setTipType("LEE");
                  setSelectedAmount(5);
                  setCustomAmount("");
                }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  tipType === "LEE"
                    ? "bg-amber-400 text-black shadow-sm"
                    : "text-zinc-400 hover:text-white"
                }`}
              >
                <Coins className="w-3.5 h-3.5" />
                <span>$LEE Tokens ({leeBalance})</span>
              </button>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="mb-5">
              <label className="text-xs font-semibold text-zinc-300 block mb-2">
                Select {tipType} Amount
              </label>
              <div className="grid grid-cols-5 gap-2 mb-3">
                {presetAmounts.map((amt) => {
                  const isSelected = selectedAmount === amt && !customAmount;
                  return (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => {
                        setSelectedAmount(amt);
                        setCustomAmount("");
                      }}
                      className={`py-2 px-1 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center gap-1 border ${
                        isSelected
                          ? tipType === "FLAME"
                            ? "bg-[#ff3358] text-white border-[#ff3358]"
                            : "bg-amber-400 text-black border-amber-400"
                          : "bg-[#181d28] hover:bg-[#1f2635] text-zinc-300 border-[#272e3f]"
                      }`}
                    >
                      <span>{amt}</span>
                    </button>
                  );
                })}
              </div>

              <div>
                <input
                  type="number"
                  placeholder={`Or enter custom ${tipType}...`}
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  min={1}
                  className="w-full bg-[#0f1218] border border-[#242b3b] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
                />
              </div>
            </div>

            <div className="mb-6">
              <label className="text-xs font-semibold text-zinc-300 block mb-1.5">
                Message (optional)
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Love your content on Chily! 🔥"
                rows={2}
                maxLength={200}
                className="w-full bg-[#0f1218] border border-[#242b3b] rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358] resize-none"
              />
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={closeTipModal}
                className="flex-1 py-3 px-4 rounded-xl text-xs font-bold text-zinc-300 bg-[#1c2230] hover:bg-[#252c3e] transition"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={submitting || !effectiveAmount}
                onClick={handleTip}
                className="flex-1 py-3 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] disabled:opacity-50 transition shadow-lg shadow-[#ff3358]/25 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {submitting ? (
                  <span>Sending...</span>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Send {effectiveAmount || 0} {tipType}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
