"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { X, Sparkles, Coins, Gift, Award } from "lucide-react";

export default function WheelModal() {
  const { wheelTarget, closeWheelModal, currentUser, refreshUser, openTokensModal } = useApp();
  const [segments, setSegments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonResult, setWonResult] = useState<any | null>(null);

  useEffect(() => {
    if (wheelTarget) {
      setLoading(true);
      fetch(`/api/wheel?modelId=${wheelTarget.modelId}`)
        .then((r) => r.json())
        .then((d) => setSegments(d.segments || []))
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [wheelTarget]);

  if (!wheelTarget) return null;

  const cost = segments[0]?.costTokens || 25;

  const handleSpin = async () => {
    if (spinning) return;
    if ((currentUser?.tokensBalance || 0) < cost) {
      alert(`You need ${cost} tokens to spin the Wheel of Fortune!`);
      openTokensModal();
      return;
    }

    setSpinning(true);
    setWonResult(null);

    try {
      const res = await fetch("/api/wheel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ modelId: wheelTarget.modelId }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to spin");
      }

      // Calculate final degree
      const numSegments = segments.length || 6;
      const segmentAngle = 360 / numSegments;
      const targetDegree = 360 * 5 + (numSegments - 1 - data.wonIndex) * segmentAngle + segmentAngle / 2;

      setRotation(targetDegree);

      setTimeout(async () => {
        setWonResult(data.wonSegment);
        setSpinning(false);
        await refreshUser();
      }, 4000);
    } catch (err: any) {
      alert(err.message);
      setSpinning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative max-w-md w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 text-center animate-in fade-in zoom-in-95">
        <button
          onClick={closeWheelModal}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#ff3358]/20 to-[#ffaa00]/20 border border-[#ff3358]/40 text-[#ff3358] text-xs font-black uppercase mb-1">
            <span>🎡 Stripchat Wheel of Fortune</span>
          </div>
          <h2 className="text-xl font-black text-white">Spin & Win Rewards</h2>
          <p className="text-xs text-zinc-400">
            Spin {wheelTarget.modelName || "Model"}'s wheel for {cost} tokens to unlock perks, sets & toy vibes!
          </p>
        </div>

        {/* Visual Roulette Wheel */}
        <div className="relative w-64 h-64 mx-auto my-4 flex items-center justify-center">
          {/* Top Pointer arrow */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[18px] border-t-amber-400 filter drop-shadow" />

          {/* Wheel Disc */}
          <div
            className="w-full h-full rounded-full border-4 border-amber-400 shadow-2xl overflow-hidden relative transition-all ease-out"
            style={{
              transform: `rotate(${rotation}deg)`,
              transitionDuration: spinning ? "4s" : "0s",
              background: "conic-gradient(#ff3358 0deg 60deg, #8b5cf6 60deg 120deg, #ec4899 120deg 180deg, #10b981 180deg 240deg, #f59e0b 240deg 300deg, #3b82f6 300deg 360deg)",
            }}
          >
            {segments.map((seg, i) => {
              const angle = (360 / segments.length) * i;
              return (
                <div
                  key={seg.id}
                  className="absolute inset-0 flex items-start justify-center pt-5 text-[10px] font-black text-white drop-shadow uppercase"
                  style={{ transform: `rotate(${angle + 30}deg)` }}
                >
                  <span className="max-w-[70px] truncate text-center">{seg.label}</span>
                </div>
              );
            })}
          </div>

          {/* Center Hub */}
          <div className="absolute w-14 h-14 rounded-full bg-[#13161f] border-2 border-white/20 shadow-xl flex items-center justify-center text-xs font-black text-amber-400">
            🎡
          </div>
        </div>

        {wonResult && (
          <div className="mb-4 p-3 bg-gradient-to-r from-emerald-500/20 to-[#ffaa00]/20 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 animate-in zoom-in-95">
            <strong className="block text-sm text-white">🎉 Winner! You landed on:</strong>
            <span className="text-amber-300 font-bold">{wonResult.label}</span> &bull; Model has been notified!
          </div>
        )}

        <div className="flex items-center justify-between bg-[#0e1118] border border-[#212738] rounded-xl p-3 mb-4 text-xs">
          <span className="text-zinc-400">Your Token Balance:</span>
          <span className="font-bold text-white flex items-center gap-1">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            {currentUser?.tokensBalance || 0} tk
          </span>
        </div>

        <button
          disabled={spinning}
          onClick={handleSpin}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3358] via-[#ff7700] to-[#ffaa00] hover:from-[#e11d48] text-white font-black text-sm uppercase tracking-wider transition shadow-lg shadow-[#ff3358]/25 cursor-pointer disabled:opacity-50"
        >
          {spinning ? "Spinning Wheel..." : `Spin Wheel (${cost} tk)`}
        </button>
      </div>
    </div>
  );
}
