"use client";

import React, { useState } from "react";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import {
  X,
  Zap,
  Clock,
  Smartphone,
  Sparkles,
  Upload,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";

interface CreateQuickieModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateQuickieModal({ isOpen, onClose }: CreateQuickieModalProps) {
  const { currentUser, refreshUser, openUpgradeModal } = useApp();
  const [videoUrl, setVideoUrl] = useState("");
  const [durationSeconds, setDurationSeconds] = useState(15);
  const [caption, setCaption] = useState("");
  const [aspectRatio, setAspectRatio] = useState("9:16");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickieVideoPresets = [
    { label: "Vertical Dance Reel 1 (10s)", url: "https://videos.pexels.com/video-files/7845993/7845993-hd_1080_1920_30fps.mp4", duration: 10 },
    { label: "Sensual Floor Choreography (9s)", url: "https://videos.pexels.com/video-files/7845994/7845994-hd_1080_1920_30fps.mp4", duration: 9 },
    { label: "Fitness Tease Clip (16s)", url: "https://videos.pexels.com/video-files/8039133/8039133-uhd_2160_4096_25fps.mp4", duration: 16 },
    { label: "Short Vibe Reel (5s)", url: "https://videos.pexels.com/video-files/27179498/12091253_2160_3840_30fps.mp4", duration: 5 },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoUrl.trim()) {
      setError("Video URL is required for Quickies.");
      return;
    }

    if (durationSeconds > 60) {
      setError("Quickies are strictly limited to maximum 60 seconds.");
      return;
    }

    if (aspectRatio !== "9:16") {
      setError("Quickies strictly require vertical 9:16 size dimensions.");
      return;
    }

    if (currentUser?.accountType === "browsing") {
      onClose();
      openUpgradeModal("creator");
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const res = await fetch("/api/quickies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          videoUrl: videoUrl.trim(),
          durationSeconds,
          aspectRatio: "9:16",
          caption: caption.trim() || null,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to post Quickie");

      setSuccess(data.message);
      await refreshUser();
      setTimeout(() => {
        onClose();
        window.location.reload();
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white p-1 shadow-lg shadow-[#ff3358]/20">
            <Zap className="w-7 h-7 fill-white" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">Create & Upload Quickie Reel</h2>
            <p className="text-xs text-zinc-400">
              Strictly <strong className="text-amber-400">9:16 vertical reel size</strong> &bull; Max <strong className="text-amber-400">60 seconds</strong>
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Strictly 9:16 aspect ratio notification */}
          <div className="bg-[#0e1118] border border-[#ff3358]/40 p-3.5 rounded-xl text-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-black text-amber-400 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-[#ff3358]" />
                Size Dimension: 9:16 Vertical Only
              </span>
              <span className="text-[10px] bg-[#ff3358] text-white px-2 py-0.5 rounded font-black">
                9:16 Enforced
              </span>
            </div>
            <p className="text-zinc-400 text-[11px]">
              Tiktok and Reels format (1080x1920). Horizontal 16:9 or 1:1 videos are not permitted on Quickies.
            </p>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">
              Vertical 9:16 Video URL *
            </label>
            <input
              type="url"
              placeholder="https://videos.pexels.com/...mp4"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              required
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
            />
          </div>

          {/* Quick presets */}
          <div>
            <span className="text-[11px] text-zinc-400 block mb-1.5">Or choose verified 9:16 sample reel:</span>
            <div className="grid grid-cols-2 gap-2">
              {quickieVideoPresets.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => {
                    setVideoUrl(p.url);
                    setDurationSeconds(p.duration);
                  }}
                  className="p-2 rounded-xl bg-[#0e1118] hover:bg-[#181d28] border border-[#232938] text-left text-xs text-zinc-300"
                >
                  <span className="font-bold block text-white truncate">{p.label}</span>
                  <span className="text-[10px] text-emerald-400">9:16 Vertical &bull; {p.duration}s</span>
                </button>
              ))}
            </div>
          </div>

          {/* Duration slider: max 60s */}
          <div className="bg-[#0e1118] border border-[#212738] p-3 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-300 font-bold flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                Quickie Length: {durationSeconds} seconds
              </span>
              <span className="text-[10px] font-black uppercase text-amber-400">Max 60s Strict Limit</span>
            </div>
            <input
              type="range"
              min={3}
              max={60}
              step={1}
              value={durationSeconds}
              onChange={(e) => setDurationSeconds(Number(e.target.value))}
              className="w-full accent-[#ff3358] cursor-pointer"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-300 block mb-1">
              Caption & Hashtags
            </label>
            <input
              type="text"
              placeholder="#quickie #dance #nairobi #sensual"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer disabled:opacity-50"
          >
            {submitting ? "Publishing 9:16 Quickie..." : `Upload 9:16 Quickie (${durationSeconds}s max)`}
          </button>
        </form>
      </div>
    </div>
  );
}
