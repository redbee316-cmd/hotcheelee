"use client";

import React, { useState, useEffect } from "react";
import { useApp } from "@/context/AppContext";
import { Plus, Flame, Clock } from "lucide-react";

export default function StoriesBar() {
  const { openStoryViewer, openCreateStoryModal, currentUser } = useApp();
  const [groupedStories, setGroupedStories] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/stories")
      .then((res) => res.json())
      .then((data) => {
        if (data.groupedStories) {
          setGroupedStories(data.groupedStories);
        }
      })
      .catch(console.error);
  }, []);

  return (
    <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-3 sm:p-4 mb-4 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between mb-2.5 px-1">
        <span className="text-[11px] font-black uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
          <Flame className="w-3.5 h-3.5 text-[#ff3358] fill-[#ff3358] animate-flame" />
          Cheele Pro 24h Stories
        </span>
        <span className="text-[10px] text-amber-400 font-bold flex items-center gap-1">
          <Clock className="w-3 h-3" />
          Max 60 Seconds
        </span>
      </div>

      <div className="flex items-center gap-3.5 overflow-x-auto pb-1 scrollbar-none select-none">
        {/* Prominent + Plus Icon for Create Story */}
        <div
          onClick={openCreateStoryModal}
          className="flex flex-col items-center gap-1.5 shrink-0 cursor-pointer group"
          title="Upload 24h Story (Max 60s)"
        >
          <div className="relative">
            <div className="w-14 h-14 rounded-full p-0.5 bg-gradient-to-tr from-[#ff3358] via-[#ff7700] to-[#ffaa00] ring-2 ring-[#ff3358]/60 group-hover:scale-105 transition shadow-lg shadow-[#ff3358]/25 flex items-center justify-center bg-[#171d2c]">
              <img
                src={currentUser?.avatar || "https://images.pexels.com/photos/27236833/pexels-photo-27236833.jpeg"}
                alt="My Story"
                className="w-full h-full rounded-full object-cover border-2 border-[#13161f]"
              />
            </div>
            {/* Prominent Plus Badge */}
            <span className="absolute -bottom-1 -right-1 bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white p-1 rounded-full ring-2 ring-[#13161f] shadow-md group-hover:scale-110 transition">
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </span>
          </div>
          <span className="text-[11px] font-bold text-white max-w-[68px] truncate text-center group-hover:text-amber-400">
            + Add Story
          </span>
        </div>

        {/* Other Creators' Stories */}
        {groupedStories.map((group, idx) => (
          <div
            key={group.user.id}
            onClick={() => openStoryViewer(groupedStories, idx)}
            className="flex flex-col items-center gap-1.5 shrink-0 cursor-pointer group"
          >
            <div className="w-14 h-14 rounded-full p-0.5 bg-gradient-to-tr from-[#ff3358] via-[#ff7700] to-[#ff0055] shadow-sm shadow-[#ff3358]/30 group-hover:scale-105 group-hover:shadow-md group-hover:shadow-[#ff3358]/50 transition">
              <img
                src={group.user.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                alt={group.user.displayName}
                className="w-full h-full rounded-full object-cover border-2 border-[#13161f]"
              />
            </div>
            <span className="text-[11px] font-semibold text-zinc-300 max-w-[64px] truncate text-center group-hover:text-white transition">
              {group.user.displayName.split(" ")[0]}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
