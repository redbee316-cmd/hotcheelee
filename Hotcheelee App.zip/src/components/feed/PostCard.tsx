"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useApp } from "@/context/AppContext";
import {
  Flame,
  MessageCircle,
  Repeat2,
  Bookmark,
  Sparkles,
  ExternalLink,
  Check,
  UserPlus,
  Coins,
  Send,
  Volume2,
  VolumeX,
  Play,
  Pause,
  X,
  Gift,
  Lock,
  Unlock,
} from "lucide-react";

export interface PostProps {
  post: {
    id: number;
    content: string;
    mediaUrls?: string;
    media?: { url: string; type: "image" | "video"; thumbnail?: string }[];
    promoLinkUrl?: string | null;
    promoLinkLabel?: string | null;
    flamesCount: number;
    commentsCount: number;
    repostsCount: number;
    viewsCount?: number;
    leeEarnedTotal?: string;
    tagsList?: string[];
    isPinned?: boolean;
    isQuickie?: boolean;
    videoUrl?: string | null;
    unlockFeeTokens?: number;
    previewVideoUrl?: string | null;
    fullVideoUrl?: string | null;
    createdAt: string;
    hasFlamed?: boolean;
    hasBookmarked?: boolean;
    isFollowingAuthor?: boolean;
    author: {
      id: number;
      username: string;
      displayName: string;
      avatar: string | null;
      isVerifiedStar?: boolean;
      isBrand?: boolean;
      badge?: string | null;
      paysiteUrl?: string | null;
      paysiteLabel?: string | null;
    } | null;
    topic?: {
      id: number;
      slug: string;
      name: string;
      icon: string;
    } | null;
  };
}

export default function PostCard({ post }: PostProps) {
  const { openTipModal, openTipMenuModal, openToyModal, openContactModal, currentUser, triggerWatchTick } = useApp();

  const [flamed, setFlamed] = useState(Boolean(post.hasFlamed));
  const [flamesCount, setFlamesCount] = useState(post.flamesCount || 0);
  const [bookmarked, setBookmarked] = useState(Boolean(post.hasBookmarked));
  const [isFollowing, setIsFollowing] = useState(Boolean(post.isFollowingAuthor));
  const [repostsCount, setRepostsCount] = useState(post.repostsCount || 0);
  const [hasReposted, setHasReposted] = useState(false);

  // Comments state
  const [showComments, setShowComments] = useState(false);
  const [commentsList, setCommentsList] = useState<any[]>([]);
  const [commentsLoaded, setCommentsLoaded] = useState(false);
  const [commentInput, setCommentInput] = useState("");
  const [submittingComment, setSubmittingComment] = useState(false);
  const [commentsCount, setCommentsCount] = useState(post.commentsCount || 0);

  // Lightbox
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  // Video state & Sharesome Pay-to-Unlock Full Video
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [isUnlocked, setIsUnlocked] = useState(
    !post.unlockFeeTokens || post.unlockFeeTokens <= 0 || (currentUser && currentUser.id === post.author?.id)
  );
  const [unlocking, setUnlocking] = useState(false);
  const [activeVideoSrc, setActiveVideoSrc] = useState(
    post.videoUrl || (post.media && post.media[0]?.url) || ""
  );

  useEffect(() => {
    // If post has an unlock fee, query the backend unlock status
    if (post.unlockFeeTokens && post.unlockFeeTokens > 0) {
      fetch(`/api/posts/${post.id}/unlock`)
        .then((r) => r.json())
        .then((d) => {
          if (d.isUnlocked) {
            setIsUnlocked(true);
            if (d.fullVideoUrl) setActiveVideoSrc(d.fullVideoUrl);
          }
        })
        .catch(() => {});
    }
  }, [post.id, post.unlockFeeTokens]);

  const handleUnlockFullVideo = async () => {
    if (!currentUser) {
      alert("Please log in to unlock this full video.");
      return;
    }
    setUnlocking(true);
    try {
      const res = await fetch(`/api/posts/${post.id}/unlock`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setIsUnlocked(true);
        if (data.fullVideoUrl) setActiveVideoSrc(data.fullVideoUrl);
        alert(data.message || "Full video unlocked successfully!");
      } else {
        alert(data.error || "Failed to unlock full video");
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setUnlocking(false);
    }
  };

  const author = post.author;
  const topic = post.topic;
  const mediaList = post.media || [];

  const handleFlame = async () => {
    const prevFlamed = flamed;
    const prevCount = flamesCount;
    setFlamed(!flamed);
    setFlamesCount(flamed ? Math.max(0, flamesCount - 1) : flamesCount + 1);

    try {
      const res = await fetch(`/api/posts/${post.id}/flame`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setFlamed(data.flamed);
        setFlamesCount(data.flamesCount);
      } else {
        setFlamed(prevFlamed);
        setFlamesCount(prevCount);
      }
    } catch {
      setFlamed(prevFlamed);
      setFlamesCount(prevCount);
    }
  };

  const handleBookmark = async () => {
    setBookmarked(!bookmarked);
    try {
      await fetch(`/api/posts/${post.id}/bookmark`, { method: "POST" });
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleFollow = async () => {
    if (!author) return;
    const prev = isFollowing;
    setIsFollowing(!isFollowing);
    try {
      const res = await fetch(`/api/users/${author.username}/follow`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) setIsFollowing(prev);
    } catch {
      setIsFollowing(prev);
    }
  };

  const handleRepost = () => {
    if (!hasReposted) {
      setHasReposted(true);
      setRepostsCount((c) => c + 1);
    }
  };

  const loadComments = async () => {
    if (commentsLoaded) return;
    try {
      const res = await fetch(`/api/posts/${post.id}/comments`);
      const data = await res.json();
      if (res.ok) {
        setCommentsList(data.comments || []);
        setCommentsLoaded(true);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleComments = () => {
    if (!showComments) {
      loadComments();
    }
    setShowComments(!showComments);
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;

    setSubmittingComment(true);
    try {
      const res = await fetch(`/api/posts/${post.id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: commentInput.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.comment) {
        setCommentsList([data.comment, ...commentsList]);
        setCommentsCount((c) => c + 1);
        setCommentInput("");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingComment(false);
    }
  };

  const renderFormattedContent = (text: string) => {
    const parts = text.split(/(#[a-zA-Z0-9_-]+)/g);
    return parts.map((part, i) => {
      if (part.startsWith("#")) {
        const tag = part.slice(1);
        return (
          <Link
            key={i}
            href={`/discover?tag=${tag}`}
            className="text-[#ff3358] hover:underline font-semibold"
          >
            {part}
          </Link>
        );
      }
      return part;
    });
  };

  const timeAgo = (dateStr: string) => {
    const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
    if (diff < 60) return "just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  return (
    <article className="bg-[#13161f] border border-[#212735] rounded-2xl mb-5 shadow-sm overflow-hidden transition hover:border-[#2a3243]">
      {/* Lightbox Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 backdrop-blur-sm cursor-zoom-out"
          onClick={() => setLightboxImage(null)}
        >
          <button
            onClick={() => setLightboxImage(null)}
            className="absolute top-5 right-5 text-white/80 hover:text-white p-2 rounded-full bg-black/40"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={lightboxImage}
            alt="Enlarged"
            className="max-w-full max-h-[90vh] object-contain rounded-xl shadow-2xl"
          />
        </div>
      )}

      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <Link href={`/profile/${author?.username || "chily_user"}`} className="relative shrink-0">
            <img
              src={author?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
              alt={author?.displayName || "Author"}
              className="w-11 h-11 rounded-full object-cover ring-2 ring-[#ff3358]/80 hover:scale-105 transition"
            />
            {author?.isVerifiedStar && (
              <span className="absolute -bottom-1 -right-1 bg-[#ff3358] p-0.5 rounded-full ring-2 ring-[#13161f]">
                <Flame className="w-2.5 h-2.5 fill-white text-white" />
              </span>
            )}
          </Link>

          <div className="truncate">
            <div className="flex items-center gap-1.5 flex-wrap">
              <Link
                href={`/profile/${author?.username || "chily_user"}`}
                className="text-xs sm:text-sm font-bold text-white hover:text-[#ff3358] transition truncate"
              >
                {author?.displayName || "Chily Creator"}
              </Link>

              {author?.isVerifiedStar && (
                <span className="bg-[#ff3358]/20 text-[#ff3358] border border-[#ff3358]/40 text-[9px] font-black px-1.5 py-0.2 rounded uppercase">
                  ⭐ Star
                </span>
              )}
              {(author as any)?.genderRole && (
                <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[9px] font-bold px-1.5 py-0.2 rounded uppercase">
                  {(author as any).genderRole}
                </span>
              )}
              {author?.isBrand && (
                <span className="bg-amber-400/20 text-amber-400 border border-amber-400/40 text-[9px] font-black px-1.5 py-0.2 rounded uppercase">
                  🏢 Agency
                </span>
              )}

              {topic && (
                <span className="text-zinc-500 text-xs hidden sm:inline">&bull;</span>
              )}

              {topic && (
                <Link
                  href={`/topics/${topic.slug}`}
                  className="text-[11px] font-bold text-zinc-400 hover:text-white flex items-center gap-1 bg-[#1a1f2b] px-2 py-0.5 rounded-full border border-[#272e3f] transition"
                >
                  <span>{topic.icon}</span>
                  <span>#{topic.name}</span>
                </Link>
              )}
            </div>

            <div className="flex items-center gap-2 text-[11px] text-zinc-500 mt-0.5">
              <span>@{author?.username || "chily_user"}</span>
              <span>&bull;</span>
              <span>{timeAgo(post.createdAt)}</span>
              {post.isPinned && (
                <>
                  <span>&bull;</span>
                  <span className="text-[#ff3358] font-semibold">📌 Pinned</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Top Right: Attention mining status + Follow */}
        <div className="flex items-center gap-2">
          {author && currentUser && author.id !== currentUser.id && (
            <button
              onClick={handleToggleFollow}
              className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                isFollowing
                  ? "bg-[#1c2230] text-zinc-300 hover:bg-[#252c3e]"
                  : "bg-[#ff3358] hover:bg-[#e11d48] text-white shadow-sm shadow-[#ff3358]/25"
              }`}
            >
              {isFollowing ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="hidden sm:inline">Following</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-3 h-3" />
                  <span>Follow</span>
                </>
              )}
            </button>
          )}

          {author && (
            <button
              onClick={() =>
                openTipModal({
                  id: author.id,
                  username: author.username,
                  displayName: author.displayName,
                  avatar: author.avatar,
                  postId: post.id,
                })
              }
              className="p-1.5 rounded-full bg-[#1b202c] hover:bg-[#252c3e] text-zinc-400 hover:text-[#ff3358] transition cursor-pointer"
              title="Tip with Flames or $LEE"
            >
              <Flame className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Post Text Content */}
      <div className="px-4 pb-3">
        <p className="text-sm text-zinc-200 leading-relaxed whitespace-pre-line">
          {renderFormattedContent(post.content)}
        </p>
      </div>

      {/* Media: Video or Image Gallery */}
      {mediaList.length > 0 && (
        <div className="w-full bg-black relative">
          {mediaList[0].type === "video" || post.videoUrl ? (
            <div className="relative aspect-video max-h-[500px] bg-black flex items-center justify-center overflow-hidden">
              <video
                src={activeVideoSrc || mediaList[0]?.url}
                poster={mediaList[0]?.thumbnail}
                playsInline
                loop
                muted={isMuted}
                autoPlay={false}
                id={`video-${post.id}`}
                className={`w-full h-full object-cover ${!isUnlocked ? "blur-md brightness-75 scale-105" : ""}`}
                onPlay={() => {
                  setIsPlaying(true);
                  triggerWatchTick();
                }}
                onPause={() => setIsPlaying(false)}
              />

              {/* SHARESOME PAY-TO-UNLOCK OVERLAY */}
              {!isUnlocked && (
                <div className="absolute inset-0 bg-black/70 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-6 text-center space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] flex items-center justify-center text-white shadow-xl">
                    <Lock className="w-7 h-7" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white">Full Video Locked by Creator</h4>
                    <p className="text-xs text-zinc-300 max-w-sm mx-auto mt-1">
                      The creator has set an unlock fee of <strong className="text-amber-400">🪙 {post.unlockFeeTokens} Tokens (KSh {post.unlockFeeTokens ? post.unlockFeeTokens * 10 : 0})</strong> to watch the full uncut scene.
                    </p>
                  </div>

                  <button
                    disabled={unlocking}
                    onClick={handleUnlockFullVideo}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-[#ff3358] via-[#ff7700] to-[#ffaa00] hover:from-[#e11d48] text-white font-black text-xs uppercase tracking-wider transition shadow-lg shadow-[#ff3358]/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>{unlocking ? "Unlocking..." : `Unlock Full Video (${post.unlockFeeTokens} Tokens)`}</span>
                  </button>
                  <span className="text-[10px] text-zinc-400">90% of fee paid directly to {author?.displayName}</span>
                </div>
              )}

              {isUnlocked && (
                <div className="absolute bottom-3 inset-x-3 flex items-center justify-between z-20">
                  <button
                    onClick={() => {
                      const el = document.getElementById(`video-${post.id}`) as HTMLVideoElement;
                      if (el) {
                        if (el.paused) {
                          el.play();
                          setIsPlaying(true);
                          triggerWatchTick();
                        } else {
                          el.pause();
                          setIsPlaying(false);
                        }
                      }
                    }}
                    className="p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:scale-110 transition cursor-pointer"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className="p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:scale-110 transition cursor-pointer"
                    >
                      {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div
              className={`grid gap-1 ${
                mediaList.length === 1 ? "grid-cols-1" : "grid-cols-2"
              }`}
            >
              {mediaList.map((m, idx) => (
                <div
                  key={idx}
                  onClick={() => setLightboxImage(m.url)}
                  className="relative group overflow-hidden max-h-[520px] bg-black cursor-zoom-in"
                >
                  <img
                    src={m.url}
                    alt={`Post media ${idx + 1}`}
                    className="w-full h-full object-cover group-hover:scale-102 transition duration-300"
                  />
                  <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                    <span className="text-white text-xs bg-black/60 px-3 py-1 rounded-full font-bold">
                      Click to expand
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Promoted Link Banner (e.g. OnlyFans, Fansly, VIP Page) */}
      {(post.promoLinkUrl || author?.paysiteUrl) && (
        <div className="p-3 bg-gradient-to-r from-[#1a1523] via-[#161a25] to-[#1a1523] border-y border-[#262134]">
          <a
            href={post.promoLinkUrl || author?.paysiteUrl || "#"}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-2.5 rounded-xl bg-gradient-to-r from-[#ff3358]/20 via-[#ff7700]/15 to-[#ff3358]/20 hover:from-[#ff3358]/30 hover:to-[#ff7700]/30 border border-[#ff3358]/40 transition group cursor-pointer shadow-sm"
          >
            <div className="flex items-center gap-2.5">
              <span className="p-1 rounded-lg bg-[#ff3358] text-white">
                <Sparkles className="w-3.5 h-3.5" />
              </span>
              <div>
                <p className="text-xs font-bold text-white group-hover:text-amber-300 transition">
                  {post.promoLinkLabel || author?.paysiteLabel || "💋 Visit Creator's VIP Club (Uncensored)"}
                </p>
                <span className="text-[10px] text-zinc-400">Direct Adult Creator Fan Portal</span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs font-bold text-white bg-[#ff3358] group-hover:bg-[#e11d48] px-3 py-1 rounded-lg transition shadow">
              <span>Visit</span>
              <ExternalLink className="w-3 h-3" />
            </div>
          </a>
        </div>
      )}

      {/* Interactive Action Bar with Cheelee Watch-to-Earn Rewards badge */}
      <div className="px-4 py-3 flex items-center justify-between border-t border-[#1e2330]">
        <div className="flex items-center gap-1 sm:gap-3">
          <button
            onClick={handleFlame}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition cursor-pointer ${
              flamed
                ? "bg-[#ff3358]/20 text-[#ff3358] border border-[#ff3358]/50 shadow-sm shadow-[#ff3358]/20"
                : "text-zinc-400 hover:text-white hover:bg-[#1a202c]"
            }`}
          >
            <Flame className={`w-4 h-4 ${flamed ? "fill-[#ff3358] text-[#ff3358] animate-flame" : ""}`} />
            <span>{flamesCount.toLocaleString()}</span>
          </button>

          <button
            onClick={toggleComments}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold text-zinc-400 hover:text-white hover:bg-[#1a202c] transition cursor-pointer"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{commentsCount.toLocaleString()}</span>
          </button>

          <button
            onClick={handleRepost}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition cursor-pointer ${
              hasReposted
                ? "text-emerald-400 bg-emerald-500/10"
                : "text-zinc-400 hover:text-white hover:bg-[#1a202c]"
            }`}
          >
            <Repeat2 className="w-4 h-4" />
            <span className="hidden sm:inline">{repostsCount}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Post LEE Token yield counter */}
          <div
            className="hidden sm:flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-[#161a24] border border-[#262c3b] px-2.5 py-1 rounded-full cursor-pointer hover:border-amber-400/50"
            onClick={triggerWatchTick}
            title="Click to claim attention viewing minute"
          >
            <Coins className="w-3 h-3" />
            <span>+{post.leeEarnedTotal || "12.40"} $LEE</span>
          </div>

          {author && (author as any).phone && (
            <button
              onClick={() =>
                openContactModal({
                  id: author.id,
                  username: author.username,
                  displayName: author.displayName,
                  avatar: author.avatar,
                  phone: (author as any).phone,
                  genderRole: (author as any).genderRole,
                  locationArea: (author as any).locationArea,
                  serviceType: (author as any).serviceType,
                  allowWhatsapp: (author as any).allowWhatsapp,
                  allowCalls: (author as any).allowCalls,
                  allowSms: (author as any).allowSms,
                })
              }
              className="px-2.5 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <span>Contact</span>
            </button>
          )}

          {author && (
            <button
              onClick={() =>
                openTipModal({
                  id: author.id,
                  username: author.username,
                  displayName: author.displayName,
                  avatar: author.avatar,
                  postId: post.id,
                })
              }
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white text-xs font-bold shadow-md shadow-[#ff3358]/25 transition cursor-pointer"
            >
              <Flame className="w-3.5 h-3.5 fill-white" />
              <span>Tip</span>
            </button>
          )}

          <button
            onClick={handleBookmark}
            className={`p-2 rounded-full transition cursor-pointer ${
              bookmarked
                ? "text-[#ff3358] bg-[#ff3358]/15"
                : "text-zinc-400 hover:text-white hover:bg-[#1a202c]"
            }`}
            title="Bookmark"
          >
            <Bookmark className={`w-4 h-4 ${bookmarked ? "fill-[#ff3358]" : ""}`} />
          </button>
        </div>
      </div>

      {/* Expandable Comments Drawer */}
      {showComments && (
        <div className="bg-[#0e1118] border-t border-[#1d222e] p-4 space-y-4 animate-in fade-in duration-150">
          <form onSubmit={handleAddComment} className="flex items-center gap-2">
            <img
              src={currentUser?.avatar || "https://images.pexels.com/photos/27236833/pexels-photo-27236833.jpeg"}
              alt="avatar"
              className="w-8 h-8 rounded-full object-cover ring-1 ring-[#ff3358]"
            />
            <input
              type="text"
              placeholder="Leave a supportive comment for the creator..."
              value={commentInput}
              onChange={(e) => setCommentInput(e.target.value)}
              className="flex-1 bg-[#141822] border border-[#252c3d] rounded-full px-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
            />
            <button
              type="submit"
              disabled={submittingComment || !commentInput.trim()}
              className="p-2 rounded-full bg-[#ff3358] hover:bg-[#e11d48] disabled:opacity-40 text-white transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

          <div className="space-y-3 pt-1">
            {commentsList.length === 0 ? (
              <p className="text-center text-xs text-zinc-500 py-3">
                No comments yet. Be the first to spark the conversation! 🔥
              </p>
            ) : (
              commentsList.map((c) => (
                <div key={c.id} className="flex items-start gap-2.5">
                  <Link href={`/profile/${c.author?.username || "chily_user"}`}>
                    <img
                      src={c.author?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                      alt="avatar"
                      className="w-7 h-7 rounded-full object-cover shrink-0 ring-1 ring-[#ff3358]/50"
                    />
                  </Link>
                  <div className="flex-1 bg-[#141822] border border-[#212738] rounded-2xl p-2.5 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <Link
                          href={`/profile/${c.author?.username || "chily_user"}`}
                          className="font-bold text-white hover:text-[#ff3358]"
                        >
                          {c.author?.displayName || "Member"}
                        </Link>
                        {c.author?.isVerifiedStar && (
                          <span className="text-[9px] bg-[#ff3358] text-white px-1 rounded font-black">
                            STAR
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-zinc-500">
                        {timeAgo(c.createdAt)}
                      </span>
                    </div>
                    <p className="text-zinc-300 leading-snug">{c.content}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </article>
  );
}
