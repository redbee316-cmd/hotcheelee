"use client";

import React from "react";
import { useApp } from "@/context/AppContext";
import { Image as ImageIcon, Video, FolderPlus, Link as LinkIcon, Sparkles } from "lucide-react";

export default function QuickPostBox() {
  const { openCreatePostModal, currentUser } = useApp();

  return (
    <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-3.5 sm:p-4 mb-5 shadow-sm">
      <div className="flex items-center gap-3 mb-3">
        <img
          src={currentUser?.avatar || "https://images.pexels.com/photos/27236833/pexels-photo-27236833.jpeg"}
          alt="Avatar"
          className="w-10 h-10 rounded-full object-cover ring-2 ring-[#ff3358]"
        />
        <button
          onClick={() => openCreatePostModal()}
          className="flex-1 text-left bg-[#0e1118] hover:bg-[#161a24] border border-[#212736] rounded-full px-4 py-2.5 text-xs text-zinc-400 hover:text-zinc-200 transition cursor-pointer"
        >
          Share a photo, video, or tease new adult content...
        </button>
      </div>

      <div className="flex items-center justify-between pt-2 border-t border-[#1d222f] text-xs">
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => openCreatePostModal()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#181d28] transition cursor-pointer"
          >
            <ImageIcon className="w-4 h-4 text-[#ff3358]" />
            <span className="hidden sm:inline">Photo</span>
          </button>
          <button
            onClick={() => openCreatePostModal()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#181d28] transition cursor-pointer"
          >
            <Video className="w-4 h-4 text-[#ff7700]" />
            <span className="hidden sm:inline">Video / Reel</span>
          </button>
          <button
            onClick={() => openCreatePostModal()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#181d28] transition cursor-pointer"
          >
            <FolderPlus className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Choose Topic</span>
          </button>
          <button
            onClick={() => openCreatePostModal()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#181d28] transition cursor-pointer"
          >
            <LinkIcon className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">OnlyFans Link</span>
          </button>
        </div>

        <button
          onClick={() => openCreatePostModal()}
          className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#ff3358] to-[#ff5033] text-white text-xs font-bold shadow-md shadow-[#ff3358]/25 hover:from-[#e11d48] hover:to-[#ea580c] transition cursor-pointer"
        >
          Post
        </button>
      </div>
    </div>
  );
}
