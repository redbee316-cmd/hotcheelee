"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useApp } from "@/context/AppContext";
import {
  X,
  Search,
  BookOpen,
  Calendar,
  Users,
  Compass,
  ShoppingBag,
  Coins,
  Trophy,
  BarChart3,
  Layers,
  Sparkles,
  Zap,
  Bookmark,
  Building2,
  Star,
  Settings,
  ShieldAlert,
  ArrowRight,
  Plus,
  Crown,
  TrendingUp,
  Clock,
} from "lucide-react";

interface FacebookMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function FacebookMenuDrawer({ isOpen, onClose }: FacebookMenuDrawerProps) {
  const {
    currentUser,
    openCreatePostModal,
    openCreateStoryModal,
    openCreateQuickieModal,
    openCreateAdModal,
    openUpgradeModal,
    openCreateProfileModal,
    openTokensModal,
    openWalletModal,
  } = useApp();

  const [menuSearch, setMenuSearch] = useState("");

  if (!isOpen) return null;

  const socialSections = [
    {
      title: "Social & Community",
      items: [
        { label: "Friends & Follows", desc: "Mutual friends and follow-for-follow requests", href: "/", icon: Users, badge: "Mutual" },
        { label: "HotCheelee Groups", desc: "Join public or secret adult community groups", href: "/groups", icon: Users, badge: "FB" },
        { label: "HotCheelee Pages", desc: "Explore verified business pages and parlour brands", href: "/pages", icon: Layers, badge: "FB" },
        { label: "Community Topics", desc: "Fetish, glamour and cosplay forum discussions", href: "/topics", icon: Compass },
      ],
    },
    {
      title: "Entertainment & Video",
      items: [
        { label: "Quickies Reels (9:16)", desc: "Strict vertical reels up to 60s max", href: "/quickies", icon: Zap, badge: "HOT" },
        { label: "Popular Feed", desc: "Top flamed and trending posts in Kenya", href: "/popular", icon: TrendingUp },
        { label: "NFT Glasses Market", desc: "Attention economy glasses with up to 3.3x earnings", href: "/marketplace", icon: Zap, badge: "3.3X" },
      ],
    },
    {
      title: "Commerce & Finance",
      items: [
        { label: "Facebook Marketplace", desc: "Adult toys, lingerie, outfits & discrete items", href: "/marketplace-fb", icon: ShoppingBag, badge: "KSh" },
        { label: "HotCheelee PtoP Finance", desc: "Peer-to-peer loans, guarantees & 10% returns", href: "/finance", icon: Coins, badge: "KES" },
        { label: "PtoP Predictions & Jackpots", desc: "Daily/weekly jackpots & match predictions (90% win)", href: "/predictions", icon: Trophy, badge: "90%" },
        { label: "Manual KSh Wallet", desc: "M-Pesa deposits and creator token withdrawals", href: "/wallet", icon: Coins },
      ],
    },
    {
      title: "Professional & Admin",
      items: [
        { label: "Creator Studio Dashboard", desc: "Professional analytics, 28-day reach & video views", href: "/creator-studio", icon: BarChart3, badge: "PRO" },
        { label: "Admin Moderation Portal", desc: "Approve 30-day subscriptions, deposits & ads", href: "/admin", icon: ShieldAlert, badge: "ADMIN" },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-2xl h-full bg-[#11151f] border-l border-[#242c3d] shadow-2xl flex flex-col justify-between overflow-hidden animate-in slide-in-from-right duration-200">
        {/* Top Header */}
        <div className="p-4 px-6 border-b border-[#212838] flex items-center justify-between bg-[#141a27]">
          <div>
            <h2 className="text-xl font-black text-white">HotCheelee Menu</h2>
            <p className="text-xs text-zinc-400">All shortcuts, creation tools & platform directories</p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#1e2638] text-zinc-300 hover:text-white hover:bg-[#ff3358] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Split into Left Shortcuts & Right Create Box (Facebook Menu Mechanic) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-6 scrollbar-none">
          {/* Left Column (8 cols): Navigation Grid */}
          <div className="md:col-span-7 space-y-6">
            {/* Menu Search */}
            <div className="relative">
              <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search menu shortcuts..."
                value={menuSearch}
                onChange={(e) => setMenuSearch(e.target.value)}
                className="w-full bg-[#171f2f] border border-[#26334a] rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
            </div>

            {socialSections.map((sec) => {
              const filteredItems = sec.items.filter(
                (i) =>
                  !menuSearch ||
                  i.label.toLowerCase().includes(menuSearch.toLowerCase()) ||
                  i.desc.toLowerCase().includes(menuSearch.toLowerCase())
              );
              if (filteredItems.length === 0) return null;

              return (
                <div key={sec.title} className="space-y-2">
                  <h3 className="text-xs font-black uppercase tracking-wider text-zinc-400">
                    {sec.title}
                  </h3>
                  <div className="space-y-1">
                    {filteredItems.map((item) => {
                      const Icon = item.icon;
                      return (
                        <Link
                          key={item.label}
                          href={item.href}
                          onClick={onClose}
                          className="p-2.5 rounded-xl bg-[#141b27] hover:bg-[#1c2638] border border-transparent hover:border-[#2b3a50] flex items-center gap-3 transition group"
                        >
                          <div className="w-9 h-9 rounded-xl bg-[#1a2333] group-hover:bg-[#ff3358] text-white flex items-center justify-center shrink-0 transition">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white group-hover:text-amber-300 truncate">
                                {item.label}
                              </span>
                              {item.badge && (
                                <span className="text-[9px] bg-black/40 text-amber-400 font-bold px-1.5 py-0.2 rounded">
                                  {item.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-zinc-400 truncate mt-0.5">{item.desc}</p>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column (5 cols): "Create" Actions Panel (Facebook Menu Right Side) */}
          <div className="md:col-span-5 bg-[#141a27] border border-[#242d3f] rounded-2xl p-4 self-start space-y-3">
            <h3 className="text-xs font-black uppercase text-white tracking-wider flex items-center gap-1.5 pb-2 border-b border-[#212a3d]">
              <Plus className="w-4 h-4 text-[#ff3358]" />
              <span>Create / Publish</span>
            </h3>

            <div className="space-y-2">
              <button
                onClick={() => {
                  onClose();
                  openCreatePostModal();
                }}
                className="w-full p-2 rounded-xl bg-[#1a2233] hover:bg-[#25324d] text-left text-xs flex items-center gap-2.5 transition cursor-pointer"
              >
                <div className="p-1.5 rounded-lg bg-[#ff3358] text-white">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block">Post to Feed</strong>
                  <span className="text-[10px] text-zinc-400">Photos or Videos</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onClose();
                  openCreateStoryModal();
                }}
                className="w-full p-2 rounded-xl bg-[#1a2233] hover:bg-[#25324d] text-left text-xs flex items-center gap-2.5 transition cursor-pointer"
              >
                <div className="p-1.5 rounded-lg bg-amber-500 text-white">
                  <Clock className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block">24h Story</strong>
                  <span className="text-[10px] text-zinc-400">Max 60 seconds</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onClose();
                  openCreateQuickieModal();
                }}
                className="w-full p-2 rounded-xl bg-[#1a2233] hover:bg-[#25324d] text-left text-xs flex items-center gap-2.5 transition cursor-pointer"
              >
                <div className="p-1.5 rounded-lg bg-emerald-500 text-white">
                  <Zap className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block">9:16 Quickie Reel</strong>
                  <span className="text-[10px] text-zinc-400">Vertical reel max 60s</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onClose();
                  openCreateAdModal();
                }}
                className="w-full p-2 rounded-xl bg-[#1a2233] hover:bg-[#25324d] text-left text-xs flex items-center gap-2.5 transition cursor-pointer"
              >
                <div className="p-1.5 rounded-lg bg-purple-500 text-white">
                  <Crown className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block">Sponsored Ad</strong>
                  <span className="text-[10px] text-zinc-400">Pay with coins</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onClose();
                  openCreateProfileModal();
                }}
                className="w-full p-2 rounded-xl bg-[#1a2233] hover:bg-[#25324d] text-left text-xs flex items-center gap-2.5 transition cursor-pointer"
              >
                <div className="p-1.5 rounded-lg bg-sky-500 text-white">
                  <Users className="w-3.5 h-3.5" />
                </div>
                <div>
                  <strong className="text-white block">New Profile (5+)</strong>
                  <span className="text-[10px] text-zinc-400">Free, Creator or Agency</span>
                </div>
              </button>

              <button
                onClick={() => {
                  onClose();
                  openUpgradeModal("creator");
                }}
                className="w-full p-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                <Crown className="w-3.5 h-3.5" />
                <span>Upgrade to 30-Day Listing</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
