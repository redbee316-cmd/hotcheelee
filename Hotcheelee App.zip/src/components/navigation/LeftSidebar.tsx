"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useApp } from "@/context/AppContext";
import {
  Home,
  Compass,
  FolderTree,
  TrendingUp,
  Zap,
  Star,
  Building2,
  Bookmark,
  MessageSquare,
  Flame,
  ShieldCheck,
  ChevronRight,
  Plus,
  Coins,
  Gift,
  Crown,
  Heart,
  ShieldAlert,
  Layers,
  ShoppingBag,
  Users,
  Trophy,
  DollarSign,
  HeartHandshake,
  BarChart3,
  Bell,
  Sparkles,
  Lock,
} from "lucide-react";

export default function LeftSidebar() {
  const pathname = usePathname();
  const { openTokensModal, openUpgradeModal, openCreateProfileModal, currentUser, triggerWatchTick } = useApp();
  const [popularTopics, setPopularTopics] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/topics")
      .then((res) => res.json())
      .then((data) => {
        if (data.topics) {
          setPopularTopics(data.topics.slice(0, 5));
        }
      })
      .catch(console.error);
  }, []);

  // Primary navigation including HotCheelee Groups, Marketplace, PtoP Finance, PtoP Predictions, Creators, Agencies, NFT Market
  const primaryLinks = [
    { href: "/", label: "Home Feed", icon: Home },
    { href: "/categories", label: "HotCheelee Categories", icon: Sparkles, badge: "HOT" },
    { href: "/private-show", label: "Private Shows (1-on-1)", icon: Zap, badge: "CAM" },
    { href: "/creator-studio", label: "Creators Dashboard", icon: BarChart3, badge: "PRO" },
    { href: "/pages", label: "HotCheelee Pages", icon: Layers, badge: "FB" },
    { href: "/groups", label: "HotCheelee Groups", icon: Users, badge: "FB" },
    { href: "/marketplace-fb", label: "Marketplace (Adult Goods)", icon: ShoppingBag, badge: "FB" },
    { href: "/stars", label: "Creators Directory", icon: Star, badge: "VERIFIED" },
    { href: "/brands", label: "Agencies & Parlours", icon: Building2, badge: "KSh" },
    { href: "/finance", label: "HotCheelee PtoP Finance", icon: HeartHandshake, badge: "KES" },
    { href: "/predictions", label: "PtoP Predictions & Jackpots", icon: Trophy, badge: "90%" },
    { href: "/marketplace", label: "NFT Glasses Market", icon: Zap, badge: "3.3X" },
    { href: "/notifications", label: "Notifications Hub", icon: Bell },
    { href: "/discover", label: "Discover", icon: Compass },
    { href: "/topics", label: "Topics", icon: FolderTree },
    { href: "/popular", label: "Popular", icon: TrendingUp },
    { href: "/quickies", label: "Quickies Reels (9:16)", icon: Zap, badge: "HOT" },
    { href: "/messages", label: "Messenger", icon: MessageSquare, badge: "NEW" },
    { href: "/wallet", label: "Manual KSh Wallet", icon: Coins },
    { href: "/saved", label: "Saved Posts", icon: Bookmark },
  ];

  return (
    <aside className="w-64 shrink-0 hidden lg:block sticky top-28 self-start space-y-3.5">
      {/* 1. Admin Moderation Section Banner on the Left Column */}
      <div className="bg-gradient-to-r from-[#2a131b] to-[#1a1524] border border-[#ff3358]/50 rounded-2xl p-3 shadow-md">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-[#ff3358]" />
            <span className="text-xs font-black uppercase text-white tracking-wider">
              Admin Moderation
            </span>
          </div>
          <span className="text-[10px] bg-[#ff3358] text-white font-bold px-1.5 py-0.2 rounded">
            PORTAL
          </span>
        </div>
        <p className="text-[11px] text-zinc-300 leading-snug mb-2">
          Moderates 30-day subscriptions, deposits, ads, withdrawals & user profiles.
        </p>
        <Link
          href="/admin"
          className="w-full py-1.5 px-3 rounded-xl bg-[#ff3358] hover:bg-[#e11d48] text-white text-xs font-bold transition flex items-center justify-center gap-1.5 shadow"
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Open Admin Dashboard &rarr;</span>
        </Link>
      </div>

      {/* 2. HotCheelee Premium Upgrade Now Section */}
      <div className="bg-gradient-to-br from-[#1c1828] via-[#141926] to-[#0e121b] border border-amber-400/40 rounded-2xl p-3 shadow-sm space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Crown className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-black uppercase text-amber-300">
              HotCheelee Premium
            </span>
          </div>
          <span className="text-[10px] bg-amber-400/20 text-amber-300 font-bold px-1.5 py-0.2 rounded">
            30 Days
          </span>
        </div>
        <p className="text-[11px] text-zinc-300 leading-snug">
          Free accounts can upgrade to Creator (KSh 500) or Agency (KSh 1,500). Creators can upgrade to Agency mode.
        </p>
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() => openUpgradeModal("creator")}
            className="flex-1 py-1 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-[11px] font-bold transition cursor-pointer shadow-sm text-center"
          >
            Upgrade Now
          </button>
          <button
            onClick={openCreateProfileModal}
            className="py-1 px-2.5 rounded-xl bg-[#1d2332] hover:bg-[#283246] text-zinc-300 text-[11px] font-bold transition cursor-pointer"
            title="Create extra profile (5+ profiles supported)"
          >
            + Profile
          </button>
        </div>
      </div>

      {/* 3. Normal Manual Wallet (1 Token = 10 KSh) */}
      <div className="bg-[#121620] border border-[#232938] rounded-2xl p-3 shadow-sm space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-zinc-300">My Coins Wallet</span>
          <span className="text-[10px] text-amber-400 font-mono font-bold">1 tk = 10 KSh</span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-base font-black text-amber-400">
            <Coins className="w-4 h-4" />
            <span>{currentUser?.tokensBalance ?? 350} tk</span>
          </div>
          <button
            onClick={openTokensModal}
            className="px-2.5 py-1 rounded-lg bg-amber-400/20 text-amber-300 text-[10px] font-bold hover:bg-amber-400 hover:text-black transition cursor-pointer"
          >
            Buy Coins
          </button>
        </div>
      </div>

      {/* 4. Primary Navigation Menu (With Groups, Marketplace, PtoP Finance & Predictions) */}
      <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-2 shadow-sm">
        <nav className="space-y-0.5">
          {primaryLinks.map((link) => {
            const Icon = link.icon;
            const isActive =
              link.href === "/"
                ? pathname === "/"
                : pathname === link.href || pathname.startsWith(link.href + "/");

            return (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center justify-between px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                  isActive
                    ? "text-white bg-[#1e2432] shadow-sm"
                    : "text-zinc-400 hover:text-white hover:bg-[#181d28]"
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? "text-[#ff3358]" : "text-zinc-400"
                    }`}
                  />
                  <span className="truncate">{link.label}</span>
                </div>
                {link.badge && (
                  <span className={`text-[9px] font-black px-1.5 py-0.2 rounded shrink-0 ${
                    link.badge === "3.3X" ? "bg-amber-400 text-black" : link.badge === "KES" ? "bg-emerald-500/20 text-emerald-400" : "bg-[#ff3358] text-white"
                  }`}>
                    {link.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* 5. Featured Topics Section */}
      <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
            <FolderTree className="w-3.5 h-3.5 text-[#ff3358]" />
            Hot Topics
          </span>
          <Link
            href="/topics/new"
            className="text-[11px] text-[#ff3358] hover:underline font-bold flex items-center gap-0.5"
          >
            <Plus className="w-3 h-3" />
            <span>New</span>
          </Link>
        </div>

        <div className="space-y-1">
          {popularTopics.map((topic) => (
            <Link
              key={topic.id}
              href={`/topics/${topic.slug}`}
              className="flex items-center justify-between p-1.5 rounded-xl hover:bg-[#181d28] transition group"
            >
              <div className="flex items-center gap-2 truncate">
                <span className="text-xs">{topic.icon}</span>
                <span className="text-xs font-semibold text-zinc-300 group-hover:text-white truncate">
                  #{topic.name}
                </span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-zinc-600 group-hover:text-zinc-400" />
            </Link>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="px-2 text-[10px] text-zinc-500 space-y-1">
        <div className="flex items-center gap-1 text-zinc-400 font-semibold">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>18+ Consenting Adults Kenya</span>
        </div>
        <p className="text-[10px] text-zinc-600">
          &copy; {new Date().getFullYear()} HotCheelee. Universal Currency: KSh.
        </p>
      </div>
    </aside>
  );
}
