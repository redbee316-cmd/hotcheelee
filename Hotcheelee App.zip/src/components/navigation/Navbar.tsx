"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useApp } from "@/context/AppContext";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import FacebookMenuDrawer from "@/components/navigation/FacebookMenuDrawer";
import {
  Flame,
  Search,
  Plus,
  Bell,
  MessageSquare,
  Compass,
  FolderTree,
  TrendingUp,
  Zap,
  Star,
  Building2,
  Bookmark,
  User,
  ChevronDown,
  Coins,
  Crown,
  ShieldAlert,
  LogOut,
  UserPlus,
  LogIn,
  Layers,
  LayoutGrid,
} from "lucide-react";

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const {
    currentUser,
    unreadNotifications,
    openCreatePostModal,
    openTokensModal,
    openWalletModal,
    openAuthModal,
    openUpgradeModal,
    openCreateProfileModal,
    lastDroppedBox,
    dismissDroppedBox,
    colorTheme,
    setColorTheme,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showFacebookMenu, setShowFacebookMenu] = useState(false);
  const [notificationsList, setNotificationsList] = useState<any[]>([]);
  const notifRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const fetchNotifications = async () => {
    try {
      const res = await fetch("/api/notifications");
      if (res.ok) {
        const data = await res.json();
        setNotificationsList(data.notifications || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleNotifications = () => {
    if (!showNotifications) {
      fetchNotifications();
      fetch("/api/notifications", { method: "PATCH" });
    }
    setShowNotifications(!showNotifications);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/discover?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      window.location.reload();
    } catch (e) {
      console.error(e);
    }
  };

  // Clean Header Links
  const cleanNavLinks = [
    { href: "/discover", label: "Discover", icon: Compass },
    { href: "/topics", label: "Topics", icon: FolderTree },
    { href: "/popular", label: "Popular", icon: TrendingUp },
    { href: "/quickies", label: "Quickies", icon: Zap, badge: "HOT" },
  ];

  return (
    <>
      <div className="w-full bg-[#0d0f14]/98 backdrop-blur-md border-b border-[#212634] sticky top-0 z-40">
        {/* 1. Top Notice Bar */}
        <div className="bg-[#121620] border-b border-[#212735] text-zinc-300 py-1.5 px-3 sm:px-6 text-[11px] overflow-hidden">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3 truncate">
              <span className="text-emerald-400 font-bold flex items-center gap-1 shrink-0">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Free Browsing Mode
              </span>
              <span className="text-zinc-600 hidden md:inline">|</span>
              <span className="truncate hidden md:inline">
                Creators: <strong>KSh 500/mo</strong> &bull; Agencies: <strong>KSh 1,500/mo</strong>
              </span>
              <span className="text-zinc-600 hidden sm:inline">|</span>
              <span className="text-amber-400 font-bold truncate">
                M-Pesa Buy Goods Till: 8923411
              </span>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => openUpgradeModal("creator")}
                className="text-[#ff3358] hover:underline font-bold flex items-center gap-1 cursor-pointer"
              >
                <Crown className="w-3.5 h-3.5" />
                <span>HotCheelee Premium Upgrade</span>
              </button>
              <span className="text-zinc-600">|</span>
              <span className="text-zinc-400">1 Token = 10 KSh</span>
            </div>
          </div>
        </div>

        {/* 2. Main Clean Header Row */}
        <header className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3">
          {/* Left: Brand Logo & HotCheelee */}
          <div className="flex items-center gap-5 shrink-0">
            <Link href="/" className="flex items-center gap-2.5 group">
              <div className="w-10 h-10 rounded-2xl bg-[#141722] border border-[#ff3358]/40 flex items-center justify-center shadow-lg shadow-[#ff3358]/20 group-hover:scale-105 group-hover:border-[#ff3358] transition p-1">
                <HotCheeleeLogo size={30} />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 leading-none">
                  <span className="text-xl font-black tracking-tight text-white group-hover:text-[#ff3358] transition">
                    Hot<span className="text-[#ff3358]">Cheelee</span>
                  </span>
                  <span className="text-[10px] font-black uppercase tracking-wider bg-[#ff3358]/20 text-[#ff3358] px-1.5 py-0.5 rounded border border-[#ff3358]/30">
                    18+ KE
                  </span>
                </div>
                <span className="text-[9px] font-bold text-zinc-400 tracking-wider uppercase mt-0.5">
                  Adult SocialFi &bull; KSh
                </span>
              </div>
            </Link>

            {/* Clean Desktop Navigation Feeds */}
            <nav className="hidden md:flex items-center gap-1">
              {cleanNavLinks.map((link) => {
                const Icon = link.icon;
                const isActive = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      isActive
                        ? "text-white bg-[#1b212d] shadow-sm"
                        : "text-zinc-400 hover:text-white hover:bg-[#141822]"
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? "text-[#ff3358]" : ""}`} />
                    <span>{link.label}</span>
                    {link.badge && (
                      <span className="bg-[#ff3358] text-white text-[9px] font-black px-1 rounded-sm">
                        {link.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Right Header Action Icons */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Join Free to Browse */}
            <button
              onClick={() => openAuthModal("join_free")}
              className="hidden sm:inline-flex items-center gap-1.5 py-1.5 px-3 rounded-full text-xs font-bold text-zinc-300 hover:text-white bg-[#161a25] hover:bg-[#202738] border border-[#262c3b] transition cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Join Free</span>
            </button>

            {/* HOTCHEELEE MENU ICON (Facebook 9-Dots Grid Menu) */}
            <button
              onClick={() => setShowFacebookMenu(true)}
              className="p-2 rounded-full bg-[#171d2b] hover:bg-[#242f44] text-zinc-200 hover:text-white transition cursor-pointer shadow flex items-center justify-center"
              title="HotCheelee Menu (Facebook Menu Clone)"
            >
              <LayoutGrid className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            </button>

            {/* + Post Button */}
            <button
              onClick={() => openCreatePostModal()}
              className="py-1.5 px-3 sm:px-3.5 rounded-full text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] shadow-md shadow-[#ff3358]/25 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Post</span>
            </button>

            {/* Theme Toggle Selector (Current Flame, Facebook Blue, Gittr Gold, Pink) */}
            <div className="relative group">
              <button
                className="p-2 rounded-full bg-[#171c26] hover:bg-[#202736] border border-white/10 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                title="Switch Color Theme"
              >
                <span className="w-3.5 h-3.5 rounded-full border border-white/20 bg-gradient-to-r from-[#ff3358] via-[#1877f2] to-[#ec4899]" />
                <ChevronDown className="w-3 h-3 text-zinc-400 hidden sm:block" />
              </button>

              <div className="absolute right-0 mt-1 w-44 bg-[#151922] border border-[#272e3f] rounded-xl shadow-2xl py-1.5 z-50 hidden group-hover:block text-xs">
                <span className="px-3 py-1 text-[10px] text-zinc-400 font-bold uppercase block">
                  Select Color Theme
                </span>
                <button
                  onClick={() => setColorTheme("flame")}
                  className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-[#1a202c] text-left text-zinc-200 hover:text-white"
                >
                  <span className="w-3 h-3 rounded-full bg-[#ff3358]" />
                  <span>Current Flame 🔥</span>
                </button>
                <button
                  onClick={() => setColorTheme("fb_blue")}
                  className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-[#1a202c] text-left text-zinc-200 hover:text-white"
                >
                  <span className="w-3 h-3 rounded-full bg-[#1877f2]" />
                  <span>Facebook Blue</span>
                </button>
                <button
                  onClick={() => setColorTheme("gittr_gold")}
                  className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-[#1a202c] text-left text-zinc-200 hover:text-white"
                >
                  <span className="w-3 h-3 rounded-full bg-[#f59e0b]" />
                  <span>Gittr Gold</span>
                </button>
                <button
                  onClick={() => setColorTheme("pink")}
                  className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-[#1a202c] text-left text-zinc-200 hover:text-white"
                >
                  <span className="w-3 h-3 rounded-full bg-[#ec4899]" />
                  <span>Pink Colours</span>
                </button>
              </div>
            </div>

            {/* Tokens Button (KSh) */}
            <button
              onClick={openTokensModal}
              className="flex items-center gap-1.5 bg-[#171c26] hover:bg-[#202736] border border-amber-400/40 rounded-full px-3 py-1.5 transition cursor-pointer group shadow-sm"
              title="HotCheelee Tokens Balance"
            >
              <Coins className="w-4 h-4 text-amber-400 group-hover:scale-110 transition" />
              <span className="text-xs font-black text-amber-400">
                {currentUser?.tokensBalance ?? 350} tk
              </span>
            </button>

            {/* Messages */}
            <Link
              href="/messages"
              className="relative p-2 rounded-full text-zinc-400 hover:text-white hover:bg-[#151a24] transition"
              title="Messages"
            >
              <MessageSquare className="w-4 h-4 sm:w-5 sm:h-5" />
            </Link>

            {/* Notifications Dropdown */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={handleToggleNotifications}
                className="relative p-2 rounded-full text-zinc-400 hover:text-white hover:bg-[#151a24] transition cursor-pointer"
                title="Notifications"
              >
                <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                {unreadNotifications > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#ff3358] rounded-full ring-2 ring-[#0d0f14]" />
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-[#151922] border border-[#272e3f] rounded-2xl shadow-2xl py-2 z-50 text-left animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-4 py-2 border-b border-[#242b3b] flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Notifications</span>
                    <Link
                      href="/notifications"
                      onClick={() => setShowNotifications(false)}
                      className="text-[10px] text-[#ff3358] hover:underline font-bold"
                    >
                      View Hub &rarr;
                    </Link>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-[#1e2330]">
                    {notificationsList.length === 0 ? (
                      <div className="py-6 text-center text-xs text-zinc-500">
                        No notifications yet
                      </div>
                    ) : (
                      notificationsList.map((n) => (
                        <div
                          key={n.id}
                          className={`p-3 text-xs flex items-start gap-2.5 hover:bg-[#1a202c] transition ${
                            !n.isRead ? "bg-[#181d28]" : ""
                          }`}
                        >
                          <img
                            src={n.actor?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                            alt="avatar"
                            className="w-8 h-8 rounded-full object-cover shrink-0 ring-1 ring-[#ff3358]"
                          />
                          <div className="flex-1">
                            <p className="text-zinc-300 leading-snug">{n.message}</p>
                            <span className="text-[10px] text-zinc-500 mt-1 block">
                              {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Profile Menu */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-1.5 p-1 rounded-full hover:ring-2 hover:ring-[#ff3358]/50 transition cursor-pointer"
              >
                <img
                  src={currentUser?.avatar || "https://images.pexels.com/photos/27236833/pexels-photo-27236833.jpeg"}
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-[#ff3358]"
                />
                <ChevronDown className="w-3.5 h-3.5 text-zinc-400 hidden sm:block" />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-[#151922] border border-[#272e3f] rounded-2xl shadow-2xl py-2 z-50 text-left animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-4 py-2 border-b border-[#242b3b]">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-bold text-white truncate">
                        {currentUser?.displayName || "Alex Rivers"}
                      </p>
                      <span className="text-[10px] bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-black px-1.5 py-0.2 rounded uppercase">
                        {currentUser?.accountType || "browsing"}
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-400 truncate">
                      @{currentUser?.username || "alex_member"} &bull; {currentUser?.locationArea || "Kilimani"}
                    </p>
                    <div className="mt-1 flex items-center justify-between text-[11px] text-amber-400 font-bold">
                      <span>{currentUser?.tokensBalance ?? 350} Tokens</span>
                      <span className="text-emerald-400">
                        {currentUser?.subscriptionStatus === "active" ? "Subscribed 30d ✓" : "Free Plan"}
                      </span>
                    </div>
                  </div>

                  <div className="py-1">
                    <Link
                      href={`/profile/${currentUser?.username || "alex_member"}`}
                      onClick={() => setShowUserMenu(false)}
                      className="px-4 py-2 text-xs text-zinc-300 hover:text-white hover:bg-[#1a202c] flex items-center gap-2"
                    >
                      <User className="w-4 h-4 text-zinc-400" />
                      <span>My Profile</span>
                    </Link>

                    {/* HotCheelee Premium Upgrade Now */}
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        openUpgradeModal("creator");
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-amber-300 hover:text-white hover:bg-[#1a202c] flex items-center gap-2 font-bold cursor-pointer"
                    >
                      <Crown className="w-4 h-4 text-amber-400" />
                      <span>HotCheelee Premium (Upgrade Now)</span>
                    </button>

                    {/* Create New Profile (Multi-profile support) */}
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        openCreateProfileModal();
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-emerald-400 hover:text-white hover:bg-[#1a202c] flex items-center gap-2 font-bold cursor-pointer"
                    >
                      <Layers className="w-4 h-4" />
                      <span>Create New Profile (5+ Profiles)</span>
                    </button>

                    <Link
                      href="/wallet"
                      onClick={() => setShowUserMenu(false)}
                      className="px-4 py-2 text-xs text-zinc-300 hover:text-white hover:bg-[#1a202c] flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <Flame className="w-4 h-4 text-[#ff3358]" />
                        <span>Wallet & M-Pesa Payouts</span>
                      </div>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-black">
                        KSh
                      </span>
                    </Link>

                    <Link
                      href="/admin"
                      onClick={() => setShowUserMenu(false)}
                      className="px-4 py-2 text-xs text-red-400 hover:text-white hover:bg-[#1a202c] flex items-center gap-2 font-bold"
                    >
                      <ShieldAlert className="w-4 h-4" />
                      <span>Admin Moderation Section</span>
                    </Link>
                  </div>

                  <div className="border-t border-[#242b3b] pt-1">
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        openAuthModal("login");
                      }}
                      className="w-full text-left px-4 py-1.5 text-xs text-zinc-400 hover:text-white hover:bg-[#1a202c] flex items-center gap-2 cursor-pointer"
                    >
                      <LogIn className="w-4 h-4" />
                      <span>Switch / Login Profile</span>
                    </button>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-1.5 text-xs text-red-400 hover:text-red-300 hover:bg-[#1a202c] flex items-center gap-2 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Log Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* 3. Search Bar Directly Below Header */}
        <div className="bg-[#10131c] border-b border-[#212735] py-2 px-3 sm:px-6">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <form onSubmit={handleSearchSubmit} className="relative flex-1 max-w-2xl">
              <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-2.5" />
              <input
                type="text"
                placeholder="Search Kenya models, areas (Kilimani, Westlands, Nyali...), massage parlours, #tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#141822] border border-[#262c3b] rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358] transition"
              />
            </form>

            <div className="hidden lg:flex items-center gap-2 text-xs">
              <span className="text-zinc-500">Popular:</span>
              <Link href="/stars?role=straight" className="text-zinc-400 hover:text-white">#Straight</Link>
              <Link href="/stars?role=gay" className="text-zinc-400 hover:text-white">#Gay</Link>
              <Link href="/stars?role=transgender" className="text-zinc-400 hover:text-white">#Trans</Link>
              <Link href="/brands?agencyType=Massage+Parlour" className="text-amber-400 hover:text-amber-300">#MassageSpas</Link>
            </div>
          </div>
        </div>
      </div>

      {/* Facebook Menu Drawer */}
      <FacebookMenuDrawer
        isOpen={showFacebookMenu}
        onClose={() => setShowFacebookMenu(false)}
      />
    </>
  );
}
