"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useApp } from "@/context/AppContext";
import {
  Coins,
  Star,
  Users,
  Building2,
  Sparkles,
  Zap,
  Phone,
  MessageCircle,
  Plus,
  ExternalLink,
  Crown,
  Heart,
  UserPlus,
  Check,
  Bookmark,
  Share2,
} from "lucide-react";

export default function RightSidebar() {
  const {
    currentUser,
    openTokensModal,
    openTipMenuModal,
    openWheelModal,
    openToyModal,
    openContactModal,
    openCreateAdModal,
  } = useApp();

  const [featuredStars, setFeaturedStars] = useState<any[]>([]);
  const [peopleYouMayKnow, setPeopleYouMayKnow] = useState<any[]>([]);
  const [friendActionMap, setFriendActionMap] = useState<Record<number, string>>({});

  useEffect(() => {
    fetch("/api/stars?type=creators")
      .then((res) => res.json())
      .then((data) => {
        if (data.stars) setFeaturedStars(data.stars.slice(0, 3));
      })
      .catch(console.error);

    fetch("/api/friends")
      .then((res) => res.json())
      .then((data) => {
        if (data.peopleYouMayKnow) setPeopleYouMayKnow(data.peopleYouMayKnow.slice(0, 4));
      })
      .catch(console.error);
  }, []);

  const handleAddFriend = async (targetUserId: number) => {
    try {
      setFriendActionMap((prev) => ({ ...prev, [targetUserId]: "sent" }));
      const res = await fetch("/api/friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "send", targetUserId }),
      });
      if (!res.ok) {
        setFriendActionMap((prev) => ({ ...prev, [targetUserId]: "error" }));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const [plusStatus, setPlusStatus] = useState<any>(null);
  const [subscribingPlus, setSubscribingPlus] = useState(false);

  useEffect(() => {
    fetch("/api/hotcheelee-plus")
      .then((r) => r.json())
      .then(setPlusStatus)
      .catch(() => {});
  }, []);

  const handleSubscribePlus = async () => {
    setSubscribingPlus(true);
    try {
      const res = await fetch("/api/hotcheelee-plus", { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        alert(data.message || "HotCheelee+ Activated!");
        setPlusStatus((prev: any) => ({ ...prev, isMember: true }));
        window.location.reload();
      } else {
        alert(data.error || "Subscription failed");
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSubscribingPlus(false);
    }
  };

  return (
    <aside className="w-80 shrink-0 hidden xl:block sticky top-28 self-start space-y-4">
      {/* HOTCHEELEE+ (CLONED SHARESOME+) PROMOTIONAL CAROUSEL & UPGRADE WIDGET */}
      <div className="bg-gradient-to-br from-[#281328] via-[#1a152a] to-[#0f111d] border-2 border-[#ff3358] rounded-2xl p-4 shadow-xl space-y-3 relative overflow-hidden group">
        <div className="absolute -right-8 -top-8 w-28 h-28 bg-gradient-to-br from-[#ff3358]/30 to-[#ffaa00]/20 rounded-full blur-2xl" />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#ff3358] to-[#ffaa00] text-white flex items-center justify-center font-black text-xs shadow">
              🔥+
            </span>
            <h3 className="text-sm font-black text-white tracking-wider">
              HotCheelee+
            </h3>
          </div>
          <span className="text-[10px] font-black uppercase bg-[#ff3358] text-white px-2 py-0.5 rounded shadow">
            {plusStatus?.isMember ? "ACTIVE MEMBER" : "70% OFF PRO"}
          </span>
        </div>

        <p className="text-xs text-zinc-200 leading-relaxed relative z-10">
          {plusStatus?.isMember
            ? "Your HotCheelee+ membership is active! Enjoy ad-free feeds, media in private chat & +100 bonus tokens."
            : "Clone of Sharesome+ for elite companions & fans. Send media in private chats, enjoy 100% ad-free feeds & get 100 free tokens monthly."}
        </p>

        <div className="bg-[#0e111a] p-2.5 rounded-xl border border-white/10 space-y-1 text-[11px] text-zinc-300 relative z-10">
          <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
            <Check className="w-3.5 h-3.5 shrink-0" />
            <span>Send photos/videos in Messenger chats</span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
            <Check className="w-3.5 h-3.5 shrink-0" />
            <span>100% Ad-Free Feeds + 100 Free Tokens</span>
          </div>
          <div className="flex items-center gap-1.5 text-amber-400 font-bold">
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
            <span>HotCheelee+ Glowing VIP Badge</span>
          </div>
        </div>

        <div className="pt-1 flex items-center justify-between text-xs relative z-10">
          <div>
            <span className="text-zinc-400 text-[10px] block">Monthly Membership</span>
            <strong className="text-amber-400 font-black text-sm">KES 1,299 / mo</strong>
          </div>

          <button
            disabled={subscribingPlus || plusStatus?.isMember}
            onClick={handleSubscribePlus}
            className={`py-2 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition shadow-lg cursor-pointer ${
              plusStatus?.isMember
                ? "bg-emerald-600 text-white cursor-default"
                : "bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white"
            }`}
          >
            {plusStatus?.isMember ? "Active ✓" : subscribingPlus ? "Activating..." : "Join HotCheelee+"}
          </button>
        </div>
      </div>

      {/* 1. Tokens Wallet Balance Card */}
      <div className="bg-gradient-to-br from-[#161a25] to-[#12151f] border border-[#232938] rounded-2xl p-4 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            Tokens Balance (KSh)
          </span>
          <button
            onClick={openTokensModal}
            className="text-[11px] font-bold text-[#ff3358] hover:underline cursor-pointer"
          >
            Refill +
          </button>
        </div>

        <div className="bg-[#0e1118] border border-[#1e2330] rounded-xl p-3 mb-3 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-zinc-400 block font-medium">Available</span>
            <span className="text-lg font-black text-amber-400">
              {currentUser?.tokensBalance ?? 350} Tokens
            </span>
            <span className="text-[10px] text-zinc-500 block">≈ KSh {((currentUser?.tokensBalance ?? 350) * 10).toLocaleString()}</span>
          </div>

          <button
            onClick={openTokensModal}
            className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold shadow transition cursor-pointer"
          >
            Buy Tokens
          </button>
        </div>

        {/* Shortcuts */}
        <div className="grid grid-cols-3 gap-1.5 text-[11px] font-bold text-center">
          <button
            onClick={() => featuredStars[0] && openTipMenuModal(featuredStars[0].id, featuredStars[0].displayName)}
            className="bg-[#181d28] hover:bg-[#222a3b] p-2 rounded-xl text-zinc-300 hover:text-white transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#ff3358] mx-auto mb-0.5" />
            <span>Tip Menu</span>
          </button>
          <button
            onClick={() => featuredStars[0] && openWheelModal(featuredStars[0].id, featuredStars[0].displayName)}
            className="bg-[#181d28] hover:bg-[#222a3b] p-2 rounded-xl text-zinc-300 hover:text-white transition cursor-pointer"
          >
            <span className="text-xs block mb-0.5">🎡</span>
            <span>Wheel</span>
          </button>
          <button
            onClick={() => featuredStars[0] && openToyModal(featuredStars[0].id, featuredStars[0].displayName)}
            className="bg-[#181d28] hover:bg-[#222a3b] p-2 rounded-xl text-amber-400 hover:text-white transition cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 mx-auto mb-0.5" />
            <span>Lovense</span>
          </button>
        </div>
      </div>

      {/* 2. FACEBOOK FEATURE: "YOUR SHORTCUTS" */}
      <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-4 shadow-sm space-y-2.5">
        <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
          <Bookmark className="w-3.5 h-3.5 text-amber-400" />
          Your Shortcuts
        </h4>

        <div className="space-y-1">
          <Link
            href="/stars?role=straight"
            className="flex items-center justify-between p-2 rounded-xl hover:bg-[#181d28] text-xs text-zinc-300 hover:text-white transition"
          >
            <span>⭐ Straight Stars Directory</span>
            <span className="text-[10px] text-zinc-500">Nairobi</span>
          </Link>
          <Link
            href="/stars?role=gay"
            className="flex items-center justify-between p-2 rounded-xl hover:bg-[#181d28] text-xs text-zinc-300 hover:text-white transition"
          >
            <span>🏳️‍🌈 Gay Performers</span>
            <span className="text-[10px] text-zinc-500">Active</span>
          </Link>
          <Link
            href="/stars?role=transgender"
            className="flex items-center justify-between p-2 rounded-xl hover:bg-[#181d28] text-xs text-zinc-300 hover:text-white transition"
          >
            <span>🏳️‍⚧️ Transgender & Shemale</span>
            <span className="text-[10px] text-zinc-500">Verified</span>
          </Link>
          <Link
            href="/brands?agencyType=Massage+Parlour"
            className="flex items-center justify-between p-2 rounded-xl hover:bg-[#181d28] text-xs text-zinc-300 hover:text-white transition"
          >
            <span>💆‍♀️ VIP Massage Parlours</span>
            <span className="text-[10px] text-amber-400">Kilimani</span>
          </Link>
        </div>
      </div>

      {/* 3. FACEBOOK FEATURE: "PEOPLE YOU MAY KNOW" (+Add Friend & Follow for Follow) */}
      <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-emerald-400" />
            People You May Know
          </h4>
          <span className="text-[10px] text-zinc-500">Follow-for-follow</span>
        </div>

        <div className="space-y-2.5">
          {peopleYouMayKnow.map((person) => {
            const state = friendActionMap[person.id];
            return (
              <div
                key={person.id}
                className="flex items-center justify-between p-2 rounded-xl bg-[#0e1118] border border-[#1e2330] hover:border-[#2b3345] transition"
              >
                <Link
                  href={`/profile/${person.username}`}
                  className="flex items-center gap-2 min-w-0 flex-1 pr-2 group"
                >
                  <img
                    src={person.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                    alt={person.displayName}
                    className="w-9 h-9 rounded-full object-cover shrink-0 ring-1 ring-white/10"
                  />
                  <div className="truncate">
                    <span className="text-xs font-bold text-white group-hover:text-[#ff3358] transition truncate block">
                      {person.displayName}
                    </span>
                    <span className="text-[10px] text-zinc-400 block truncate">
                      {person.locationArea || "Kenya"}
                    </span>
                  </div>
                </Link>

                <button
                  disabled={state === "sent"}
                  onClick={() => handleAddFriend(person.id)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer shrink-0 ${
                    state === "sent"
                      ? "bg-[#1f2636] text-emerald-400 cursor-default"
                      : "bg-[#ff3358] hover:bg-[#e11d48] text-white"
                  }`}
                >
                  {state === "sent" ? "Sent ✓" : "+ Add"}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. FACEBOOK FEATURE: SPONSORED ADS CREATION */}
      <div className="bg-gradient-to-br from-[#1c1424] via-[#141824] to-[#10131d] border border-amber-400/40 rounded-2xl p-4 shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase text-amber-300">Sponsored Ads</span>
          <span className="text-[10px] bg-amber-400/20 text-amber-300 px-1.5 py-0.2 rounded font-bold">Ad Center</span>
        </div>
        <p className="text-[11px] text-zinc-300 leading-snug">
          Reach thousands of clients across Kenya. Promote your massage parlour or escort agency on infinite feeds.
        </p>
        <button
          onClick={openCreateAdModal}
          className="w-full py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-[#ff3358] hover:from-amber-400 text-white text-xs font-bold transition shadow cursor-pointer text-center"
        >
          + Create Sponsored Ad
        </button>
      </div>
    </aside>
  );
}
