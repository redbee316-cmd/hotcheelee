import { pgTable, serial, text, varchar, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  displayName: varchar("display_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }),
  password: text("password"),
  avatar: text("avatar"),
  coverImage: text("cover_image"),
  bio: text("bio"),
  isVerifiedStar: boolean("is_verified_star").default(false).notNull(),
  isBrand: boolean("is_brand").default(false).notNull(),
  badge: text("badge"),
  paysiteUrl: text("paysite_url"),
  paysiteLabel: text("paysite_label"),
  
  // Account Category & Role
  accountType: varchar("account_type", { length: 30 }).default("browsing").notNull(), // browsing, creator, agency, admin
  genderRole: varchar("gender_role", { length: 30 }).default("straight"), // straight, gay, transgender, shemale, queer
  agencyType: varchar("agency_type", { length: 50 }), // Massage Parlour, Lodging, Brothel, Agency, Club
  
  // Contact details & Reveal mechanics
  phone: varchar("phone", { length: 50 }),
  allowWhatsapp: boolean("allow_whatsapp").default(true).notNull(),
  allowCalls: boolean("allow_calls").default(true).notNull(),
  allowSms: boolean("allow_sms").default(true).notNull(),
  
  // Location & Services
  location: varchar("location", { length: 100 }),
  locationArea: varchar("location_area", { length: 120 }),
  serviceType: varchar("service_type", { length: 40 }).default("Both Incall & Outcall"),
  servicesOffered: text("services_offered"),
  rates: text("rates"),
  interests: text("interests"), // JSON string array of interest tags for algorithmic matching
  
  // Media & Gallery
  advertMediaUrl: text("advert_media_url"),
  advertMediaType: varchar("advert_media_type", { length: 20 }).default("image"),
  galleryUrls: text("gallery_urls"),
  
  // 30-Day Subscription Enforcement (Creator KSh 500/mo, Agency KSh 1500/mo)
  subscriptionStatus: varchar("subscription_status", { length: 30 }).default("inactive").notNull(), // inactive, pending, active, expired
  subscriptionPlan: varchar("subscription_plan", { length: 40 }),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  subscriptionPaidAt: timestamp("subscription_paid_at"),
  lastMpesaCode: varchar("last_mpesa_code", { length: 50 }),
  
  // Normal Manual Wallet (Universal Currency: KSh. 1 Token = 10 KSh)
  tokensBalance: integer("tokens_balance").default(350).notNull(),
  flamesBalance: integer("flames_balance").default(580).notNull(),
  flamesReceived: integer("flames_received").default(0).notNull(),
  leeBalance: numeric("lee_balance", { precision: 14, scale: 2 }).default("15.50").notNull(),
  cheelBalance: numeric("cheel_balance", { precision: 14, scale: 2 }).default("50.00").notNull(),
  usdtBalance: numeric("usdt_balance", { precision: 14, scale: 2 }).default("28.75").notNull(),
  
  // Gamification & Status
  userLevel: integer("user_level").default(5).notNull(),
  userXp: integer("user_xp").default(1250).notNull(),
  isUltimateMember: boolean("is_ultimate_member").default(true).notNull(),
  isKnight: boolean("is_knight").default(false).notNull(),
  vipTier: varchar("vip_tier", { length: 30 }).default("Diamond").notNull(),
  
  // Performer live settings
  interactiveToyBrand: varchar("interactive_toy_brand", { length: 50 }).default("Lovense Lush 3"),
  interactiveToyConnected: boolean("interactive_toy_connected").default(true).notNull(),
  interactiveToyLevel: integer("interactive_toy_level").default(0).notNull(),
  currentGoalTitle: varchar("current_goal_title", { length: 255 }).default("Unlock Uncensored Cyber Set 🔥"),
  currentGoalTokens: integer("current_goal_tokens").default(2500).notNull(),
  currentGoalProgress: integer("current_goal_progress").default(1680).notNull(),
  fanClubPriceMonthly: integer("fan_club_price_monthly").default(50).notNull(),

  // Attention economy
  attentionMinutesLeft: integer("attention_minutes_left").default(20).notNull(),
  attentionMaxMinutes: integer("attention_max_minutes").default(30).notNull(),
  activeGlassesId: integer("active_glasses_id"),
  selectedStrategy: varchar("selected_strategy", { length: 20 }).default("Mix").notNull(),
  
  followersCount: integer("followers_count").default(0).notNull(),
  followingCount: integer("following_count").default(0).notNull(),
  friendsCount: integer("friends_count").default(0).notNull(),
  dailyFollowsCount: integer("daily_follows_count").default(0).notNull(), // tracks 200/day follow limit
  lastFollowDate: varchar("last_follow_date", { length: 20 }),
  website: varchar("website", { length: 255 }),
  
  isAdmin: boolean("is_admin").default(false).notNull(),
  isBanned: boolean("is_banned").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Manual M-Pesa Subscriptions Table (Till: 8923411, 30 days)
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  accountType: varchar("account_type", { length: 30 }).notNull(),
  plan: varchar("plan", { length: 40 }).notNull(),
  amountKsh: integer("amount_ksh").notNull(),
  tillNumber: varchar("till_number", { length: 40 }).default("8923411").notNull(),
  mpesaCode: varchar("mpesa_code", { length: 60 }).notNull(),
  phonePaid: varchar("phone_paid", { length: 40 }).notNull(),
  status: varchar("status", { length: 30 }).default("pending").notNull(),
  approvedBy: integer("approved_by"),
  approvedAt: timestamp("approved_at"),
  expiresAt: timestamp("expires_at"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Manual Wallet Deposits (Approved in Admin)
export const walletDeposits = pgTable("wallet_deposits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amountKsh: integer("amount_ksh").notNull(),
  tokensCredited: integer("tokens_credited").notNull(),
  tillNumber: varchar("till_number", { length: 40 }).default("8923411").notNull(),
  mpesaCode: varchar("mpesa_code", { length: 60 }).notNull(),
  phonePaid: varchar("phone_paid", { length: 40 }).notNull(),
  status: varchar("status", { length: 30 }).default("pending").notNull(),
  approvedBy: integer("approved_by"),
  approvedAt: timestamp("approved_at"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Facebook Friend Requests
export const friendRequests = pgTable("friend_requests", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  status: varchar("status", { length: 30 }).default("pending").notNull(), // pending, accepted, declined
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Sponsored Ads (Paid from wallet tokens, approved by admin)
export const sponsoredAds = pgTable("sponsored_ads", {
  id: serial("id").primaryKey(),
  advertiserId: integer("advertiser_id").notNull(),
  brandName: varchar("brand_name", { length: 120 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  content: text("content").notNull(),
  mediaUrl: text("media_url").notNull(),
  mediaType: varchar("media_type", { length: 20 }).default("image").notNull(),
  ctaText: varchar("cta_text", { length: 50 }).default("Learn More").notNull(),
  targetUrl: text("target_url").notNull(),
  budgetTokens: integer("budget_tokens").default(300).notNull(), // paid with tokens from wallet
  budgetKsh: integer("budget_ksh").default(3000).notNull(),
  status: varchar("status", { length: 30 }).default("pending").notNull(), // pending, approved, rejected, completed
  clicksCount: integer("clicks_count").default(0).notNull(),
  impressionsCount: integer("impressions_count").default(0).notNull(),
  isActive: boolean("is_active").default(false).notNull(), // goes live once admin approves!
  approvedBy: integer("approved_by"),
  approvedAt: timestamp("approved_at"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Facebook Groups Clone
export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  creatorId: integer("creator_id").notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  description: text("description").notNull(),
  coverImage: text("cover_image").notNull(),
  privacy: varchar("privacy", { length: 20 }).default("public").notNull(), // public, private
  membersCount: integer("members_count").default(1).notNull(),
  postsCount: integer("posts_count").default(0).notNull(),
  category: varchar("category", { length: 50 }).default("Adult & Social").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const groupMembers = pgTable("group_members", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  userId: integer("user_id").notNull(),
  role: varchar("role", { length: 20 }).default("member").notNull(), // admin, moderator, member
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const groupPosts = pgTable("group_posts", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  mediaUrls: text("media_urls"),
  likesCount: integer("likes_count").default(0).notNull(),
  commentsCount: integer("comments_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Facebook Marketplace Clone (Adult Goods, Toys, Outfits, Services)
export const marketplaceItems = pgTable("marketplace_items", {
  id: serial("id").primaryKey(),
  sellerId: integer("seller_id").notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  description: text("description").notNull(),
  priceKsh: integer("price_ksh").notNull(),
  priceCoins: integer("price_coins").notNull(),
  category: varchar("category", { length: 50 }).notNull(), // Toys, Lingerie & Outfits, Wellness & Oils, VIP Services, Costumes
  location: varchar("location", { length: 80 }).default("Nairobi").notNull(),
  locationArea: varchar("location_area", { length: 100 }),
  condition: varchar("condition", { length: 30 }).default("Brand New").notNull(),
  images: text("images").notNull(), // JSON array
  isSold: boolean("is_sold").default(false).notNull(),
  status: varchar("status", { length: 20 }).default("active").notNull(), // active, pending_moderation
  contactPhone: varchar("contact_phone", { length: 40 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// HotCheelee PtoP Finance (Loans, Guarantees, Peer Funding)
export const ptopLoans = pgTable("ptop_loans", {
  id: serial("id").primaryKey(),
  borrowerId: integer("borrower_id").notNull(),
  lenderId: integer("lender_id"), // null if open loan request
  guarantorId: integer("guarantor_id"), // peer guarantor
  amountKsh: integer("amount_ksh").notNull(),
  interestRatePercent: integer("interest_rate_percent").default(10).notNull(),
  totalRepayableKsh: integer("total_repayable_ksh").notNull(),
  durationDays: integer("duration_days").default(30).notNull(),
  purpose: text("purpose").notNull(),
  status: varchar("status", { length: 30 }).default("open").notNull(), // open, funded, repaid, defaulted
  dueDate: timestamp("due_date"),
  fundedAt: timestamp("funded_at"),
  repaidAt: timestamp("repaid_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// HotCheelee PtoP Predictions & Jackpot Marketplace
export const ptopPredictions = pgTable("ptop_predictions", {
  id: serial("id").primaryKey(),
  creatorId: integer("creator_id").notNull(), // who posted prediction
  opponentId: integer("opponent_id"), // who matched/challenged
  league: varchar("league", { length: 50 }).notNull(), // Premier League, Bundesliga, La Liga, KPL, Serie A, Ligue 1
  homeTeam: varchar("home_team", { length: 80 }).notNull(),
  awayTeam: varchar("away_team", { length: 80 }).notNull(),
  matchDate: varchar("match_date", { length: 60 }).notNull(),
  creatorPick: varchar("creator_pick", { length: 80 }).notNull(), // Home, Draw, Away
  opponentPick: varchar("opponent_pick", { length: 80 }),
  stakeCoins: integer("stake_coins").notNull(), // e.g. 500 Coins
  totalPotCoins: integer("total_pot_coins").notNull(), // stake * 2
  winnerRewardCoins: integer("winner_reward_coins").notNull(), // 90% of pot
  platformFeeCoins: integer("platform_fee_coins").notNull(), // 10% platform
  status: varchar("status", { length: 30 }).default("open").notNull(), // open, matched, completed, cancelled
  winnerUserId: integer("winner_user_id"),
  declaredAt: timestamp("declared_at"),
  winningPick: varchar("winning_pick", { length: 80 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Bookings & Contact Orders
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  modelId: integer("model_id").notNull(),
  serviceRequested: varchar("service_requested", { length: 150 }).notNull(),
  serviceType: varchar("service_type", { length: 40 }).default("Incall").notNull(),
  duration: varchar("duration", { length: 50 }).default("1 Hour").notNull(),
  totalPriceKsh: integer("total_price_ksh").notNull(),
  preferredDate: varchar("preferred_date", { length: 100 }),
  clientPhone: varchar("client_phone", { length: 50 }).notNull(),
  clientNote: text("client_note"),
  status: varchar("status", { length: 30 }).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Contact Reveals
export const contactReveals = pgTable("contact_reveals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  modelId: integer("model_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Audit Trail
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  details: text("details"),
  targetId: integer("target_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Platform Settings
export const platformSettings = pgTable("platform_settings", {
  id: serial("id").primaryKey(),
  tillNumber: varchar("till_number", { length: 40 }).default("8923411").notNull(),
  paybillNumber: varchar("paybill_number", { length: 40 }).default("522522").notNull(),
  accountName: varchar("account_name", { length: 80 }).default("HOTCHEELEE").notNull(),
  creatorPriceKsh: integer("creator_price_ksh").default(500).notNull(),
  agencyPriceKsh: integer("agency_price_ksh").default(1500).notNull(),
  supportPhone: varchar("support_phone", { length: 40 }).default("+254 700 892341").notNull(),
  supportWhatsapp: varchar("support_whatsapp", { length: 40 }).default("+254 700 892341").notNull(),
  announcement: text("announcement").default("Welcome to HotCheelee! M-Pesa Till: 8923411. Creators: KSh 500/mo, Agencies: KSh 1,500/mo. 18+ only."),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User Reports
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  reporterId: integer("reporter_id").notNull(),
  targetUserId: integer("target_user_id"),
  postId: integer("post_id"),
  reason: text("reason").notNull(),
  status: varchar("status", { length: 30 }).default("pending").notNull(),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stripchat Performer Tip Menu
export const tipMenuItems = pgTable("tip_menu_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  actionName: varchar("action_name", { length: 120 }).notNull(),
  category: varchar("category", { length: 50 }).default("Show").notNull(),
  tokensCost: integer("tokens_cost").notNull(),
  toyIntensity: integer("toy_intensity").default(0).notNull(),
  durationSeconds: integer("duration_seconds").default(10).notNull(),
  description: text("description"),
  orderIndex: integer("order_index").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stripchat Wheel of Fortune
export const wheelSegments = pgTable("wheel_segments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  label: varchar("label", { length: 100 }).notNull(),
  rewardType: varchar("reward_type", { length: 50 }).notNull(),
  rewardValue: text("reward_value"),
  color: varchar("color", { length: 30 }).default("#ff3358").notNull(),
  probability: integer("probability").default(10).notNull(),
  costTokens: integer("cost_tokens").default(25).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Wheel Spin History
export const wheelSpins = pgTable("wheel_spins", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  modelId: integer("model_id").notNull(),
  segmentId: integer("segment_id").notNull(),
  tokensSpent: integer("tokens_spent").notNull(),
  wonLabel: varchar("won_label", { length: 150 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stripchat Interactive Toy Trigger Log
export const toyTriggers = pgTable("toy_triggers", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  modelId: integer("model_id").notNull(),
  toyName: varchar("toy_name", { length: 60 }).default("Lovense Lush 3").notNull(),
  intensity: integer("intensity").notNull(),
  durationSeconds: integer("duration_seconds").notNull(),
  tokensTipped: integer("tokens_tipped").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stripchat Fan Club Subscriptions
export const fanClubMemberships = pgTable("fan_club_memberships", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  modelId: integer("model_id").notNull(),
  tier: varchar("tier", { length: 30 }).default("VIP Club").notNull(),
  tokensPaid: integer("tokens_paid").default(50).notNull(),
  discountPercent: integer("discount_percent").default(10).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Wishlist Items
export const wishlistItems = pgTable("wishlist_items", {
  id: serial("id").primaryKey(),
  modelId: integer("model_id").notNull(),
  title: varchar("title", { length: 150 }).notNull(),
  tokenCost: integer("token_cost").notNull(),
  category: varchar("category", { length: 50 }).default("Lingerie").notNull(),
  image: text("image"),
  isFulfilled: boolean("is_fulfilled").default(false).notNull(),
  fulfilledByUserId: integer("fulfilled_by_user_id"),
  fulfilledAt: timestamp("fulfilled_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Room Knights
export const roomKnights = pgTable("room_knights", {
  id: serial("id").primaryKey(),
  modelId: integer("model_id").notNull(),
  knightUserId: integer("knight_user_id").notNull(),
  grantedBy: integer("granted_by").notNull(),
  canMute: boolean("can_mute").default(true).notNull(),
  canKick: boolean("can_kick").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Goal Contributions
export const goalContributions = pgTable("goal_contributions", {
  id: serial("id").primaryKey(),
  modelId: integer("model_id").notNull(),
  contributorId: integer("contributor_id").notNull(),
  tokensAmount: integer("tokens_amount").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// NFT Glasses (optional collectible)
export const nftGlasses = pgTable("nft_glasses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  name: varchar("name", { length: 100 }).notNull(),
  rarity: varchar("rarity", { length: 30 }).notNull(),
  multiplier: numeric("multiplier", { precision: 4, scale: 2 }).default("1.30").notNull(),
  paidMinutesDaily: integer("paid_minutes_daily").default(20).notNull(),
  durability: integer("durability").default(100).notNull(),
  level: integer("level").default(1).notNull(),
  radarPoints: integer("radar_points").default(10).notNull(),
  lensesPoints: integer("lenses_points").default(10).notNull(),
  image: text("image").notNull(),
  priceUsd: numeric("price_usd", { precision: 10, scale: 2 }).default("0.00").notNull(),
  priceLee: numeric("price_lee", { precision: 10, scale: 2 }).default("0.00").notNull(),
  isEquipped: boolean("is_equipped").default(false).notNull(),
  isListedForSale: boolean("is_listed_for_sale").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Loot Boxes
export const lootBoxes = pgTable("loot_boxes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  boxType: varchar("box_type", { length: 30 }).notNull(),
  leeReward: numeric("lee_reward", { precision: 10, scale: 2 }).notNull(),
  cheelBonus: numeric("cheel_bonus", { precision: 10, scale: 2 }).default("0.00"),
  isOpened: boolean("is_opened").default(false).notNull(),
  openedAt: timestamp("opened_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const topics = pgTable("topics", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  name: varchar("name", { length: 100 }).notNull(),
  tagline: text("tagline"),
  description: text("description"),
  banner: text("banner"),
  icon: text("icon"),
  rules: text("rules"),
  followersCount: integer("followers_count").default(0).notNull(),
  postsCount: integer("posts_count").default(0).notNull(),
  category: varchar("category", { length: 50 }).default("General").notNull(),
  isNsfw: boolean("is_nsfw").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const topicMembers = pgTable("topic_members", {
  id: serial("id").primaryKey(),
  topicId: integer("topic_id").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  topicId: integer("topic_id"),
  content: text("content").notNull(),
  mediaUrls: text("media_urls"),
  promoLinkUrl: text("promo_link_url"),
  promoLinkLabel: text("promo_link_label"),
  flamesCount: integer("flames_count").default(0).notNull(),
  tokensEarnedTotal: integer("tokens_earned_total").default(0).notNull(),
  leeEarnedTotal: numeric("lee_earned_total", { precision: 12, scale: 2 }).default("0.00").notNull(),
  commentsCount: integer("comments_count").default(0).notNull(),
  repostsCount: integer("reposts_count").default(0).notNull(),
  viewsCount: integer("views_count").default(0).notNull(),
  tags: text("tags"),
  isQuickie: boolean("is_quickie").default(false).notNull(),
  videoUrl: text("video_url"),
  videoDuration: integer("video_duration"), // strictly max 60 seconds
  aspectRatio: varchar("aspect_ratio", { length: 10 }).default("9:16"), // strictly 9:16 for quickies
  isFanClubOnly: boolean("is_fan_club_only").default(false).notNull(),
  priceKsh: integer("price_ksh"),
  unlockFeeTokens: integer("unlock_fee_tokens").default(0).notNull(), // Sharesome pay-to-unlock video fee set by creator
  previewVideoUrl: text("preview_video_url"), // Short teaser for locked video
  fullVideoUrl: text("full_video_url"), // Full video revealed once fee paid
  isPinned: boolean("is_pinned").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Sharesome Content Unlocks Table (tracks users who unlocked a creator's locked video)
export const contentUnlocks = pgTable("content_unlocks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  postId: integer("post_id").notNull(),
  feePaidTokens: integer("fee_paid_tokens").notNull(),
  feePaidKsh: integer("fee_paid_ksh").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stripchat Private Shows Table
export const privateShows = pgTable("private_shows", {
  id: serial("id").primaryKey(),
  modelId: integer("model_id").notNull(),
  clientId: integer("client_id").notNull(),
  pricePerMinuteTokens: integer("price_per_minute_tokens").default(30).notNull(), // set by model e.g. 30 tk/min (KSh 300/min)
  minimumMinutes: integer("minimum_minutes").default(5).notNull(),
  requestedMinutes: integer("requested_minutes").default(10).notNull(),
  totalCostTokens: integer("total_cost_tokens").notNull(),
  totalCostKsh: integer("total_cost_ksh").notNull(),
  status: varchar("status", { length: 30 }).default("pending").notNull(), // pending, accepted, active, completed, cancelled
  scheduledTime: varchar("scheduled_time", { length: 80 }),
  specialRequests: text("special_requests"),
  isSpyAllowed: boolean("is_spy_allowed").default(false).notNull(),
  spyPriceTokens: integer("spy_price_tokens").default(10).notNull(),
  roomSecret: varchar("room_secret", { length: 64 }),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// HotCheelee+ (Sharesome+ Clone) Premium User Subscriptions
export const hotcheeleePlusMemberships = pgTable("hotcheelee_plus_memberships", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  plan: varchar("plan", { length: 40 }).default("hotcheelee_plus_monthly").notNull(),
  priceKsh: integer("price_ksh").default(1299).notNull(), // KSh 1,299/mo (Sharesome+ $12.99 equivalent)
  tokensBonus: integer("tokens_bonus").default(100).notNull(), // Bonus 100 tokens per month
  expiresAt: timestamp("expires_at").notNull(),
  status: varchar("status", { length: 20 }).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const stories = pgTable("stories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mediaUrl: text("media_url").notNull(),
  mediaType: varchar("media_type", { length: 20 }).default("image").notNull(), // image or video
  durationSeconds: integer("duration_seconds").default(15).notNull(), // max 60s
  caption: text("caption"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  flamesCount: integer("flames_count").default(0).notNull(),
  tokensAttached: integer("tokens_attached").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const postFlames = pgTable("post_flames", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  amount: integer("amount").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const follows = pgTable("follows", {
  id: serial("id").primaryKey(),
  followerId: integer("follower_id").notNull(),
  followingId: integer("following_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tips = pgTable("tips", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  postId: integer("post_id"),
  amount: integer("amount").notNull(),
  tokenType: varchar("token_type", { length: 20 }).default("TOKENS").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  content: text("content").notNull(),
  mediaUrl: text("media_url"),
  mediaType: varchar("media_type", { length: 20 }), // voice, photo, video, file
  tokensTipped: integer("tokens_tipped").default(0).notNull(),
  flamesTipped: integer("flames_tipped").default(0).notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  replyToMessageId: integer("reply_to_message_id"),
  reaction: varchar("reaction", { length: 20 }), // emoji reaction e.g. ❤️, 😂, 🔥, 👍, 😮
  isPinned: boolean("is_pinned").default(false).notNull(),
  isStarred: boolean("is_starred").default(false).notNull(),
  isEdited: boolean("is_edited").default(false).notNull(),
  isReported: boolean("is_reported").default(false).notNull(),
  isDeleted: boolean("is_deleted").default(false).notNull(),
  forwardedFrom: varchar("forwarded_from", { length: 80 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  actorId: integer("actor_id").notNull(),
  type: varchar("type", { length: 30 }).notNull(),
  category: varchar("category", { length: 30 }).default("general").notNull(), // general, tips, bookings, friend_requests, subscriptions, mentions
  postId: integer("post_id"),
  targetUrl: text("target_url"),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Jackpots Table (PtoP Jackpot Marketplace)
export const jackpots = pgTable("jackpots", {
  id: serial("id").primaryKey(),
  creatorId: integer("creator_id").notNull(),
  jackpotType: varchar("jackpot_type", { length: 20 }).default("daily").notNull(), // daily, weekly
  title: varchar("title", { length: 140 }).notNull(),
  matches: text("matches").notNull(), // JSON array of matches [{ matchIndex, teamA, teamB, matchDate }]
  matchesCount: integer("matches_count").default(2).notNull(),
  creationCostCoins: integer("creation_cost_coins").default(500).notNull(), // count * 250
  entryFeeCoins: integer("entry_fee_coins").default(50).notNull(), // count * 25
  totalPoolCoins: integer("total_pool_coins").default(500).notNull(),
  creatorRewardPercent: integer("creator_reward_percent").default(90).notNull(),
  platformFeePercent: integer("platform_fee_percent").default(10).notNull(),
  status: varchar("status", { length: 20 }).default("open").notNull(), // open, completed, cancelled
  winnerUserId: integer("winner_user_id"),
  entriesCount: integer("entries_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
});

export const jackpotEntries = pgTable("jackpot_entries", {
  id: serial("id").primaryKey(),
  jackpotId: integer("jackpot_id").notNull(),
  userId: integer("user_id").notNull(),
  entryFeePaid: integer("entry_fee_paid").notNull(),
  predictions: text("predictions").notNull(), // JSON array of picks
  status: varchar("status", { length: 20 }).default("active").notNull(), // active, won, lost
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Facebook-style Pages Clone
export const pages = pgTable("pages", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id").notNull(),
  name: varchar("name", { length: 140 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  category: varchar("category", { length: 60 }).notNull(), // Escort Agency, Massage Parlour, Nightclub, Glamour Brand, Creator Official, Wellness Spa
  about: text("about"),
  bio: text("bio"),
  location: varchar("location", { length: 80 }).default("Nairobi"),
  locationArea: varchar("location_area", { length: 120 }),
  phone: varchar("phone", { length: 50 }),
  whatsapp: varchar("whatsapp", { length: 50 }),
  avatar: text("avatar"),
  coverImage: text("cover_image"),
  likesCount: integer("likes_count").default(0).notNull(),
  followersCount: integer("followers_count").default(0).notNull(),
  verified: boolean("verified").default(true).notNull(),
  website: varchar("website", { length: 255 }),
  priceRange: varchar("price_range", { length: 40 }).default("KSh 3,000 - 15,000"),
  services: text("services"),
  rates: text("rates"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const pageLikes = pgTable("page_likes", {
  id: serial("id").primaryKey(),
  pageId: integer("page_id").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const pagePosts = pgTable("page_posts", {
  id: serial("id").primaryKey(),
  pageId: integer("page_id").notNull(),
  authorId: integer("author_id").notNull(),
  content: text("content").notNull(),
  mediaUrls: text("media_urls"),
  likesCount: integer("likes_count").default(0).notNull(),
  commentsCount: integer("comments_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Manual M-Pesa Withdrawals (Approved by Admin)
export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amountKsh: integer("amount_ksh").default(0).notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  token: varchar("token", { length: 10 }).default("KSH").notNull(),
  destinationAddress: text("destination_address").notNull(), // Phone / M-Pesa number
  network: varchar("network", { length: 30 }).default("M-Pesa Kenya").notNull(),
  status: varchar("status", { length: 20 }).default("Pending").notNull(), // Pending, Approved, Completed, Rejected
  chargesKsh: integer("charges_ksh").default(52).notNull(),
  netAmountKsh: integer("net_amount_ksh").default(0).notNull(),
  mpesaReceipt: text("mpesa_receipt"),
  adminNotes: text("admin_notes"),
  txHash: text("tx_hash"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
