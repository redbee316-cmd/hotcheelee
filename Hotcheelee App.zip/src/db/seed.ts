import { db } from "./index";
import {
  users,
  topics,
  posts,
  stories,
  comments,
  follows,
  messages,
  notifications,
  nftGlasses,
  lootBoxes,
  tipMenuItems,
  wheelSegments,
  wishlistItems,
  fanClubMemberships,
  subscriptions,
  bookings,
  platformSettings,
  pages,
  pagePosts,
  jackpots,
} from "./schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  console.log("Checking database seed for HotCheelee (Kenyan KSh, Diverse Creators, Agencies)...");

  // Seed default platform settings if not present
  const existingSettings = await db.select().from(platformSettings).limit(1);
  if (existingSettings.length === 0) {
    await db.insert(platformSettings).values({
      tillNumber: "8923411",
      paybillNumber: "522522",
      accountName: "HOTCHEELEE",
      creatorPriceKsh: 500,
      agencyPriceKsh: 1500,
      supportPhone: "+254 700 892341",
      supportWhatsapp: "+254 700 892341",
      announcement: "HotCheelee Kenya: Join Free to Browse! Creators pay KSh 500/mo, Agencies pay KSh 1,500/mo via M-Pesa Buy Goods Till: 8923411.",
    });
  }

  // Ensure Admin user exists
  const existingAdmin = await db.select().from(users).where(eq(users.username, "admin")).limit(1);
  if (existingAdmin.length === 0) {
    await db.insert(users).values({
      username: "admin",
      displayName: "HotCheelee Admin 🛡️",
      email: "admin@hotcheelee.com",
      password: "admin123password",
      avatar: "https://images.pexels.com/photos/31130286/pexels-photo-31130286.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      bio: "Official System Administrator & Compliance Custodian. Managing approvals, payments & security.",
      accountType: "admin",
      isAdmin: true,
      tokensBalance: 10000,
      flamesBalance: 50000,
      subscriptionStatus: "active",
      location: "Nairobi",
      locationArea: "Westlands HQ",
    });
  }

  // Seed or update creators representing: Straight, Gay, Transgender, Shemale, Queer + Agencies
  const sampleUsers = [
    // 1. Browsing User (Alex Rivers)
    {
      username: "alex_member",
      displayName: "Alex Rivers",
      email: "alex@hotcheelee.com",
      avatar: "https://images.pexels.com/photos/27236833/pexels-photo-27236833.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      bio: "Enthusiastic adult explorer. Browsing profiles, booking appointments and supporting models with tokens!",
      accountType: "browsing",
      genderRole: "straight",
      location: "Nairobi",
      locationArea: "Kilimani",
      phone: "+254 712 345678",
      tokensBalance: 450,
      flamesBalance: 580,
      userLevel: 6,
      subscriptionStatus: "active",
      isAdmin: false,
    },
    // 2. Straight Female Star (Elena Lux)
    {
      username: "elena_lux",
      displayName: "Elena Lux 💎 (Nairobi VIP)",
      email: "elena@luxstars.com",
      avatar: "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      coverImage: "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
      bio: "High-end luxury companion & glamour model. Clean private penthouse in Kilimani. Discrete, sensual, and unforgettable.",
      accountType: "creator",
      genderRole: "straight",
      isVerifiedStar: true,
      badge: "Verified Star",
      location: "Nairobi",
      locationArea: "Kilimani - Argwings Kodhek",
      serviceType: "Both Incall & Outcall",
      phone: "+254 722 890123",
      allowWhatsapp: true,
      allowCalls: true,
      allowSms: true,
      servicesOffered: JSON.stringify([
        "Sensual Full Body Massage",
        "Dinner Date & Companionship",
        "Overnight Stays",
        "Couples Experience",
        "Erotic Photo Shoots",
        "GFE (Girlfriend Experience)",
      ]),
      rates: JSON.stringify([
        { duration: "1 Hour Incall", priceKsh: 4000 },
        { duration: "2 Hours Incall", priceKsh: 7000 },
        { duration: "Overnight Incall", priceKsh: 15000 },
        { duration: "1 Hour Outcall (Hotel)", priceKsh: 6000 },
        { duration: "Overnight Outcall", priceKsh: 20000 },
      ]),
      subscriptionStatus: "active",
      subscriptionPlan: "creator_500",
      subscriptionExpiresAt: new Date(Date.now() + 25 * 86400000),
      subscriptionPaidAt: new Date(Date.now() - 5 * 86400000),
      lastMpesaCode: "SHB492X1KL",
      tokensBalance: 1450,
      flamesBalance: 12450,
      followersCount: 42100,
    },
    // 3. Gay Male Creator (Liam Onyango)
    {
      username: "liam_fitness",
      displayName: "Liam Onyango 🏋️ (Gay Companion)",
      email: "liam@hotcheelee.com",
      avatar: "https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      coverImage: "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
      bio: "Athletic 26yo gym enthusiast catering exclusively to gentleman and discerning queer men. Muscular, well-spoken, discreet private apartment.",
      accountType: "creator",
      genderRole: "gay",
      isVerifiedStar: true,
      badge: "Gay Star",
      location: "Nairobi",
      locationArea: "Westlands - Rhapta Road",
      serviceType: "Both Incall & Outcall",
      phone: "+254 733 456789",
      allowWhatsapp: true,
      allowCalls: true,
      allowSms: true,
      servicesOffered: JSON.stringify([
        "Deep Tissue Athletic Massage",
        "Active / Versatile Companionship",
        "Executive Dinner & Escort",
        "Weekend Getaways",
        "Fitness Roleplay",
      ]),
      rates: JSON.stringify([
        { duration: "1 Hour Incall", priceKsh: 3500 },
        { duration: "2 Hours Incall", priceKsh: 6000 },
        { duration: "Overnight Incall", priceKsh: 12000 },
        { duration: "Outcall Service", priceKsh: 5000 },
      ]),
      subscriptionStatus: "active",
      subscriptionPlan: "creator_500",
      subscriptionExpiresAt: new Date(Date.now() + 28 * 86400000),
      lastMpesaCode: "QKL823M9PA",
      tokensBalance: 980,
      followersCount: 18400,
    },
    // 4. Transgender Creator (Sasha Vixen)
    {
      username: "sasha_vixen",
      displayName: "Sasha Vixen 🏳️‍⚧️ (Trans Goddess)",
      email: "sasha@hotcheelee.com",
      avatar: "https://images.pexels.com/photos/29271917/pexels-photo-29271917.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      coverImage: "https://images.pexels.com/photos/18570527/pexels-photo-18570527.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
      bio: "Glamorous pre-op transgender beauty. 100% real photos, stunning curves, high heels and sensual touch. Welcoming open-minded and respectful men.",
      accountType: "creator",
      genderRole: "transgender",
      isVerifiedStar: true,
      badge: "Trans Star",
      location: "Nairobi",
      locationArea: "Lavington",
      serviceType: "Incall",
      phone: "+254 798 112233",
      allowWhatsapp: true,
      allowCalls: false,
      allowSms: true,
      servicesOffered: JSON.stringify([
        "Sensual Oil Massage",
        "Top / Bottom Versatile Fun",
        "Crossdress & Fantasy Roleplay",
        "Private Strip Show",
        "BDSM & Mild Domination",
      ]),
      rates: JSON.stringify([
        { duration: "1 Hour Incall", priceKsh: 4500 },
        { duration: "2 Hours Incall", priceKsh: 8000 },
        { duration: "Overnight Incall", priceKsh: 16000 },
      ]),
      subscriptionStatus: "active",
      subscriptionPlan: "creator_500",
      subscriptionExpiresAt: new Date(Date.now() + 22 * 86400000),
      lastMpesaCode: "TNM912X4BC",
      tokensBalance: 1250,
      followersCount: 29500,
    },
    // 5. Shemale Creator (Nikki Exotic)
    {
      username: "nikki_exotic",
      displayName: "Nikki Exotic 💋 (Shemale TS)",
      email: "nikki@hotcheelee.com",
      avatar: "https://images.pexels.com/photos/29057433/pexels-photo-29057433.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      coverImage: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
      bio: "Exotic shemale companion with long legs, smooth skin & feminine energy. Fully functional and energetic. Discreet private studio in Mombasa.",
      accountType: "creator",
      genderRole: "shemale",
      isVerifiedStar: true,
      badge: "Shemale Verified",
      location: "Mombasa",
      locationArea: "Nyali Beach Road",
      serviceType: "Both Incall & Outcall",
      phone: "+254 745 667788",
      allowWhatsapp: true,
      allowCalls: true,
      allowSms: true,
      servicesOffered: JSON.stringify([
        "Full Body Tantric Massage",
        "Active Role & Greek Fun",
        "Shower / Jacuzzi Play",
        "Vacation Companion",
      ]),
      rates: JSON.stringify([
        { duration: "1 Hour Incall", priceKsh: 5000 },
        { duration: "2 Hours Incall", priceKsh: 9000 },
        { duration: "Overnight Beachfront", priceKsh: 18000 },
      ]),
      subscriptionStatus: "active",
      subscriptionPlan: "creator_500",
      subscriptionExpiresAt: new Date(Date.now() + 19 * 86400000),
      lastMpesaCode: "BVP841P7JK",
      tokensBalance: 870,
      followersCount: 21300,
    },
    // 6. Queer / Non-Binary Creator (Kai Starlight)
    {
      username: "kai_queer",
      displayName: "Kai Starlight 🌈 (Queer / NB)",
      email: "kai@hotcheelee.com",
      avatar: "https://images.pexels.com/photos/17509326/pexels-photo-17509326.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      coverImage: "https://images.pexels.com/photos/33282388/pexels-photo-33282388.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
      bio: "Gender-fluid queer creator, alt babe and kink practitioner. Safe space for LGBTQ+ community and exploratory singles/couples.",
      accountType: "creator",
      genderRole: "queer",
      isVerifiedStar: true,
      badge: "Queer Verified",
      location: "Nairobi",
      locationArea: "Kileleshwa",
      serviceType: "Incall",
      phone: "+254 711 998877",
      allowWhatsapp: true,
      allowCalls: false,
      allowSms: true,
      servicesOffered: JSON.stringify([
        "Kink & BDSM Exploration",
        "Tantric Energy Work",
        "Couples Seduction",
        "Sensual Rope Bondage",
      ]),
      rates: JSON.stringify([
        { duration: "1 Hour Session", priceKsh: 4000 },
        { duration: "2 Hours Extended", priceKsh: 7500 },
        { duration: "Couples 2 Hours", priceKsh: 10000 },
      ]),
      subscriptionStatus: "active",
      subscriptionPlan: "creator_500",
      subscriptionExpiresAt: new Date(Date.now() + 29 * 86400000),
      lastMpesaCode: "ZKL349W0RT",
      tokensBalance: 640,
      followersCount: 15600,
    },
    // 7. Agency - Massage Parlour (Serenity Spa & Lounge)
    {
      username: "serenity_spa",
      displayName: "Serenity Executive Spa & Parlour 💆‍♀️",
      email: "serenity@hotcheelee.com",
      avatar: "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      coverImage: "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
      bio: "Premier VIP Executive Massage Parlour in Kilimani. 12+ certified gorgeous female therapists on rotation. Sauna, steam, jacuzzi & private VIP suites.",
      accountType: "agency",
      agencyType: "Massage Parlour",
      isBrand: true,
      badge: "Official Parlour",
      location: "Nairobi",
      locationArea: "Kilimani - Wood Avenue",
      serviceType: "Incall",
      phone: "+254 720 500600",
      allowWhatsapp: true,
      allowCalls: true,
      allowSms: true,
      advertMediaUrl: "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200",
      advertMediaType: "image",
      servicesOffered: JSON.stringify([
        "Nuru Massage (Body to Body)",
        "Swedish & Deep Tissue Massage",
        "Four-Hands Double Therapist Massage",
        "Jacuzzi & Bubble Bath Treatment",
        "Executive VIP Suite Relaxation",
      ]),
      rates: JSON.stringify([
        { duration: "1 Hour Full Body", priceKsh: 3000 },
        { duration: "1 Hour Nuru Exotic", priceKsh: 5000 },
        { duration: "Four Hands 1 Hour", priceKsh: 8000 },
      ]),
      subscriptionStatus: "active",
      subscriptionPlan: "agency_1500",
      subscriptionExpiresAt: new Date(Date.now() + 26 * 86400000),
      subscriptionPaidAt: new Date(Date.now() - 4 * 86400000),
      lastMpesaCode: "MPR982M1AA",
      tokensBalance: 5800,
      followersCount: 52000,
    },
    // 8. Agency - Lodging & Brothel (Velvet Suites & Agency)
    {
      username: "velvet_suites",
      displayName: "Velvet Suites & Escort Agency 🏨",
      email: "velvet@hotcheelee.com",
      avatar: "https://images.pexels.com/photos/13328313/pexels-photo-13328313.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
      coverImage: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
      bio: "Luxury discrete lodging & 24/7 brothel agency in Westlands. Discrete entrance, secure basement parking, beautiful models ready in-house.",
      accountType: "agency",
      agencyType: "Lodging",
      isBrand: true,
      badge: "Verified Agency",
      location: "Nairobi",
      locationArea: "Westlands - Mpaka Road",
      serviceType: "Both Incall & Outcall",
      phone: "+254 701 223344",
      allowWhatsapp: true,
      allowCalls: true,
      allowSms: true,
      advertMediaUrl: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200",
      advertMediaType: "image",
      servicesOffered: JSON.stringify([
        "Private Room Lodging & Fun",
        "Outcall Hotel Deliveries 24/7",
        "Group Party & Stag Events",
        "Overnight Stay Packages",
      ]),
      rates: JSON.stringify([
        { duration: "Short Time Lodging", priceKsh: 2500 },
        { duration: "Full Hour with Model", priceKsh: 4500 },
        { duration: "Overnight Package", priceKsh: 12000 },
      ]),
      subscriptionStatus: "active",
      subscriptionPlan: "agency_1500",
      subscriptionExpiresAt: new Date(Date.now() + 27 * 86400000),
      lastMpesaCode: "MKO451P9BB",
      tokensBalance: 12000,
      followersCount: 76000,
    },
  ];

  for (const u of sampleUsers) {
    const existing = await db.select().from(users).where(eq(users.username, u.username)).limit(1);
    if (existing.length === 0) {
      await db.insert(users).values(u);
    } else {
      await db.update(users).set(u).where(eq(users.username, u.username));
    }
  }

  // Seed sample subscription records for admin review
  const allUsersNow = await db.select().from(users);
  const elena = allUsersNow.find((u) => u.username === "elena_lux") || allUsersNow[0];
  const serenity = allUsersNow.find((u) => u.username === "serenity_spa") || allUsersNow[0];
  const sasha = allUsersNow.find((u) => u.username === "sasha_vixen") || allUsersNow[0];

  const existingSubs = await db.select().from(subscriptions).limit(1);
  if (existingSubs.length === 0 && elena) {
    await db.insert(subscriptions).values([
      {
        userId: elena.id,
        accountType: "creator",
        plan: "creator_500",
        amountKsh: 500,
        tillNumber: "8923411",
        mpesaCode: "SHB492X1KL",
        phonePaid: "+254722890123",
        status: "approved",
        approvedAt: new Date(),
        expiresAt: new Date(Date.now() + 30 * 86400000),
        notes: "M-Pesa payment confirmed for Elena Lux",
      },
      {
        userId: serenity.id,
        accountType: "agency",
        plan: "agency_1500",
        amountKsh: 1500,
        tillNumber: "8923411",
        mpesaCode: "MPR982M1AA",
        phonePaid: "+254720500600",
        status: "approved",
        approvedAt: new Date(),
        expiresAt: new Date(Date.now() + 30 * 86400000),
        notes: "Agency monthly subscription approved",
      },
      {
        userId: sasha.id,
        accountType: "creator",
        plan: "creator_500",
        amountKsh: 500,
        tillNumber: "8923411",
        mpesaCode: "TNM912X4BC",
        phonePaid: "+254798112233",
        status: "pending", // Pending approval for admin demo
        notes: "Awaiting admin confirmation",
      },
    ]);
  }

  // Seed sample bookings
  const existingBookings = await db.select().from(bookings).limit(1);
  if (existingBookings.length === 0 && elena) {
    await db.insert(bookings).values([
      {
        userId: allUsersNow[0].id,
        modelId: elena.id,
        serviceRequested: "Sensual Full Body Massage",
        serviceType: "Incall",
        duration: "1 Hour Incall",
        totalPriceKsh: 4000,
        preferredDate: "Tonight at 8:00 PM",
        clientPhone: "+254712345678",
        clientNote: "Looking forward to relaxing session in Kilimani.",
        status: "confirmed",
      },
      {
        userId: allUsersNow[0].id,
        modelId: serenity.id,
        serviceRequested: "Nuru Exotic Massage",
        serviceType: "Incall",
        duration: "1 Hour Nuru Exotic",
        totalPriceKsh: 5000,
        preferredDate: "Tomorrow 3:00 PM",
        clientPhone: "+254712345678",
        clientNote: "VIP suite booked.",
        status: "pending",
      },
    ]);
  }

  // Seed Facebook-style HotCheelee Pages
  const existingPages = await db.select().from(pages).limit(1);
  if (existingPages.length === 0 && serenity && elena) {
    const [p1, p2, p3] = await db.insert(pages).values([
      {
        ownerId: serenity.id,
        name: "Serenity Executive Spa & Parlour",
        slug: "serenity-executive-spa",
        category: "Massage Parlour",
        about: "Nairobi's top rated luxury massage and wellness parlour located along Wood Avenue, Kilimani. 12+ qualified therapists offering Nuru, Swedish, Jacuzzi and VIP relaxation.",
        bio: "Certified VIP Therapists & Private Suites in Kilimani. Open 24/7.",
        location: "Nairobi",
        locationArea: "Kilimani - Wood Avenue",
        phone: "+254 720 500600",
        whatsapp: "+254 720 500600",
        avatar: "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg",
        coverImage: "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg",
        likesCount: 1420,
        followersCount: 3840,
        verified: true,
        priceRange: "KSh 3,000 - 8,000",
        services: JSON.stringify(["Nuru Body to Body", "Swedish Deep Tissue", "Four Hands Massage", "VIP Jacuzzi Experience"]),
        rates: JSON.stringify([{ title: "Swedish 1hr", price: 3000 }, { title: "Nuru Exotic 1hr", price: 5000 }, { title: "Four Hands 1hr", price: 8000 }]),
      },
      {
        ownerId: elena.id,
        name: "Elena Lux VIP Escort & Glamour",
        slug: "elena-lux-vip",
        category: "Creator Official",
        about: "Official verified page for Elena Lux. High-end sensual companionship, luxury boudoir photo updates, international travel companion bookings and VIP events.",
        bio: "Top 0.05% Creator & Companion &bull; Penthouse Incall in Kilimani.",
        location: "Nairobi",
        locationArea: "Kilimani - Argwings Kodhek",
        phone: "+254 722 890123",
        whatsapp: "+254 722 890123",
        avatar: "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg",
        coverImage: "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg",
        likesCount: 2890,
        followersCount: 8120,
        verified: true,
        priceRange: "KSh 4,000 - 20,000",
        services: JSON.stringify(["Dinner & Escort Date", "Sensual Full Body Massage", "Overnight Stays", "GFE Experience"]),
        rates: JSON.stringify([{ title: "1 Hour Incall", price: 4000 }, { title: "2 Hours Extended", price: 7000 }, { title: "Overnight Incall", price: 15000 }]),
      },
      {
        ownerId: allUsersNow.find((u) => u.username === "velvet_suites")?.id || serenity.id,
        name: "Velvet Suites 24/7 Brothel & Lodging",
        slug: "velvet-suites-brothel",
        category: "Lodging",
        about: "Discreet hotel lodging and in-house companions in Westlands. 24-hour private access, secure basement parking, fully licensed and discrete.",
        bio: "Private rooms & verified in-house models ready 24/7 in Westlands.",
        location: "Nairobi",
        locationArea: "Westlands - Mpaka Road",
        phone: "+254 701 223344",
        whatsapp: "+254 701 223344",
        avatar: "https://images.pexels.com/photos/13328313/pexels-photo-13328313.jpeg",
        coverImage: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg",
        likesCount: 940,
        followersCount: 2450,
        verified: true,
        priceRange: "KSh 2,500 - 12,000",
        services: JSON.stringify(["Short Time Lodging", "Full Hour with Model", "Overnight Package", "Outcall Delivery"]),
        rates: JSON.stringify([{ title: "Short Time Lodging", price: 2500 }, { title: "Full Hour Package", price: 4500 }, { title: "Overnight Stay", price: 12000 }]),
      },
    ]).returning();

    if (p1) {
      await db.insert(pagePosts).values([
        {
          pageId: p1.id,
          authorId: serenity.id,
          content: "✨ Friday Special at Serenity Spa! Book our 4-hands body massage today and get complimentary jacuzzi access. 12 therapists ready in Kilimani.",
          mediaUrls: JSON.stringify([{ url: "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg", type: "image" }]),
          likesCount: 48,
          commentsCount: 12,
        },
      ]);
    }
  }

  // Seed default Jackpot
  const existingJackpots = await db.select().from(jackpots).limit(1);
  const mainUser = allUsersNow.find((u) => u.username === "alex_member") || allUsersNow[0];
  if (existingJackpots.length === 0 && mainUser) {
    await db.insert(jackpots).values([
      {
        creatorId: mainUser.id,
        jackpotType: "daily",
        title: "Daily HotCheelee Jackpot #101",
        matches: JSON.stringify([
          { matchIndex: 1, teamA: "Arsenal", teamB: "Chelsea", matchDate: "Tonight 20:00" },
          { matchIndex: 2, teamA: "Bayern Munich", teamB: "Dortmund", matchDate: "Tonight 21:30" },
        ]),
        matchesCount: 2,
        creationCostCoins: 500,
        entryFeeCoins: 50,
        totalPoolCoins: 1250,
        creatorRewardPercent: 90,
        platformFeePercent: 10,
        status: "open",
        entriesCount: 5,
        expiresAt: new Date(Date.now() + 24 * 3600 * 1000),
      },
    ]);
  }

  console.log("Seeding completed successfully for HotCheelee!");
}

export default seedDatabase;
