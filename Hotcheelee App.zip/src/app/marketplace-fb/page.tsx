"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  ShoppingBag,
  Plus,
  Coins,
  MapPin,
  Tag,
  Search,
  Filter,
  Check,
  Phone,
  Sparkles,
  X,
} from "lucide-react";

export default function MarketplaceFacebookPage() {
  const { currentUser, openTokensModal } = useApp();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [showSellModal, setShowSellModal] = useState(false);

  // Form states
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priceKsh, setPriceKsh] = useState("2500");
  const [itemCategory, setItemCategory] = useState("Toys & Hardware");
  const [condition, setCondition] = useState("Brand New");
  const [locationArea, setLocationArea] = useState("Kilimani, Nairobi");
  const [imageUrl, setImageUrl] = useState("");

  const categories = ["All", "Toys & Hardware", "Lingerie & Outfits", "Sensual Oils & Gels", "VIP Services", "Cosplay & Costumes"];

  const loadItems = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/market-fb");
      const data = await res.json();
      if (data.items) setItems(data.items);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadItems();
  }, []);

  const handleSellItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !priceKsh) return;

    try {
      const res = await fetch("/api/market-fb", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          priceKsh: Number(priceKsh),
          category: itemCategory,
          condition,
          locationArea,
          images: [imageUrl.trim() || "https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg"],
          contactPhone: currentUser?.phone || "+254 700 892341",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setShowSellModal(false);
        setTitle("");
        setDescription("");
        loadItems();
      } else {
        alert(data.error || "Failed to list item");
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#1f1624] via-[#141829] to-[#0e121b] border border-[#ff3358]/40 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <ShoppingBag className="w-6 h-6 text-amber-400" />
                <h1 className="text-2xl font-black text-white">HotCheelee Marketplace (Facebook Clone)</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
                Buy & sell adult toys (Lovense), luxury lingerie, massage oils, and discrete items across Kenya.
              </p>
            </div>

            <button
              onClick={() => setShowSellModal(true)}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
            >
              <Plus className="w-4 h-4" />
              <span>Create Listing</span>
            </button>
          </div>

          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  category === c
                    ? "bg-[#ff3358] text-white shadow-sm"
                    : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          {/* Items Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {items
              .filter((i) => category === "All" || i.category.toLowerCase().includes(category.toLowerCase()))
              .map((item) => {
                const img = (() => {
                  try {
                    return JSON.parse(item.images)[0];
                  } catch {
                    return item.images;
                  }
                })();
                return (
                  <div
                    key={item.id}
                    className="bg-[#13161f] border border-[#212735] hover:border-amber-400/60 rounded-2xl overflow-hidden transition group flex flex-col justify-between"
                  >
                    <div className="relative aspect-square bg-black overflow-hidden">
                      <img
                        src={img || "https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg"}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      />
                      <span className="absolute top-2.5 right-2.5 bg-black/70 backdrop-blur-md text-[10px] font-black uppercase text-amber-400 px-2 py-0.5 rounded-full border border-white/10">
                        {item.condition}
                      </span>
                    </div>

                    <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2">
                      <div>
                        <div className="text-base font-black text-amber-400">
                          KSh {item.priceKsh.toLocaleString()}
                        </div>
                        <h4 className="text-xs font-bold text-white group-hover:text-[#ff3358] transition truncate">
                          {item.title}
                        </h4>
                        <span className="text-[10px] text-zinc-400 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-[#ff3358]" />
                          {item.locationArea || "Nairobi"}
                        </span>
                      </div>

                      <div className="pt-2 border-t border-[#1e2330] flex items-center justify-between text-xs">
                        <span className="text-[10px] text-zinc-500">{item.priceCoins} Coins</span>
                        <a
                          href={`https://wa.me/${(item.contactPhone || "254700892341").replace(/[^0-9]/g, "")}?text=Hi,%20inquiring%20about%20${encodeURIComponent(item.title)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px]"
                        >
                          WhatsApp &rarr;
                        </a>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>

          {/* Create Listing Modal */}
          {showSellModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
              <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
                <button
                  onClick={() => setShowSellModal(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>

                <h3 className="text-lg font-black text-white mb-1">Create Marketplace Listing</h3>
                <p className="text-xs text-zinc-400 mb-4">Post toys, outfits or products for sale</p>

                <form onSubmit={handleSellItem} className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Product Title *</label>
                    <input
                      type="text"
                      placeholder="e.g. Lovense Lush 3 Bluetooth Vibrator (Brand New)"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Price (KSh) *</label>
                      <input
                        type="number"
                        placeholder="4500"
                        value={priceKsh}
                        onChange={(e) => setPriceKsh(e.target.value)}
                        required
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Category</label>
                      <select
                        value={itemCategory}
                        onChange={(e) => setItemCategory(e.target.value)}
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      >
                        {categories.filter((c) => c !== "All").map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Condition</label>
                      <select
                        value={condition}
                        onChange={(e) => setCondition(e.target.value)}
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      >
                        <option value="Brand New">Brand New</option>
                        <option value="Like New">Like New</option>
                        <option value="Good Condition">Good Condition</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Area / City</label>
                      <input
                        type="text"
                        placeholder="Kilimani, Nairobi"
                        value={locationArea}
                        onChange={(e) => setLocationArea(e.target.value)}
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Product Photo URL</label>
                    <input
                      type="url"
                      placeholder="https://images.pexels.com/...jpg"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Description</label>
                    <textarea
                      rows={2}
                      placeholder="Describe features, battery life, packaging..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer"
                  >
                    Publish Marketplace Listing
                  </button>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
