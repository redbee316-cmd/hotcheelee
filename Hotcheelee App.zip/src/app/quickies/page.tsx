"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import { useApp } from "@/context/AppContext";
import {
  Flame,
  MessageCircle,
  Volume2,
  VolumeX,
  ChevronUp,
  ChevronDown,
  Sparkles,
  ExternalLink,
  UserPlus,
  Check,
  Send,
  Coins,
  Gift,
  Phone,
  Plus,
  Smartphone,
} from "lucide-react";

export default function QuickiesPage() {
  const { openTipModal, openTipMenuModal, openToyModal, openContactModal, openCreateQuickieModal, currentUser, triggerWatchTick } = useApp();
  const [quickies, setQuickies] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [flamedMap, setFlamedMap] = useState<Record<number, boolean>>({});
  const [flamesMap, setFlamesMap] = useState<Record<number, number>>({});
  const [followingMap, setFollowingMap] = useState<Record<number, boolean>>({});
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [commentInput, setCommentInput] = useState("");
  const [loading, setLoading] = useState(true);

  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    fetch("/api/posts?filter=quickies")
      .then((res) => res.json())
      .then((data) => {
        if (data.posts && data.posts.length > 0) {
          setQuickies(data.posts);
          const fMap: Record<number, boolean> = {};
          const cMap: Record<number, number> = {};
          const followMap: Record<number, boolean> = {};
          data.posts.forEach((p: any) => {
            fMap[p.id] = Boolean(p.hasFlamed);
            cMap[p.id] = p.flamesCount || 0;
            if (p.author) followMap[p.author.id] = Boolean(p.isFollowingAuthor);
          });
          setFlamedMap(fMap);
          setFlamesMap(cMap);
          setFollowingMap(followMap);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const currentQuickie = quickies[currentIndex];

  const handleNext = () => {
    if (currentIndex < quickies.length - 1) {
      setCurrentIndex((c) => c + 1);
      setIsPlaying(true);
      triggerWatchTick();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((c) => c - 1);
      setIsPlaying(true);
    }
  };

  const handleToggleFlame = async () => {
    if (!currentQuickie) return;
    const isFlamed = flamedMap[currentQuickie.id];
    const prevCount = flamesMap[currentQuickie.id] || 0;

    setFlamedMap((prev) => ({ ...prev, [currentQuickie.id]: !isFlamed }));
    setFlamesMap((prev) => ({
      ...prev,
      [currentQuickie.id]: isFlamed ? Math.max(0, prevCount - 1) : prevCount + 1,
    }));

    try {
      await fetch(`/api/posts/${currentQuickie.id}/flame`, { method: "POST" });
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleFollow = async () => {
    if (!currentQuickie?.author) return;
    const authorId = currentQuickie.author.id;
    const isFollowing = followingMap[authorId];
    setFollowingMap((prev) => ({ ...prev, [authorId]: !isFollowing }));

    try {
      await fetch(`/api/users/${currentQuickie.author.username}/follow`, { method: "POST" });
    } catch (e) {
      console.error(e);
    }
  };

  const loadComments = async () => {
    if (!currentQuickie) return;
    try {
      const res = await fetch(`/api/posts/${currentQuickie.id}/comments`);
      const data = await res.json();
      if (res.ok) setComments(data.comments || []);
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !currentQuickie) return;

    try {
      const res = await fetch(`/api/posts/${currentQuickie.id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: commentInput.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.comment) {
        setComments([data.comment, ...comments]);
        setCommentInput("");
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-xl mx-auto w-full min-w-0 flex flex-col items-center">
          {/* Top Quickie Action Bar with + Create Quickie Icon Button */}
          <div className="w-full max-w-md flex items-center justify-between mb-3 bg-[#13161f] border border-[#212735] p-2.5 px-4 rounded-2xl shadow-sm">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-[#ff3358]" />
                9:16 Vertical Quickies
              </span>
              <span className="text-[10px] text-amber-400 font-bold">&bull; Max 60s</span>
            </div>

            <button
              onClick={openCreateQuickieModal}
              className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold transition flex items-center gap-1.5 shadow cursor-pointer hover:scale-105"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Create Quickie</span>
            </button>
          </div>

          {loading ? (
            <div className="w-full max-w-md h-[78vh] bg-[#13161f] border border-[#212735] rounded-3xl animate-pulse" />
          ) : !currentQuickie ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center text-white space-y-3">
              <p className="text-sm font-bold">No quickies available right now.</p>
              <button
                onClick={openCreateQuickieModal}
                className="py-2 px-4 rounded-xl bg-[#ff3358] text-white text-xs font-bold"
              >
                + Post the First 9:16 Quickie
              </button>
            </div>
          ) : (
            <div className="relative w-full max-w-md h-[80vh] bg-black rounded-3xl overflow-hidden shadow-2xl border border-[#252c3c] flex flex-col justify-between">
              {/* Strictly 9:16 vertical video */}
              <video
                ref={videoRef}
                src={
                  currentQuickie.videoUrl ||
                  (currentQuickie.media && currentQuickie.media[0]?.url) ||
                  "https://videos.pexels.com/video-files/7845993/7845993-hd_1080_1920_30fps.mp4"
                }
                autoPlay
                playsInline
                loop
                muted={isMuted}
                onClick={() => {
                  if (videoRef.current) {
                    if (videoRef.current.paused) {
                      videoRef.current.play();
                      setIsPlaying(true);
                      triggerWatchTick();
                    } else {
                      videoRef.current.pause();
                      setIsPlaying(false);
                    }
                  }
                }}
                className="absolute inset-0 w-full h-full object-cover cursor-pointer"
                style={{ aspectRatio: "9/16" }}
              />

              {/* Top Controls: Sound & Quickies Tag */}
              <div className="relative z-20 p-4 flex items-center justify-between bg-gradient-to-b from-black/80 via-black/30 to-transparent">
                <div className="flex items-center gap-2">
                  <span className="bg-[#ff3358] text-white text-[11px] font-black uppercase px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1">
                    <Flame className="w-3 h-3 fill-white" />
                    Quickie #{currentIndex + 1}
                  </span>
                  <span className="bg-amber-400 text-black text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow-md flex items-center gap-1">
                    <Coins className="w-3 h-3" />
                    9:16 Max 60s
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Inside Quickies: Create Quickie icon button */}
                  <button
                    onClick={openCreateQuickieModal}
                    className="p-2 rounded-full bg-[#ff3358] text-white hover:scale-110 transition cursor-pointer shadow-lg"
                    title="Upload 9:16 Quickie Reel"
                  >
                    <Plus className="w-4 h-4 stroke-[3]" />
                  </button>

                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:scale-110 transition cursor-pointer"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Floating Action Buttons Right Side */}
              <div className="absolute right-3 bottom-20 z-30 flex flex-col items-center gap-4">
                <div className="relative">
                  <Link href={`/profile/${currentQuickie.author?.username || "alex_member"}`}>
                    <img
                      src={currentQuickie.author?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                      alt="Creator"
                      className="w-12 h-12 rounded-full object-cover ring-2 ring-[#ff3358]"
                    />
                  </Link>
                  {currentQuickie.author && (
                    <button
                      onClick={handleToggleFollow}
                      className={`absolute -bottom-1 left-1/2 -translate-x-1/2 p-0.5 rounded-full cursor-pointer transition ${
                        followingMap[currentQuickie.author.id]
                          ? "bg-emerald-500 text-white"
                          : "bg-[#ff3358] text-white"
                      }`}
                    >
                      {followingMap[currentQuickie.author.id] ? (
                        <Check className="w-3 h-3" />
                      ) : (
                        <UserPlus className="w-3 h-3" />
                      )}
                    </button>
                  )}
                </div>

                <button
                  onClick={handleToggleFlame}
                  className="flex flex-col items-center gap-1 cursor-pointer group"
                >
                  <div
                    className={`p-3 rounded-full backdrop-blur-md transition ${
                      flamedMap[currentQuickie.id]
                        ? "bg-[#ff3358] text-white shadow-lg shadow-[#ff3358]/50 scale-110"
                        : "bg-black/60 text-white group-hover:text-[#ff3358]"
                    }`}
                  >
                    <Flame className={`w-5 h-5 ${flamedMap[currentQuickie.id] ? "fill-white" : ""}`} />
                  </div>
                  <span className="text-[11px] font-bold text-white drop-shadow">
                    {(flamesMap[currentQuickie.id] || 0).toLocaleString()}
                  </span>
                </button>

                <button
                  onClick={() => {
                    if (!showComments) loadComments();
                    setShowComments(!showComments);
                  }}
                  className="flex flex-col items-center gap-1 cursor-pointer group"
                >
                  <div className="p-3 rounded-full bg-black/60 backdrop-blur-md text-white group-hover:text-[#ff3358] transition">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-bold text-white drop-shadow">
                    {currentQuickie.commentsCount || 0}
                  </span>
                </button>

                {/* Contact & WhatsApp Reveal on Reel */}
                {currentQuickie.author && (
                  <button
                    onClick={() => openContactModal(currentQuickie.author)}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                    title="Reveal Contact & WhatsApp"
                  >
                    <div className="p-3 rounded-full bg-emerald-600/90 text-white shadow-md shadow-emerald-600/30 group-hover:scale-105 transition">
                      <Phone className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-emerald-400 drop-shadow">
                      Call/WA
                    </span>
                  </button>
                )}

                {currentQuickie.author && (
                  <button
                    onClick={() =>
                      openTipModal({
                        id: currentQuickie.author.id,
                        username: currentQuickie.author.username,
                        displayName: currentQuickie.author.displayName,
                        avatar: currentQuickie.author.avatar,
                        postId: currentQuickie.id,
                      })
                    }
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="p-3 rounded-full bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white shadow-md shadow-[#ff3358]/30 group-hover:scale-105 transition">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-bold text-amber-300 drop-shadow">
                      Tip
                    </span>
                  </button>
                )}
              </div>

              {/* Bottom Caption Overlay */}
              <div className="relative z-20 p-4 pt-8 bg-gradient-to-t from-black via-black/70 to-transparent space-y-2">
                <div className="flex items-center gap-2">
                  <Link
                    href={`/profile/${currentQuickie.author?.username || "creator"}`}
                    className="text-sm font-bold text-white hover:text-[#ff3358] drop-shadow"
                  >
                    @{currentQuickie.author?.username || "creator"}
                  </Link>
                  {currentQuickie.author?.isVerifiedStar && (
                    <span className="bg-[#ff3358] text-white text-[9px] font-black px-1.5 py-0.2 rounded">
                      STAR
                    </span>
                  )}
                  <span className="text-[10px] bg-black/60 text-amber-400 px-1.5 py-0.2 rounded font-mono">
                    9:16 &bull; {currentQuickie.videoDuration || 15}s
                  </span>
                </div>

                <p className="text-xs text-white/95 line-clamp-2 drop-shadow leading-snug">
                  {currentQuickie.content}
                </p>

                {(currentQuickie.promoLinkUrl || currentQuickie.author?.paysiteUrl) && (
                  <a
                    href={currentQuickie.promoLinkUrl || currentQuickie.author?.paysiteUrl || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-xl bg-[#ff3358]/90 hover:bg-[#e11d48] text-white text-xs font-bold transition shadow-lg cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span className="truncate">
                        {currentQuickie.promoLinkLabel || currentQuickie.author?.paysiteLabel || "Watch Full Set"}
                      </span>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                  </a>
                )}
              </div>

              {/* Navigation Up/Down */}
              <div className="absolute left-3 top-1/2 -translate-y-1/2 z-30 flex flex-col gap-2">
                <button
                  onClick={handlePrev}
                  disabled={currentIndex === 0}
                  className="p-2 rounded-full bg-black/60 text-white disabled:opacity-30 hover:scale-110 transition cursor-pointer"
                >
                  <ChevronUp className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  disabled={currentIndex === quickies.length - 1}
                  className="p-2 rounded-full bg-black/60 text-white disabled:opacity-30 hover:scale-110 transition cursor-pointer"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>

              {/* Comments Drawer */}
              {showComments && (
                <div className="absolute inset-x-0 bottom-0 top-1/3 z-40 bg-[#13161f] border-t border-[#262c3b] rounded-t-3xl p-4 flex flex-col justify-between animate-in slide-in-from-bottom duration-200">
                  <div className="flex items-center justify-between pb-2 border-b border-[#212738]">
                    <span className="text-xs font-bold text-white">Comments</span>
                    <button
                      onClick={() => setShowComments(false)}
                      className="text-xs text-zinc-400 hover:text-white"
                    >
                      Close
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto py-2 space-y-2.5">
                    {comments.map((c) => (
                      <div key={c.id} className="flex items-start gap-2 text-xs">
                        <img
                          src={c.author?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                          alt="avatar"
                          className="w-6 h-6 rounded-full object-cover shrink-0"
                        />
                        <div className="flex-1 bg-[#1a202c] p-2 rounded-xl">
                          <span className="font-bold text-white block">{c.author?.displayName}</span>
                          <span className="text-zinc-300">{c.content}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleAddComment} className="flex items-center gap-2 pt-2">
                    <input
                      type="text"
                      placeholder="Comment..."
                      value={commentInput}
                      onChange={(e) => setCommentInput(e.target.value)}
                      className="flex-1 bg-[#0e1118] border border-[#232938] rounded-full px-3 py-1.5 text-xs text-white"
                    />
                    <button
                      type="submit"
                      className="p-1.5 rounded-full bg-[#ff3358] text-white"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
