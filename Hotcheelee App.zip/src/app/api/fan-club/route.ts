import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { fanClubMemberships, users, notifications } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const modelId = url.searchParams.get("modelId");
    const currentUser = await getCurrentUser();

    if (!modelId) {
      return NextResponse.json({ isMember: false });
    }

    const targetModel = await db.select().from(users).where(eq(users.id, Number(modelId))).limit(1);
    if (targetModel.length === 0) {
      return NextResponse.json({ error: "Model not found" }, { status: 404 });
    }

    let isMember = false;
    let membership = null;

    if (currentUser) {
      const res = await db
        .select()
        .from(fanClubMemberships)
        .where(
          and(
            eq(fanClubMemberships.userId, currentUser.id),
            eq(fanClubMemberships.modelId, Number(modelId))
          )
        )
        .limit(1);

      if (res.length > 0) {
        isMember = true;
        membership = res[0];
      }
    }

    // Count total club members
    const totalMembers = await db
      .select()
      .from(fanClubMemberships)
      .where(eq(fanClubMemberships.modelId, Number(modelId)));

    return NextResponse.json({
      isMember,
      membership,
      fanClubPriceMonthly: targetModel[0].fanClubPriceMonthly || 50,
      totalClubMembers: totalMembers.length,
      perks: [
        "10% OFF entire performer tip menu actions",
        "Exclusive access to Fan-Club only photos & 4K clips",
        "Direct offline messaging priority with Star badge",
        "Special highlighted chat name & VIP badge",
        "Free participation in model's monthly token raffles",
      ],
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Join or Renew Fan Club with Tokens
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { modelId } = body;

    const modelRes = await db.select().from(users).where(eq(users.id, Number(modelId))).limit(1);
    if (modelRes.length === 0) {
      return NextResponse.json({ error: "Model not found" }, { status: 404 });
    }

    const model = modelRes[0];
    const cost = model.fanClubPriceMonthly || 50;

    if (currentUser.tokensBalance < cost) {
      return NextResponse.json({
        error: `Insufficient tokens! You need ${cost} tokens to subscribe to ${model.displayName}'s Fan Club.`,
      }, { status: 400 });
    }

    // Deduct tokens
    const newBalance = currentUser.tokensBalance - cost;
    await db
      .update(users)
      .set({
        tokensBalance: newBalance,
        userXp: currentUser.userXp + 500,
      })
      .where(eq(users.id, currentUser.id));

    // Calculate expiry (30 days from now)
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    const [membership] = await db
      .insert(fanClubMemberships)
      .values({
        userId: currentUser.id,
        modelId: Number(modelId),
        tier: "VIP Fan Club",
        tokensPaid: cost,
        discountPercent: 10,
        expiresAt,
      })
      .returning();

    // Notify model
    await db.insert(notifications).values({
      userId: Number(modelId),
      actorId: currentUser.id,
      type: "fanclub",
      message: `${currentUser.displayName} joined your VIP Fan Club for ${cost} tokens! 👑`,
    });

    return NextResponse.json({
      success: true,
      message: `Welcome to ${model.displayName}'s VIP Fan Club! Enjoy 10% off tip menus & exclusive content.`,
      membership,
      newTokensBalance: newBalance,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
