import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { posts, users, topics, postFlames, bookmarks, follows } from "@/db/schema";
import { eq, desc, sql, and } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const filter = url.searchParams.get("filter") || "for-you"; // for-you, following, popular, latest, quickies, media-only
    const topicSlug = url.searchParams.get("topic");
    const username = url.searchParams.get("username");
    const search = url.searchParams.get("q");
    const tag = url.searchParams.get("tag");

    const currentUser = await getCurrentUser();

    // Base query
    let allPosts = await db
      .select({
        post: posts,
        author: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          phone: users.phone,
          accountType: users.accountType,
          genderRole: users.genderRole,
          locationArea: users.locationArea,
          serviceType: users.serviceType,
          allowWhatsapp: users.allowWhatsapp,
          allowCalls: users.allowCalls,
          allowSms: users.allowSms,
          isVerifiedStar: users.isVerifiedStar,
          isBrand: users.isBrand,
          badge: users.badge,
          paysiteUrl: users.paysiteUrl,
          paysiteLabel: users.paysiteLabel,
          subscriptionStatus: users.subscriptionStatus,
        },
        topic: {
          id: topics.id,
          slug: topics.slug,
          name: topics.name,
          icon: topics.icon,
        },
      })
      .from(posts)
      .leftJoin(users, eq(posts.userId, users.id))
      .leftJoin(topics, eq(posts.topicId, topics.id))
      .orderBy(desc(posts.isPinned), desc(posts.createdAt));

    // Get current user interactions
    let flamedPostIds = new Set<number>();
    let bookmarkedPostIds = new Set<number>();
    let followedUserIds = new Set<number>();

    if (currentUser) {
      const flames = await db
        .select({ postId: postFlames.postId })
        .from(postFlames)
        .where(eq(postFlames.userId, currentUser.id));
      flames.forEach((f) => flamedPostIds.add(f.postId));

      const saved = await db
        .select({ postId: bookmarks.postId })
        .from(bookmarks)
        .where(eq(bookmarks.userId, currentUser.id));
      saved.forEach((b) => bookmarkedPostIds.add(b.postId));

      const following = await db
        .select({ followingId: follows.followingId })
        .from(follows)
        .where(eq(follows.followerId, currentUser.id));
      following.forEach((f) => followedUserIds.add(f.followingId));
    }

    // Apply filters in JS
    let filtered = allPosts;

    if (topicSlug) {
      filtered = filtered.filter((p) => p.topic?.slug === topicSlug);
    }

    if (username) {
      filtered = filtered.filter((p) => p.author?.username === username);
    }

    if (tag) {
      const cleanTag = tag.replace(/^#/, "").toLowerCase();
      filtered = filtered.filter((p) => {
        try {
          const postTags = JSON.parse(p.post.tags || "[]") as string[];
          return postTags.some((t) => t.toLowerCase() === cleanTag);
        } catch {
          return false;
        }
      });
    }

    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.post.content.toLowerCase().includes(q) ||
          p.author?.displayName.toLowerCase().includes(q) ||
          p.author?.username.toLowerCase().includes(q) ||
          p.topic?.name.toLowerCase().includes(q)
      );
    }

    if (filter === "following" && currentUser) {
      filtered = filtered.filter((p) => p.author?.id && followedUserIds.has(p.author.id));
    } else if (filter === "popular") {
      filtered = [...filtered].sort((a, b) => b.post.flamesCount - a.post.flamesCount);
    } else if (filter === "latest") {
      filtered = [...filtered].sort((a, b) => new Date(b.post.createdAt).getTime() - new Date(a.post.createdAt).getTime());
    } else if (filter === "quickies") {
      filtered = filtered.filter((p) => p.post.isQuickie || p.post.videoUrl);
    } else if (filter === "media-only") {
      filtered = filtered.filter((p) => {
        try {
          const media = JSON.parse(p.post.mediaUrls || "[]");
          return media.length > 0 || p.post.videoUrl;
        } catch {
          return false;
        }
      });
    }

    const responseData = filtered.map((item) => ({
      ...item.post,
      author: item.author,
      topic: item.topic,
      hasFlamed: flamedPostIds.has(item.post.id),
      hasBookmarked: bookmarkedPostIds.has(item.post.id),
      isFollowingAuthor: item.author?.id ? followedUserIds.has(item.author.id) : false,
      media: (() => {
        try {
          return JSON.parse(item.post.mediaUrls || "[]");
        } catch {
          return [];
        }
      })(),
      tagsList: (() => {
        try {
          return JSON.parse(item.post.tags || "[]");
        } catch {
          return [];
        }
      })(),
    }));

    return NextResponse.json(
      { posts: responseData },
      { headers: { "Cache-Control": "public, s-maxage=2, stale-while-revalidate=15" } }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { content, topicId, media, promoLinkUrl, promoLinkLabel, tags, isQuickie, videoUrl, priceKsh, isFanClubOnly } = body;

    if (!content && (!media || media.length === 0) && !videoUrl) {
      return NextResponse.json({ error: "Post content or media is required" }, { status: 400 });
    }

    // Extract hashtags from content if tags not explicitly passed
    let postTags = tags || [];
    if (!tags || tags.length === 0) {
      const matched = content.match(/#(\w+)/g);
      if (matched) {
        postTags = matched.map((m: string) => m.replace("#", ""));
      }
    }

    const [newPost] = await db
      .insert(posts)
      .values({
        userId: currentUser.id,
        topicId: topicId ? Number(topicId) : null,
        content: content || "",
        mediaUrls: media ? JSON.stringify(media) : "[]",
        promoLinkUrl: promoLinkUrl || currentUser.paysiteUrl || null,
        promoLinkLabel: promoLinkLabel || currentUser.paysiteLabel || null,
        tags: JSON.stringify(postTags),
        isQuickie: Boolean(isQuickie),
        videoUrl: videoUrl || null,
        priceKsh: priceKsh ? Number(priceKsh) : null,
        isFanClubOnly: Boolean(isFanClubOnly),
      })
      .returning();

    // If posted to a topic, increment topic post count
    if (topicId) {
      await db
        .update(topics)
        .set({ postsCount: sql`${topics.postsCount} + 1` })
        .where(eq(topics.id, Number(topicId)));
    }

    return NextResponse.json({ post: newPost }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
