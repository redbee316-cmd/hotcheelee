import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { bookmarks, posts } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const postId = Number(id);
    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const post = await db.select().from(posts).where(eq(posts.id, postId)).limit(1);
    if (post.length === 0) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    const existing = await db
      .select()
      .from(bookmarks)
      .where(and(eq(bookmarks.postId, postId), eq(bookmarks.userId, currentUser.id)))
      .limit(1);

    let bookmarked = false;
    if (existing.length > 0) {
      await db
        .delete(bookmarks)
        .where(and(eq(bookmarks.postId, postId), eq(bookmarks.userId, currentUser.id)));
      bookmarked = false;
    } else {
      await db.insert(bookmarks).values({
        postId,
        userId: currentUser.id,
      });
      bookmarked = true;
    }

    return NextResponse.json({ success: true, bookmarked });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
