import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { comments, users, posts, notifications } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const postId = Number(id);

    const postComments = await db
      .select({
        comment: comments,
        author: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          isVerifiedStar: users.isVerifiedStar,
          badge: users.badge,
        },
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.postId, postId))
      .orderBy(desc(comments.createdAt));

    const formatted = postComments.map((item) => ({
      ...item.comment,
      author: item.author,
    }));

    return NextResponse.json({ comments: formatted });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const postId = Number(id);
    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { content } = body;

    if (!content || !content.trim()) {
      return NextResponse.json({ error: "Comment cannot be empty" }, { status: 400 });
    }

    const post = await db.select().from(posts).where(eq(posts.id, postId)).limit(1);
    if (post.length === 0) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    const [newComment] = await db
      .insert(comments)
      .values({
        postId,
        userId: currentUser.id,
        content: content.trim(),
      })
      .returning();

    // Increment post commentsCount
    await db
      .update(posts)
      .set({ commentsCount: sql`${posts.commentsCount} + 1` })
      .where(eq(posts.id, postId));

    // Notify author if not self
    if (post[0].userId !== currentUser.id) {
      await db.insert(notifications).values({
        userId: post[0].userId,
        actorId: currentUser.id,
        type: "comment",
        postId,
        message: `${currentUser.displayName} commented on your post: "${content.trim().slice(0, 50)}..."`,
      });
    }

    return NextResponse.json({
      comment: {
        ...newComment,
        author: {
          id: currentUser.id,
          username: currentUser.username,
          displayName: currentUser.displayName,
          avatar: currentUser.avatar,
          isVerifiedStar: currentUser.isVerifiedStar,
          badge: currentUser.badge,
        },
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
