import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { posts, contentUnlocks, users, notifications, auditLogs } from "@/db/schema";
import { eq, and } from "drizzle-orm";

// Check if a specific post's full video has been unlocked by the current user
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const postId = Number(id);
    const currentUser = await getCurrentUser();

    const postRes = await db.select().from(posts).where(eq(posts.id, postId)).limit(1);
    if (postRes.length === 0) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    const post = postRes[0];
    const isOwner = currentUser && currentUser.id === post.userId;

    let isUnlocked = Boolean(isOwner) || !post.unlockFeeTokens || post.unlockFeeTokens <= 0;

    if (!isUnlocked && currentUser) {
      const unlockRes = await db
        .select()
        .from(contentUnlocks)
        .where(and(eq(contentUnlocks.userId, currentUser.id), eq(contentUnlocks.postId, postId)))
        .limit(1);

      isUnlocked = unlockRes.length > 0;
    }

    return NextResponse.json({
      postId: post.id,
      unlockFeeTokens: post.unlockFeeTokens,
      unlockFeeKsh: post.unlockFeeTokens * 10,
      isUnlocked,
      previewVideoUrl: post.previewVideoUrl,
      // Only reveal full video if unlocked or owner!
      fullVideoUrl: isUnlocked ? (post.fullVideoUrl || post.videoUrl) : null,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Unlock full video by paying the creator-set fee (Sharesome pay-to-unlock mechanic)
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const postId = Number(id);
    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized. Please log in to unlock full video." }, { status: 401 });
    }

    const postRes = await db.select().from(posts).where(eq(posts.id, postId)).limit(1);
    if (postRes.length === 0) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    const post = postRes[0];
    const feeTokens = post.unlockFeeTokens || 0;

    if (feeTokens <= 0) {
      return NextResponse.json({
        success: true,
        message: "This video is already free!",
        fullVideoUrl: post.fullVideoUrl || post.videoUrl,
      });
    }

    // Check if already unlocked
    const existing = await db
      .select()
      .from(contentUnlocks)
      .where(and(eq(contentUnlocks.userId, currentUser.id), eq(contentUnlocks.postId, postId)))
      .limit(1);

    if (existing.length > 0) {
      return NextResponse.json({
        success: true,
        message: "You have already unlocked this full video!",
        fullVideoUrl: post.fullVideoUrl || post.videoUrl,
      });
    }

    // Check balance
    if (currentUser.tokensBalance < feeTokens) {
      return NextResponse.json({
        error: `Insufficient tokens! Unlocking this full video requires 🪙 ${feeTokens} Tokens (KSh ${feeTokens * 10}). You have 🪙 ${currentUser.tokensBalance} Tokens. Please top up your wallet.`,
        requiredTokens: feeTokens,
        currentBalance: currentUser.tokensBalance,
      }, { status: 400 });
    }

    // Deduct tokens from viewer
    const newViewerBalance = currentUser.tokensBalance - feeTokens;
    await db
      .update(users)
      .set({ tokensBalance: newViewerBalance })
      .where(eq(users.id, currentUser.id));

    // Credit 90% to creator, 10% platform fee
    const creatorCredit = Math.floor(feeTokens * 0.90);
    const creatorUser = await db.select().from(users).where(eq(users.id, post.userId)).limit(1);
    if (creatorUser.length > 0) {
      await db
        .update(users)
        .set({ tokensBalance: creatorUser[0].tokensBalance + creatorCredit })
        .where(eq(users.id, post.userId));
    }

    // Log the unlock transaction
    await db.insert(contentUnlocks).values({
      userId: currentUser.id,
      postId,
      feePaidTokens: feeTokens,
      feePaidKsh: feeTokens * 10,
    });

    // Notify creator
    await db.insert(notifications).values({
      userId: post.userId,
      actorId: currentUser.id,
      type: "video_unlocked",
      postId,
      message: `🎉 ${currentUser.displayName} unlocked your full video for 🪙 ${feeTokens} Tokens (+🪙 ${creatorCredit} net credited to your wallet)!`,
    });

    return NextResponse.json({
      success: true,
      message: `Full video unlocked successfully! Paid 🪙 ${feeTokens} Tokens (KSh ${feeTokens * 10}).`,
      fullVideoUrl: post.fullVideoUrl || post.videoUrl,
      newBalance: newViewerBalance,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
