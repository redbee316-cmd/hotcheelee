import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { posts, postFlames, notifications, users } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const postId = Number(id);
    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const post = await db.select().from(posts).where(eq(posts.id, postId)).limit(1);
    if (post.length === 0) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    // Check if user already flamed
    const existing = await db
      .select()
      .from(postFlames)
      .where(and(eq(postFlames.postId, postId), eq(postFlames.userId, currentUser.id)))
      .limit(1);

    let flamed = false;
    let newCount = post[0].flamesCount;

    if (existing.length > 0) {
      // Remove flame
      await db
        .delete(postFlames)
        .where(and(eq(postFlames.postId, postId), eq(postFlames.userId, currentUser.id)));

      await db
        .update(posts)
        .set({ flamesCount: sql`GREATEST(0, ${posts.flamesCount} - 1)` })
        .where(eq(posts.id, postId));

      newCount = Math.max(0, newCount - 1);
      flamed = false;
    } else {
      // Add flame
      await db.insert(postFlames).values({
        postId,
        userId: currentUser.id,
        amount: 1,
      });

      await db
        .update(posts)
        .set({ flamesCount: sql`${posts.flamesCount} + 1` })
        .where(eq(posts.id, postId));

      // Credit post author's flamesReceived counter
      if (post[0].userId !== currentUser.id) {
        await db
          .update(users)
          .set({ flamesReceived: sql`${users.flamesReceived} + 1` })
          .where(eq(users.id, post[0].userId));

        // Create notification
        await db.insert(notifications).values({
          userId: post[0].userId,
          actorId: currentUser.id,
          type: "flame",
          postId,
          message: `${currentUser.displayName} gave your post a Flame 🔥`,
        });
      }

      newCount += 1;
      flamed = true;
    }

    return NextResponse.json({ success: true, flamed, flamesCount: newCount });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
