import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { notifications, users } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(req.url);
    const filter = url.searchParams.get("filter") || "all"; // all, unread, tips, bookings, friends, subscriptions, system

    const items = await db
      .select({
        notification: notifications,
        actor: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(notifications)
      .leftJoin(users, eq(notifications.actorId, users.id))
      .where(eq(notifications.userId, currentUser.id))
      .orderBy(desc(notifications.createdAt))
      .limit(60);

    let formatted = items.map((i) => ({
      ...i.notification,
      actor: i.actor,
    }));

    if (filter === "unread") {
      formatted = formatted.filter((n) => !n.isRead);
    } else if (filter === "tips") {
      formatted = formatted.filter((n) => n.type.includes("tip") || n.type.includes("toy") || n.type.includes("gift") || n.type.includes("flame"));
    } else if (filter === "bookings") {
      formatted = formatted.filter((n) => n.type.includes("booking"));
    } else if (filter === "friends") {
      formatted = formatted.filter((n) => n.type.includes("friend") || n.type.includes("follow"));
    } else if (filter === "subscriptions") {
      formatted = formatted.filter((n) => n.type.includes("sub"));
    }

    const unreadCount = items.filter((i) => !i.notification.isRead).length;

    return NextResponse.json({
      notifications: formatted,
      unreadCount,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Mark single or all notifications as read
export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const { notificationId } = body;

    if (notificationId) {
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(and(eq(notifications.id, Number(notificationId)), eq(notifications.userId, currentUser.id)));
    } else {
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(eq(notifications.userId, currentUser.id));
    }

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Delete notification
export async function DELETE(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(req.url);
    const id = url.searchParams.get("id");

    if (id) {
      await db
        .delete(notifications)
        .where(and(eq(notifications.id, Number(id)), eq(notifications.userId, currentUser.id)));
    }

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
