import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { ptopLoans, users, notifications, auditLogs } from "@/db/schema";
import { eq, desc, or } from "drizzle-orm";

export async function GET() {
  try {
    const loans = await db
      .select({
        loan: ptopLoans,
        borrower: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          phone: users.phone,
          locationArea: users.locationArea,
          userLevel: users.userLevel,
        },
      })
      .from(ptopLoans)
      .leftJoin(users, eq(ptopLoans.borrowerId, users.id))
      .orderBy(desc(ptopLoans.createdAt));

    const all = loans.map((l) => ({ ...l.loan, borrower: l.borrower }));
    const openLoans = all.filter((l) => l.status === "open");
    const fundedLoans = all.filter((l) => l.status === "funded");
    const totalSecuredKsh = fundedLoans.reduce((sum, l) => sum + (l.amountKsh || 0), 0);

    return NextResponse.json({
      loans: all,
      openLoans,
      openCount: openLoans.length,
      fundedCount: fundedLoans.length,
      totalSecuredKsh,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Create Loan Request or Fund / Guarantee
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { action, amountKsh, purpose, durationDays, loanId } = body;

    if (action === "request") {
      const amount = Number(amountKsh);
      if (!amount || amount < 1000) {
        return NextResponse.json({ error: "Minimum peer loan request is KSh 1,000" }, { status: 400 });
      }

      const totalRepayable = Math.round(amount * 1.10); // 10% standard peer interest
      const days = Number(durationDays) || 30;

      const [newLoan] = await db
        .insert(ptopLoans)
        .values({
          borrowerId: currentUser.id,
          amountKsh: amount,
          totalRepayableKsh: totalRepayable,
          durationDays: days,
          purpose: purpose ? purpose.trim() : "Working capital for creator content & equipment",
          status: "open",
        })
        .returning();

      return NextResponse.json({
        success: true,
        message: `Peer loan request for KSh ${amount.toLocaleString()} posted to HotCheelee PtoP Finance!`,
        loan: newLoan,
      }, { status: 201 });
    }

    if (action === "fund" && loanId) {
      const target = await db.select().from(ptopLoans).where(eq(ptopLoans.id, Number(loanId))).limit(1);
      if (target.length === 0) return NextResponse.json({ error: "Loan not found" }, { status: 404 });
      if (target[0].status !== "open") return NextResponse.json({ error: "Loan is already funded or closed" }, { status: 400 });

      // Check lender balance
      const requiredCoins = Math.floor(target[0].amountKsh / 10);
      if (currentUser.tokensBalance < requiredCoins) {
        return NextResponse.json({
          error: `Insufficient wallet balance to fund KSh ${target[0].amountKsh} (requires ${requiredCoins} tokens). Available: ${currentUser.tokensBalance} tk.`,
        }, { status: 400 });
      }

      // Deduct coins from lender
      await db.update(users).set({ tokensBalance: currentUser.tokensBalance - requiredCoins }).where(eq(users.id, currentUser.id));

      // Credit borrower
      const borrower = await db.select().from(users).where(eq(users.id, target[0].borrowerId)).limit(1);
      if (borrower.length > 0) {
        await db.update(users).set({ tokensBalance: borrower[0].tokensBalance + requiredCoins }).where(eq(users.id, borrower[0].id));
      }

      const dueDate = new Date(Date.now() + (target[0].durationDays || 30) * 86400000);

      const [funded] = await db
        .update(ptopLoans)
        .set({
          lenderId: currentUser.id,
          status: "funded",
          fundedAt: new Date(),
          dueDate,
        })
        .where(eq(ptopLoans.id, target[0].id))
        .returning();

      await db.insert(notifications).values({
        userId: target[0].borrowerId,
        actorId: currentUser.id,
        type: "loan_funded",
        message: `${currentUser.displayName} funded your peer loan of KSh ${target[0].amountKsh.toLocaleString()}! Due: ${dueDate.toLocaleDateString()}.`,
      });

      return NextResponse.json({
        success: true,
        message: `You successfully funded loan #${target[0].id} for KSh ${target[0].amountKsh.toLocaleString()}! Repayable: KSh ${target[0].totalRepayableKsh.toLocaleString()}.`,
        loan: funded,
      });
    }

    if (action === "guarantee" && loanId) {
      const [guaranteed] = await db
        .update(ptopLoans)
        .set({ guarantorId: currentUser.id })
        .where(eq(ptopLoans.id, Number(loanId)))
        .returning();

      return NextResponse.json({ success: true, message: "You are now a peer guarantor for this request!", loan: guaranteed });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
