import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { tipMenuItems, users, fanClubMemberships, toyTriggers, notifications } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const modelId = url.searchParams.get("modelId");
    const currentUser = await getCurrentUser();

    let targetModelId = modelId ? Number(modelId) : null;
    if (!targetModelId && currentUser) {
      targetModelId = currentUser.id;
    }

    if (!targetModelId) {
      return NextResponse.json({ items: [] });
    }

    const items = await db
      .select()
      .from(tipMenuItems)
      .where(eq(tipMenuItems.userId, targetModelId));

    // Check if current user is in fan club for 10% discount
    let hasFanClubDiscount = false;
    if (currentUser) {
      const membership = await db
        .select()
        .from(fanClubMemberships)
        .where(
          and(
            eq(fanClubMemberships.userId, currentUser.id),
            eq(fanClubMemberships.modelId, targetModelId)
          )
        )
        .limit(1);
      hasFanClubDiscount = membership.length > 0;
    }

    return NextResponse.json({
      items,
      hasFanClubDiscount,
      discountPercent: hasFanClubDiscount ? 10 : 0,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Execute a Tip Menu Action using Tokens
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { actionId, customMessage } = body;

    const itemRes = await db
      .select()
      .from(tipMenuItems)
      .where(eq(tipMenuItems.id, Number(actionId)))
      .limit(1);

    if (itemRes.length === 0) {
      return NextResponse.json({ error: "Tip menu action not found" }, { status: 404 });
    }

    const item = itemRes[0];
    const modelId = item.userId;

    // Check if user has fan club 10% discount
    const membership = await db
      .select()
      .from(fanClubMemberships)
      .where(
        and(
          eq(fanClubMemberships.userId, currentUser.id),
          eq(fanClubMemberships.modelId, modelId)
        )
      )
      .limit(1);

    let finalCost = item.tokensCost;
    if (membership.length > 0) {
      finalCost = Math.max(1, Math.round(finalCost * 0.9)); // 10% Fan Club perk
    }

    if (currentUser.tokensBalance < finalCost) {
      return NextResponse.json({
        error: `Insufficient Tokens! You need ${finalCost} tokens, but have ${currentUser.tokensBalance}. Buy more tokens below.`,
      }, { status: 400 });
    }

    // Deduct tokens from user, grant XP
    const newBalance = currentUser.tokensBalance - finalCost;
    const gainedXp = finalCost * 10;
    const newXp = currentUser.userXp + gainedXp;
    const newLevel = Math.floor(newXp / 500) + 1;

    await db
      .update(users)
      .set({
        tokensBalance: newBalance,
        userXp: newXp,
        userLevel: newLevel,
      })
      .where(eq(users.id, currentUser.id));

    // Credit tokens to performer
    const modelUser = await db.select().from(users).where(eq(users.id, modelId)).limit(1);
    if (modelUser.length > 0) {
      await db
        .update(users)
        .set({
          tokensBalance: modelUser[0].tokensBalance + finalCost,
        })
        .where(eq(users.id, modelId));
    }

    // If it's a toy vibration trigger, log Lovense trigger
    if (item.toyIntensity > 0) {
      await db.insert(toyTriggers).values({
        senderId: currentUser.id,
        modelId,
        toyName: "Lovense Lush 3",
        intensity: item.toyIntensity,
        durationSeconds: item.durationSeconds,
        tokensTipped: finalCost,
        message: customMessage || `Triggered tip menu: ${item.actionName}`,
      });

      // Update performer live toy intensity level
      await db
        .update(users)
        .set({ interactiveToyLevel: item.toyIntensity })
        .where(eq(users.id, modelId));
    }

    // Send Stripchat notification to performer
    await db.insert(notifications).values({
      userId: modelId,
      actorId: currentUser.id,
      type: "tip_menu",
      message: `${currentUser.displayName} triggered "${item.actionName}" for ${finalCost} tokens! ⚡`,
    });

    return NextResponse.json({
      success: true,
      message: `Triggered "${item.actionName}" for ${finalCost} tokens!`,
      finalCost,
      newTokensBalance: newBalance,
      gainedXp,
      toyIntensity: item.toyIntensity,
      durationSeconds: item.durationSeconds,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
