import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, goalContributions, notifications } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const modelId = url.searchParams.get("modelId");

    if (!modelId) {
      return NextResponse.json({ error: "modelId required" }, { status: 400 });
    }

    const res = await db.select().from(users).where(eq(users.id, Number(modelId))).limit(1);
    if (res.length === 0) {
      return NextResponse.json({ error: "Model not found" }, { status: 404 });
    }

    const model = res[0];
    const percentage = Math.min(
      100,
      Math.round((model.currentGoalProgress / Math.max(1, model.currentGoalTokens)) * 100)
    );

    return NextResponse.json({
      title: model.currentGoalTitle,
      targetTokens: model.currentGoalTokens,
      progressTokens: model.currentGoalProgress,
      percentage,
      isReached: model.currentGoalProgress >= model.currentGoalTokens,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Contribute tokens toward a performer's tip goal
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { modelId, amount, message } = body;

    const tokens = Math.max(1, Number(amount) || 10);
    if (currentUser.tokensBalance < tokens) {
      return NextResponse.json({
        error: `Insufficient tokens! You need ${tokens} tokens. Available: ${currentUser.tokensBalance}`,
      }, { status: 400 });
    }

    // Deduct tokens
    const newBalance = currentUser.tokensBalance - tokens;
    await db
      .update(users)
      .set({
        tokensBalance: newBalance,
        userXp: currentUser.userXp + tokens * 12,
      })
      .where(eq(users.id, currentUser.id));

    // Increase model goal progress
    await db
      .update(users)
      .set({
        currentGoalProgress: sql`${users.currentGoalProgress} + ${tokens}`,
      })
      .where(eq(users.id, Number(modelId)));

    // Record contribution
    await db.insert(goalContributions).values({
      modelId: Number(modelId),
      contributorId: currentUser.id,
      tokensAmount: tokens,
      message: message || "Contributed to Tip Goal 🔥",
    });

    // Notify model
    await db.insert(notifications).values({
      userId: Number(modelId),
      actorId: currentUser.id,
      type: "goal",
      message: `${currentUser.displayName} contributed ${tokens} tokens to your Tip Goal! 🎯`,
    });

    return NextResponse.json({
      success: true,
      message: `Contributed ${tokens} tokens to the goal!`,
      newTokensBalance: newBalance,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
