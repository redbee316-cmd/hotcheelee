import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, tips, notifications } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { receiverId, postId, amount, tokenType, message } = body;

    const tipAmount = Math.max(1, Number(amount) || 10);
    const token = tokenType === "LEE" ? "LEE" : "FLAME";

    const receiver = await db.select().from(users).where(eq(users.id, Number(receiverId))).limit(1);
    if (receiver.length === 0) {
      return NextResponse.json({ error: "Creator not found" }, { status: 404 });
    }

    if (token === "FLAME") {
      if (currentUser.flamesBalance < tipAmount) {
        return NextResponse.json(
          { error: `Insufficient Flames balance. You have ${currentUser.flamesBalance} Flames.` },
          { status: 400 }
        );
      }

      // Deduct from sender
      await db
        .update(users)
        .set({ flamesBalance: sql`${users.flamesBalance} - ${tipAmount}` })
        .where(eq(users.id, currentUser.id));

      // Credit to receiver
      await db
        .update(users)
        .set({
          flamesBalance: sql`${users.flamesBalance} + ${tipAmount}`,
          flamesReceived: sql`${users.flamesReceived} + ${tipAmount}`,
        })
        .where(eq(users.id, receiver[0].id));
    } else {
      // LEE token tip
      const senderLee = Number(currentUser.leeBalance);
      if (senderLee < tipAmount) {
        return NextResponse.json(
          { error: `Insufficient $LEE balance. You have ${senderLee} $LEE.` },
          { status: 400 }
        );
      }

      const newSenderLee = (senderLee - tipAmount).toFixed(2);
      const newRecvLee = (Number(receiver[0].leeBalance) + tipAmount).toFixed(2);

      await db.update(users).set({ leeBalance: newSenderLee }).where(eq(users.id, currentUser.id));
      await db.update(users).set({ leeBalance: newRecvLee }).where(eq(users.id, receiver[0].id));
    }

    // Record tip
    const [tipRecord] = await db
      .insert(tips)
      .values({
        senderId: currentUser.id,
        receiverId: receiver[0].id,
        postId: postId ? Number(postId) : null,
        amount: tipAmount,
        tokenType: token,
        message: message || `Sent you ${tipAmount} ${token}! 🔥`,
      })
      .returning();

    // Create notification
    await db.insert(notifications).values({
      userId: receiver[0].id,
      actorId: currentUser.id,
      type: "tip",
      postId: postId ? Number(postId) : null,
      message: `${currentUser.displayName} tipped you ${tipAmount} ${token}! "${message || 'Keep shining!'}"`,
    });

    const updatedUser = await db.select().from(users).where(eq(users.id, currentUser.id)).limit(1);

    return NextResponse.json({
      success: true,
      tip: tipRecord,
      flamesBalance: updatedUser[0].flamesBalance,
      leeBalance: updatedUser[0].leeBalance,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
