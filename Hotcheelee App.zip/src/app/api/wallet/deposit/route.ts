import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { walletDeposits, users, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const deposits = await db
      .select()
      .from(walletDeposits)
      .where(eq(walletDeposits.userId, currentUser.id))
      .orderBy(desc(walletDeposits.createdAt));

    return NextResponse.json({ deposits });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// User submits manual M-Pesa deposit code for Admin Approval
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { amountKsh, mpesaCode, phonePaid } = body;

    const amount = Number(amountKsh);
    if (!amount || amount < 100) {
      return NextResponse.json({ error: "Minimum M-Pesa deposit is KSh 100 (10 Tokens)" }, { status: 400 });
    }

    if (!mpesaCode || !phonePaid) {
      return NextResponse.json({ error: "M-Pesa code and phone number are required" }, { status: 400 });
    }

    // 1 Token = 10 KSh
    const tokensToCredit = Math.floor(amount / 10);
    const cleanCode = mpesaCode.trim().toUpperCase();

    const [depositRecord] = await db
      .insert(walletDeposits)
      .values({
        userId: currentUser.id,
        amountKsh: amount,
        tokensCredited: tokensToCredit,
        tillNumber: "8923411",
        mpesaCode: cleanCode,
        phonePaid: phonePaid.trim(),
        status: "pending", // strictly moderated by admin
        adminNotes: "Pending confirmation against M-Pesa Till 8923411 statement",
      })
      .returning();

    // Notify all admins
    const admins = await db.select().from(users).where(eq(users.isAdmin, true));
    for (const a of admins) {
      await db.insert(notifications).values({
        userId: a.id,
        actorId: currentUser.id,
        type: "deposit_pending",
        message: `M-Pesa Deposit: KSh ${amount} (${tokensToCredit} tk) from ${currentUser.displayName} (${cleanCode}). Needs verification.`,
      });
    }

    return NextResponse.json({
      success: true,
      message: `Deposit request for KSh ${amount} (${tokensToCredit} tokens) submitted! Admin will verify code ${cleanCode} and credit your wallet.`,
      deposit: depositRecord,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
