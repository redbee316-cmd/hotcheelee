import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, tips } from "@/db/schema";
import { eq, or, desc, sql } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get tips sent and tips received
    const userTips = await db
      .select({
        tip: tips,
        sender: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(tips)
      .leftJoin(users, eq(tips.senderId, users.id))
      .where(or(eq(tips.senderId, currentUser.id), eq(tips.receiverId, currentUser.id)))
      .orderBy(desc(tips.createdAt))
      .limit(30);

    return NextResponse.json({
      balance: currentUser.flamesBalance,
      receivedTotal: currentUser.flamesReceived,
      transactions: userTips.map((t) => ({
        ...t.tip,
        isOutgoing: t.tip.senderId === currentUser.id,
        sender: t.sender,
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { flamesAmount } = body;

    const amount = Number(flamesAmount);
    if (!amount || amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }

    await db
      .update(users)
      .set({ flamesBalance: sql`${users.flamesBalance} + ${amount}` })
      .where(eq(users.id, currentUser.id));

    const updated = await db.select().from(users).where(eq(users.id, currentUser.id)).limit(1);

    return NextResponse.json({
      success: true,
      newBalance: updated[0].flamesBalance,
      addedAmount: amount,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
