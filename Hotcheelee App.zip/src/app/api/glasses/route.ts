import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { nftGlasses, users } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const url = new URL(req.url);
    const filter = url.searchParams.get("filter") || "all"; // all, my, market

    let all = await db.select().from(nftGlasses).orderBy(desc(nftGlasses.priceUsd));

    let myGlasses: any[] = [];
    let marketGlasses: any[] = [];

    if (currentUser) {
      myGlasses = all.filter((g) => g.userId === currentUser.id);
      marketGlasses = all.filter((g) => g.userId === null || g.isListedForSale);
    } else {
      marketGlasses = all.filter((g) => g.userId === null || g.isListedForSale);
    }

    const equippedGlasses = myGlasses.find((g) => g.isEquipped) || myGlasses[0] || null;

    return NextResponse.json({
      myGlasses,
      marketGlasses,
      equippedGlasses,
      totalCount: all.length,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Equip or Buy Glasses
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { action, glassesId } = body; // action: 'equip' | 'buy'

    if (!glassesId) {
      return NextResponse.json({ error: "glassesId required" }, { status: 400 });
    }

    const targetGlasses = await db.select().from(nftGlasses).where(eq(nftGlasses.id, Number(glassesId))).limit(1);
    if (targetGlasses.length === 0) {
      return NextResponse.json({ error: "Glasses not found" }, { status: 404 });
    }

    const item = targetGlasses[0];

    if (action === "equip") {
      // Unequip all user glasses first
      await db
        .update(nftGlasses)
        .set({ isEquipped: false })
        .where(eq(nftGlasses.userId, currentUser.id));

      // Equip this one
      await db
        .update(nftGlasses)
        .set({ isEquipped: true })
        .where(eq(nftGlasses.id, item.id));

      // Update user active_glasses_id & max attention minutes
      await db
        .update(users)
        .set({
          activeGlassesId: item.id,
          attentionMaxMinutes: item.paidMinutesDaily,
          attentionMinutesLeft: Math.min(currentUser.attentionMinutesLeft, item.paidMinutesDaily),
        })
        .where(eq(users.id, currentUser.id));

      return NextResponse.json({ success: true, message: `Equipped ${item.name}!` });
    }

    if (action === "buy") {
      const priceUsd = Number(item.priceUsd);
      const userUsdt = Number(currentUser.usdtBalance);

      if (userUsdt < priceUsd) {
        return NextResponse.json({
          error: `Insufficient USDT balance. Price: $${priceUsd}, your balance: $${userUsdt.toFixed(2)}`,
        }, { status: 400 });
      }

      // Deduct USDT balance
      const newUsdt = (userUsdt - priceUsd).toFixed(2);
      await db
        .update(users)
        .set({ usdtBalance: newUsdt })
        .where(eq(users.id, currentUser.id));

      // Transfer NFT to user
      const [bought] = await db
        .update(nftGlasses)
        .set({
          userId: currentUser.id,
          isListedForSale: false,
          isEquipped: true,
        })
        .where(eq(nftGlasses.id, item.id))
        .returning();

      // Set as active glasses
      await db
        .update(users)
        .set({
          activeGlassesId: item.id,
          attentionMaxMinutes: item.paidMinutesDaily,
          attentionMinutesLeft: item.paidMinutesDaily,
        })
        .where(eq(users.id, currentUser.id));

      return NextResponse.json({
        success: true,
        message: `Purchased ${item.name} for $${priceUsd} USDT!`,
        glasses: bought,
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
