import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { jackpots, jackpotEntries, users, notifications, auditLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const all = await db
      .select({
        jackpot: jackpots,
        creator: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(jackpots)
      .leftJoin(users, eq(jackpots.creatorId, users.id))
      .orderBy(desc(jackpots.createdAt));

    const formatted = all.map((j) => {
      let parsedMatches = [];
      try {
        parsedMatches = JSON.parse(j.jackpot.matches || "[]");
      } catch {}
      return {
        ...j.jackpot,
        creator: j.creator,
        matchesList: parsedMatches,
      };
    });

    const openCount = formatted.filter((j) => j.status === "open").length;
    const totalStaked = formatted.reduce((sum, j) => sum + (j.totalPoolCoins || 0), 0);

    return NextResponse.json({
      jackpots: formatted,
      openCount,
      totalStaked,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Create new Jackpot or Enter existing Jackpot
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { action, jackpotType, matches, jackpotId, predictions } = body;

    // 1. CREATE JACKPOT
    if (action === "create") {
      const type = jackpotType || "daily"; // daily or weekly
      const matchesList = matches || [];

      if (matchesList.length < 2 || matchesList.length > 10) {
        return NextResponse.json({ error: "Jackpot must contain between 2 and 10 matches" }, { status: 400 });
      }

      // Check all team names filled
      for (const m of matchesList) {
        if (!m.teamA?.trim() || !m.teamB?.trim()) {
          return NextResponse.json({ error: "Fill in all team names before creating." }, { status: 400 });
        }
      }

      const matchesCount = matchesList.length;
      const creationCost = matchesCount * 250; // e.g. 2 games * 250 = 500 coins
      const entryCost = matchesCount * 25; // e.g. 2 * 25 = 50 coins

      if (currentUser.tokensBalance < creationCost) {
        return NextResponse.json({
          error: `Insufficient balance! Creating this ${matchesCount}-match jackpot requires 🪙 ${creationCost} Coins. Your balance is 🪙 ${currentUser.tokensBalance}. Buy coins first.`,
          requiredCoins: creationCost,
        }, { status: 400 });
      }

      // Deduct creation cost
      await db
        .update(users)
        .set({ tokensBalance: currentUser.tokensBalance - creationCost })
        .where(eq(users.id, currentUser.id));

      const title = `${type === "daily" ? "Daily" : "Weekly"} HotCheelee Jackpot #${Math.floor(Math.random() * 900 + 100)}`;
      const durationHours = type === "daily" ? 24 : 168;
      const expiresAt = new Date(Date.now() + durationHours * 3600 * 1000);

      const [newJackpot] = await db
        .insert(jackpots)
        .values({
          creatorId: currentUser.id,
          jackpotType: type,
          title,
          matches: JSON.stringify(matchesList),
          matchesCount,
          creationCostCoins: creationCost,
          entryFeeCoins: entryCost,
          totalPoolCoins: creationCost, // pool begins with creator seed
          creatorRewardPercent: 90,
          platformFeePercent: 10,
          status: "open",
          entriesCount: 0,
          expiresAt,
        })
        .returning();

      return NextResponse.json({
        success: true,
        message: `🏆 Jackpot created! Seeded with 🪙 ${creationCost} Coins. Creator wins 90% pool!`,
        jackpot: newJackpot,
        newBalance: currentUser.tokensBalance - creationCost,
      }, { status: 201 });
    }

    // 2. ENTER JACKPOT
    if (action === "enter" && jackpotId) {
      const targetJackpot = await db.select().from(jackpots).where(eq(jackpots.id, Number(jackpotId))).limit(1);
      if (targetJackpot.length === 0) return NextResponse.json({ error: "Jackpot not found" }, { status: 404 });

      const jk = targetJackpot[0];
      if (jk.status !== "open") return NextResponse.json({ error: "Jackpot is no longer accepting entries" }, { status: 400 });

      const fee = jk.entryFeeCoins;
      if (currentUser.tokensBalance < fee) {
        return NextResponse.json({
          error: `Insufficient balance to enter jackpot! Requires 🪙 ${fee} Coins. Available: 🪙 ${currentUser.tokensBalance}.`,
        }, { status: 400 });
      }

      // Deduct entry fee
      await db.update(users).set({ tokensBalance: currentUser.tokensBalance - fee }).where(eq(users.id, currentUser.id));

      // Add fee to total pool
      await db
        .update(jackpots)
        .set({
          totalPoolCoins: jk.totalPoolCoins + fee,
          entriesCount: jk.entriesCount + 1,
        })
        .where(eq(jackpots.id, jk.id));

      const [entry] = await db
        .insert(jackpotEntries)
        .values({
          jackpotId: jk.id,
          userId: currentUser.id,
          entryFeePaid: fee,
          predictions: JSON.stringify(predictions || []),
          status: "active",
        })
        .returning();

      return NextResponse.json({
        success: true,
        message: `Entry submitted for 🪙 ${fee} Coins! Total pool now 🪙 ${jk.totalPoolCoins + fee} Coins.`,
        entry,
        newBalance: currentUser.tokensBalance - fee,
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
