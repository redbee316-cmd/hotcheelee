import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, subscriptions, platformSettings, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";

// Upgrade user to Creator Mode (500 KSh) or Agency Mode (1500 KSh)
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized. Please sign in first." }, { status: 401 });
    }

    const body = await req.json();
    const {
      targetMode, // "creator" or "agency"
      genderRole,
      agencyType,
      location,
      locationArea,
      phone,
      allowWhatsapp,
      allowCalls,
      allowSms,
      serviceType,
      servicesOffered,
      rates,
      advertMediaUrl,
      advertMediaType,
      mpesaCode,
    } = body;

    if (!targetMode || (targetMode !== "creator" && targetMode !== "agency")) {
      return NextResponse.json({ error: "Invalid target mode. Choose 'creator' or 'agency'." }, { status: 400 });
    }

    if (!mpesaCode || !phone) {
      return NextResponse.json({ error: "M-Pesa code and phone number are required for 30-day activation." }, { status: 400 });
    }

    const planAmount = targetMode === "agency" ? 1500 : 500;
    const planName = targetMode === "agency" ? "agency_1500" : "creator_500";
    const cleanCode = mpesaCode.trim().toUpperCase();

    // Update user profile fields
    await db
      .update(users)
      .set({
        accountType: targetMode,
        genderRole: targetMode === "creator" ? genderRole || "straight" : null,
        agencyType: targetMode === "agency" ? agencyType || "Massage Parlour" : null,
        location: location || currentUser.location || "Nairobi",
        locationArea: locationArea || currentUser.locationArea || "Kilimani",
        phone: phone || currentUser.phone,
        allowWhatsapp: allowWhatsapp !== undefined ? Boolean(allowWhatsapp) : true,
        allowCalls: allowCalls !== undefined ? Boolean(allowCalls) : true,
        allowSms: allowSms !== undefined ? Boolean(allowSms) : true,
        serviceType: serviceType || currentUser.serviceType || "Both Incall & Outcall",
        servicesOffered: servicesOffered ? (typeof servicesOffered === "string" ? servicesOffered : JSON.stringify(servicesOffered)) : currentUser.servicesOffered,
        rates: rates ? (typeof rates === "string" ? rates : JSON.stringify(rates)) : currentUser.rates,
        advertMediaUrl: advertMediaUrl || currentUser.advertMediaUrl,
        advertMediaType: advertMediaType || currentUser.advertMediaType || "image",
        subscriptionStatus: "pending",
        subscriptionPlan: planName,
        lastMpesaCode: cleanCode,
      })
      .where(eq(users.id, currentUser.id));

    // Insert pending subscription record for admin approval
    const [subRecord] = await db
      .insert(subscriptions)
      .values({
        userId: currentUser.id,
        accountType: targetMode,
        plan: planName,
        amountKsh: planAmount,
        tillNumber: "8923411",
        mpesaCode: cleanCode,
        phonePaid: phone,
        status: "pending",
        notes: `Upgrade to ${targetMode.toUpperCase()} mode submitted by @${currentUser.username}`,
      })
      .returning();

    // Notify admins
    const admins = await db.select().from(users).where(eq(users.isAdmin, true));
    for (const a of admins) {
      await db.insert(notifications).values({
        userId: a.id,
        actorId: currentUser.id,
        type: "upgrade_pending",
        message: `Upgrade Request: @${currentUser.username} upgraded to ${targetMode.toUpperCase()} mode (M-Pesa: ${cleanCode}, KSh ${planAmount}). Needs confirmation.`,
      });
    }

    const updatedUser = await db.select().from(users).where(eq(users.id, currentUser.id)).limit(1);

    return NextResponse.json({
      success: true,
      message: `Upgrade to ${targetMode.toUpperCase()} mode submitted! Send KSh ${planAmount} to M-Pesa Till: 8923411. Once admin verifies code ${cleanCode}, your 30-day active listing starts immediately.`,
      user: updatedUser[0],
      subscription: subRecord,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
