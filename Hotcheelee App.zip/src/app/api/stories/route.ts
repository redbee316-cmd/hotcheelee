import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { stories, users, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const allStories = await db
      .select({
        story: stories,
        user: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          isVerifiedStar: users.isVerifiedStar,
          badge: users.badge,
        },
      })
      .from(stories)
      .leftJoin(users, eq(stories.userId, users.id))
      .orderBy(desc(stories.createdAt));

    // Group stories by user
    const userStoryMap: Record<number, {
      user: any;
      stories: any[];
    }> = {};

    allStories.forEach((item) => {
      if (!item.user) return;
      if (!userStoryMap[item.user.id]) {
        userStoryMap[item.user.id] = {
          user: item.user,
          stories: [],
        };
      }
      userStoryMap[item.user.id].stories.push(item.story);
    });

    const grouped = Object.values(userStoryMap);

    return NextResponse.json({ groupedStories: grouped });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Upload & Post a 24h Story (Strictly max 60 seconds)
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Browsing accounts cannot post stories
    if (currentUser.accountType === "browsing") {
      return NextResponse.json({
        error: "Free browsing accounts cannot post stories. Please upgrade to Creator or Agency mode.",
      }, { status: 403 });
    }

    if (currentUser.subscriptionStatus !== "active") {
      return NextResponse.json({
        error: "Your 30-day listing subscription has expired or is inactive. Please renew to post stories.",
      }, { status: 403 });
    }

    const body = await req.json();
    const { mediaUrl, mediaType, durationSeconds, caption } = body;

    if (!mediaUrl || !mediaUrl.trim()) {
      return NextResponse.json({ error: "Media URL is required" }, { status: 400 });
    }

    // Validate max 60s
    const duration = Math.min(60, Math.max(1, Number(durationSeconds) || 15));

    const [newStory] = await db
      .insert(stories)
      .values({
        userId: currentUser.id,
        mediaUrl: mediaUrl.trim(),
        mediaType: mediaType || "image",
        durationSeconds: duration,
        caption: caption ? caption.trim() : null,
        expiresAt: new Date(Date.now() + 24 * 3600 * 1000), // 24 hours
      })
      .returning();

    return NextResponse.json({
      success: true,
      story: newStory,
      message: `Story posted successfully! Live for 24 hours (Duration: ${duration}s max).`,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
