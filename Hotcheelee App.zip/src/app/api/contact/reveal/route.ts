import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, contactReveals } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { modelId } = body;

    if (!modelId) {
      return NextResponse.json({ error: "modelId is required" }, { status: 400 });
    }

    const modelRes = await db.select().from(users).where(eq(users.id, Number(modelId))).limit(1);
    if (modelRes.length === 0) {
      return NextResponse.json({ error: "Creator or agency not found" }, { status: 404 });
    }

    const model = modelRes[0];

    // Log contact reveal
    await db.insert(contactReveals).values({
      userId: currentUser ? currentUser.id : null,
      modelId: model.id,
    });

    const rawPhone = model.phone || "+254 700 000000";
    const cleanDigits = rawPhone.replace(/[^0-9]/g, "");
    const waNumber = cleanDigits.startsWith("0")
      ? "254" + cleanDigits.slice(1)
      : cleanDigits;

    const encodedMsg = encodeURIComponent(
      `Hello ${model.displayName}, I found your listing on HotCheelee Kenya. Are you available for appointment?`
    );

    return NextResponse.json({
      success: true,
      phone: rawPhone,
      cleanDigits,
      allowWhatsapp: model.allowWhatsapp,
      allowCalls: model.allowCalls,
      allowSms: model.allowSms,
      whatsappUrl: `https://wa.me/${waNumber}?text=${encodedMsg}`,
      callUrl: `tel:${rawPhone}`,
      smsUrl: `sms:${rawPhone}?body=${encodedMsg}`,
      locationArea: model.locationArea,
      serviceType: model.serviceType,
      rates: (() => {
        try {
          return JSON.parse(model.rates || "[]");
        } catch {
          return [];
        }
      })(),
      servicesOffered: (() => {
        try {
          return JSON.parse(model.servicesOffered || "[]");
        } catch {
          return [];
        }
      })(),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
