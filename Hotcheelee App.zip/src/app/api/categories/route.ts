import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { and, eq, desc } from "drizzle-orm";

export const STRIPCHAT_CATEGORIES = [
  { id: "all", label: "All Categories", icon: "✨", count: 1840 },
  { id: "teen18", label: "Teen 18+", icon: "🌸", count: 320, description: "Young adult verified creators aged 18-21" },
  { id: "milf", label: "MILF", icon: "💎", count: 480, description: "Experienced, mature & sensual companions 30+" },
  { id: "ebony", label: "Ebony & African", icon: "👑", count: 890, description: "Kenyan, Nairobi & Mombasa melanin beauties" },
  { id: "latina", label: "Latina & Exotic", icon: "💃", count: 210, description: "Exotic and passionate performers" },
  { id: "asian", label: "Asian", icon: "🎋", count: 140, description: "Delicate & playful companions" },
  { id: "bdsm", label: "BDSM & Kink", icon: "⛓️", count: 260, description: "Leather, latex, dominant and submissive play" },
  { id: "feet", label: "Feet & High Heels", icon: "👠", count: 310, description: "Foot fetish, stilettos, stockings & arches" },
  { id: "cosplay", label: "Cosplay & Anime", icon: "🦊", count: 280, description: "Gaming characters, anime vixens & fantasy roleplay" },
  { id: "bbw", label: "BBW & Curvy", icon: "🍑", count: 420, description: "Curvy, thick thighs & hourglass silhouettes" },
  { id: "squirt", label: "Erotic & Sensual", icon: "💦", count: 370, description: "Sensual oil massage, passionate couples & intimacy" },
  { id: "tattoo", label: "Tattoo & Alternative", icon: "🖤", count: 195, description: "Inked beauties, piercings & gothic aesthetics" },
  { id: "trans", label: "Trans & Shemale", icon: "🏳️‍⚧️", count: 230, description: "Pre-op & non-op trans goddesses & TS beauties" },
  { id: "couples", label: "Couples", icon: "🥂", count: 180, description: "Real duos, romantic intimacy & multi-partner shows" },
];

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const selectedCategory = url.searchParams.get("cat") || "all";
    const search = url.searchParams.get("q");

    // Fetch creators from PostgreSQL
    let allCreators = await db
      .select()
      .from(users)
      .where(and(eq(users.isBanned, false)))
      .orderBy(desc(users.followersCount));

    // Dynamic filtering according to Stripchat category rules
    let filtered = allCreators;

    if (selectedCategory !== "all") {
      const cat = selectedCategory.toLowerCase();
      filtered = filtered.filter((u) => {
        const textToSearch = `${u.genderRole || ""} ${u.servicesOffered || ""} ${u.bio || ""} ${u.interests || ""}`.toLowerCase();
        if (cat === "teen18") return textToSearch.includes("teen") || textToSearch.includes("18") || textToSearch.includes("amateur");
        if (cat === "milf") return textToSearch.includes("milf") || textToSearch.includes("mature") || textToSearch.includes("experienced");
        if (cat === "ebony") return textToSearch.includes("nairobi") || textToSearch.includes("mombasa") || textToSearch.includes("kenya") || textToSearch.includes("ebony");
        if (cat === "bdsm") return textToSearch.includes("bdsm") || textToSearch.includes("kink") || textToSearch.includes("latex") || textToSearch.includes("bondage");
        if (cat === "feet") return textToSearch.includes("feet") || textToSearch.includes("heels") || textToSearch.includes("stockings");
        if (cat === "cosplay") return textToSearch.includes("cosplay") || textToSearch.includes("anime") || textToSearch.includes("gaming");
        if (cat === "bbw") return textToSearch.includes("curves") || textToSearch.includes("bbw") || textToSearch.includes("thick");
        if (cat === "tattoo") return textToSearch.includes("tattoo") || textToSearch.includes("goth") || textToSearch.includes("alt");
        if (cat === "trans") return u.genderRole === "transgender" || u.genderRole === "shemale";
        return textToSearch.includes(cat);
      });
    }

    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(
        (u) =>
          u.displayName.toLowerCase().includes(q) ||
          u.username.toLowerCase().includes(q) ||
          (u.locationArea && u.locationArea.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({
      categories: STRIPCHAT_CATEGORIES,
      selectedCategory,
      totalCreators: filtered.length,
      creators: filtered.map((c) => ({
        id: c.id,
        username: c.username,
        displayName: c.displayName,
        avatar: c.avatar,
        coverImage: c.coverImage,
        bio: c.bio,
        locationArea: c.locationArea || "Kilimani, Nairobi",
        phone: c.phone,
        genderRole: c.genderRole,
        accountType: c.accountType,
        isVerifiedStar: c.isVerifiedStar,
        followersCount: c.followersCount,
        tokensBalance: c.tokensBalance,
        ratesList: (() => {
          try {
            return JSON.parse(c.rates || "[]");
          } catch {
            return [];
          }
        })(),
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
