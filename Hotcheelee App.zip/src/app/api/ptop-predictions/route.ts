import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { ptopPredictions, users, notifications, auditLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const leagueFilter = url.searchParams.get("league");

    const all = await db
      .select({
        prediction: ptopPredictions,
        creator: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(ptopPredictions)
      .leftJoin(users, eq(ptopPredictions.creatorId, users.id))
      .orderBy(desc(ptopPredictions.createdAt));

    let items = all.map((p) => ({ ...p.prediction, creator: p.creator }));

    if (leagueFilter && leagueFilter !== "All") {
      items = items.filter((p) => p.league.toLowerCase() === leagueFilter.toLowerCase());
    }

    const openCount = items.filter((p) => p.status === "open").length;
    const totalStakedCoins = items.reduce((sum, p) => sum + (p.totalPotCoins || 0), 0);

    return NextResponse.json({
      predictions: items,
      openCount,
      totalStakedCoins,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Create new prediction match or Challenge / Match & Stake
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { action, league, homeTeam, awayTeam, matchDate, creatorPick, stakeCoins, predictionId, opponentPick, winningPick } = body;

    // 1. Post a new match prediction challenge
    if (action === "create") {
      const stake = Number(stakeCoins);
      if (!stake || stake < 10) {
        return NextResponse.json({ error: "Minimum prediction stake is 10 Coins" }, { status: 400 });
      }

      if (currentUser.tokensBalance < stake) {
        return NextResponse.json({
          error: `Insufficient coins to stake ${stake} coins! You have ${currentUser.tokensBalance} coins in your wallet.`,
        }, { status: 400 });
      }

      // Deduct coins from creator
      await db.update(users).set({ tokensBalance: currentUser.tokensBalance - stake }).where(eq(users.id, currentUser.id));

      const totalPot = stake * 2;
      const winnerReward = Math.floor(totalPot * 0.90); // 90% winner
      const platformFee = totalPot - winnerReward; // 10% platform

      const [newPred] = await db
        .insert(ptopPredictions)
        .values({
          creatorId: currentUser.id,
          league: league || "Premier League",
          homeTeam: homeTeam || "Arsenal",
          awayTeam: awayTeam || "Chelsea",
          matchDate: matchDate || "Tomorrow",
          creatorPick: creatorPick || "Home",
          stakeCoins: stake,
          totalPotCoins: totalPot,
          winnerRewardCoins: winnerReward,
          platformFeeCoins: platformFee,
          status: "open",
        })
        .returning();

      return NextResponse.json({
        success: true,
        message: `Prediction posted! Staked ${stake} coins. Potential prize: ${winnerReward} coins (90%).`,
        prediction: newPred,
      }, { status: 201 });
    }

    // 2. Challenge & Match an Open Prediction
    if (action === "challenge" && predictionId) {
      const target = await db.select().from(ptopPredictions).where(eq(ptopPredictions.id, Number(predictionId))).limit(1);
      if (target.length === 0) return NextResponse.json({ error: "Prediction challenge not found" }, { status: 404 });
      if (target[0].status !== "open") return NextResponse.json({ error: "Challenge is already matched or completed" }, { status: 400 });
      if (target[0].creatorId === currentUser.id) return NextResponse.json({ error: "Cannot challenge your own prediction" }, { status: 400 });

      const stake = target[0].stakeCoins;
      if (currentUser.tokensBalance < stake) {
        return NextResponse.json({
          error: `Insufficient coins to match stake of ${stake} coins! Available: ${currentUser.tokensBalance} coins.`,
        }, { status: 400 });
      }

      // Deduct stake from opponent
      await db.update(users).set({ tokensBalance: currentUser.tokensBalance - stake }).where(eq(users.id, currentUser.id));

      const [matched] = await db
        .update(ptopPredictions)
        .set({
          opponentId: currentUser.id,
          opponentPick: opponentPick || (target[0].creatorPick === "Home" ? "Away" : "Home"),
          status: "matched",
        })
        .where(eq(ptopPredictions.id, target[0].id))
        .returning();

      await db.insert(notifications).values({
        userId: target[0].creatorId,
        actorId: currentUser.id,
        type: "prediction_matched",
        message: `${currentUser.displayName} matched your prediction challenge on ${target[0].homeTeam} vs ${target[0].awayTeam} for ${stake} coins! Total pot: ${target[0].totalPotCoins} coins.`,
      });

      return NextResponse.json({
        success: true,
        message: `Challenge accepted! Matched stake of ${stake} coins. Total Pot: ${target[0].totalPotCoins} coins. Winner gets 90%!`,
        prediction: matched,
      });
    }

    // 3. Declare Winner (90% to winner, 10% platform)
    if (action === "declare" && predictionId) {
      const target = await db.select().from(ptopPredictions).where(eq(ptopPredictions.id, Number(predictionId))).limit(1);
      if (target.length === 0) return NextResponse.json({ error: "Prediction not found" }, { status: 404 });

      const pred = target[0];
      const winPick = winningPick || pred.creatorPick;
      const winnerId = winPick === pred.creatorPick ? pred.creatorId : (pred.opponentId || pred.creatorId);

      // Award 90% payout to winner
      const winnerUser = await db.select().from(users).where(eq(users.id, winnerId)).limit(1);
      if (winnerUser.length > 0) {
        await db.update(users).set({ tokensBalance: winnerUser[0].tokensBalance + pred.winnerRewardCoins }).where(eq(users.id, winnerId));
      }

      const [completed] = await db
        .update(ptopPredictions)
        .set({
          status: "completed",
          winnerUserId: winnerId,
          winningPick: winPick,
          declaredAt: new Date(),
        })
        .where(eq(ptopPredictions.id, pred.id))
        .returning();

      return NextResponse.json({
        success: true,
        message: `Winner declared (${winPick})! Paid out ${pred.winnerRewardCoins} coins to winner (90%), platform retained 10%.`,
        prediction: completed,
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
