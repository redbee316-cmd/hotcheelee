import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, follows } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const type = url.searchParams.get("type"); // stars, agencies, all
    const genderRole = url.searchParams.get("role"); // straight, gay, transgender, shemale, queer
    const agencyType = url.searchParams.get("agencyType"); // Massage Parlour, Lodging, Brothel, Agency
    const serviceType = url.searchParams.get("serviceType"); // Incall, Outcall, Both
    const location = url.searchParams.get("location"); // Nairobi, Mombasa, etc.
    const search = url.searchParams.get("q");

    const currentUser = await getCurrentUser();

    let allUsers = await db
      .select()
      .from(users)
      .where(eq(users.isBanned, false))
      .orderBy(desc(users.followersCount));

    let followedUserIds = new Set<number>();
    if (currentUser) {
      const myFollows = await db
        .select({ followingId: follows.followingId })
        .from(follows)
        .where(eq(follows.followerId, currentUser.id));
      myFollows.forEach((f) => followedUserIds.add(f.followingId));
    }

    let filtered = allUsers;

    // Filter by type
    if (type === "agencies" || type === "brands") {
      filtered = filtered.filter((u) => u.accountType === "agency" || u.isBrand);
    } else if (type === "creators" || type === "stars") {
      filtered = filtered.filter((u) => u.accountType === "creator" || (u.isVerifiedStar && !u.isBrand));
    } else {
      filtered = filtered.filter((u) => u.accountType === "creator" || u.accountType === "agency" || u.isVerifiedStar || u.isBrand);
    }

    // Filter by genderRole
    if (genderRole && genderRole !== "all") {
      filtered = filtered.filter((u) => u.genderRole?.toLowerCase() === genderRole.toLowerCase());
    }

    // Filter by agencyType
    if (agencyType && agencyType !== "all") {
      filtered = filtered.filter((u) => u.agencyType?.toLowerCase().includes(agencyType.toLowerCase()));
    }

    // Filter by serviceType
    if (serviceType && serviceType !== "all") {
      filtered = filtered.filter((u) => u.serviceType?.toLowerCase().includes(serviceType.toLowerCase()) || u.serviceType === "Both Incall & Outcall");
    }

    // Filter by location
    if (location && location !== "all") {
      filtered = filtered.filter((u) => u.location?.toLowerCase().includes(location.toLowerCase()) || u.locationArea?.toLowerCase().includes(location.toLowerCase()));
    }

    // Search query
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(
        (u) =>
          u.displayName.toLowerCase().includes(q) ||
          u.username.toLowerCase().includes(q) ||
          (u.bio && u.bio.toLowerCase().includes(q)) ||
          (u.locationArea && u.locationArea.toLowerCase().includes(q)) ||
          (u.servicesOffered && u.servicesOffered.toLowerCase().includes(q))
      );
    }

    const result = filtered.map((u) => {
      let parsedRates = [];
      let parsedServices = [];
      try {
        parsedRates = JSON.parse(u.rates || "[]");
      } catch {}
      try {
        parsedServices = JSON.parse(u.servicesOffered || "[]");
      } catch {}

      // Mask phone number initially: e.g. "+254 7•• ••• 123"
      const rawPhone = u.phone || "+254 700 000000";
      const maskedPhone = rawPhone.length > 8
        ? rawPhone.slice(0, 7) + " ••• " + rawPhone.slice(-3)
        : "+254 7•• ••• •••";

      return {
        ...u,
        maskedPhone,
        ratesList: parsedRates,
        servicesList: parsedServices,
        isFollowing: followedUserIds.has(u.id),
        isSelf: currentUser ? currentUser.id === u.id : false,
      };
    });

    return NextResponse.json(
      { stars: result, totalCount: result.length },
      { headers: { "Cache-Control": "public, s-maxage=3, stale-while-revalidate=20" } }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
