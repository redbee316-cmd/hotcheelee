import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { cookies } from "next/headers";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { usernameOrEmail, password } = body;

    if (!usernameOrEmail) {
      return NextResponse.json({ error: "Username or email is required" }, { status: 400 });
    }

    const cleanInput = usernameOrEmail.trim().toLowerCase();

    const userRes = await db
      .select()
      .from(users)
      .where(or(eq(users.username, cleanInput), eq(users.email, cleanInput)))
      .limit(1);

    if (userRes.length === 0) {
      return NextResponse.json({ error: "User not found with this username or email" }, { status: 404 });
    }

    const user = userRes[0];

    if (user.isBanned) {
      return NextResponse.json({ error: "This account has been suspended by administration." }, { status: 403 });
    }

    // Set cookie session
    const cookieStore = await cookies();
    cookieStore.set("hotcheelee_session", user.username, {
      path: "/",
      maxAge: 60 * 60 * 24 * 30, // 30 days
      httpOnly: false,
      sameSite: "lax",
    });

    return NextResponse.json({
      success: true,
      user,
      message: `Welcome back, ${user.displayName}!`,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
