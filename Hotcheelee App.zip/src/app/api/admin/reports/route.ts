import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { reports, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const list = await db
      .select({
        report: reports,
        reporter: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
        },
      })
      .from(reports)
      .leftJoin(users, eq(reports.reporterId, users.id))
      .orderBy(desc(reports.createdAt));

    return NextResponse.json({ reports: list.map((r) => ({ ...r.report, reporter: r.reporter })) });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { targetUserId, postId, reason } = body;

    if (!reason) {
      return NextResponse.json({ error: "Reason required" }, { status: 400 });
    }

    const [created] = await db
      .insert(reports)
      .values({
        reporterId: currentUser ? currentUser.id : 1,
        targetUserId: targetUserId ? Number(targetUserId) : null,
        postId: postId ? Number(postId) : null,
        reason,
        status: "pending",
      })
      .returning();

    return NextResponse.json({ success: true, report: created });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
