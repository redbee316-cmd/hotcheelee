import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { withdrawals, users, auditLogs, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const list = await db
      .select({
        withdrawal: withdrawals,
        user: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          phone: users.phone,
        },
      })
      .from(withdrawals)
      .leftJoin(users, eq(withdrawals.userId, users.id))
      .orderBy(desc(withdrawals.createdAt));

    return NextResponse.json({
      withdrawals: list.map((w) => ({ ...w.withdrawal, user: w.user })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Approve / Complete M-Pesa Payout
export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { withdrawalId, status, mpesaReceipt, adminNotes } = body; // status: 'Completed' | 'Rejected'

    if (!withdrawalId || !status) {
      return NextResponse.json({ error: "withdrawalId and status are required" }, { status: 400 });
    }

    const itemRes = await db.select().from(withdrawals).where(eq(withdrawals.id, Number(withdrawalId))).limit(1);
    if (itemRes.length === 0) {
      return NextResponse.json({ error: "Withdrawal not found" }, { status: 404 });
    }

    const item = itemRes[0];

    const [updated] = await db
      .update(withdrawals)
      .set({
        status,
        mpesaReceipt: mpesaReceipt || item.mpesaReceipt,
        adminNotes: adminNotes || item.adminNotes,
      })
      .where(eq(withdrawals.id, item.id))
      .returning();

    // Audit log
    await db.insert(auditLogs).values({
      adminId: currentUser ? currentUser.id : 1,
      action: "PROCESS_WITHDRAWAL",
      details: `Withdrawal ID ${item.id} (${item.amountKsh || item.amount} KSh to ${item.destinationAddress}) set to ${status}. Receipt: ${mpesaReceipt || 'N/A'}.`,
      targetId: item.id,
    });

    // Notify creator
    await db.insert(notifications).values({
      userId: item.userId,
      actorId: currentUser ? currentUser.id : 1,
      type: "payout",
      message: `Your withdrawal request of KSh ${item.amountKsh || item.amount} has been ${status}! M-Pesa Ref: ${mpesaReceipt || 'Sent'}.`,
    });

    return NextResponse.json({ success: true, withdrawal: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
