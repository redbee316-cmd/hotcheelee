import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { walletDeposits, users, notifications, auditLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const list = await db
      .select({
        deposit: walletDeposits,
        user: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          phone: users.phone,
          tokensBalance: users.tokensBalance,
        },
      })
      .from(walletDeposits)
      .leftJoin(users, eq(walletDeposits.userId, users.id))
      .orderBy(desc(walletDeposits.createdAt));

    return NextResponse.json({
      deposits: list.map((d) => ({ ...d.deposit, user: d.user })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Approve or Reject Manual Wallet Deposit
export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { depositId, action, notes } = body; // action: 'approve' | 'reject'

    if (!depositId || !action) {
      return NextResponse.json({ error: "depositId and action are required" }, { status: 400 });
    }

    const depRes = await db.select().from(walletDeposits).where(eq(walletDeposits.id, Number(depositId))).limit(1);
    if (depRes.length === 0) {
      return NextResponse.json({ error: "Deposit record not found" }, { status: 404 });
    }

    const item = depRes[0];

    if (action === "approve") {
      const [updated] = await db
        .update(walletDeposits)
        .set({
          status: "approved",
          approvedBy: currentUser ? currentUser.id : 1,
          approvedAt: new Date(),
          adminNotes: notes || "Payment confirmed on Till 8923411",
        })
        .where(eq(walletDeposits.id, item.id))
        .returning();

      // Credit tokens to user wallet
      const targetUser = await db.select().from(users).where(eq(users.id, item.userId)).limit(1);
      if (targetUser.length > 0) {
        const newBalance = targetUser[0].tokensBalance + item.tokensCredited;
        await db.update(users).set({ tokensBalance: newBalance }).where(eq(users.id, item.userId));
      }

      // Audit Log
      await db.insert(auditLogs).values({
        adminId: currentUser ? currentUser.id : 1,
        action: "APPROVE_DEPOSIT",
        details: `Approved M-Pesa deposit of KSh ${item.amountKsh} (+${item.tokensCredited} tokens) for user ID ${item.userId}. Ref: ${item.mpesaCode}.`,
        targetId: item.id,
      });

      // Notify User
      await db.insert(notifications).values({
        userId: item.userId,
        actorId: currentUser ? currentUser.id : 1,
        type: "deposit_approved",
        message: `Your deposit of KSh ${item.amountKsh} has been approved! +${item.tokensCredited} Tokens added to your wallet.`,
      });

      return NextResponse.json({
        success: true,
        message: `Approved deposit! Credited ${item.tokensCredited} tokens to user.`,
        deposit: updated,
      });
    }

    if (action === "reject") {
      const [updated] = await db
        .update(walletDeposits)
        .set({
          status: "rejected",
          adminNotes: notes || "Could not be verified against Till statement",
        })
        .where(eq(walletDeposits.id, item.id))
        .returning();

      await db.insert(auditLogs).values({
        adminId: currentUser ? currentUser.id : 1,
        action: "REJECT_DEPOSIT",
        details: `Rejected deposit of KSh ${item.amountKsh} for user ID ${item.userId}. Ref: ${item.mpesaCode}.`,
        targetId: item.id,
      });

      await db.insert(notifications).values({
        userId: item.userId,
        actorId: currentUser ? currentUser.id : 1,
        type: "deposit_rejected",
        message: `Your deposit submission (${item.mpesaCode}) was rejected: "${notes || "Invalid code"}". Contact support.`,
      });

      return NextResponse.json({
        success: true,
        message: "Deposit marked as rejected.",
        deposit: updated,
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
