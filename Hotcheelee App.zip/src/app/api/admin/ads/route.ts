import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { sponsoredAds, users, auditLogs, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const list = await db
      .select({
        ad: sponsoredAds,
        advertiser: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          phone: users.phone,
        },
      })
      .from(sponsoredAds)
      .leftJoin(users, eq(sponsoredAds.advertiserId, users.id))
      .orderBy(desc(sponsoredAds.createdAt));

    return NextResponse.json({ ads: list.map((a) => ({ ...a.ad, advertiser: a.advertiser })) });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Approve or Reject Sponsored Ad Campaign
export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { adId, action, notes } = body; // action: 'approve' | 'reject'

    if (!adId || !action) {
      return NextResponse.json({ error: "adId and action are required" }, { status: 400 });
    }

    const target = await db.select().from(sponsoredAds).where(eq(sponsoredAds.id, Number(adId))).limit(1);
    if (target.length === 0) return NextResponse.json({ error: "Ad not found" }, { status: 404 });

    const ad = target[0];

    if (action === "approve") {
      const [approved] = await db
        .update(sponsoredAds)
        .set({
          status: "approved",
          isActive: true, // Go live on infinite feeds
          approvedBy: currentUser ? currentUser.id : 1,
          approvedAt: new Date(),
          adminNotes: notes || "Campaign copy and media verified compliant.",
        })
        .where(eq(sponsoredAds.id, ad.id))
        .returning();

      // Audit Log
      await db.insert(auditLogs).values({
        adminId: currentUser ? currentUser.id : 1,
        action: "APPROVE_SPONSORED_AD",
        details: `Approved sponsored campaign "${ad.title}" (${ad.budgetTokens} tokens, KSh ${ad.budgetKsh}) by advertiser ID ${ad.advertiserId}.`,
        targetId: ad.id,
      });

      // Notify Advertiser
      await db.insert(notifications).values({
        userId: ad.advertiserId,
        actorId: currentUser ? currentUser.id : 1,
        type: "ad_approved",
        message: `Your sponsored advertisement "${ad.title}" has been approved! Now live on infinite feeds.`,
      });

      return NextResponse.json({ success: true, message: "Sponsored ad approved and live!", ad: approved });
    }

    if (action === "reject") {
      // Refund tokens to advertiser wallet
      const advertiser = await db.select().from(users).where(eq(users.id, ad.advertiserId)).limit(1);
      if (advertiser.length > 0) {
        await db.update(users).set({ tokensBalance: advertiser[0].tokensBalance + ad.budgetTokens }).where(eq(users.id, ad.advertiserId));
      }

      const [rejected] = await db
        .update(sponsoredAds)
        .set({
          status: "rejected",
          isActive: false,
          adminNotes: notes || "Did not comply with advertising guidelines.",
        })
        .where(eq(sponsoredAds.id, ad.id))
        .returning();

      await db.insert(notifications).values({
        userId: ad.advertiserId,
        actorId: currentUser ? currentUser.id : 1,
        type: "ad_rejected",
        message: `Your sponsored ad "${ad.title}" was rejected: "${notes || "Guidelines issue"}". Refunded ${ad.budgetTokens} tokens to your wallet.`,
      });

      return NextResponse.json({ success: true, message: "Ad campaign rejected and tokens refunded.", ad: rejected });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
