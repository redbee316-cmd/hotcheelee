import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, auditLogs, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const roleFilter = url.searchParams.get("role"); // creator, agency, browsing, banned
    const search = url.searchParams.get("q");

    let allUsers = await db.select().from(users).orderBy(desc(users.createdAt));

    if (roleFilter && roleFilter !== "all") {
      if (roleFilter === "banned") {
        allUsers = allUsers.filter((u) => u.isBanned);
      } else {
        allUsers = allUsers.filter((u) => u.accountType === roleFilter);
      }
    }

    if (search) {
      const q = search.toLowerCase();
      allUsers = allUsers.filter(
        (u) =>
          u.displayName.toLowerCase().includes(q) ||
          u.username.toLowerCase().includes(q) ||
          (u.phone && u.phone.includes(q)) ||
          (u.locationArea && u.locationArea.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({ users: allUsers });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { userId, isBanned, isVerifiedStar, isAdmin, extendDays, tokensAdjustment } = body;

    if (!userId) {
      return NextResponse.json({ error: "userId is required" }, { status: 400 });
    }

    const userRes = await db.select().from(users).where(eq(users.id, Number(userId))).limit(1);
    if (userRes.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const target = userRes[0];
    const updateData: any = {};

    if (isBanned !== undefined) updateData.isBanned = Boolean(isBanned);
    if (isVerifiedStar !== undefined) updateData.isVerifiedStar = Boolean(isVerifiedStar);
    if (isAdmin !== undefined) updateData.isAdmin = Boolean(isAdmin);

    if (extendDays) {
      const currentExpiry = target.subscriptionExpiresAt ? new Date(target.subscriptionExpiresAt).getTime() : Date.now();
      const newExpiry = new Date(Math.max(Date.now(), currentExpiry) + Number(extendDays) * 86400000);
      updateData.subscriptionExpiresAt = newExpiry;
      updateData.subscriptionStatus = "active";
    }

    if (tokensAdjustment) {
      updateData.tokensBalance = Math.max(0, target.tokensBalance + Number(tokensAdjustment));
    }

    const [updated] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, target.id))
      .returning();

    // Audit log
    await db.insert(auditLogs).values({
      adminId: currentUser ? currentUser.id : 1,
      action: "UPDATE_USER_PROFILE",
      details: `Admin modified profile for @${target.username}. Changes: ${JSON.stringify(updateData)}`,
      targetId: target.id,
    });

    return NextResponse.json({ success: true, user: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
