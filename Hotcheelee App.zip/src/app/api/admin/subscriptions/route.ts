import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { subscriptions, users, auditLogs, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const statusFilter = url.searchParams.get("status");

    const allSubs = await db
      .select({
        subscription: subscriptions,
        user: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          accountType: users.accountType,
          phone: users.phone,
        },
      })
      .from(subscriptions)
      .leftJoin(users, eq(subscriptions.userId, users.id))
      .orderBy(desc(subscriptions.createdAt));

    let filtered = allSubs.map((s) => ({ ...s.subscription, user: s.user }));
    if (statusFilter && statusFilter !== "all") {
      filtered = filtered.filter((s) => s.status === statusFilter);
    }

    return NextResponse.json({ subscriptions: filtered });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Admin Approve or Reject Manual M-Pesa Subscription (Enforce 30 days rule)
export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { subscriptionId, action, notes } = body; // action: 'approve' | 'reject'

    if (!subscriptionId || !action) {
      return NextResponse.json({ error: "subscriptionId and action are required" }, { status: 400 });
    }

    const subRes = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.id, Number(subscriptionId)))
      .limit(1);

    if (subRes.length === 0) {
      return NextResponse.json({ error: "Subscription record not found" }, { status: 404 });
    }

    const sub = subRes[0];

    if (action === "approve") {
      // Exactly 30 days validity
      const approvedAt = new Date();
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      const [updatedSub] = await db
        .update(subscriptions)
        .set({
          status: "approved",
          approvedBy: currentUser ? currentUser.id : 1,
          approvedAt,
          expiresAt,
          notes: notes || "Payment verified by administrator.",
        })
        .where(eq(subscriptions.id, sub.id))
        .returning();

      // Activate user's profile for 30 days
      await db
        .update(users)
        .set({
          subscriptionStatus: "active",
          subscriptionExpiresAt: expiresAt,
          subscriptionPaidAt: approvedAt,
          isVerifiedStar: sub.accountType === "creator" ? true : undefined,
          isBrand: sub.accountType === "agency" ? true : undefined,
        })
        .where(eq(users.id, sub.userId));

      // Audit Log
      await db.insert(auditLogs).values({
        adminId: currentUser ? currentUser.id : 1,
        action: "APPROVE_SUBSCRIPTION",
        details: `Approved 30-day ${sub.plan} (KSh ${sub.amountKsh}) for user ID ${sub.userId} with M-Pesa code ${sub.mpesaCode}. Expires on ${expiresAt.toLocaleDateString()}.`,
        targetId: sub.id,
      });

      // Notify User
      await db.insert(notifications).values({
        userId: sub.userId,
        actorId: currentUser ? currentUser.id : 1,
        type: "subscription_approved",
        message: `🎉 Your HotCheelee ${sub.accountType.toUpperCase()} subscription (M-Pesa ${sub.mpesaCode}) has been approved! Your 30-day active listing is live until ${expiresAt.toLocaleDateString()}.`,
      });

      return NextResponse.json({
        success: true,
        message: `Approved subscription for 30 days (expires ${expiresAt.toLocaleDateString()})`,
        subscription: updatedSub,
      });
    }

    if (action === "reject") {
      const [updatedSub] = await db
        .update(subscriptions)
        .set({
          status: "rejected",
          notes: notes || "Payment could not be verified on Till records.",
        })
        .where(eq(subscriptions.id, sub.id))
        .returning();

      await db
        .update(users)
        .set({ subscriptionStatus: "inactive" })
        .where(eq(users.id, sub.userId));

      await db.insert(auditLogs).values({
        adminId: currentUser ? currentUser.id : 1,
        action: "REJECT_SUBSCRIPTION",
        details: `Rejected subscription for user ID ${sub.userId}. Reason: ${notes || "Invalid code"}`,
        targetId: sub.id,
      });

      await db.insert(notifications).values({
        userId: sub.userId,
        actorId: currentUser ? currentUser.id : 1,
        type: "subscription_rejected",
        message: `⚠️ Your M-Pesa subscription code (${sub.mpesaCode}) could not be confirmed: "${notes || "Invalid code"}". Please contact admin or resubmit.`,
      });

      return NextResponse.json({
        success: true,
        message: "Subscription marked as rejected",
        subscription: updatedSub,
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
