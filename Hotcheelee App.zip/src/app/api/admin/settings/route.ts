import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { platformSettings, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const res = await db.select().from(platformSettings).limit(1);
    const settings = res[0] || {
      tillNumber: "8923411",
      paybillNumber: "522522",
      accountName: "HOTCHEELEE",
      creatorPriceKsh: 500,
      agencyPriceKsh: 1500,
      supportPhone: "+254 700 892341",
      supportWhatsapp: "+254 700 892341",
      announcement: "HotCheelee Kenya. All Creators pay KSh 500/mo, Agencies KSh 1,500/mo via M-Pesa Buy Goods Till: 8923411.",
    };
    return NextResponse.json({ settings });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { tillNumber, paybillNumber, accountName, creatorPriceKsh, agencyPriceKsh, supportPhone, supportWhatsapp, announcement } = body;

    const res = await db.select().from(platformSettings).limit(1);
    let updated;

    if (res.length === 0) {
      [updated] = await db.insert(platformSettings).values({
        tillNumber: tillNumber || "8923411",
        paybillNumber: paybillNumber || "522522",
        accountName: accountName || "HOTCHEELEE",
        creatorPriceKsh: Number(creatorPriceKsh) || 500,
        agencyPriceKsh: Number(agencyPriceKsh) || 1500,
        supportPhone: supportPhone || "+254 700 892341",
        supportWhatsapp: supportWhatsapp || "+254 700 892341",
        announcement: announcement || "",
      }).returning();
    } else {
      [updated] = await db
        .update(platformSettings)
        .set({
          tillNumber: tillNumber || res[0].tillNumber,
          paybillNumber: paybillNumber || res[0].paybillNumber,
          accountName: accountName || res[0].accountName,
          creatorPriceKsh: creatorPriceKsh !== undefined ? Number(creatorPriceKsh) : res[0].creatorPriceKsh,
          agencyPriceKsh: agencyPriceKsh !== undefined ? Number(agencyPriceKsh) : res[0].agencyPriceKsh,
          supportPhone: supportPhone || res[0].supportPhone,
          supportWhatsapp: supportWhatsapp || res[0].supportWhatsapp,
          announcement: announcement !== undefined ? announcement : res[0].announcement,
          updatedAt: new Date(),
        })
        .where(eq(platformSettings.id, res[0].id))
        .returning();
    }

    // Audit log
    await db.insert(auditLogs).values({
      adminId: currentUser ? currentUser.id : 1,
      action: "UPDATE_PLATFORM_SETTINGS",
      details: `Updated platform settings (Till: ${updated.tillNumber}, Creator Price: KSh ${updated.creatorPriceKsh}, Agency Price: KSh ${updated.agencyPriceKsh})`,
      targetId: updated.id,
    });

    return NextResponse.json({ success: true, settings: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
