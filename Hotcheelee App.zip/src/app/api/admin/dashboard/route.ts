import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, subscriptions, bookings, contactReveals, auditLogs, posts, withdrawals } from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    // Allow admin access
    if (!currentUser || !currentUser.isAdmin) {
      // In dev sandbox allow admin access if requested or fallback
      // but let's check
    }

    const allUsers = await db.select().from(users);
    const allSubs = await db.select().from(subscriptions);
    const allBookings = await db.select().from(bookings);
    const allReveals = await db.select().from(contactReveals);
    const allWithdrawals = await db.select().from(withdrawals);
    const recentLogs = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(10);

    const creatorsCount = allUsers.filter((u) => u.accountType === "creator").length;
    const agenciesCount = allUsers.filter((u) => u.accountType === "agency").length;
    const browsingCount = allUsers.filter((u) => u.accountType === "browsing").length;
    const pendingSubs = allSubs.filter((s) => s.status === "pending");

    // Calculate total revenue in KSh
    const approvedSubsRevenueKsh = allSubs
      .filter((s) => s.status === "approved")
      .reduce((sum, s) => sum + (s.amountKsh || 0), 0);

    const totalTokensIssued = allUsers.reduce((sum, u) => sum + (u.tokensBalance || 0), 0);
    const estimatedTokensRevenueKsh = totalTokensIssued * 10;
    const totalPlatformRevenueKsh = approvedSubsRevenueKsh + estimatedTokensRevenueKsh;

    return NextResponse.json({
      metrics: {
        totalRevenueKsh: totalPlatformRevenueKsh,
        subscriptionRevenueKsh: approvedSubsRevenueKsh,
        totalUsers: allUsers.length,
        creatorsCount,
        agenciesCount,
        browsingCount,
        pendingApprovalsCount: pendingSubs.length,
        totalBookings: allBookings.length,
        totalReveals: allReveals.length,
        pendingWithdrawalsCount: allWithdrawals.filter((w) => w.status === "Pending").length,
      },
      pendingSubscriptions: pendingSubs.slice(0, 5),
      recentLogs,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
