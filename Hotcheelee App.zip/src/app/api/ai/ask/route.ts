import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const { message, context } = body;

    if (!message) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 });
    }

    const q = message.toLowerCase();

    // HotCheelee AI specialized knowledge
    let reply = "";
    if (q.includes("rate") || q.includes("price") || q.includes("cost")) {
      reply = `🔥 HotCheelee Rates Guide:\n• 1 Token = KSh 10 KES.\n• Standard 1hr Incall rates range from KSh 3,000 to 7,000.\n• Overnight sessions: KSh 12,000 to 20,000.\n• Creators listing subscription: KSh 500/mo (30 days).\n• Agencies (spas/lodgings): KSh 1,500/mo.`;
    } else if (q.includes("till") || q.includes("mpesa") || q.includes("pay")) {
      reply = `💳 HotCheelee Official M-Pesa Till: 8923411 (Buy Goods).\nAlways verify your transaction code in the Wallet before submitting for instant admin confirmation!`;
    } else if (q.includes("toy") || q.includes("lovense") || q.includes("lush")) {
      reply = `📳 Lovense Interactive Toys:\nYou can send token tips (5 to 100 tokens) in chat or on creator profiles to trigger direct tactile vibrations up to Level 20 on Lush 3 hardware!`;
    } else if (q.includes("location") || q.includes("area") || q.includes("nairobi")) {
      reply = `📍 Top HotCheelee demand areas in Kenya:\n• Nairobi: Kilimani, Westlands, Kileleshwa, Lavington, CBD.\n• Coast: Nyali Beach, Bamburi, Mtwapa, Diani.\n• Western: Kisumu Milimani, Nakuru, Eldoret.`;
    } else if (q.includes("jackpot") || q.includes("prediction")) {
      reply = `⚽ PtoP Predictions & Jackpots:\nStake HotCheelee Coins on Premier League, KPL, Bundesliga, and La Liga matches! 90% goes to the winner, and 10% platform fee.`;
    } else {
      reply = `🌶️ HotCheelee AI: "${message}"\nI am your companion assistant. You can ask me about M-Pesa Tills (8923411), rates in KSh, Lovense toy controls, booking etiquette, or PtoP finance & prediction rules. How can I assist you further?`;
    }

    return NextResponse.json({
      success: true,
      query: message,
      reply,
      aiName: "HotCheelee AI Assistant 🌶️",
      timestamp: new Date(),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
