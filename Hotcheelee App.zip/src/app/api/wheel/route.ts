import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { wheelSegments, wheelSpins, users, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const modelId = url.searchParams.get("modelId");

    const segments = await db
      .select()
      .from(wheelSegments)
      .where(modelId ? eq(wheelSegments.userId, Number(modelId)) : undefined);

    const spins = await db
      .select()
      .from(wheelSpins)
      .orderBy(desc(wheelSpins.createdAt))
      .limit(10);

    return NextResponse.json({
      segments,
      recentSpins: spins,
      spinCostTokens: segments[0]?.costTokens || 25,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Spin the Stripchat Wheel of Fortune
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { modelId } = body;

    const segments = await db
      .select()
      .from(wheelSegments)
      .where(eq(wheelSegments.userId, Number(modelId)));

    if (segments.length === 0) {
      return NextResponse.json({ error: "Wheel not configured for this model" }, { status: 404 });
    }

    const costTokens = segments[0].costTokens || 25;

    if (currentUser.tokensBalance < costTokens) {
      return NextResponse.json({
        error: `Insufficient tokens to spin! You need ${costTokens} tokens.`,
      }, { status: 400 });
    }

    // Weighted random selection
    const randomIndex = Math.floor(Math.random() * segments.length);
    const wonSegment = segments[randomIndex];

    // Deduct tokens
    const newBalance = currentUser.tokensBalance - costTokens;
    await db
      .update(users)
      .set({
        tokensBalance: newBalance,
        userXp: currentUser.userXp + 250,
      })
      .where(eq(users.id, currentUser.id));

    // Record Spin
    const [spinRecord] = await db
      .insert(wheelSpins)
      .values({
        userId: currentUser.id,
        modelId: Number(modelId),
        segmentId: wonSegment.id,
        tokensSpent: costTokens,
        wonLabel: wonSegment.label,
      })
      .returning();

    // Notify model
    await db.insert(notifications).values({
      userId: Number(modelId),
      actorId: currentUser.id,
      type: "wheel",
      message: `${currentUser.displayName} spun the Wheel of Fortune and won: ${wonSegment.label}! 🎡`,
    });

    return NextResponse.json({
      success: true,
      wonSegment,
      wonIndex: randomIndex,
      newTokensBalance: newBalance,
      spinRecord,
      message: `You landed on ${wonSegment.label}!`,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
