import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { subscriptions, users, platformSettings, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const settingsRes = await db.select().from(platformSettings).limit(1);
    const settings = settingsRes[0] || {
      tillNumber: "8923411",
      paybillNumber: "522522",
      accountName: "HOTCHEELEE",
      creatorPriceKsh: 500,
      agencyPriceKsh: 1500,
    };

    // User's subscription history
    const userSubs = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, currentUser.id))
      .orderBy(desc(subscriptions.createdAt));

    // Calculate days remaining if active (enforcing strict 30 days)
    let daysRemaining = 0;
    let isExpired = false;
    let hoursRemaining = 0;

    if (currentUser.subscriptionExpiresAt) {
      const diffMs = new Date(currentUser.subscriptionExpiresAt).getTime() - Date.now();
      daysRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
      hoursRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60)));

      // When subscription expires, user is reduced to browsing only until they pay again!
      if (diffMs <= 0 && currentUser.subscriptionStatus === "active") {
        isExpired = true;
        await db
          .update(users)
          .set({
            subscriptionStatus: "expired",
            accountType: "browsing", // reduced to browsing only!
          })
          .where(eq(users.id, currentUser.id));

        // Create expiration notice
        await db.insert(notifications).values({
          userId: currentUser.id,
          actorId: currentUser.id,
          type: "subscription_expired",
          message: "Your 30-day listing subscription has expired. Your account has been reduced to browsing only until you renew.",
        });
      } else if (daysRemaining <= 5 && daysRemaining > 0 && currentUser.subscriptionStatus === "active") {
        // 5-day expiration alert
        const recentNotif = await db
          .select()
          .from(notifications)
          .where(eq(notifications.userId, currentUser.id))
          .limit(5);

        const hasReminded = recentNotif.some(n => n.type === "subscription_reminder_5d");
        if (!hasReminded) {
          await db.insert(notifications).values({
            userId: currentUser.id,
            actorId: currentUser.id,
            type: "subscription_reminder_5d",
            message: `⚠️ URGENT: Your 30-day HotCheelee subscription expires in ${daysRemaining} days! Renew via Till 8923411 to avoid being reduced to browsing. Email reminder sent to ${currentUser.email}.`,
          });
        }
      }
    }

    return NextResponse.json({
      status: isExpired ? "expired" : currentUser.subscriptionStatus,
      plan: currentUser.subscriptionPlan,
      accountType: currentUser.accountType,
      expiresAt: currentUser.subscriptionExpiresAt,
      daysRemaining,
      hoursRemaining,
      isExpiringSoon: daysRemaining <= 5 && daysRemaining > 0,
      lastMpesaCode: currentUser.lastMpesaCode,
      history: userSubs,
      tillDetails: {
        tillNumber: settings.tillNumber,
        paybillNumber: settings.paybillNumber,
        accountName: settings.accountName,
        creatorPriceKsh: settings.creatorPriceKsh,
        agencyPriceKsh: settings.agencyPriceKsh,
        supportPhone: settings.supportPhone,
        supportWhatsapp: settings.supportWhatsapp,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Submit manual M-Pesa Payment for Creator (500 KSh) or Agency (1500 KSh)
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { mpesaCode, phonePaid, amountKsh, plan } = body;

    if (!mpesaCode || !phonePaid || !amountKsh) {
      return NextResponse.json({ error: "M-Pesa transaction code, payment amount and phone number are required" }, { status: 400 });
    }

    const cleanCode = mpesaCode.trim().toUpperCase();
    const cleanPhone = phonePaid.trim();
    const cleanAmount = Number(amountKsh);

    const targetPlan = plan || (currentUser.accountType === "agency" ? "agency_1500" : "creator_500");
    const accountType = currentUser.accountType === "agency" ? "agency" : "creator";

    const expectedAmount = accountType === "agency" ? 1500 : 500;
    if (cleanAmount < expectedAmount) {
      return NextResponse.json({
        error: `Invalid amount. ${accountType === "agency" ? "Agency" : "Creator"} subscription is KSh ${expectedAmount}. You submitted KSh ${cleanAmount}.`,
      }, { status: 400 });
    }

    const [subRecord] = await db
      .insert(subscriptions)
      .values({
        userId: currentUser.id,
        accountType,
        plan: targetPlan,
        amountKsh: cleanAmount,
        tillNumber: "8923411",
        mpesaCode: cleanCode,
        phonePaid: cleanPhone,
        status: "pending", // Strictly moderated by Admin
        notes: `Submitted manual M-Pesa payment KSh ${cleanAmount} by ${currentUser.displayName}`,
      })
      .returning();

    await db
      .update(users)
      .set({
        subscriptionStatus: "pending",
        subscriptionPlan: targetPlan,
        lastMpesaCode: cleanCode,
        accountType,
      })
      .where(eq(users.id, currentUser.id));

    // Notify all admins
    const admins = await db.select().from(users).where(eq(users.isAdmin, true));
    for (const a of admins) {
      await db.insert(notifications).values({
        userId: a.id,
        actorId: currentUser.id,
        type: "subscription_pending",
        message: `New M-Pesa Subscription payment: KSh ${cleanAmount} from ${currentUser.displayName} (${cleanCode}). Needs review.`,
      });
    }

    return NextResponse.json({
      success: true,
      message: `Payment code ${cleanCode} received! Your subscription is pending admin confirmation. Once confirmed, your 30-day active listing will start immediately.`,
      subscription: subRecord,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
