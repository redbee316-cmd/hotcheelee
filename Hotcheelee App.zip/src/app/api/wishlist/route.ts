import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { wishlistItems, users, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const modelId = url.searchParams.get("modelId");

    const items = await db
      .select({
        wishlist: wishlistItems,
        fulfilledBy: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(wishlistItems)
      .leftJoin(users, eq(wishlistItems.fulfilledByUserId, users.id))
      .where(modelId ? eq(wishlistItems.modelId, Number(modelId)) : undefined)
      .orderBy(desc(wishlistItems.createdAt));

    return NextResponse.json({
      items: items.map((i) => ({ ...i.wishlist, fulfilledBy: i.fulfilledBy })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Fulfill a Wishlist Item with Tokens (Buying gifts for models)
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { itemId } = body;

    const res = await db.select().from(wishlistItems).where(eq(wishlistItems.id, Number(itemId))).limit(1);
    if (res.length === 0) {
      return NextResponse.json({ error: "Wishlist item not found" }, { status: 404 });
    }

    const item = res[0];
    if (item.isFulfilled) {
      return NextResponse.json({ error: "Item has already been gifted!" }, { status: 400 });
    }

    const cost = item.tokenCost;
    if (currentUser.tokensBalance < cost) {
      return NextResponse.json({
        error: `Insufficient tokens! You need ${cost} tokens to buy this gift. You have ${currentUser.tokensBalance} tokens.`,
      }, { status: 400 });
    }

    // Deduct tokens, award huge XP (1500 XP)
    const newBalance = currentUser.tokensBalance - cost;
    await db
      .update(users)
      .set({
        tokensBalance: newBalance,
        userXp: currentUser.userXp + cost * 20,
      })
      .where(eq(users.id, currentUser.id));

    // Mark item fulfilled
    const [updated] = await db
      .update(wishlistItems)
      .set({
        isFulfilled: true,
        fulfilledByUserId: currentUser.id,
        fulfilledAt: new Date(),
      })
      .where(eq(wishlistItems.id, item.id))
      .returning();

    // Notify model
    await db.insert(notifications).values({
      userId: item.modelId,
      actorId: currentUser.id,
      type: "gift",
      message: `${currentUser.displayName} bought you a gift from your wishlist: "${item.title}" (${cost} tokens)! 🎁💝`,
    });

    return NextResponse.json({
      success: true,
      message: `Gift sent! You fulfilled "${item.title}" for ${cost} tokens.`,
      item: updated,
      newTokensBalance: newBalance,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
