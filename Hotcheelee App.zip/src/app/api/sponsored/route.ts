import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { sponsoredAds, users, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const ads = await db
      .select()
      .from(sponsoredAds)
      .where(eq(sponsoredAds.isActive, true))
      .orderBy(desc(sponsoredAds.createdAt));

    return NextResponse.json({ ads });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Create a Paid Sponsored Ad (Deducts Coins from wallet, moderated by Admin)
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { brandName, title, content, mediaUrl, mediaType, ctaText, targetUrl, budgetKsh } = body;

    if (!title || !content || !mediaUrl) {
      return NextResponse.json({ error: "Title, content and media URL are required" }, { status: 400 });
    }

    const budget = Number(budgetKsh) || 3000;
    const requiredCoins = Math.floor(budget / 10); // 1 coin = 10 KSh

    if (currentUser.tokensBalance < requiredCoins) {
      return NextResponse.json({
        error: `Insufficient wallet balance! Sponsoring this campaign requires 🪙 ${requiredCoins} Coins (KSh ${budget.toLocaleString()}). You currently have 🪙 ${currentUser.tokensBalance} Coins. Please top up your coins wallet first.`,
        requiredCoins,
      }, { status: 400 });
    }

    // Deduct coins from user wallet
    await db
      .update(users)
      .set({ tokensBalance: currentUser.tokensBalance - requiredCoins })
      .where(eq(users.id, currentUser.id));

    const [newAd] = await db
      .insert(sponsoredAds)
      .values({
        advertiserId: currentUser.id,
        brandName: brandName || currentUser.displayName,
        title: title.trim(),
        content: content.trim(),
        mediaUrl: mediaUrl.trim(),
        mediaType: mediaType || "image",
        ctaText: ctaText || "Book Appointment",
        targetUrl: targetUrl || `https://hotcheelee.com/profile/${currentUser.username}`,
        budgetTokens: requiredCoins,
        budgetKsh: budget,
        status: "pending", // Moderated by admin!
        isActive: false, // Goes live only after admin approval!
      })
      .returning();

    // Notify admins
    const admins = await db.select().from(users).where(eq(users.isAdmin, true));
    for (const a of admins) {
      await db.insert(notifications).values({
        userId: a.id,
        actorId: currentUser.id,
        type: "ad_pending",
        message: `New Sponsored Ad Campaign: "${title}" (🪙 ${requiredCoins} Coins / KSh ${budget}) by ${currentUser.displayName}. Review and approve in Admin Portal.`,
      });
    }

    return NextResponse.json({
      success: true,
      message: `Paid 🪙 ${requiredCoins} Coins from wallet! Campaign submitted for admin moderation. Once approved, your ad will go live on infinite feeds.`,
      ad: newAd,
      remainingCoins: currentUser.tokensBalance - requiredCoins,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
