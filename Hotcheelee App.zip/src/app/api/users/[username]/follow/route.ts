import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { follows, users, notifications } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ username: string }> }
) {
  try {
    const { username } = await params;
    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const targetUser = await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (targetUser.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const target = targetUser[0];
    if (target.id === currentUser.id) {
      return NextResponse.json({ error: "Cannot follow yourself" }, { status: 400 });
    }

    // Check 200/day follow limit rule
    const todayStr = new Date().toISOString().split("T")[0];
    let dailyCount = currentUser.dailyFollowsCount;
    if (currentUser.lastFollowDate !== todayStr) {
      dailyCount = 0; // reset for new day
    }

    const existing = await db
      .select()
      .from(follows)
      .where(and(eq(follows.followerId, currentUser.id), eq(follows.followingId, target.id)))
      .limit(1);

    let isFollowing = false;
    let followersCount = target.followersCount;

    if (existing.length > 0) {
      // Unfollow
      await db
        .delete(follows)
        .where(and(eq(follows.followerId, currentUser.id), eq(follows.followingId, target.id)));

      await db
        .update(users)
        .set({ followersCount: sql`GREATEST(0, ${users.followersCount} - 1)` })
        .where(eq(users.id, target.id));

      await db
        .update(users)
        .set({ followingCount: sql`GREATEST(0, ${users.followingCount} - 1)` })
        .where(eq(users.id, currentUser.id));

      followersCount = Math.max(0, followersCount - 1);
      isFollowing = false;
    } else {
      // Follow - ENFORCE 200 FOLLOWS PER DAY LIMIT
      if (dailyCount >= 200) {
        return NextResponse.json({
          error: "Daily limit reached! You can only follow up to 200 people per day. Create interesting & interactive content so following grows organically!",
        }, { status: 429 });
      }

      await db.insert(follows).values({
        followerId: currentUser.id,
        followingId: target.id,
      });

      await db
        .update(users)
        .set({ followersCount: sql`${users.followersCount} + 1` })
        .where(eq(users.id, target.id));

      await db
        .update(users)
        .set({
          followingCount: sql`${users.followingCount} + 1`,
          dailyFollowsCount: dailyCount + 1,
          lastFollowDate: todayStr,
        })
        .where(eq(users.id, currentUser.id));

      followersCount += 1;
      isFollowing = true;

      // TikTok Follow-for-Follow check: does target already follow currentUser?
      const targetFollowsMe = await db
        .select()
        .from(follows)
        .where(and(eq(follows.followerId, target.id), eq(follows.followingId, currentUser.id)))
        .limit(1);

      let isMutualFriend = false;
      if (targetFollowsMe.length > 0) {
        isMutualFriend = true;
        await db.update(users).set({ friendsCount: sql`${users.friendsCount} + 1` }).where(eq(users.id, currentUser.id));
        await db.update(users).set({ friendsCount: sql`${users.friendsCount} + 1` }).where(eq(users.id, target.id));
      }

      // Notification
      await db.insert(notifications).values({
        userId: target.id,
        actorId: currentUser.id,
        type: isMutualFriend ? "mutual_friend" : "follow",
        message: isMutualFriend
          ? `🎉 You and ${currentUser.displayName} followed each other back! You are now mutual friends with full feed access.`
          : `${currentUser.displayName} followed you! Follow back to become mutual friends.`,
      });
    }

    return NextResponse.json({
      success: true,
      isFollowing,
      followersCount,
      dailyFollowsCount: dailyCount + (isFollowing ? 1 : 0),
      limitRemaining: Math.max(0, 200 - (dailyCount + (isFollowing ? 1 : 0))),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
