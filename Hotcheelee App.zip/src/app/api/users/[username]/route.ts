import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, follows, posts, bookmarks, postFlames, topics } from "@/db/schema";
import { eq, and, desc, or } from "drizzle-orm";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ username: string }> }
) {
  try {
    const { username } = await params;
    const currentUser = await getCurrentUser();

    const result = await db
      .select()
      .from(users)
      .where(or(eq(users.username, username), eq(users.username, decodeURIComponent(username))))
      .limit(1);

    if (result.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const targetUser = result[0];

    let isFollowing = false;
    if (currentUser) {
      const followRecord = await db
        .select()
        .from(follows)
        .where(
          and(
            eq(follows.followerId, currentUser.id),
            eq(follows.followingId, targetUser.id)
          )
        )
        .limit(1);
      isFollowing = followRecord.length > 0;
    }

    // Get all user's posts
    const userPosts = await db
      .select({
        post: posts,
        topic: {
          id: topics.id,
          name: topics.name,
          slug: topics.slug,
          icon: topics.icon,
        },
      })
      .from(posts)
      .leftJoin(topics, eq(posts.topicId, topics.id))
      .where(eq(posts.userId, targetUser.id))
      .orderBy(desc(posts.createdAt));

    let parsedRates = [];
    let parsedServices = [];
    let parsedGallery: string[] = [];
    try {
      parsedRates = JSON.parse(targetUser.rates || "[]");
    } catch {}
    try {
      parsedServices = JSON.parse(targetUser.servicesOffered || "[]");
    } catch {}
    try {
      parsedGallery = JSON.parse(targetUser.galleryUrls || "[]");
    } catch {}

    const rawPhone = targetUser.phone || "+254 700 000000";
    const maskedPhone =
      rawPhone.length > 8 ? rawPhone.slice(0, 7) + " ••• " + rawPhone.slice(-3) : "+254 7•• ••• •••";

    return NextResponse.json({
      user: {
        ...targetUser,
        isFollowing,
        isSelf: currentUser ? currentUser.id === targetUser.id : false,
        postsCount: userPosts.length,
        ratesList: parsedRates,
        servicesList: parsedServices,
        galleryList: parsedGallery,
        maskedPhone,
      },
      posts: userPosts.map((p) => ({
        ...p.post,
        topic: p.topic,
        author: {
          id: targetUser.id,
          username: targetUser.username,
          displayName: targetUser.displayName,
          avatar: targetUser.avatar,
          phone: targetUser.phone,
          locationArea: targetUser.locationArea,
          serviceType: targetUser.serviceType,
          isVerifiedStar: targetUser.isVerifiedStar,
          badge: targetUser.badge,
          genderRole: targetUser.genderRole,
          accountType: targetUser.accountType,
          isBrand: targetUser.isBrand,
        },
        media: (() => {
          try {
            return JSON.parse(p.post.mediaUrls || "[]");
          } catch {
            return [];
          }
        })(),
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Edit Profile & Edit Cover Photo / Profile Photo
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ username: string }> }
) {
  try {
    const { username } = await params;
    const currentUser = await getCurrentUser();

    if (!currentUser || (currentUser.username !== username && !currentUser.isAdmin)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      displayName,
      bio,
      avatar,
      coverImage,
      location,
      locationArea,
      phone,
      serviceType,
      servicesOffered,
      rates,
      genderRole,
      agencyType,
      website,
      paysiteUrl,
      paysiteLabel,
      galleryUrls,
    } = body;

    const [updated] = await db
      .update(users)
      .set({
        displayName: displayName !== undefined ? displayName.trim() : currentUser.displayName,
        bio: bio !== undefined ? bio : currentUser.bio,
        avatar: avatar !== undefined ? avatar : currentUser.avatar,
        coverImage: coverImage !== undefined ? coverImage : currentUser.coverImage,
        location: location !== undefined ? location : currentUser.location,
        locationArea: locationArea !== undefined ? locationArea : currentUser.locationArea,
        phone: phone !== undefined ? phone : currentUser.phone,
        serviceType: serviceType !== undefined ? serviceType : currentUser.serviceType,
        servicesOffered:
          servicesOffered !== undefined
            ? typeof servicesOffered === "string"
              ? servicesOffered
              : JSON.stringify(servicesOffered)
            : currentUser.servicesOffered,
        rates:
          rates !== undefined
            ? typeof rates === "string"
              ? rates
              : JSON.stringify(rates)
            : currentUser.rates,
        genderRole: genderRole !== undefined ? genderRole : currentUser.genderRole,
        agencyType: agencyType !== undefined ? agencyType : currentUser.agencyType,
        website: website !== undefined ? website : currentUser.website,
        paysiteUrl: paysiteUrl !== undefined ? paysiteUrl : currentUser.paysiteUrl,
        paysiteLabel: paysiteLabel !== undefined ? paysiteLabel : currentUser.paysiteLabel,
        galleryUrls:
          galleryUrls !== undefined
            ? typeof galleryUrls === "string"
              ? galleryUrls
              : JSON.stringify(galleryUrls)
            : currentUser.galleryUrls,
      })
      .where(eq(users.id, currentUser.id))
      .returning();

    return NextResponse.json({ success: true, user: updated, message: "Profile updated successfully!" });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
