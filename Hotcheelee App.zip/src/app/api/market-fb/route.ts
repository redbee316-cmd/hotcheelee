import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { marketplaceItems, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const category = url.searchParams.get("category");
    const search = url.searchParams.get("q");

    const items = await db
      .select({
        item: marketplaceItems,
        seller: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          phone: users.phone,
        },
      })
      .from(marketplaceItems)
      .leftJoin(users, eq(marketplaceItems.sellerId, users.id))
      .where(eq(marketplaceItems.isSold, false))
      .orderBy(desc(marketplaceItems.createdAt));

    let filtered = items.map((i) => ({ ...i.item, seller: i.seller }));

    if (category && category !== "All") {
      filtered = filtered.filter((i) => i.category.toLowerCase() === category.toLowerCase());
    }

    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter((i) => i.title.toLowerCase().includes(q) || i.description.toLowerCase().includes(q) || (i.locationArea && i.locationArea.toLowerCase().includes(q)));
    }

    return NextResponse.json({ items: filtered });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// List new Adult Marketplace Item
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { title, description, priceKsh, category, locationArea, condition, images, contactPhone } = body;

    if (!title || !priceKsh || !category) {
      return NextResponse.json({ error: "Title, Price and Category required" }, { status: 400 });
    }

    const price = Number(priceKsh);
    const coins = Math.floor(price / 10);

    const [newItem] = await db
      .insert(marketplaceItems)
      .values({
        sellerId: currentUser.id,
        title: title.trim(),
        description: description ? description.trim() : "Available in Nairobi / Kenya for discrete delivery.",
        priceKsh: price,
        priceCoins: coins,
        category,
        location: currentUser.location || "Nairobi",
        locationArea: locationArea || currentUser.locationArea || "Kilimani",
        condition: condition || "Brand New",
        images: images ? (typeof images === "string" ? images : JSON.stringify(images)) : JSON.stringify(["https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg"]),
        contactPhone: contactPhone || currentUser.phone || "+254 700 892341",
        status: "active",
      })
      .returning();

    return NextResponse.json({ success: true, item: newItem }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
