import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { pages, pageLikes, pagePosts, users } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const currentUser = await getCurrentUser();

    const pageRes = await db.select().from(pages).where(eq(pages.slug, slug)).limit(1);
    if (pageRes.length === 0) {
      return NextResponse.json({ error: "Page not found" }, { status: 404 });
    }

    const page = pageRes[0];

    // Check if liked by current user
    let isLiked = false;
    if (currentUser) {
      const likeRecord = await db
        .select()
        .from(pageLikes)
        .where(and(eq(pageLikes.pageId, page.id), eq(pageLikes.userId, currentUser.id)))
        .limit(1);
      isLiked = likeRecord.length > 0;
    }

    // Get page posts
    const posts = await db
      .select({
        post: pagePosts,
        author: {
          id: users.id,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(pagePosts)
      .leftJoin(users, eq(pagePosts.authorId, users.id))
      .where(eq(pagePosts.pageId, page.id))
      .orderBy(desc(pagePosts.createdAt));

    let parsedServices = [];
    let parsedRates = [];
    try {
      parsedServices = JSON.parse(page.services || "[]");
    } catch {}
    try {
      parsedRates = JSON.parse(page.rates || "[]");
    } catch {}

    return NextResponse.json({
      page: {
        ...page,
        isLiked,
        servicesList: parsedServices,
        ratesList: parsedRates,
      },
      posts: posts.map((p) => ({ ...p.post, author: p.author })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Like / Follow page or post to page
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const pageRes = await db.select().from(pages).where(eq(pages.slug, slug)).limit(1);
    if (pageRes.length === 0) return NextResponse.json({ error: "Page not found" }, { status: 404 });

    const page = pageRes[0];
    const body = await req.json().catch(() => ({}));
    const { action, content, mediaUrls } = body;

    // 1. Post to page
    if (action === "post") {
      const [newPost] = await db
        .insert(pagePosts)
        .values({
          pageId: page.id,
          authorId: currentUser.id,
          content: content ? content.trim() : "New update from page",
          mediaUrls: mediaUrls ? (typeof mediaUrls === "string" ? mediaUrls : JSON.stringify(mediaUrls)) : null,
        })
        .returning();

      return NextResponse.json({ success: true, post: newPost }, { status: 201 });
    }

    // 2. Like / Unlike page
    const existing = await db
      .select()
      .from(pageLikes)
      .where(and(eq(pageLikes.pageId, page.id), eq(pageLikes.userId, currentUser.id)))
      .limit(1);

    let isLiked = false;
    let newCount = page.likesCount;

    if (existing.length > 0) {
      await db.delete(pageLikes).where(and(eq(pageLikes.pageId, page.id), eq(pageLikes.userId, currentUser.id)));
      newCount = Math.max(0, newCount - 1);
      await db.update(pages).set({ likesCount: newCount }).where(eq(pages.id, page.id));
      isLiked = false;
    } else {
      await db.insert(pageLikes).values({ pageId: page.id, userId: currentUser.id });
      newCount += 1;
      await db.update(pages).set({ likesCount: newCount }).where(eq(pages.id, page.id));
      isLiked = true;
    }

    return NextResponse.json({ success: true, isLiked, likesCount: newCount });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
