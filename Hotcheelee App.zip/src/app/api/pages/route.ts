import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { pages, pageLikes, pagePosts, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const category = url.searchParams.get("category");
    const search = url.searchParams.get("q");

    const allPages = await db.select().from(pages).orderBy(desc(pages.followersCount));

    let filtered = allPages;
    if (category && category !== "All") {
      filtered = filtered.filter((p) => p.category.toLowerCase().includes(category.toLowerCase()));
    }
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.about && p.about.toLowerCase().includes(q)) ||
          (p.locationArea && p.locationArea.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({ pages: filtered });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Create new Facebook-style HotCheelee Page
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { name, category, about, locationArea, phone, whatsapp, coverImage, avatar, services, rates } = body;

    if (!name || !category) {
      return NextResponse.json({ error: "Page name and category are required" }, { status: 400 });
    }

    const cleanSlug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-" + Math.floor(Math.random() * 900 + 100);

    const [newPage] = await db
      .insert(pages)
      .values({
        ownerId: currentUser.id,
        name: name.trim(),
        slug: cleanSlug,
        category,
        about: about ? about.trim() : `Official Page for ${name}`,
        locationArea: locationArea || currentUser.locationArea || "Kilimani, Nairobi",
        phone: phone || currentUser.phone || "+254 700 892341",
        whatsapp: whatsapp || currentUser.phone || "+254 700 892341",
        avatar: avatar || "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg",
        coverImage: coverImage || "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg",
        services: services ? (typeof services === "string" ? services : JSON.stringify(services)) : JSON.stringify(["VIP Relaxation", "Massage Therapy", "Sensual Companionship"]),
        rates: rates ? (typeof rates === "string" ? rates : JSON.stringify(rates)) : JSON.stringify([{ title: "Standard 1hr", price: 4000 }, { title: "Overnight VIP", price: 15000 }]),
        likesCount: 1,
        followersCount: 1,
        verified: true,
      })
      .returning();

    // Auto-like for creator
    await db.insert(pageLikes).values({ pageId: newPage.id, userId: currentUser.id });

    return NextResponse.json({ success: true, page: newPage }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
