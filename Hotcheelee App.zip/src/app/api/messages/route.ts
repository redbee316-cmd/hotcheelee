import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { messages, users, notifications } from "@/db/schema";
import { eq, or, and, desc, asc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(req.url);
    const withUserId = url.searchParams.get("withUserId");

    if (withUserId) {
      const otherId = Number(withUserId);

      const threadMessages = await db
        .select()
        .from(messages)
        .where(
          and(
            eq(messages.isDeleted, false),
            or(
              and(eq(messages.senderId, currentUser.id), eq(messages.receiverId, otherId)),
              and(eq(messages.senderId, otherId), eq(messages.receiverId, currentUser.id))
            )
          )
        )
        .orderBy(asc(messages.createdAt));

      // Mark received messages as read
      await db
        .update(messages)
        .set({ isRead: true })
        .where(and(eq(messages.receiverId, currentUser.id), eq(messages.senderId, otherId)));

      const otherUser = await db.select().from(users).where(eq(users.id, otherId)).limit(1);

      return NextResponse.json({
        messages: threadMessages,
        otherUser: otherUser[0] || null,
      });
    }

    // List all dialogs for current user
    const allUserMessages = await db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.isDeleted, false),
          or(eq(messages.senderId, currentUser.id), eq(messages.receiverId, currentUser.id))
        )
      )
      .orderBy(desc(messages.createdAt));

    const partnerIds = new Set<number>();
    const lastMessageMap: Record<number, any> = {};

    allUserMessages.forEach((m) => {
      const partnerId = m.senderId === currentUser.id ? m.receiverId : m.senderId;
      partnerIds.add(partnerId);
      if (!lastMessageMap[partnerId]) {
        lastMessageMap[partnerId] = m;
      }
    });

    const conversationList = [];
    for (const pid of partnerIds) {
      const userRes = await db.select().from(users).where(eq(users.id, pid)).limit(1);
      if (userRes.length > 0) {
        conversationList.push({
          user: userRes[0],
          lastMessage: lastMessageMap[pid],
          unread: lastMessageMap[pid].receiverId === currentUser.id && !lastMessageMap[pid].isRead,
        });
      }
    }

    // Provide default contacts if empty
    if (conversationList.length === 0) {
      const suggested = await db
        .select()
        .from(users)
        .where(eq(users.accountType, "creator"))
        .limit(3);

      suggested.forEach((u) => {
        if (u.id !== currentUser.id) {
          conversationList.push({
            user: u,
            lastMessage: { content: "Tap to start conversation...", createdAt: new Date() },
            unread: false,
          });
        }
      });
    }

    return NextResponse.json({ conversations: conversationList });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Send message or forward
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { receiverId, content, mediaUrl, mediaType, tokensTipped, replyToMessageId, forwardedFrom } = body;

    if (!content && !mediaUrl && !tokensTipped) {
      return NextResponse.json({ error: "Message content or attachment is required" }, { status: 400 });
    }

    const tokens = Number(tokensTipped) || 0;

    if (tokens > 0) {
      if (currentUser.tokensBalance < tokens) {
        return NextResponse.json({
          error: `Insufficient tokens! You need ${tokens} tokens. Available: ${currentUser.tokensBalance} tk.`,
        }, { status: 400 });
      }

      await db
        .update(users)
        .set({ tokensBalance: currentUser.tokensBalance - tokens })
        .where(eq(users.id, currentUser.id));
    }

    const [newMessage] = await db
      .insert(messages)
      .values({
        senderId: currentUser.id,
        receiverId: Number(receiverId),
        content: content || (tokens > 0 ? `Sent ${tokens} Tokens 🪙` : "Media attachment"),
        mediaUrl: mediaUrl || null,
        mediaType: mediaType || null,
        tokensTipped: tokens,
        replyToMessageId: replyToMessageId ? Number(replyToMessageId) : null,
        forwardedFrom: forwardedFrom || null,
        isRead: false,
      })
      .returning();

    await db.insert(notifications).values({
      userId: Number(receiverId),
      actorId: currentUser.id,
      type: "chat_message",
      message: `${currentUser.displayName}: "${(content || "Attachment").slice(0, 40)}"`,
    });

    return NextResponse.json({ message: newMessage }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Action features on messages: Reply, React, Pin/Unpin, Star, Edit, Report, Delete
export async function PATCH(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { messageId, action, reaction, newContent, reportReason } = body;

    if (!messageId || !action) {
      return NextResponse.json({ error: "messageId and action required" }, { status: 400 });
    }

    const msgRes = await db.select().from(messages).where(eq(messages.id, Number(messageId))).limit(1);
    if (msgRes.length === 0) {
      return NextResponse.json({ error: "Message not found" }, { status: 404 });
    }

    const targetMsg = msgRes[0];

    // WhatsApp Action Matrix
    if (action === "react") {
      const [updated] = await db
        .update(messages)
        .set({ reaction: reaction || null })
        .where(eq(messages.id, targetMsg.id))
        .returning();
      return NextResponse.json({ success: true, message: updated });
    }

    if (action === "pin") {
      const [updated] = await db
        .update(messages)
        .set({ isPinned: true })
        .where(eq(messages.id, targetMsg.id))
        .returning();
      return NextResponse.json({ success: true, message: updated });
    }

    if (action === "unpin") {
      const [updated] = await db
        .update(messages)
        .set({ isPinned: false })
        .where(eq(messages.id, targetMsg.id))
        .returning();
      return NextResponse.json({ success: true, message: updated });
    }

    if (action === "star") {
      const [updated] = await db
        .update(messages)
        .set({ isStarred: !targetMsg.isStarred })
        .where(eq(messages.id, targetMsg.id))
        .returning();
      return NextResponse.json({ success: true, message: updated });
    }

    if (action === "edit") {
      if (targetMsg.senderId !== currentUser.id) {
        return NextResponse.json({ error: "You can only edit your own messages" }, { status: 403 });
      }
      const [updated] = await db
        .update(messages)
        .set({
          content: newContent ? newContent.trim() : targetMsg.content,
          isEdited: true,
        })
        .where(eq(messages.id, targetMsg.id))
        .returning();
      return NextResponse.json({ success: true, message: updated });
    }

    if (action === "delete") {
      if (targetMsg.senderId !== currentUser.id && targetMsg.receiverId !== currentUser.id) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
      }
      const [updated] = await db
        .update(messages)
        .set({ isDeleted: true })
        .where(eq(messages.id, targetMsg.id))
        .returning();
      return NextResponse.json({ success: true, messageId: updated.id, isDeleted: true });
    }

    if (action === "report") {
      await db
        .update(messages)
        .set({ isReported: true })
        .where(eq(messages.id, targetMsg.id));
      return NextResponse.json({ success: true, message: "Message reported to HotCheelee moderators." });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
