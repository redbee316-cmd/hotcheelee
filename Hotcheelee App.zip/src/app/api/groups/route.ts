import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { groups, groupMembers, groupPosts, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const category = url.searchParams.get("category");
    const search = url.searchParams.get("q");

    const allGroups = await db.select().from(groups).orderBy(desc(groups.membersCount));

    let filtered = allGroups;
    if (category && category !== "All") {
      filtered = filtered.filter((g) => g.category.toLowerCase() === category.toLowerCase());
    }
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter((g) => g.name.toLowerCase().includes(q) || g.description.toLowerCase().includes(q));
    }

    return NextResponse.json({ groups: filtered });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Create new HotCheelee Group
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { name, description, category, privacy, coverImage } = body;

    if (!name || !description) {
      return NextResponse.json({ error: "Name and description are required" }, { status: 400 });
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-" + Math.floor(Math.random() * 900 + 100);

    const [newGroup] = await db
      .insert(groups)
      .values({
        creatorId: currentUser.id,
        name: name.trim(),
        slug,
        description: description.trim(),
        category: category || "Adult & Social",
        privacy: privacy || "public",
        coverImage: coverImage || "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1200",
        membersCount: 1,
      })
      .returning();

    // Auto-join creator as admin
    await db.insert(groupMembers).values({
      groupId: newGroup.id,
      userId: currentUser.id,
      role: "admin",
    });

    return NextResponse.json({ success: true, group: newGroup }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
