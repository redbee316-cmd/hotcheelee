import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { friendRequests, follows, users, notifications } from "@/db/schema";
import { eq, or, and, ne } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // 1. Pending incoming friend requests
    const incomingRequests = await db
      .select({
        request: friendRequests,
        sender: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          accountType: users.accountType,
          locationArea: users.locationArea,
        },
      })
      .from(friendRequests)
      .leftJoin(users, eq(friendRequests.senderId, users.id))
      .where(and(eq(friendRequests.receiverId, currentUser.id), eq(friendRequests.status, "pending")));

    // 2. Mutual Friends (follow-for-follow + accepted requests)
    const myFollowings = await db
      .select({ followingId: follows.followingId })
      .from(follows)
      .where(eq(follows.followerId, currentUser.id));

    const followingIds = new Set(myFollowings.map((f) => f.followingId));

    const myFollowers = await db
      .select({ followerId: follows.followerId })
      .from(follows)
      .where(eq(follows.followingId, currentUser.id));

    // Mutual = someone I follow AND who follows me back
    const mutualFriendIds = myFollowers
      .map((f) => f.followerId)
      .filter((id) => followingIds.has(id));

    // 3. "People You May Know" (Fresh suggestions everyday)
    const allCandidates = await db
      .select()
      .from(users)
      .where(and(ne(users.id, currentUser.id), eq(users.isBanned, false)))
      .limit(20);

    const peopleYouMayKnow = allCandidates.filter(
      (u) => !followingIds.has(u.id)
    ).slice(0, 8);

    return NextResponse.json({
      incomingRequests: incomingRequests.map((r) => ({ ...r.request, sender: r.sender })),
      mutualFriendsCount: mutualFriendIds.length,
      peopleYouMayKnow,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Send, Accept or Decline Friend Request
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { targetUserId, action, requestId } = body; // action: 'send' | 'accept' | 'decline'

    if (action === "send") {
      const targetId = Number(targetUserId);
      if (targetId === currentUser.id) {
        return NextResponse.json({ error: "Cannot add yourself" }, { status: 400 });
      }

      // Check if already exists
      const existing = await db
        .select()
        .from(friendRequests)
        .where(
          or(
            and(eq(friendRequests.senderId, currentUser.id), eq(friendRequests.receiverId, targetId)),
            and(eq(friendRequests.senderId, targetId), eq(friendRequests.receiverId, currentUser.id))
          )
        )
        .limit(1);

      if (existing.length > 0) {
        return NextResponse.json({ error: "Friend request already sent or exists" }, { status: 400 });
      }

      const [reqRecord] = await db
        .insert(friendRequests)
        .values({
          senderId: currentUser.id,
          receiverId: targetId,
          status: "pending",
        })
        .returning();

      // Also auto-follow target user (TikTok follow-for-follow step 1)
      const isFollowing = await db
        .select()
        .from(follows)
        .where(and(eq(follows.followerId, currentUser.id), eq(follows.followingId, targetId)))
        .limit(1);

      if (isFollowing.length === 0) {
        await db.insert(follows).values({ followerId: currentUser.id, followingId: targetId });
        await db.update(users).set({ followingCount: currentUser.followingCount + 1 }).where(eq(users.id, currentUser.id));
      }

      await db.insert(notifications).values({
        userId: targetId,
        actorId: currentUser.id,
        type: "friend_request",
        message: `${currentUser.displayName} sent you a friend request & followed you!`,
      });

      return NextResponse.json({
        success: true,
        message: "Friend request sent!",
        request: reqRecord,
      });
    }

    if (action === "accept" && requestId) {
      const targetReq = await db.select().from(friendRequests).where(eq(friendRequests.id, Number(requestId))).limit(1);
      if (targetReq.length === 0) {
        return NextResponse.json({ error: "Request not found" }, { status: 404 });
      }

      const senderId = targetReq[0].senderId;

      await db
        .update(friendRequests)
        .set({ status: "accepted" })
        .where(eq(friendRequests.id, targetReq[0].id));

      // Mutual follow-for-follow: current user follows back sender!
      const followBack = await db
        .select()
        .from(follows)
        .where(and(eq(follows.followerId, currentUser.id), eq(follows.followingId, senderId)))
        .limit(1);

      if (followBack.length === 0) {
        await db.insert(follows).values({ followerId: currentUser.id, followingId: senderId });
      }

      // Increment friends count on both users
      await db.update(users).set({ friendsCount: currentUser.friendsCount + 1 }).where(eq(users.id, currentUser.id));

      await db.insert(notifications).values({
        userId: senderId,
        actorId: currentUser.id,
        type: "friend_accepted",
        message: `${currentUser.displayName} accepted your friend request! You are now mutual friends on HotCheelee.`,
      });

      return NextResponse.json({
        success: true,
        message: "Friend request accepted! You are now mutual friends.",
      });
    }

    if (action === "decline" && requestId) {
      await db
        .update(friendRequests)
        .set({ status: "declined" })
        .where(eq(friendRequests.id, Number(requestId)));

      return NextResponse.json({ success: true, message: "Request declined." });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
