import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { withdrawals, users, notifications, auditLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const history = await db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.userId, currentUser.id))
      .orderBy(desc(withdrawals.createdAt));

    return NextResponse.json({
      withdrawals: history,
      tokensBalance: currentUser.tokensBalance,
      availableKsh: currentUser.tokensBalance * 10, // 1 Token = 10 KSh
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Creator Manual M-Pesa or Crypto Withdrawal Request in KSh
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { tokenCount, mpesaPhone, method } = body;

    const count = Number(tokenCount);
    if (!count || count < 50) {
      return NextResponse.json({ error: "Minimum withdrawal is 50 Tokens (KSh 500)" }, { status: 400 });
    }

    if (currentUser.tokensBalance < count) {
      return NextResponse.json({
        error: `Insufficient token balance. You have ${currentUser.tokensBalance} tokens available.`,
      }, { status: 400 });
    }

    const phone = mpesaPhone ? mpesaPhone.trim() : (currentUser.phone || "0700000000");
    const amountKsh = count * 10; // 1 token = 10 KSh payout

    // Deduct tokens from creator
    const newTokens = currentUser.tokensBalance - count;
    await db
      .update(users)
      .set({ tokensBalance: newTokens })
      .where(eq(users.id, currentUser.id));

    const [record] = await db
      .insert(withdrawals)
      .values({
        userId: currentUser.id,
        amountKsh,
        amount: count.toFixed(2),
        token: "KSH",
        destinationAddress: phone,
        network: method || "M-Pesa Kenya",
        status: "Pending", // Awaiting Admin verification & M-Pesa disbursement
      })
      .returning();

    // Notify admins
    const admins = await db.select().from(users).where(eq(users.isAdmin, true));
    for (const a of admins) {
      await db.insert(notifications).values({
        userId: a.id,
        actorId: currentUser.id,
        type: "withdrawal_pending",
        message: `Payout request: KSh ${amountKsh} (${count} tokens) to ${phone} from ${currentUser.displayName}.`,
      });
    }

    return NextResponse.json({
      success: true,
      message: `Withdrawal request for KSh ${amountKsh} sent to administration! Disbursed to M-Pesa: ${phone} within 1-2 hours.`,
      withdrawal: record,
      remainingTokens: newTokens,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
