import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { bookings, users, notifications } from "@/db/schema";
import { eq, or, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const items = await db
      .select({
        booking: bookings,
        client: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(bookings)
      .leftJoin(users, eq(bookings.userId, users.id))
      .where(or(eq(bookings.userId, currentUser.id), eq(bookings.modelId, currentUser.id)))
      .orderBy(desc(bookings.createdAt));

    return NextResponse.json({
      bookings: items.map((i) => ({ ...i.booking, client: i.client })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized. Please login to book an appointment." }, { status: 401 });
    }

    const body = await req.json();
    const { modelId, serviceRequested, serviceType, duration, totalPriceKsh, preferredDate, clientPhone, clientNote } = body;

    if (!modelId || !serviceRequested || !clientPhone || !totalPriceKsh) {
      return NextResponse.json({ error: "Missing required booking details (service, contact phone, price)" }, { status: 400 });
    }

    const [newBooking] = await db
      .insert(bookings)
      .values({
        userId: currentUser.id,
        modelId: Number(modelId),
        serviceRequested: serviceRequested.trim(),
        serviceType: serviceType || "Incall",
        duration: duration || "1 Hour",
        totalPriceKsh: Number(totalPriceKsh),
        preferredDate: preferredDate || "Today",
        clientPhone: clientPhone.trim(),
        clientNote: clientNote ? clientNote.trim() : null,
        status: "pending",
      })
      .returning();

    // Notify model
    await db.insert(notifications).values({
      userId: Number(modelId),
      actorId: currentUser.id,
      type: "booking",
      message: `New Booking Request from ${currentUser.displayName}: "${serviceRequested}" (${serviceType}, KSh ${totalPriceKsh}) for ${preferredDate}. Contact: ${clientPhone}`,
    });

    return NextResponse.json({
      success: true,
      message: "Appointment request sent to model! They will contact you via WhatsApp / Phone to confirm.",
      booking: newBooking,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
