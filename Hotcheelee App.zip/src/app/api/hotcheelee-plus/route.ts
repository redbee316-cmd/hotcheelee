import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { hotcheeleePlusMemberships, users, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const activeSub = await db
      .select()
      .from(hotcheeleePlusMemberships)
      .where(eq(hotcheeleePlusMemberships.userId, currentUser.id))
      .orderBy(desc(hotcheeleePlusMemberships.createdAt))
      .limit(1);

    const isMember = activeSub.length > 0 && new Date(activeSub[0].expiresAt).getTime() > Date.now();

    return NextResponse.json({
      isMember,
      membership: isMember ? activeSub[0] : null,
      priceKsh: 1299, // KSh 1,299/mo (Sharesome+ equivalent)
      tokensBonus: 100, // 100 free tokens monthly bonus
      features: [
        "Transmitting high-res photos & videos directly inside private chats",
        "Browse 100% ad-free feeds without sponsored promotions",
        "100 Free HotCheelee Tokens automatically credited upon monthly renewal",
        "Exclusive HotCheelee+ glowing badge on profile and chat bubbles",
        "Priority positioning across all creator and agency discovery rails",
        "Full access to 9:16 Quickies and uncensored stories archive",
      ],
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Subscribe to HotCheelee+ (Sharesome+ clone)
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const { mpesaCode, phonePaid } = body;

    const priceKsh = 1299;
    const tokensBonus = 100;
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

    // Credit bonus 100 tokens to user wallet
    await db
      .update(users)
      .set({
        tokensBalance: currentUser.tokensBalance + tokensBonus,
        isUltimateMember: true,
      })
      .where(eq(users.id, currentUser.id));

    const [membership] = await db
      .insert(hotcheeleePlusMemberships)
      .values({
        userId: currentUser.id,
        plan: "hotcheelee_plus_monthly",
        priceKsh,
        tokensBonus,
        expiresAt,
        status: "active",
      })
      .returning();

    await db.insert(notifications).values({
      userId: currentUser.id,
      actorId: currentUser.id,
      type: "plus_activated",
      message: `👑 Welcome to HotCheelee+! Enjoy ad-free feeds, media in private chat, and your +100 bonus tokens.`,
    });

    return NextResponse.json({
      success: true,
      message: `🎉 HotCheelee+ activated for 30 days! +100 bonus tokens credited to your wallet.`,
      membership,
      newTokensBalance: currentUser.tokensBalance + tokensBonus,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
