import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { topics, topicMembers } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const category = url.searchParams.get("category");
    const search = url.searchParams.get("q");

    const currentUser = await getCurrentUser();

    let allTopics = await db
      .select()
      .from(topics)
      .orderBy(desc(topics.followersCount));

    let joinedTopicIds = new Set<number>();
    if (currentUser) {
      const memberships = await db
        .select({ topicId: topicMembers.topicId })
        .from(topicMembers)
        .where(eq(topicMembers.userId, currentUser.id));
      memberships.forEach((m) => joinedTopicIds.add(m.topicId));
    }

    let filtered = allTopics;

    if (category && category !== "All") {
      filtered = filtered.filter(
        (t) => t.category.toLowerCase() === category.toLowerCase()
      );
    }

    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.slug.toLowerCase().includes(q) ||
          (t.description && t.description.toLowerCase().includes(q))
      );
    }

    const result = filtered.map((t) => ({
      ...t,
      isJoined: joinedTopicIds.has(t.id),
      rulesList: (() => {
        try {
          return JSON.parse(t.rules || "[]");
        } catch {
          return [];
        }
      })(),
    }));

    return NextResponse.json({ topics: result });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { name, tagline, description, category, icon, banner, rules } = body;

    if (!name) {
      return NextResponse.json({ error: "Topic name is required" }, { status: 400 });
    }

    const slug = name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");

    const existing = await db.select().from(topics).where(eq(topics.slug, slug)).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ error: "A topic with this name already exists" }, { status: 409 });
    }

    const [newTopic] = await db
      .insert(topics)
      .values({
        slug,
        name: name.trim(),
        tagline: tagline || `The community for ${name}`,
        description: description || `Welcome to ${name} on Cheele.`,
        category: category || "General",
        icon: icon || "🔥",
        banner: banner || "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1400",
        rules: JSON.stringify(
          rules && rules.length > 0
            ? rules
            : [
                "18+ content only. Strict 2257 compliance required.",
                "Original or properly credited media only.",
                "Be respectful to all creators and models.",
              ]
        ),
        followersCount: 1,
      })
      .returning();

    // Auto-join creator to topic
    await db.insert(topicMembers).values({
      topicId: newTopic.id,
      userId: currentUser.id,
    });

    return NextResponse.json({ topic: newTopic }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
