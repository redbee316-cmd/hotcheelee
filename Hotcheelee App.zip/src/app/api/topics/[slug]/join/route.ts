import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { topics, topicMembers } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const currentUser = await getCurrentUser();

    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const topicResult = await db.select().from(topics).where(eq(topics.slug, slug)).limit(1);
    if (topicResult.length === 0) {
      return NextResponse.json({ error: "Topic not found" }, { status: 404 });
    }

    const topic = topicResult[0];

    const existing = await db
      .select()
      .from(topicMembers)
      .where(and(eq(topicMembers.topicId, topic.id), eq(topicMembers.userId, currentUser.id)))
      .limit(1);

    let isJoined = false;
    let followersCount = topic.followersCount;

    if (existing.length > 0) {
      await db
        .delete(topicMembers)
        .where(and(eq(topicMembers.topicId, topic.id), eq(topicMembers.userId, currentUser.id)));

      await db
        .update(topics)
        .set({ followersCount: sql`GREATEST(0, ${topics.followersCount} - 1)` })
        .where(eq(topics.id, topic.id));

      followersCount = Math.max(0, followersCount - 1);
      isJoined = false;
    } else {
      await db.insert(topicMembers).values({
        topicId: topic.id,
        userId: currentUser.id,
      });

      await db
        .update(topics)
        .set({ followersCount: sql`${topics.followersCount} + 1` })
        .where(eq(topics.id, topic.id));

      followersCount += 1;
      isJoined = true;
    }

    return NextResponse.json({ success: true, isJoined, followersCount });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
