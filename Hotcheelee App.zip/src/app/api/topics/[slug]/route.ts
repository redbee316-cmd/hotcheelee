import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { topics, topicMembers } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const currentUser = await getCurrentUser();

    const result = await db.select().from(topics).where(eq(topics.slug, slug)).limit(1);
    if (result.length === 0) {
      return NextResponse.json({ error: "Topic not found" }, { status: 404 });
    }

    const topic = result[0];
    let isJoined = false;

    if (currentUser) {
      const membership = await db
        .select()
        .from(topicMembers)
        .where(and(eq(topicMembers.topicId, topic.id), eq(topicMembers.userId, currentUser.id)))
        .limit(1);
      isJoined = membership.length > 0;
    }

    let rulesList = [];
    try {
      rulesList = JSON.parse(topic.rules || "[]");
    } catch {
      rulesList = [];
    }

    return NextResponse.json({
      topic: {
        ...topic,
        isJoined,
        rulesList,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
