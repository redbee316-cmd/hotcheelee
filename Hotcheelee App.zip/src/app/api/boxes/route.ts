import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { lootBoxes, users, nftGlasses } from "@/db/schema";
import { eq, and, sql, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const boxes = await db
      .select()
      .from(lootBoxes)
      .where(eq(lootBoxes.userId, currentUser.id))
      .orderBy(desc(lootBoxes.createdAt));

    return NextResponse.json({
      boxes,
      unopenedCount: boxes.filter((b) => !b.isOpened).length,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Open a Loot Box or Trigger Attention Watch Drop
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { action, boxId, minutesWatched } = body;

    // 1. User watched feed minutes -> simulate attention mining + drop box
    if (action === "watch_tick") {
      const mins = Number(minutesWatched) || 1;
      const currentMinutesLeft = currentUser.attentionMinutesLeft;

      if (currentMinutesLeft <= 0) {
        return NextResponse.json({
          message: "Daily attention minutes depleted. Buy rarer glasses to increase daily minutes!",
          attentionMinutesLeft: 0,
          boxDropped: null,
        });
      }

      // Deduct 1 minute
      const newMinutes = Math.max(0, currentMinutesLeft - mins);

      // Get multiplier from equipped glasses
      let multiplier = 1.30;
      if (currentUser.activeGlassesId) {
        const glasses = await db.select().from(nftGlasses).where(eq(nftGlasses.id, currentUser.activeGlassesId)).limit(1);
        if (glasses.length > 0) {
          multiplier = Number(glasses[0].multiplier);
        }
      }

      // Random chance of drop box (1 in 2 chance during watching)
      let boxDropped = null;
      const willDrop = Math.random() < 0.6;

      if (willDrop) {
        const boxTypes = ["Smart", "Rare", "Lucky", "Starting"];
        const chosenType = boxTypes[Math.floor(Math.random() * boxTypes.length)];
        const baseLee = (Math.random() * 4 + 2) * multiplier;
        const cheel = (Math.random() * 0.5 * multiplier).toFixed(2);

        const [createdBox] = await db.insert(lootBoxes).values({
          userId: currentUser.id,
          boxType: chosenType,
          leeReward: baseLee.toFixed(2),
          cheelBonus: cheel,
          isOpened: false,
        }).returning();

        boxDropped = createdBox;
      }

      await db.update(users).set({ attentionMinutesLeft: newMinutes }).where(eq(users.id, currentUser.id));

      return NextResponse.json({
        success: true,
        attentionMinutesLeft: newMinutes,
        boxDropped,
      });
    }

    // 2. Open an existing Box
    if (action === "open_box") {
      if (!boxId) {
        return NextResponse.json({ error: "boxId required" }, { status: 400 });
      }

      const boxRes = await db
        .select()
        .from(lootBoxes)
        .where(and(eq(lootBoxes.id, Number(boxId)), eq(lootBoxes.userId, currentUser.id)))
        .limit(1);

      if (boxRes.length === 0) {
        return NextResponse.json({ error: "Box not found" }, { status: 404 });
      }

      const targetBox = boxRes[0];
      if (targetBox.isOpened) {
        return NextResponse.json({ error: "Box already opened" }, { status: 400 });
      }

      const leeReward = Number(targetBox.leeReward);
      const cheelBonus = Number(targetBox.cheelBonus || 0);

      // Mark opened
      await db
        .update(lootBoxes)
        .set({ isOpened: true, openedAt: new Date() })
        .where(eq(lootBoxes.id, targetBox.id));

      // Credit tokens to user
      const currentLee = Number(currentUser.leeBalance);
      const currentCheel = Number(currentUser.cheelBalance);

      const newLee = (currentLee + leeReward).toFixed(2);
      const newCheel = (currentCheel + cheelBonus).toFixed(2);

      await db
        .update(users)
        .set({
          leeBalance: newLee,
          cheelBalance: newCheel,
        })
        .where(eq(users.id, currentUser.id));

      return NextResponse.json({
        success: true,
        message: `Unlocked Box! Received +${leeReward.toFixed(2)} $LEE tokens and +${cheelBonus.toFixed(2)} $CHEEL!`,
        rewards: {
          leeReward,
          cheelBonus,
        },
        newBalances: {
          leeBalance: newLee,
          cheelBalance: newCheel,
        },
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
