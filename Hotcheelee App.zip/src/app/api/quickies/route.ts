import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { posts, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const quickies = await db
      .select({
        post: posts,
        author: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          phone: users.phone,
          locationArea: users.locationArea,
          serviceType: users.serviceType,
          isVerifiedStar: users.isVerifiedStar,
          badge: users.badge,
        },
      })
      .from(posts)
      .leftJoin(users, eq(posts.userId, users.id))
      .where(eq(posts.isQuickie, true))
      .orderBy(desc(posts.createdAt));

    return NextResponse.json({
      quickies: quickies.map((q) => ({
        ...q.post,
        author: q.author,
        aspectRatio: "9:16",
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Upload a strictly 9:16 aspect ratio, max 60s video quickie
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (currentUser.accountType === "browsing") {
      return NextResponse.json({
        error: "Free accounts cannot post Quickies. Please upgrade to Creator or Agency mode.",
      }, { status: 403 });
    }

    if (currentUser.subscriptionStatus !== "active") {
      return NextResponse.json({
        error: "Your 30-day subscription is expired or inactive. Please pay KSh 500 via M-Pesa Till 8923411.",
      }, { status: 403 });
    }

    const body = await req.json();
    const { videoUrl, caption, durationSeconds, aspectRatio } = body;

    if (!videoUrl || !videoUrl.trim()) {
      return NextResponse.json({ error: "Quickie video URL is required" }, { status: 400 });
    }

    // STRICT VALIDATION: Max 60 seconds
    const duration = Number(durationSeconds) || 15;
    if (duration > 60) {
      return NextResponse.json({
        error: `Quickie video is ${duration}s! Maximum allowed length is strictly 60 seconds.`,
      }, { status: 400 });
    }

    // STRICT VALIDATION: Only 9:16 size allowed
    const ratio = aspectRatio || "9:16";
    if (ratio !== "9:16") {
      return NextResponse.json({
        error: `Invalid size (${ratio})! Quickies strictly require vertical 9:16 reel dimensions.`,
      }, { status: 400 });
    }

    const [newQuickie] = await db
      .insert(posts)
      .values({
        userId: currentUser.id,
        content: caption ? caption.trim() : "Watch my new 9:16 Quickie reel! 🔥",
        videoUrl: videoUrl.trim(),
        videoDuration: duration,
        aspectRatio: "9:16",
        isQuickie: true,
        mediaUrls: JSON.stringify([{ url: videoUrl.trim(), type: "video" }]),
        tags: JSON.stringify(["quickie", "vertical916", "reel"]),
      })
      .returning();

    return NextResponse.json({
      success: true,
      message: "Quickie reel published successfully! (Strict 9:16 vertical & max 60 seconds).",
      quickie: newQuickie,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
