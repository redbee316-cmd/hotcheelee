import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, follows } from "@/db/schema";
import { and, eq, ne, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const url = new URL(req.url);
    const limit = Number(url.searchParams.get("limit")) || 20;

    // Get who current user is following
    let followingIds = new Set<number>();
    if (currentUser) {
      const myFollows = await db.select({ followingId: follows.followingId }).from(follows).where(eq(follows.followerId, currentUser.id));
      myFollows.forEach((f) => followingIds.add(f.followingId));
    }

    // Algorithmic Recommendation: Match users sharing interests, locations, or high engagement
    const allUsers = await db
      .select()
      .from(users)
      .where(and(eq(users.isBanned, false), currentUser ? ne(users.id, currentUser.id) : undefined))
      .orderBy(desc(users.followersCount));

    const currentUserInterests = (() => {
      try {
        return JSON.parse(currentUser?.interests || "[]") as string[];
      } catch {
        return ["glamour", "massage", "nairobi", "companion", "amateur", "fitness"];
      }
    })();

    // Rank candidates by interest intersection + location proximity
    const candidates = allUsers
      .filter((u) => !followingIds.has(u.id))
      .map((u) => {
        let candidateInterests: string[] = [];
        try {
          candidateInterests = JSON.parse(u.interests || "[]");
        } catch {
          candidateInterests = [u.genderRole || "straight", u.locationArea || "Kilimani"];
        }

        const commonTags = candidateInterests.filter((t) =>
          currentUserInterests.some((myTag) => myTag.toLowerCase() === t.toLowerCase())
        );

        let matchScore = commonTags.length * 20;
        if (u.location === currentUser?.location) matchScore += 30;
        if (u.locationArea === currentUser?.locationArea) matchScore += 25;
        if (u.accountType === "creator") matchScore += 15;

        return {
          ...u,
          matchScore,
          matchReason: commonTags.length > 0
            ? `Matches interests in ${commonTags.slice(0, 2).join(", ")}`
            : `Trending in ${u.locationArea || u.location || "Nairobi"}`,
        };
      })
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, limit);

    return NextResponse.json({
      recommendations: candidates,
      dailyFollowsCount: currentUser?.dailyFollowsCount || 0,
      dailyLimit: 200,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
