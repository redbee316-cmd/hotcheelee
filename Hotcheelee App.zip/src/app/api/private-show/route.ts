import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { privateShows, users, notifications, auditLogs } from "@/db/schema";
import { eq, or, and, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(req.url);
    const modelId = url.searchParams.get("modelId");

    // Fetch shows involving currentUser
    const shows = await db
      .select({
        show: privateShows,
        model: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          phone: users.phone,
        },
      })
      .from(privateShows)
      .leftJoin(users, eq(privateShows.modelId, users.id))
      .where(or(eq(privateShows.clientId, currentUser.id), eq(privateShows.modelId, currentUser.id)))
      .orderBy(desc(privateShows.createdAt));

    return NextResponse.json({
      shows: shows.map((s) => ({ ...s.show, model: s.model })),
      defaultRateTokens: 30, // 30 tokens/min = KSh 300/min
      defaultMinMinutes: 5,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Book a Stripchat Private Show with per-minute rate
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized. Please log in to request a private show." }, { status: 401 });
    }

    const body = await req.json();
    const { modelId, requestedMinutes, scheduledTime, specialRequests, isSpyAllowed } = body;

    if (!modelId) {
      return NextResponse.json({ error: "modelId is required" }, { status: 400 });
    }

    const modelRes = await db.select().from(users).where(eq(users.id, Number(modelId))).limit(1);
    if (modelRes.length === 0) {
      return NextResponse.json({ error: "Model not found" }, { status: 404 });
    }

    const model = modelRes[0];
    const minutes = Math.max(5, Number(requestedMinutes) || 10); // Minimum 5 mins
    const ratePerMin = 30; // 30 tokens per minute (KSh 300/min)
    const totalTokens = minutes * ratePerMin;
    const totalKsh = totalTokens * 10;

    // Check client balance
    if (currentUser.tokensBalance < totalTokens) {
      return NextResponse.json({
        error: `Insufficient tokens for a ${minutes}-minute private show! Total cost: 🪙 ${totalTokens} Tokens (KSh ${totalKsh.toLocaleString()}). You have 🪙 ${currentUser.tokensBalance} Tokens. Please refill tokens.`,
        requiredTokens: totalTokens,
      }, { status: 400 });
    }

    // Deduct tokens from client wallet immediately
    const newClientBalance = currentUser.tokensBalance - totalTokens;
    await db
      .update(users)
      .set({ tokensBalance: newClientBalance })
      .where(eq(users.id, currentUser.id));

    // Secret room key for 1-on-1 private show
    const roomSecret = "room_" + Math.random().toString(36).substring(2, 10);

    const [newShow] = await db
      .insert(privateShows)
      .values({
        modelId: model.id,
        clientId: currentUser.id,
        pricePerMinuteTokens: ratePerMin,
        minimumMinutes: 5,
        requestedMinutes: minutes,
        totalCostTokens: totalTokens,
        totalCostKsh: totalKsh,
        status: "accepted", // Auto-approved upon payment
        scheduledTime: scheduledTime || "Right Now (Immediate Session)",
        specialRequests: specialRequests ? specialRequests.trim() : null,
        isSpyAllowed: Boolean(isSpyAllowed),
        spyPriceTokens: 10,
        roomSecret,
        startedAt: new Date(),
      })
      .returning();

    // Credit 90% of tokens to model wallet, 10% platform fee
    const modelPayoutTokens = Math.floor(totalTokens * 0.90);
    await db
      .update(users)
      .set({ tokensBalance: model.tokensBalance + modelPayoutTokens })
      .where(eq(users.id, model.id));

    // Send notifications to model & client
    await db.insert(notifications).values({
      userId: model.id,
      actorId: currentUser.id,
      type: "private_show",
      message: `🔒 PRIVATE SHOW BOOKED! ${currentUser.displayName} hired you for a ${minutes}-min Private Show (🪙 ${totalTokens} Tokens / KSh ${totalKsh.toLocaleString()}). Room Key: ${roomSecret}`,
    });

    return NextResponse.json({
      success: true,
      message: `Private show booked! 🪙 ${totalTokens} Tokens deducted (KSh ${totalKsh.toLocaleString()}). Connect with ${model.displayName} in your private room.`,
      show: newShow,
      newBalance: newClientBalance,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
