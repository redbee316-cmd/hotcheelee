import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, subscriptions, platformSettings, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { cookies } from "next/headers";

export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const {
      username,
      displayName,
      email,
      password,
      accountType, // "browsing", "creator", "agency"
      genderRole,
      agencyType,
      location,
      locationArea,
      phone,
      allowWhatsapp,
      allowCalls,
      allowSms,
      serviceType,
      servicesOffered,
      rates,
      advertMediaUrl,
      advertMediaType,
      galleryUrls,
      bio,
      avatar,
      coverImage,
      mpesaCode,
    } = body;

    if (!username || !displayName) {
      return NextResponse.json({ error: "Username and Profile Name are required" }, { status: 400 });
    }

    const cleanUsername = username.toLowerCase().trim().replace(/[^a-z0-9_]/g, "");
    if (cleanUsername.length < 3) {
      return NextResponse.json({ error: "Username must be at least 3 characters alphanumeric" }, { status: 400 });
    }

    const existing = await db.select().from(users).where(eq(users.username, cleanUsername)).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ error: "Username already taken. Please choose another." }, { status: 409 });
    }

    const type = accountType || "browsing";
    const isPaidAccount = type === "creator" || type === "agency";

    // Insert new profile
    const [newUser] = await db
      .insert(users)
      .values({
        username: cleanUsername,
        displayName: displayName.trim(),
        email: email ? email.trim().toLowerCase() : `${cleanUsername}@hotcheelee.com`,
        password: password || "hotcheelee123",
        accountType: type,
        genderRole: type === "creator" ? genderRole || "straight" : "straight",
        agencyType: type === "agency" ? agencyType || "Massage Parlour" : null,
        location: location || "Nairobi",
        locationArea: locationArea || "Kilimani",
        phone: phone || null,
        allowWhatsapp: allowWhatsapp !== undefined ? Boolean(allowWhatsapp) : true,
        allowCalls: allowCalls !== undefined ? Boolean(allowCalls) : true,
        allowSms: allowSms !== undefined ? Boolean(allowSms) : true,
        serviceType: serviceType || "Both Incall & Outcall",
        servicesOffered: servicesOffered ? (typeof servicesOffered === "string" ? servicesOffered : JSON.stringify(servicesOffered)) : JSON.stringify(["Sensual Massage", "Companionship"]),
        rates: rates ? (typeof rates === "string" ? rates : JSON.stringify(rates)) : JSON.stringify([{ duration: "1 Hour Incall", priceKsh: 4000 }, { duration: "Overnight Incall", priceKsh: 15000 }]),
        advertMediaUrl: advertMediaUrl || null,
        advertMediaType: advertMediaType || "image",
        galleryUrls: galleryUrls ? (typeof galleryUrls === "string" ? galleryUrls : JSON.stringify(galleryUrls)) : null,
        bio: bio || (type === "browsing" ? "HotCheelee browsing member" : `Welcome to ${displayName}'s official profile on HotCheelee.`),
        avatar: avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
        coverImage: coverImage || "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1600",
        subscriptionStatus: isPaidAccount ? (mpesaCode ? "pending" : "inactive") : "active",
        subscriptionPlan: type === "creator" ? "creator_500" : type === "agency" ? "agency_1500" : null,
        lastMpesaCode: mpesaCode || null,
        tokensBalance: 100,
        flamesBalance: 250,
      })
      .returning();

    // Log pending subscription if M-Pesa code was supplied
    if (isPaidAccount && mpesaCode) {
      const planAmount = type === "creator" ? 500 : 1500;
      await db.insert(subscriptions).values({
        userId: newUser.id,
        accountType: type,
        plan: type === "creator" ? "creator_500" : "agency_1500",
        amountKsh: planAmount,
        tillNumber: "8923411",
        mpesaCode: mpesaCode.trim().toUpperCase(),
        phonePaid: phone || "0700000000",
        status: "pending",
        notes: `New profile creation (${type.toUpperCase()}) for ${displayName}`,
      });
    }

    // Switch active session to this new profile
    const cookieStore = await cookies();
    cookieStore.set("hotcheelee_session", newUser.username, {
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
      httpOnly: false,
      sameSite: "lax",
    });

    return NextResponse.json({
      success: true,
      user: newUser,
      message: `Profile @${newUser.username} created successfully! You can switch between profiles anytime from the menu.`,
    }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
