import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { toyTriggers, users, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const modelId = url.searchParams.get("modelId");

    const triggers = await db
      .select({
        trigger: toyTriggers,
        sender: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          userLevel: users.userLevel,
          vipTier: users.vipTier,
        },
      })
      .from(toyTriggers)
      .leftJoin(users, eq(toyTriggers.senderId, users.id))
      .where(modelId ? eq(toyTriggers.modelId, Number(modelId)) : undefined)
      .orderBy(desc(toyTriggers.createdAt))
      .limit(15);

    return NextResponse.json({
      triggers: triggers.map((t) => ({ ...t.trigger, sender: t.sender })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Send interactive vibration to Lovense toy via token tip
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { modelId, intensity, durationSeconds, tokensTipped, message } = body;

    const tokens = Math.max(1, Number(tokensTipped) || 10);
    const toyIntensity = Math.min(20, Math.max(1, Number(intensity) || 10));
    const duration = Math.min(60, Math.max(3, Number(durationSeconds) || 10));

    if (currentUser.tokensBalance < tokens) {
      return NextResponse.json({
        error: `Insufficient tokens! You need ${tokens} tokens to trigger this vibration.`,
      }, { status: 400 });
    }

    // Deduct tokens
    const newBalance = currentUser.tokensBalance - tokens;
    const gainedXp = tokens * 15;

    await db
      .update(users)
      .set({
        tokensBalance: newBalance,
        userXp: currentUser.userXp + gainedXp,
      })
      .where(eq(users.id, currentUser.id));

    // Update performer live toy status
    await db
      .update(users)
      .set({
        interactiveToyLevel: toyIntensity,
      })
      .where(eq(users.id, Number(modelId)));

    // Record trigger
    const [record] = await db
      .insert(toyTriggers)
      .values({
        senderId: currentUser.id,
        modelId: Number(modelId),
        toyName: "Lovense Lush 3",
        intensity: toyIntensity,
        durationSeconds: duration,
        tokensTipped: tokens,
        message: message || `Vibrated Lovense toy at Level ${toyIntensity}!`,
      })
      .returning();

    // Notify model
    await db.insert(notifications).values({
      userId: Number(modelId),
      actorId: currentUser.id,
      type: "toy",
      message: `${currentUser.displayName} buzzed your Lovense toy (Level ${toyIntensity}, ${duration}s) for ${tokens} tk! 📳`,
    });

    return NextResponse.json({
      success: true,
      message: `Lovense toy vibrating at Level ${toyIntensity} for ${duration}s!`,
      newTokensBalance: newBalance,
      trigger: record,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
