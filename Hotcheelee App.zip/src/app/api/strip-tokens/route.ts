import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

// Stripchat token packages in Kenyan Shillings (KSh)
export const TOKEN_PACKAGES = [
  { tokens: 45, priceKsh: 450, popular: false, badge: "Starter" },
  { tokens: 90, priceKsh: 850, popular: false, badge: "Basic" },
  { tokens: 200, priceKsh: 1800, popular: true, badge: "Best Value" },
  { tokens: 540, priceKsh: 4500, popular: false, bonusDaysUltimate: 7, badge: "+7 Days Ultimate" },
  { tokens: 765, priceKsh: 6200, popular: false, badge: "Silver Fan" },
  { tokens: 1350, priceKsh: 10500, popular: false, badge: "Gold VIP" },
  { tokens: 2350, priceKsh: 18000, popular: false, badge: "High Roller" },
];

export async function GET() {
  const currentUser = await getCurrentUser();
  return NextResponse.json({
    packages: TOKEN_PACKAGES,
    userTokens: currentUser?.tokensBalance || 0,
    userLevel: currentUser?.userLevel || 1,
    userXp: currentUser?.userXp || 0,
    vipTier: currentUser?.vipTier || "Bronze",
    isUltimateMember: currentUser?.isUltimateMember || false,
    tillNumber: "8923411",
  });
}

// Purchase Token Package via M-Pesa or Card (in KSh)
export async function POST(req: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { tokenCount, paymentMethod, mpesaCode } = body;

    const count = Number(tokenCount);
    if (!count || count <= 0) {
      return NextResponse.json({ error: "Invalid token count" }, { status: 400 });
    }

    // Grant tokens and award XP
    const newBalance = currentUser.tokensBalance + count;
    const gainedXp = count * 5;
    const newXp = currentUser.userXp + gainedXp;
    const newLevel = Math.floor(newXp / 500) + 1;

    let newTier = currentUser.vipTier;
    if (newLevel >= 20) newTier = "Royal Master";
    else if (newLevel >= 12) newTier = "Diamond";
    else if (newLevel >= 8) newTier = "Platinum";
    else if (newLevel >= 4) newTier = "Gold";

    await db
      .update(users)
      .set({
        tokensBalance: newBalance,
        userXp: newXp,
        userLevel: newLevel,
        vipTier: newTier,
      })
      .where(eq(users.id, currentUser.id));

    return NextResponse.json({
      success: true,
      message: `Credited ${count} Tokens! Total balance: ${newBalance} Tokens. Level: ${newLevel}.`,
      newBalance,
      userLevel: newLevel,
      vipTier: newTier,
      paymentMethod: paymentMethod || "M-Pesa Till 8923411",
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
