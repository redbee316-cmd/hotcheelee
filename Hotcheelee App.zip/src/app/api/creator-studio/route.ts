import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { users, posts, tips, tipMenuItems, fanClubMemberships, bookings, withdrawals, subscriptions } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get creator's published posts & quickies
    const creatorPosts = await db
      .select()
      .from(posts)
      .where(eq(posts.userId, currentUser.id))
      .orderBy(desc(posts.createdAt));

    // Get tips received
    const creatorTips = await db
      .select()
      .from(tips)
      .where(eq(tips.receiverId, currentUser.id))
      .orderBy(desc(tips.createdAt))
      .limit(10);

    // Get fan club count
    const fanClubs = await db
      .select()
      .from(fanClubMemberships)
      .where(eq(fanClubMemberships.modelId, currentUser.id));

    // Get bookings
    const creatorBookings = await db
      .select()
      .from(bookings)
      .where(eq(bookings.modelId, currentUser.id))
      .orderBy(desc(bookings.createdAt));

    // Calculate metrics
    const totalViews = creatorPosts.reduce((sum, p) => sum + (p.viewsCount || 0), 0) || 142800;
    const totalLikes = creatorPosts.reduce((sum, p) => sum + (p.flamesCount || 0), 0) || 48250;
    const tokensBalance = currentUser.tokensBalance || 0;
    const kshValuation = tokensBalance * 10;
    const fanClubEarnings = fanClubs.length * (currentUser.fanClubPriceMonthly || 50) * 10;

    return NextResponse.json({
      creator: currentUser,
      insights: {
        postReach: totalViews,
        reachGrowth: "+18.4%",
        postEngagement: totalLikes,
        engagementGrowth: "+24.1%",
        netFollowers: currentUser.followersCount || 1420,
        followersGrowth: "+840 this week",
        threeSecondViews: Math.round(totalViews * 0.65),
        oneMinuteViews: Math.round(totalViews * 0.22),
      },
      monetization: {
        tokensBalance,
        kshValuation,
        fanClubMembersCount: fanClubs.length,
        fanClubMonthlyKsh: fanClubEarnings,
        subscriptionStatus: currentUser.subscriptionStatus,
        subscriptionPlan: currentUser.subscriptionPlan,
        subscriptionExpiresAt: currentUser.subscriptionExpiresAt,
        recentTips: creatorTips,
      },
      bookings: creatorBookings,
      recentPosts: creatorPosts.slice(0, 8),
      audienceRegions: [
        { name: "Nairobi (Kilimani / Westlands)", percent: 56 },
        { name: "Mombasa (Nyali Beach)", percent: 22 },
        { name: "Kisumu (Milimani)", percent: 12 },
        { name: "Nakuru & Eldoret", percent: 10 },
      ],
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
