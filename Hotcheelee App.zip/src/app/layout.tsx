"use client";

import "./globals.css";
import { AppProvider, useApp } from "@/context/AppContext";
import Navbar from "@/components/navigation/Navbar";
import AgeGateModal from "@/components/modals/AgeGateModal";
import TipModal from "@/components/modals/TipModal";
import WalletModal from "@/components/modals/WalletModal";
import CreatePostModal from "@/components/modals/CreatePostModal";
import StoryViewerModal from "@/components/modals/StoryViewerModal";
import TipMenuModal from "@/components/modals/TipMenuModal";
import WheelModal from "@/components/modals/WheelModal";
import ToyModal from "@/components/modals/ToyModal";
import FanClubModal from "@/components/modals/FanClubModal";
import WishlistModal from "@/components/modals/WishlistModal";
import StripTokensModal from "@/components/modals/StripTokensModal";
import AuthModal from "@/components/modals/AuthModal";
import ContactBookingModal from "@/components/modals/ContactBookingModal";
import UpgradeModal from "@/components/modals/UpgradeModal";
import CreateProfileModal from "@/components/modals/CreateProfileModal";
import CreateStoryModal from "@/components/modals/CreateStoryModal";
import CreateQuickieModal from "@/components/modals/CreateQuickieModal";
import CreateAdModal from "@/components/modals/CreateAdModal";

function GlobalModals() {
  const {
    isAuthOpen,
    closeAuthModal,
    authMode,
    contactTarget,
    closeContactModal,
    isUpgradeOpen,
    closeUpgradeModal,
    upgradeInitialMode,
    isCreateProfileOpen,
    closeCreateProfileModal,
    isCreateStoryOpen,
    closeCreateStoryModal,
    isCreateQuickieOpen,
    closeCreateQuickieModal,
    isCreateAdOpen,
    closeCreateAdModal,
  } = useApp();

  return (
    <>
      <AgeGateModal />
      <TipModal />
      <WalletModal />
      <CreatePostModal />
      <StoryViewerModal />
      <TipMenuModal />
      <WheelModal />
      <ToyModal />
      <FanClubModal />
      <WishlistModal />
      <StripTokensModal />
      <AuthModal isOpen={isAuthOpen} onClose={closeAuthModal} initialMode={authMode} />
      <ContactBookingModal target={contactTarget} onClose={closeContactModal} />
      <UpgradeModal isOpen={isUpgradeOpen} onClose={closeUpgradeModal} initialMode={upgradeInitialMode} />
      <CreateProfileModal isOpen={isCreateProfileOpen} onClose={closeCreateProfileModal} />
      <CreateStoryModal isOpen={isCreateStoryOpen} onClose={closeCreateStoryModal} />
      <CreateQuickieModal isOpen={isCreateQuickieOpen} onClose={closeCreateQuickieModal} />
      <CreateAdModal isOpen={isCreateAdOpen} onClose={closeCreateAdModal} />
    </>
  );
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <title>HotCheelee - Kenya Adult SocialFi, Stripchat Tokens & PtoP Finance (KSh)</title>
        <meta
          name="description"
          content="HotCheelee is Kenya's adult social platform. Join free to browse Straight, Gay, Trans, Shemale & Queer creators, Messenger, PtoP Finance & Predictions. M-Pesa Till: 8923411."
        />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className="bg-[#0c0e12] text-zinc-100 min-h-screen antialiased selection:bg-[#ff3358] selection:text-white overflow-x-hidden">
        <AppProvider>
          <Navbar />
          {children}
          <GlobalModals />
        </AppProvider>
      </body>
    </html>
  );
}
