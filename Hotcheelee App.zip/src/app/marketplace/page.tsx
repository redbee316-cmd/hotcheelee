"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Zap,
  ShoppingBag,
  ShieldCheck,
  Check,
  Sparkles,
  TrendingUp,
  Activity,
  Layers,
  Award,
} from "lucide-react";

export default function MarketplacePage() {
  const { currentUser, refreshUser } = useApp();
  const [marketGlasses, setMarketGlasses] = useState<any[]>([]);
  const [myGlasses, setMyGlasses] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<"market" | "my">("market");
  const [strategy, setStrategy] = useState("Mix");
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState<number | null>(null);
  const [equipping, setEquipping] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const loadGlasses = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/glasses");
      const data = await res.json();
      if (res.ok) {
        setMarketGlasses(data.marketGlasses || []);
        setMyGlasses(data.myGlasses || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGlasses();
    if (currentUser?.selectedStrategy) {
      setStrategy(currentUser.selectedStrategy);
    }
  }, [currentUser]);

  const handleBuy = async (glassesId: number, name: string) => {
    setPurchasing(glassesId);
    try {
      const res = await fetch("/api/glasses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "buy", glassesId }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(`Congratulations! You purchased ${name}. Earning multiplier updated!`);
        await refreshUser();
        await loadGlasses();
        setActiveTab("my");
      } else {
        alert(data.error || "Failed to buy glasses");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setPurchasing(null);
    }
  };

  const handleEquip = async (glassesId: number, name: string) => {
    setEquipping(glassesId);
    try {
      const res = await fetch("/api/glasses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "equip", glassesId }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(`Equipped ${name}! Your feed watch minutes have updated.`);
        await refreshUser();
        await loadGlasses();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setEquipping(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-6">
          {/* Hero Banner adapted from Cheelee.us Attention Economy */}
          <div className="relative bg-gradient-to-r from-[#1f102c] via-[#141829] to-[#121620] border border-[#3b244d] rounded-3xl p-6 sm:p-8 overflow-hidden shadow-2xl">
            <div className="relative z-10 max-w-xl">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ff3358]/20 text-[#ff3358] border border-[#ff3358]/40 text-xs font-black uppercase tracking-wider mb-3">
                <Zap className="w-3.5 h-3.5 fill-[#ff3358]" />
                Cheelee Watch-to-Earn Mechanics
              </span>
              <h1 className="text-2xl sm:text-3xl font-black text-white leading-tight mb-2">
                Digital NFT Glasses Marketplace
              </h1>
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed mb-6">
                Turn your social media scrolling into daily income. Rarity unlocks up to{" "}
                <strong className="text-amber-400">3.3x earning multipliers</strong> and more paid watching minutes for $LEE token drop boxes.
              </p>

              {/* Strategy Selectors (from cheelee.us Lucky, Mix, Stability) */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-400 font-bold">Your Strategy:</span>
                {["Lucky", "Mix", "Stability"].map((strat) => (
                  <button
                    key={strat}
                    onClick={() => setStrategy(strat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      strategy === strat
                        ? "bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white shadow-md shadow-[#ff3358]/30"
                        : "bg-[#181d28] hover:bg-[#222a3b] text-zinc-300 border border-[#2b3345]"
                    }`}
                  >
                    {strat}
                  </button>
                ))}
              </div>
            </div>

            {/* Glowing Accent background */}
            <div className="absolute -right-10 -bottom-10 w-72 h-72 rounded-full bg-gradient-to-tr from-[#ff3358]/20 to-[#7928ca]/20 blur-3xl" />
          </div>

          {notice && (
            <div className="p-4 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center justify-between">
              <span className="font-bold">{notice}</span>
              <button onClick={() => setNotice(null)} className="text-zinc-400 hover:text-white">
                ✕
              </button>
            </div>
          )}

          {/* Navigation Tabs */}
          <div className="flex items-center justify-between border-b border-[#212735] pb-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab("market")}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  activeTab === "market"
                    ? "bg-[#ff3358] text-white shadow-md"
                    : "text-zinc-400 hover:text-white hover:bg-[#141822]"
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Marketplace Inventory</span>
                <span className="text-[10px] bg-black/30 px-1.5 py-0.2 rounded-full">
                  {marketGlasses.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab("my")}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  activeTab === "my"
                    ? "bg-[#ff3358] text-white shadow-md"
                    : "text-zinc-400 hover:text-white hover:bg-[#141822]"
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>My Glasses ({myGlasses.length})</span>
              </button>
            </div>

            <div className="text-xs text-zinc-400 hidden sm:block">
              Wallet USDT: <strong className="text-white">${currentUser?.usdtBalance || "0.00"}</strong>
            </div>
          </div>

          {/* Glasses Grid */}
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((n) => (
                <div key={n} className="bg-[#13161f] border border-[#212735] rounded-2xl h-80 animate-pulse" />
              ))}
            </div>
          ) : activeTab === "market" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {marketGlasses.map((glasses) => (
                <div
                  key={glasses.id}
                  className="bg-[#13161f] border border-[#212735] hover:border-[#ff3358]/60 rounded-2xl overflow-hidden transition group flex flex-col justify-between shadow-sm"
                >
                  <div className="relative aspect-video bg-black/40 overflow-hidden flex items-center justify-center p-4">
                    <img
                      src={glasses.image}
                      alt={glasses.name}
                      className="w-full h-full object-cover rounded-xl group-hover:scale-105 transition duration-300"
                    />
                    <span className="absolute top-3 right-3 bg-black/70 backdrop-blur-md text-[10px] font-black uppercase tracking-wider text-amber-400 px-2 py-0.5 rounded-full border border-white/10">
                      {glasses.rarity}
                    </span>
                    <span className="absolute bottom-3 left-3 bg-[#ff3358] text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow">
                      {glasses.multiplier}x Boost
                    </span>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-[#ff3358] transition truncate">
                        {glasses.name}
                      </h3>
                      <div className="grid grid-cols-2 gap-2 mt-2 text-[11px] text-zinc-400">
                        <div className="bg-[#0e1118] p-2 rounded-xl">
                          <span className="block text-[10px]">Daily Watch:</span>
                          <strong className="text-white">{glasses.paidMinutesDaily} mins</strong>
                        </div>
                        <div className="bg-[#0e1118] p-2 rounded-xl">
                          <span className="block text-[10px]">Durability:</span>
                          <strong className="text-emerald-400">{glasses.durability}%</strong>
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-[#1e2330] flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-zinc-500 block">Price (KSh)</span>
                        <span className="text-base font-black text-amber-400">
                          KSh {(Number(glasses.priceUsd) * 100).toLocaleString()}
                        </span>
                        <span className="text-[10px] text-zinc-400 block">{glasses.priceLee} $LEE</span>
                      </div>

                      <button
                        disabled={purchasing === glasses.id}
                        onClick={() => handleBuy(glasses.id, glasses.name)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white text-xs font-bold transition shadow-md shadow-[#ff3358]/25 cursor-pointer disabled:opacity-50"
                      >
                        {purchasing === glasses.id ? "Buying..." : "Buy NFT"}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {myGlasses.length === 0 ? (
                <div className="col-span-full bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center text-zinc-400 text-xs">
                  You don't own any NFT glasses yet. Switch to the Marketplace Inventory to grab a pair!
                </div>
              ) : (
                myGlasses.map((glasses) => (
                  <div
                    key={glasses.id}
                    className={`bg-[#13161f] border rounded-2xl overflow-hidden transition flex flex-col justify-between shadow-sm ${
                      glasses.isEquipped ? "border-[#ff3358] ring-2 ring-[#ff3358]/30" : "border-[#212735]"
                    }`}
                  >
                    <div className="relative aspect-video bg-black/40 overflow-hidden flex items-center justify-center p-4">
                      <img
                        src={glasses.image}
                        alt={glasses.name}
                        className="w-full h-full object-cover rounded-xl"
                      />
                      {glasses.isEquipped && (
                        <span className="absolute top-3 left-3 bg-emerald-500 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow flex items-center gap-1">
                          <Check className="w-3 h-3" /> Equipped
                        </span>
                      )}
                      <span className="absolute top-3 right-3 bg-black/70 backdrop-blur-md text-[10px] font-black uppercase text-amber-400 px-2 py-0.5 rounded-full border border-white/10">
                        {glasses.rarity}
                      </span>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                      <div>
                        <h3 className="text-sm font-bold text-white truncate">{glasses.name}</h3>
                        <p className="text-xs text-zinc-400 mt-1">
                          Multiplier: <strong className="text-amber-400">{glasses.multiplier}x</strong> &bull; {glasses.paidMinutesDaily} daily minutes
                        </p>
                      </div>

                      <div className="pt-3 border-t border-[#1e2330] flex items-center justify-between">
                        <span className="text-[11px] text-zinc-500">
                          Level {glasses.level} &bull; Durability: {glasses.durability}%
                        </span>

                        <button
                          disabled={glasses.isEquipped || equipping === glasses.id}
                          onClick={() => handleEquip(glasses.id, glasses.name)}
                          className={`px-4 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                            glasses.isEquipped
                              ? "bg-[#181d28] text-zinc-500 cursor-default"
                              : "bg-[#ff3358] hover:bg-[#e11d48] text-white"
                          }`}
                        >
                          {glasses.isEquipped ? "Active" : equipping === glasses.id ? "Equipping..." : "Equip"}
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
