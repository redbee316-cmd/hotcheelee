"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { HotCheeleeLogo } from "@/components/brand/HotCheeleeLogo";
import { useApp } from "@/context/AppContext";
import {
  ShieldCheck,
  CheckCircle2,
  Coins,
  Users,
  Building2,
  Calendar,
  AlertTriangle,
  Settings,
  CreditCard,
  PhoneCall,
  Search,
  RefreshCw,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Clock,
  Layers,
  Check,
  XCircle,
} from "lucide-react";

export default function AdminPage() {
  const { currentUser, refreshUser } = useApp();
  const [activeTab, setActiveTab] = useState<
    | "dashboard"
    | "subscriptions"
    | "deposits"
    | "withdrawals"
    | "ads"
    | "users"
    | "bookings"
    | "settings"
    | "reports"
  >("dashboard");

  const [metrics, setMetrics] = useState<any>(null);
  const [subscriptionsList, setSubscriptionsList] = useState<any[]>([]);
  const [depositsList, setDepositsList] = useState<any[]>([]);
  const [withdrawalsList, setWithdrawalsList] = useState<any[]>([]);
  const [adsList, setAdsList] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [bookingsList, setBookingsList] = useState<any[]>([]);
  const [reportsList, setReportsList] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({
    tillNumber: "8923411",
    paybillNumber: "522522",
    accountName: "HOTCHEELEE",
    creatorPriceKsh: 500,
    agencyPriceKsh: 1500,
    supportPhone: "+254 700 892341",
    supportWhatsapp: "+254 700 892341",
    announcement: "HotCheelee Kenya. All Creators pay KSh 500/mo, Agencies KSh 1,500/mo via M-Pesa Buy Goods Till: 8923411.",
  });

  const [loading, setLoading] = useState(true);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const [processingId, setProcessingId] = useState<number | null>(null);
  const [receiptInput, setReceiptInput] = useState<string>("");
  const [notesInput, setNotesInput] = useState<string>("");
  const [userSearch, setUserSearch] = useState<string>("");

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [dashRes, subsRes, depRes, wRes, adsRes, usersRes, bookRes, setRes, repRes] = await Promise.all([
        fetch("/api/admin/dashboard"),
        fetch("/api/admin/subscriptions"),
        fetch("/api/admin/deposits"),
        fetch("/api/admin/withdrawals"),
        fetch("/api/admin/ads"),
        fetch("/api/admin/users"),
        fetch("/api/bookings"),
        fetch("/api/admin/settings"),
        fetch("/api/admin/reports"),
      ]);

      const dashData = await dashRes.json();
      const subsData = await subsRes.json();
      const depData = await depRes.json();
      const wData = await wRes.json();
      const adsData = await adsRes.json();
      const usersData = await usersRes.json();
      const bookData = await bookRes.json();
      const setData = await setRes.json();
      const repData = await repRes.json();

      if (dashData.metrics) setMetrics(dashData.metrics);
      if (subsData.subscriptions) setSubscriptionsList(subsData.subscriptions);
      if (depData.deposits) setDepositsList(depData.deposits);
      if (wData.withdrawals) setWithdrawalsList(wData.withdrawals);
      if (adsData.ads) setAdsList(adsData.ads);
      if (usersData.users) setUsersList(usersData.users);
      if (bookData.bookings) setBookingsList(bookData.bookings);
      if (setData.settings) setSettings(setData.settings);
      if (repData.reports) setReportsList(repData.reports);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllAdminData();
  }, []);

  // 1. Subscription Approval: Enforces exactly 30 days active
  const handleApproveSub = async (subId: number) => {
    setProcessingId(subId);
    try {
      const res = await fetch("/api/admin/subscriptions", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subscriptionId: subId,
          action: "approve",
          notes: notesInput || "M-Pesa payment confirmed by admin.",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setActionNotice("Subscription Approved! Enforced exactly 30 days active listing.");
        setNotesInput("");
        await loadAllAdminData();
      } else {
        alert(data.error || "Approval failed");
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setProcessingId(null);
    }
  };

  const handleRejectSub = async (subId: number) => {
    setProcessingId(subId);
    try {
      const res = await fetch("/api/admin/subscriptions", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subscriptionId: subId,
          action: "reject",
          notes: notesInput || "Payment code could not be verified on Till.",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setActionNotice("Subscription marked as rejected.");
        setNotesInput("");
        await loadAllAdminData();
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setProcessingId(null);
    }
  };

  // 2. Deposit Approval: Moderated manual wallet deposits
  const handleApproveDeposit = async (depositId: number) => {
    setProcessingId(depositId);
    try {
      const res = await fetch("/api/admin/deposits", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ depositId, action: "approve" }),
      });
      const data = await res.json();
      if (res.ok) {
        setActionNotice("Deposit approved and tokens credited to user wallet!");
        await loadAllAdminData();
      } else {
        alert(data.error || "Approval failed");
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setProcessingId(null);
    }
  };

  const handleRejectDeposit = async (depositId: number) => {
    setProcessingId(depositId);
    try {
      const res = await fetch("/api/admin/deposits", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ depositId, action: "reject", notes: "Code not found on Till statement" }),
      });
      if (res.ok) {
        setActionNotice("Deposit marked as rejected.");
        await loadAllAdminData();
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setProcessingId(null);
    }
  };

  // Sponsored Ads Moderation
  const handleApproveAd = async (adId: number) => {
    setProcessingId(adId);
    try {
      const res = await fetch("/api/admin/ads", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adId, action: "approve" }),
      });
      const data = await res.json();
      if (res.ok) {
        setActionNotice("Sponsored Ad approved! It is now live on infinite feeds.");
        await loadAllAdminData();
      } else {
        alert(data.error || "Approval failed");
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setProcessingId(null);
    }
  };

  const handleRejectAd = async (adId: number) => {
    setProcessingId(adId);
    try {
      const res = await fetch("/api/admin/ads", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adId, action: "reject", notes: "Campaign did not meet platform guidelines" }),
      });
      if (res.ok) {
        setActionNotice("Sponsored Ad rejected & tokens refunded to advertiser.");
        await loadAllAdminData();
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setProcessingId(null);
    }
  };

  // 3. Withdrawal Disbursement: Moderated M-Pesa payouts
  const handleProcessWithdrawal = async (withdrawalId: number, status: "Completed" | "Rejected") => {
    setProcessingId(withdrawalId);
    try {
      const res = await fetch("/api/admin/withdrawals", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          withdrawalId,
          status,
          mpesaReceipt: receiptInput || "QHR918X2AA",
          adminNotes: "Disbursed via business M-Pesa",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setActionNotice(`Withdrawal marked as ${status}!`);
        setReceiptInput("");
        await loadAllAdminData();
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setProcessingId(null);
    }
  };

  // 4. User Moderation: Ban, unban, extend
  const handleToggleUserBan = async (userId: number, currentBanned: boolean) => {
    try {
      await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, isBanned: !currentBanned }),
      });
      setActionNotice(`User account ${!currentBanned ? "Banned" : "Unbanned"}!`);
      await loadAllAdminData();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleExtend30Days = async (userId: number) => {
    try {
      await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, extendDays: 30 }),
      });
      setActionNotice("Extended subscription by 30 days!");
      await loadAllAdminData();
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        setActionNotice("Platform settings updated successfully!");
      }
    } catch (e: any) {
      alert(e.message);
    }
  };

  const navItems = [
    { id: "dashboard", label: "Dashboard & Revenue", icon: TrendingUp },
    { id: "subscriptions", label: "Subscription Approvals (30d)", icon: CheckCircle2, count: subscriptionsList.filter(s => s.status === "pending").length },
    { id: "deposits", label: "Wallet Deposits", icon: Coins, count: depositsList.filter(d => d.status === "pending").length },
    { id: "withdrawals", label: "M-Pesa Withdrawals", icon: CreditCard, count: withdrawalsList.filter(w => w.status === "Pending").length },
    { id: "ads", label: "Sponsored Ads", icon: Sparkles, count: adsList.filter(a => a.status === "pending").length },
    { id: "users", label: "Profile Check", icon: Users, count: usersList.length },
    { id: "bookings", label: "Bookings", icon: Calendar, count: bookingsList.length },
    { id: "settings", label: "Till Settings", icon: Settings },
    { id: "reports", label: "Reports", icon: AlertTriangle, count: reportsList.filter(r => r.status === "pending").length },
  ];

  return (
    <div className="min-h-screen bg-[#090b0f] text-zinc-100 py-6">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        {/* Header */}
        <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 sm:p-6 mb-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#171d2c] border-2 border-[#ff3358] flex items-center justify-center p-1.5 shadow-lg shadow-[#ff3358]/20">
              <HotCheeleeLogo size={32} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  HotCheelee Administration & Moderation
                </h1>
                <span className="bg-[#ff3358] text-white text-[10px] font-black uppercase px-2 py-0.5 rounded shadow">
                  Admin Panel
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                M-Pesa Buy Goods Till: <strong className="text-amber-400">{settings.tillNumber}</strong> &bull; Creators KSh 500/mo &bull; Agencies KSh 1,500/mo
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center">
            <button
              onClick={loadAllAdminData}
              className="p-2 rounded-xl bg-[#1a202c] hover:bg-[#252c3e] text-zinc-300 hover:text-white transition cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <Link
              href="/"
              className="py-2 px-3 rounded-xl bg-[#ff3358] hover:bg-[#e11d48] text-white text-xs font-bold transition flex items-center gap-1 shadow-sm"
            >
              <span>Back to App</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {actionNotice && (
          <div className="mb-6 p-4 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span className="font-bold">{actionNotice}</span>
            </div>
            <button onClick={() => setActionNotice(null)} className="text-zinc-400 hover:text-white">✕</button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 overflow-x-auto pb-3 mb-6 scrollbar-none border-b border-[#1f2636]">
          {navItems.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-3.5 rounded-xl text-xs font-bold whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? "bg-[#ff3358] text-white shadow-md shadow-[#ff3358]/20"
                    : "text-zinc-400 hover:text-white hover:bg-[#161a25]"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.count !== undefined && tab.count > 0 && (
                  <span className={`text-[10px] font-black px-1.5 py-0.2 rounded-full ${isActive ? "bg-black/40 text-white" : "bg-[#ff3358] text-white"}`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB 1: Dashboard & Revenue */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5">
                <span className="text-xs text-zinc-400 block mb-1">Total Platform Revenue</span>
                <div className="text-2xl font-black text-emerald-400">
                  KSh {(metrics?.totalRevenueKsh || 0).toLocaleString()}
                </div>
                <span className="text-[11px] text-zinc-500 mt-2 block">
                  Subscriptions + Manual Deposits
                </span>
              </div>

              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5">
                <span className="text-xs text-zinc-400 block mb-1">Subscription Revenue (30-day)</span>
                <div className="text-2xl font-black text-amber-400">
                  KSh {(metrics?.subscriptionRevenueKsh || 0).toLocaleString()}
                </div>
                <span className="text-[11px] text-zinc-500 mt-2 block">
                  KSh 500 (Creators) &bull; KSh 1,500 (Agencies)
                </span>
              </div>

              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5">
                <span className="text-xs text-zinc-400 block mb-1">Pending Approvals</span>
                <div className="text-2xl font-black text-[#ff3358] flex items-center gap-2">
                  <span>{subscriptionsList.filter(s => s.status === "pending").length} Subs</span>
                  <span className="text-xs text-zinc-500">|</span>
                  <span className="text-amber-400 text-base">{depositsList.filter(d => d.status === "pending").length} Deposits</span>
                </div>
                <span className="text-[11px] text-zinc-500 mt-2 block">Awaiting admin M-Pesa check</span>
              </div>

              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5">
                <span className="text-xs text-zinc-400 block mb-1">Pending Withdrawals</span>
                <div className="text-2xl font-black text-purple-400">
                  {withdrawalsList.filter(w => w.status === "Pending").length} Requests
                </div>
                <button
                  onClick={() => setActiveTab("withdrawals")}
                  className="text-[11px] text-purple-400 hover:underline font-bold mt-2 block"
                >
                  Disburse to M-Pesa &rarr;
                </button>
              </div>
            </div>

            {/* Quick Pending Subscriptions queue */}
            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Pending M-Pesa 30-Day Subscriptions (Till: {settings.tillNumber})
                </h3>
                <span className="text-xs text-zinc-400">Strictly 30-day automatic validation</span>
              </div>

              {subscriptionsList.filter(s => s.status === "pending").length === 0 ? (
                <div className="py-8 text-center text-xs text-zinc-500">
                  No pending subscription payments right now. All caught up!
                </div>
              ) : (
                <div className="divide-y divide-[#1d2332]">
                  {subscriptionsList.filter(s => s.status === "pending").map((sub) => (
                    <div key={sub.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-white text-sm">{sub.user?.displayName || "User"}</span>
                          <span className="text-[10px] bg-amber-400/20 text-amber-400 px-1.5 py-0.2 rounded font-bold uppercase">
                            {sub.accountType}
                          </span>
                          <span className="text-[11px] font-mono text-emerald-400 font-bold bg-[#141b27] px-2 py-0.5 rounded">
                            M-PESA: {sub.mpesaCode}
                          </span>
                        </div>
                        <p className="text-zinc-400 text-[11px] mt-1">
                          Phone: <strong>{sub.phonePaid}</strong> &bull; Amount: <strong className="text-white">KSh {sub.amountKsh}</strong> &bull; Plan: {sub.plan}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          disabled={processingId === sub.id}
                          onClick={() => handleApproveSub(sub.id)}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition cursor-pointer"
                        >
                          Approve 30 Days ✓
                        </button>
                        <button
                          disabled={processingId === sub.id}
                          onClick={() => handleRejectSub(sub.id)}
                          className="px-3.5 py-1.5 rounded-xl bg-[#202738] hover:bg-red-600/30 text-zinc-300 hover:text-red-400 text-xs font-bold transition cursor-pointer"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: Subscriptions Approvals */}
        {activeTab === "subscriptions" && (
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-black text-white">Manual M-Pesa Subscriptions Moderation (30-Days Rule)</h2>
            <div className="divide-y divide-[#1e2433]">
              {subscriptionsList.map((sub) => (
                <div key={sub.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-white text-sm">{sub.user?.displayName || "Member"}</span>
                      <span className="text-zinc-500">(@{sub.user?.username})</span>
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                        sub.status === "approved" ? "bg-emerald-500/20 text-emerald-400" : sub.status === "pending" ? "bg-amber-400/20 text-amber-400" : "bg-red-500/20 text-red-400"
                      }`}>
                        {sub.status}
                      </span>
                      <span className="bg-[#171d2b] text-white font-mono font-bold px-2 py-0.5 rounded">
                        {sub.mpesaCode}
                      </span>
                    </div>
                    <div className="text-zinc-400 flex flex-wrap gap-x-3 gap-y-1 text-[11px]">
                      <span>Amount: <strong className="text-amber-400">KSh {sub.amountKsh}</strong></span>
                      <span>&bull;</span>
                      <span>Paid via: <strong>{sub.phonePaid}</strong></span>
                      <span>&bull;</span>
                      <span>Account Type: <strong className="uppercase text-white">{sub.accountType}</strong></span>
                      {sub.expiresAt && (
                        <span>&bull; Expires: <strong className="text-emerald-400">{new Date(sub.expiresAt).toLocaleDateString()}</strong> (30-day limit)</span>
                      )}
                    </div>
                  </div>

                  {sub.status === "pending" ? (
                    <div className="flex items-center gap-2">
                      <button
                        disabled={processingId === sub.id}
                        onClick={() => handleApproveSub(sub.id)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                      >
                        Confirm & Activate 30 Days ✓
                      </button>
                      <button
                        disabled={processingId === sub.id}
                        onClick={() => handleRejectSub(sub.id)}
                        className="px-3.5 py-2 rounded-xl bg-[#1d2332] text-zinc-300 hover:text-red-400 text-xs font-bold"
                      >
                        Reject
                      </button>
                    </div>
                  ) : (
                    <div className="text-zinc-500 text-[11px]">
                      {sub.status === "approved" ? "Active for 30 days" : "Rejected"}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: Wallet Deposits */}
        {activeTab === "deposits" && (
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-black text-white">Manual Wallet Deposits (M-Pesa Till 8923411)</h2>
            <div className="divide-y divide-[#1e2433]">
              {depositsList.length === 0 ? (
                <div className="py-8 text-center text-xs text-zinc-500">No deposit records submitted.</div>
              ) : (
                depositsList.map((d) => (
                  <div key={d.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{d.user?.displayName || "User"}</span>
                        <span className="font-black text-emerald-400 text-sm">+KSh {d.amountKsh} (+{d.tokensCredited} Tokens)</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${d.status === "approved" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-400/20 text-amber-400"}`}>
                          {d.status}
                        </span>
                      </div>
                      <p className="text-zinc-400 mt-1">
                        Phone: {d.phonePaid} &bull; M-Pesa Code: <strong className="font-mono text-white">{d.mpesaCode}</strong> &bull; {new Date(d.createdAt).toLocaleDateString()}
                      </p>
                    </div>

                    {d.status === "pending" && (
                      <div className="flex items-center gap-2">
                        <button
                          disabled={processingId === d.id}
                          onClick={() => handleApproveDeposit(d.id)}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                        >
                          Confirm & Credit Tokens ✓
                        </button>
                        <button
                          disabled={processingId === d.id}
                          onClick={() => handleRejectDeposit(d.id)}
                          className="px-3.5 py-2 rounded-xl bg-[#1d2332] text-zinc-300 hover:text-red-400 text-xs font-bold"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 4: M-Pesa Withdrawals */}
        {activeTab === "withdrawals" && (
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-black text-white">Manual Creator M-Pesa Withdrawals</h2>
            <div className="divide-y divide-[#1e2433]">
              {withdrawalsList.length === 0 ? (
                <div className="py-8 text-center text-xs text-zinc-500">No withdrawal requests found.</div>
              ) : (
                withdrawalsList.map((w) => (
                  <div key={w.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{w.user?.displayName || "Creator"}</span>
                        <span className="font-black text-emerald-400 text-sm">
                          KSh {(w.amountKsh || Number(w.amount) * 10).toLocaleString()}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${w.status === "Completed" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-400/20 text-amber-400"}`}>
                          {w.status}
                        </span>
                      </div>
                      <p className="text-zinc-400 mt-1">
                        Send to M-Pesa: <strong className="text-white">{w.destinationAddress}</strong> &bull; Tokens Redeemed: {w.amount} tk &bull; {new Date(w.createdAt).toLocaleDateString()}
                      </p>
                      {w.mpesaReceipt && (
                        <p className="text-[11px] text-emerald-400 font-mono mt-0.5">Receipt: {w.mpesaReceipt}</p>
                      )}
                    </div>

                    {w.status === "Pending" && (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          placeholder="M-Pesa Receipt (e.g. QHR918X2AA)"
                          value={receiptInput}
                          onChange={(e) => setReceiptInput(e.target.value)}
                          className="bg-[#0e1118] border border-[#2b3345] rounded-xl px-3 py-1.5 text-xs text-white"
                        />
                        <button
                          onClick={() => handleProcessWithdrawal(w.id, "Completed")}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                        >
                          Mark Paid ✓
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB: Sponsored Ads Approvals */}
        {activeTab === "ads" && (
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-black text-white">Paid Sponsored Advertisements Moderation</h2>
            <div className="divide-y divide-[#1e2433]">
              {adsList.length === 0 ? (
                <div className="py-8 text-center text-xs text-zinc-500">No sponsored campaigns submitted yet.</div>
              ) : (
                adsList.map((ad) => (
                  <div key={ad.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div className="space-y-1 max-w-xl">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{ad.title}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ad.status === "approved" ? "bg-emerald-500/20 text-emerald-400" : ad.status === "pending" ? "bg-amber-400/20 text-amber-400" : "bg-red-500/20 text-red-400"}`}>
                          {ad.status}
                        </span>
                        <span className="text-amber-400 font-bold">🪙 {ad.budgetTokens} Tokens (KSh {ad.budgetKsh})</span>
                      </div>
                      <p className="text-zinc-300 text-xs">{ad.content}</p>
                      <p className="text-zinc-500 text-[11px]">
                        Advertiser: @{ad.advertiser?.username || "user"} &bull; CTA: {ad.ctaText} &bull; Target: {ad.targetUrl}
                      </p>
                    </div>

                    {ad.status === "pending" ? (
                      <div className="flex items-center gap-2">
                        <button
                          disabled={processingId === ad.id}
                          onClick={() => handleApproveAd(ad.id)}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                        >
                          Approve & Launch Live ✓
                        </button>
                        <button
                          disabled={processingId === ad.id}
                          onClick={() => handleRejectAd(ad.id)}
                          className="px-3.5 py-2 rounded-xl bg-[#1d2332] text-zinc-300 hover:text-red-400 text-xs font-bold"
                        >
                          Reject & Refund
                        </button>
                      </div>
                    ) : (
                      <div className="text-zinc-500 text-[11px]">
                        {ad.status === "approved" ? "Active on feed" : "Rejected"}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 5: Profile Check */}
        {activeTab === "users" && (
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h2 className="text-base font-black text-white">Users, Creators & Agencies Profile Check</h2>
              <input
                type="text"
                placeholder="Search name, phone, area..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-1.5 text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {usersList
                .filter((u) => !userSearch || u.displayName.toLowerCase().includes(userSearch.toLowerCase()) || u.username.toLowerCase().includes(userSearch.toLowerCase()))
                .map((u) => (
                  <div key={u.id} className="bg-[#0e1118] border border-[#212738] p-4 rounded-xl flex flex-col justify-between space-y-3">
                    <div className="flex items-start gap-3">
                      <img
                        src={u.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                        alt="avatar"
                        className="w-12 h-12 rounded-xl object-cover ring-1 ring-white/20"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-white text-xs truncate">{u.displayName}</span>
                          <span className="text-[10px] bg-[#ff3358] text-white px-1.5 py-0.2 rounded font-black uppercase">
                            {u.accountType}
                          </span>
                          {u.genderRole && (
                            <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.2 rounded font-bold uppercase">
                              {u.genderRole}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-0.5">
                          @{u.username} &bull; {u.locationArea || "Kenya"} &bull; Phone: <strong className="text-white">{u.phone || "None"}</strong>
                        </p>
                        <div className="flex items-center gap-2 mt-1 text-[11px]">
                          <span className={`font-bold px-2 py-0.5 rounded text-[10px] uppercase ${u.subscriptionStatus === "active" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-400/20 text-amber-400"}`}>
                            {u.subscriptionStatus}
                          </span>
                          {u.subscriptionExpiresAt && (
                            <span className="text-zinc-500">Exp: {new Date(u.subscriptionExpiresAt).toLocaleDateString()}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#1d2332] flex items-center justify-between text-xs">
                      <button
                        onClick={() => handleExtend30Days(u.id)}
                        className="text-amber-400 hover:underline font-bold text-[11px] cursor-pointer"
                      >
                        + Extend 30 Days
                      </button>
                      <div className="flex items-center gap-2">
                        <Link href={`/profile/${u.username}`} className="text-zinc-400 hover:text-white text-[11px]">
                          View
                        </Link>
                        <button
                          onClick={() => handleToggleUserBan(u.id, u.isBanned)}
                          className={`px-2 py-1 rounded text-[10px] font-bold cursor-pointer ${u.isBanned ? "bg-emerald-600 text-white" : "bg-red-600/30 text-red-400"}`}
                        >
                          {u.isBanned ? "Unban" : "Ban"}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* TAB 6: Settings */}
        {activeTab === "settings" && (
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-6 space-y-4 max-w-2xl">
            <h2 className="text-base font-black text-white">Platform Settings & M-Pesa Till</h2>
            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">Buy Goods Till Number *</label>
                  <input
                    type="text"
                    value={settings.tillNumber}
                    onChange={(e) => setSettings({ ...settings, tillNumber: e.target.value })}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">Paybill Number</label>
                  <input
                    type="text"
                    value={settings.paybillNumber}
                    onChange={(e) => setSettings({ ...settings, paybillNumber: e.target.value })}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">Creator Price (KSh) *</label>
                  <input
                    type="number"
                    value={settings.creatorPriceKsh}
                    onChange={(e) => setSettings({ ...settings, creatorPriceKsh: e.target.value })}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">Agency Price (KSh) *</label>
                  <input
                    type="number"
                    value={settings.agencyPriceKsh}
                    onChange={(e) => setSettings({ ...settings, agencyPriceKsh: e.target.value })}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="py-2.5 px-6 rounded-xl bg-[#ff3358] text-white font-bold text-xs"
              >
                Save Settings
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
