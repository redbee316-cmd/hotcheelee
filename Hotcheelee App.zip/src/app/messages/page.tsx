"use client";

import React, { useState, useEffect, useRef, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import { useApp } from "@/context/AppContext";
import {
  Send,
  Coins,
  Search,
  CheckCheck,
  Paperclip,
  Smile,
  ArrowLeft,
  Flame,
  Reply,
  Image as ImageIcon,
  Video,
  X,
  Users,
  Sparkles,
  Phone,
} from "lucide-react";

function MessengerLayout() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const urlUserId = searchParams.get("userId");
  const { currentUser, openTipModal, openTokensModal } = useApp();

  const [conversations, setConversations] = useState<any[]>([]);
  const [friendsList, setFriendsList] = useState<any[]>([]);
  const [leftTab, setLeftTab] = useState<"chats" | "friends">("chats");
  const [activePartner, setActivePartner] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [inputText, setInputText] = useState("");
  const [searchChat, setSearchChat] = useState("");
  const [replyMessage, setReplyMessage] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [tipAmount, setTipAmount] = useState<string>("");

  // Attach media state
  const [showAttachModal, setShowAttachModal] = useState(false);
  const [attachedUrl, setAttachedUrl] = useState("");
  const [attachedType, setAttachedType] = useState<"image" | "video">("image");
  const [showEmojiBar, setShowEmojiBar] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickEmojis = ["😀", "🔥", "💋", "💖", "🌶️", "💎", "🥂", "🍑", "👑", "⚡", "😉", "😍", "🎉", "🌹"];

  const sampleMediaPresets = [
    { label: "Penthouse Suite", url: "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg", type: "image" as const },
    { label: "Sensual Lingerie", url: "https://images.pexels.com/photos/33282388/pexels-photo-33282388.jpeg", type: "image" as const },
    { label: "Dance Clip (10s)", url: "https://videos.pexels.com/video-files/7845993/7845993-hd_1080_1920_30fps.mp4", type: "video" as const },
  ];

  const loadData = async () => {
    try {
      const [msgRes, frRes, stRes] = await Promise.all([
        fetch("/api/messages"),
        fetch("/api/friends"),
        fetch("/api/stars?type=creators"),
      ]);

      const msgData = await msgRes.json();
      const frData = await frRes.json();
      const stData = await stRes.json();

      if (msgData.conversations) {
        setConversations(msgData.conversations);
        if (!activePartner && msgData.conversations.length > 0 && !urlUserId) {
          setActivePartner(msgData.conversations[0].user);
        }
      }

      // Friends list for Left icon tab
      const allFriends = [
        ...(frData.peopleYouMayKnow || []),
        ...(stData.stars || []).slice(0, 8),
      ];
      setFriendsList(allFriends);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const loadThread = async (userId: number) => {
    try {
      const res = await fetch(`/api/messages?withUserId=${userId}`);
      const data = await res.json();
      if (data.messages) {
        setMessages(data.messages);
      }
      if (data.otherUser) {
        setActivePartner(data.otherUser);
      }
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (urlUserId) {
      loadThread(Number(urlUserId));
    } else if (activePartner) {
      loadThread(activePartner.id);
    }
  }, [urlUserId, activePartner?.id]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!inputText.trim() && !attachedUrl && !tipAmount) || !activePartner) return;

    const text = inputText.trim();
    const tokenTip = Number(tipAmount) || 0;
    const media = attachedUrl.trim() || null;
    const mType = media ? attachedType : null;

    setInputText("");
    setAttachedUrl("");
    setTipAmount("");
    setReplyMessage(null);
    setShowAttachModal(false);
    setShowEmojiBar(false);

    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          receiverId: activePartner.id,
          content: text || (media ? "Sent media attachment" : `Sent ${tokenTip} Tokens 🪙`),
          mediaUrl: media,
          mediaType: mType,
          tokensTipped: tokenTip,
          replyToMessageId: replyMessage?.id || null,
        }),
      });

      const data = await res.json();
      if (res.ok && data.message) {
        setMessages((prev) => [...prev, data.message]);
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
        loadData();
      } else {
        alert(data.error || "Failed to send message");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredConversations = conversations.filter((c) =>
    c.user.displayName.toLowerCase().includes(searchChat.toLowerCase()) ||
    c.user.username.toLowerCase().includes(searchChat.toLowerCase())
  );

  return (
    <main className="flex-1 max-w-5xl mx-auto w-full min-w-0">
      {/* Messenger Cloned Chat Shell */}
      <div className="bg-[#0f141c] border border-[#232b3b] rounded-2xl overflow-hidden shadow-2xl h-[84vh] flex">
        {/* Left Column: Dialogs & Friends List */}
        <div
          className={`w-full sm:w-80 border-r border-[#1b2230] flex flex-col bg-[#111622] ${
            activePartner ? "hidden sm:flex" : "flex"
          }`}
        >
          {/* Header with Return Back Arrow */}
          <div className="p-3 bg-[#171e2e] border-b border-[#212a3d] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link
                href="/"
                className="p-1.5 rounded-lg bg-[#212b3d] hover:bg-[#ff3358] text-white transition flex items-center justify-center cursor-pointer"
                title="Return to Feed"
              >
                <ArrowLeft className="w-4 h-4" />
              </Link>
              <div>
                <h3 className="text-xs font-black text-white uppercase tracking-wider">
                  Messenger
                </h3>
                <span className="text-[10px] text-emerald-400 font-semibold">Active & Encrypted</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold bg-[#1d2538] px-2.5 py-1 rounded-full">
              <Coins className="w-3.5 h-3.5" />
              <span>{currentUser?.tokensBalance ?? 0} tk</span>
            </div>
          </div>

          {/* Left Tabs: Chats vs All Friends */}
          <div className="grid grid-cols-2 p-1 bg-[#141b27] border-b border-[#1f293d] text-xs font-bold text-center">
            <button
              onClick={() => setLeftTab("chats")}
              className={`py-1.5 rounded-lg transition ${
                leftTab === "chats" ? "bg-[#2a7be4] text-white shadow" : "text-zinc-400 hover:text-white"
              }`}
            >
              Chats ({conversations.length})
            </button>
            <button
              onClick={() => setLeftTab("friends")}
              className={`py-1.5 rounded-lg transition flex items-center justify-center gap-1.5 ${
                leftTab === "friends" ? "bg-[#2a7be4] text-white shadow" : "text-zinc-400 hover:text-white"
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>All Friends ({friendsList.length})</span>
            </button>
          </div>

          {/* Search Bar */}
          <div className="p-2.5 bg-[#111622] border-b border-[#1b2230]">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder={leftTab === "chats" ? "Search chats..." : "Search friends..."}
                value={searchChat}
                onChange={(e) => setSearchChat(e.target.value)}
                className="w-full bg-[#171f2f] border border-[#243046] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#2a7be4]"
              />
            </div>
          </div>

          {/* Dialogs or Friends List */}
          <div className="flex-1 overflow-y-auto divide-y divide-[#182030] scrollbar-none">
            {loading ? (
              <div className="p-4 text-center text-xs text-zinc-500">Loading Messenger...</div>
            ) : leftTab === "chats" ? (
              filteredConversations.length === 0 ? (
                <div className="p-8 text-center text-xs text-zinc-500">
                  No chat history yet. Switch to "All Friends" tab to start chatting!
                </div>
              ) : (
                filteredConversations.map((conv) => {
                  const isSelected = activePartner?.id === conv.user.id;
                  return (
                    <div
                      key={conv.user.id}
                      onClick={() => setActivePartner(conv.user)}
                      className={`p-3 flex items-center gap-3 cursor-pointer transition ${
                        isSelected ? "bg-[#1f293d] border-l-3 border-[#2a7be4]" : "hover:bg-[#151c2a]"
                      }`}
                    >
                      <div className="relative shrink-0">
                        <img
                          src={conv.user.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                          alt={conv.user.displayName}
                          className="w-11 h-11 rounded-full object-cover ring-1 ring-white/10"
                        />
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-[#111622]" />
                      </div>

                      <div className="truncate flex-1">
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="text-xs font-bold text-white truncate flex items-center gap-1">
                            {conv.user.displayName}
                            {conv.user.isVerifiedStar && <span className="text-[#2a7be4]">✓</span>}
                          </span>
                          {conv.lastMessage && (
                            <span className="text-[10px] text-zinc-500">
                              {new Date(conv.lastMessage.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-zinc-400 truncate">
                          {conv.lastMessage?.content || "Tap to chat"}
                        </p>
                      </div>
                    </div>
                  );
                })
              )
            ) : (
              /* All Friends View on Left Tab */
              friendsList.map((friend) => (
                <div
                  key={friend.id}
                  onClick={() => {
                    setActivePartner(friend);
                    setLeftTab("chats");
                  }}
                  className="p-3 flex items-center justify-between hover:bg-[#161d2b] cursor-pointer transition"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={friend.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                      alt={friend.displayName}
                      className="w-10 h-10 rounded-full object-cover ring-1 ring-white/10 shrink-0"
                    />
                    <div className="truncate">
                      <span className="text-xs font-bold text-white truncate block">{friend.displayName}</span>
                      <span className="text-[10px] text-zinc-400">{friend.locationArea || "Kenya"} &bull; @{friend.username}</span>
                    </div>
                  </div>

                  <span className="text-[10px] bg-[#2a7be4]/20 text-[#2a7be4] font-bold px-2 py-0.5 rounded-full">
                    Chat &rarr;
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Active Messenger Chat Window */}
        <div className={`flex-1 flex flex-col bg-[#0b0e14] ${!activePartner ? "hidden sm:flex" : "flex"}`}>
          {activePartner ? (
            <>
              {/* Messenger Header with Back Arrow on Mobile & Desktop */}
              <div className="p-3 px-4 bg-[#141b27] border-b border-[#212b3d] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setActivePartner(null)}
                    className="p-1.5 rounded-lg bg-[#1f293d] hover:bg-[#ff3358] text-white transition flex items-center justify-center cursor-pointer"
                    title="Back to conversation list"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                  <img
                    src={activePartner.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                    alt={activePartner.displayName}
                    className="w-10 h-10 rounded-full object-cover ring-2 ring-[#2a7be4]"
                  />
                  <div>
                    <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                      {activePartner.displayName}
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.2 rounded">
                        Online
                      </span>
                    </h3>
                    <span className="text-[10px] text-zinc-400">
                      @{activePartner.username} &bull; {activePartner.locationArea || "Kilimani"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      openTipModal({
                        id: activePartner.id,
                        username: activePartner.username,
                        displayName: activePartner.displayName,
                        avatar: activePartner.avatar,
                      })
                    }
                    className="px-3 py-1.5 rounded-full bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold flex items-center gap-1 shadow-sm cursor-pointer"
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>Tip Tokens</span>
                  </button>
                </div>
              </div>

              {/* Chat Message Stream */}
              <div
                className="flex-1 overflow-y-auto p-4 space-y-2.5"
                style={{
                  backgroundImage: "radial-gradient(#1c2638 1px, transparent 1px)",
                  backgroundSize: "20px 20px",
                }}
              >
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-zinc-500 text-xs">
                    <div className="w-14 h-14 rounded-full bg-[#151d2a] flex items-center justify-center text-2xl mb-2">
                      💬
                    </div>
                    <p className="font-bold text-zinc-300">Start Messaging with {activePartner.displayName}</p>
                    <p className="text-[11px] text-zinc-400 max-w-xs mt-1">
                      Send photos, videos, emojis, or tip tokens directly in the chat.
                    </p>
                  </div>
                ) : (
                  messages.map((m) => {
                    const isFromMe = currentUser && m.senderId === currentUser.id;
                    return (
                      <div
                        key={m.id}
                        className={`flex ${isFromMe ? "justify-end" : "justify-start"} group`}
                      >
                        <div
                          className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed shadow-sm relative ${
                            isFromMe
                              ? "bg-[#2b5278] text-white rounded-br-xs"
                              : "bg-[#182533] text-zinc-100 border border-[#223347] rounded-bl-xs"
                          }`}
                        >
                          {m.tokensTipped > 0 && (
                            <div className="mb-1.5 flex items-center gap-1 bg-amber-400/20 text-amber-300 font-black px-2 py-0.5 rounded-lg text-[10px]">
                              <Coins className="w-3 h-3" />
                              <span>+{m.tokensTipped} Tokens Tipped!</span>
                            </div>
                          )}

                          {/* Media attachments */}
                          {m.mediaUrl && (
                            <div className="my-1.5 rounded-xl overflow-hidden max-h-56 bg-black">
                              {m.mediaType === "video" ? (
                                <video src={m.mediaUrl} controls className="w-full max-h-56 object-cover" />
                              ) : (
                                <img src={m.mediaUrl} alt="Attached" className="w-full max-h-56 object-cover" />
                              )}
                            </div>
                          )}

                          <p className="whitespace-pre-wrap">{m.content}</p>

                          <div className="flex items-center justify-end gap-1 text-[9px] mt-1 opacity-70">
                            <span>
                              {new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                            {isFromMe && <CheckCheck className="w-3 h-3 text-sky-300" />}
                          </div>

                          <button
                            onClick={() => setReplyMessage(m)}
                            className="absolute -top-2 -right-2 bg-[#121924] text-zinc-400 hover:text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition shadow"
                            title="Reply"
                          >
                            <Reply className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Reply Banner */}
              {replyMessage && (
                <div className="bg-[#141b27] border-t border-[#232f44] px-4 py-2 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 truncate">
                    <Reply className="w-3.5 h-3.5 text-[#2a7be4]" />
                    <span className="text-zinc-400">Replying to:</span>
                    <span className="text-zinc-200 truncate italic max-w-xs">"{replyMessage.content}"</span>
                  </div>
                  <button onClick={() => setReplyMessage(null)} className="text-zinc-400 hover:text-white">
                    ✕
                  </button>
                </div>
              )}

              {/* Emoji Quick Picker Toolbar */}
              {showEmojiBar && (
                <div className="bg-[#121926] border-t border-[#212f45] px-3 py-1.5 flex items-center gap-2 overflow-x-auto scrollbar-none animate-in slide-in-from-bottom duration-150">
                  {quickEmojis.map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setInputText((prev) => prev + emoji)}
                      className="text-base p-1 hover:scale-125 transition cursor-pointer"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}

              {/* Attachment Preview Banner if selected */}
              {attachedUrl && (
                <div className="bg-[#141d2b] border-t border-[#25364f] p-2 px-4 flex items-center justify-between text-xs text-amber-300">
                  <div className="flex items-center gap-2 truncate">
                    {attachedType === "video" ? <Video className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
                    <span className="truncate">Attached {attachedType}: {attachedUrl}</span>
                  </div>
                  <button onClick={() => setAttachedUrl("")} className="text-zinc-400 hover:text-white">✕</button>
                </div>
              )}

              {/* Input Bar */}
              <form onSubmit={handleSendMessage} className="p-2.5 bg-[#141b27] border-t border-[#212b3d] flex items-center gap-2">
                {/* Paperclip Button for Media */}
                <button
                  type="button"
                  onClick={() => setShowAttachModal(true)}
                  className="p-2 text-zinc-400 hover:text-white hover:bg-[#1c2536] rounded-full transition cursor-pointer"
                  title="Attach Photo or Video"
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                {/* Emoji Bar Toggle */}
                <button
                  type="button"
                  onClick={() => setShowEmojiBar(!showEmojiBar)}
                  className="p-2 text-zinc-400 hover:text-amber-400 hover:bg-[#1c2536] rounded-full transition cursor-pointer"
                  title="Insert Emojis"
                >
                  <Smile className="w-4 h-4" />
                </button>

                {/* Token Tip Input Pill */}
                <div className="flex items-center gap-1 bg-[#1a2233] px-2 py-1 rounded-xl border border-[#27344a]">
                  <Coins className="w-3 h-3 text-amber-400" />
                  <input
                    type="number"
                    placeholder="Tip tk"
                    value={tipAmount}
                    onChange={(e) => setTipAmount(e.target.value)}
                    className="w-14 bg-transparent text-xs text-amber-400 placeholder-zinc-500 focus:outline-none"
                  />
                </div>

                <input
                  type="text"
                  placeholder={`Write a message to @${activePartner.username}...`}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="flex-1 bg-[#1a2333] border border-[#243147] rounded-full px-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#2a7be4]"
                />

                <button
                  type="submit"
                  disabled={!inputText.trim() && !attachedUrl && !tipAmount}
                  className="p-2.5 rounded-full bg-[#2a7be4] hover:bg-[#2069cb] disabled:opacity-40 text-white transition cursor-pointer shadow"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center text-zinc-500 text-xs">
              <span className="text-3xl mb-2">💬</span>
              <p className="font-bold text-zinc-300">Select a Chat or Friend to Start Messaging</p>
              <p className="text-[11px] text-zinc-500">Pick from left sidebar or start a conversation from a creator profile</p>
            </div>
          )}
        </div>
      </div>

      {/* Attach Media Modal */}
      {showAttachModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="relative max-w-md w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-5 shadow-2xl space-y-3">
            <button
              onClick={() => setShowAttachModal(false)}
              className="absolute top-4 right-4 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Paperclip className="w-4 h-4 text-[#2a7be4]" />
              Attach Photo or Video to Chat
            </h3>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setAttachedType("image")}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition ${
                  attachedType === "image" ? "bg-[#2a7be4] text-white" : "bg-[#182030] text-zinc-400"
                }`}
              >
                Photo
              </button>
              <button
                type="button"
                onClick={() => setAttachedType("video")}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition ${
                  attachedType === "video" ? "bg-[#2a7be4] text-white" : "bg-[#182030] text-zinc-400"
                }`}
              >
                Video
              </button>
            </div>

            <input
              type="url"
              placeholder={attachedType === "video" ? "https://videos.pexels.com/...mp4" : "https://images.pexels.com/...jpg"}
              value={attachedUrl}
              onChange={(e) => setAttachedUrl(e.target.value)}
              className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
            />

            <div>
              <span className="text-[10px] text-zinc-400 block mb-1">Stock presets:</span>
              <div className="grid grid-cols-3 gap-1.5">
                {sampleMediaPresets.map((p) => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => {
                      setAttachedUrl(p.url);
                      setAttachedType(p.type);
                    }}
                    className="p-1 rounded bg-[#0e1118] border border-[#222838] text-[10px] text-zinc-300 truncate text-left"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setShowAttachModal(false)}
              className="w-full py-2 rounded-xl bg-[#2a7be4] text-white text-xs font-bold mt-2"
            >
              Attach to Message
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

export default function MessagesPage() {
  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />
        <Suspense fallback={<div className="flex-1 p-8 text-center text-zinc-500 text-xs">Loading Messenger...</div>}>
          <MessengerLayout />
        </Suspense>
      </div>
    </div>
  );
}
