"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Bell,
  CheckCircle2,
  Check,
  Trash2,
  Coins,
  Flame,
  Calendar,
  Users,
  CreditCard,
  ShieldAlert,
  ArrowRight,
  Filter,
  Sparkles,
} from "lucide-react";

export default function NotificationsPage() {
  const { currentUser, refreshUser } = useApp();
  const [filter, setFilter] = useState("all");
  const [notificationsList, setNotificationsList] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const categories = [
    { id: "all", label: "All" },
    { id: "unread", label: "Unread" },
    { id: "tips", label: "Tips & Gifts", icon: Coins },
    { id: "bookings", label: "Bookings", icon: Calendar },
    { id: "friends", label: "Friends & Follows", icon: Users },
    { id: "subscriptions", label: "Subscriptions", icon: CreditCard },
  ];

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/notifications?filter=${filter}`);
      const data = await res.json();
      if (data.notifications) {
        setNotificationsList(data.notifications);
        setUnreadCount(data.unreadCount || 0);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadNotifications();
  }, [filter]);

  const handleMarkAllRead = async () => {
    try {
      await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      loadNotifications();
      refreshUser();
    } catch (e) {
      console.error(e);
    }
  };

  const handleMarkOneRead = async (id: number) => {
    try {
      await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notificationId: id }),
      });
      setNotificationsList((prev) =>
        prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
      );
      setUnreadCount((c) => Math.max(0, c - 1));
      refreshUser();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await fetch(`/api/notifications?id=${id}`, { method: "DELETE" });
      setNotificationsList((prev) => prev.filter((n) => n.id !== id));
    } catch (e) {
      console.error(e);
    }
  };

  const getIconForType = (type: string) => {
    if (type.includes("tip") || type.includes("gift")) return <Coins className="w-4 h-4 text-amber-400" />;
    if (type.includes("flame")) return <Flame className="w-4 h-4 text-[#ff3358]" />;
    if (type.includes("booking")) return <Calendar className="w-4 h-4 text-emerald-400" />;
    if (type.includes("sub")) return <CreditCard className="w-4 h-4 text-purple-400" />;
    if (type.includes("friend") || type.includes("follow")) return <Users className="w-4 h-4 text-sky-400" />;
    return <Bell className="w-4 h-4 text-zinc-400" />;
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-3xl mx-auto w-full min-w-0 space-y-4">
          {/* Header (Facebook Clone Notifications Hub) */}
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-[#ff3358]" />
                <h1 className="text-xl font-black text-white">HotCheelee Notifications</h1>
                {unreadCount > 0 && (
                  <span className="bg-[#ff3358] text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                    {unreadCount} New
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Real-time activity on your posts, tip menus, bookings, friend requests & M-Pesa subscriptions
              </p>
            </div>

            <button
              onClick={handleMarkAllRead}
              className="py-1.5 px-3 rounded-xl bg-[#1a2233] hover:bg-[#25324d] text-zinc-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
            >
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Mark all as read</span>
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setFilter(c.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  filter === c.id
                    ? "bg-[#ff3358] text-white shadow-sm"
                    : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                }`}
              >
                {c.icon && <c.icon className="w-3.5 h-3.5" />}
                <span>{c.label}</span>
              </button>
            ))}
          </div>

          {/* Notifications List */}
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl overflow-hidden shadow-sm">
            {loading ? (
              <div className="p-8 text-center text-xs text-zinc-500">Loading notifications...</div>
            ) : notificationsList.length === 0 ? (
              <div className="py-12 text-center text-xs text-zinc-500 space-y-2">
                <Bell className="w-8 h-8 mx-auto text-zinc-600" />
                <p className="font-bold text-zinc-300">No notifications in this category</p>
                <p className="text-[11px]">When people tip you, book appointments, or send friend requests, they will show here!</p>
              </div>
            ) : (
              <div className="divide-y divide-[#1d2332]">
                {notificationsList.map((n) => (
                  <div
                    key={n.id}
                    onClick={() => !n.isRead && handleMarkOneRead(n.id)}
                    className={`p-4 flex items-start gap-3.5 transition group cursor-pointer ${
                      !n.isRead ? "bg-[#181f2d] hover:bg-[#1d2638]" : "hover:bg-[#151a24]"
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img
                        src={n.actor?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                        alt="avatar"
                        className="w-11 h-11 rounded-full object-cover ring-2 ring-white/10"
                      />
                      <span className="absolute -bottom-1 -right-1 p-1 rounded-full bg-[#121622] shadow">
                        {getIconForType(n.type)}
                      </span>
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className={`text-xs leading-relaxed ${!n.isRead ? "text-white font-semibold" : "text-zinc-300"}`}>
                        {n.message}
                      </p>

                      <div className="flex items-center gap-2 text-[10px] text-zinc-500 mt-1">
                        <span>{new Date(n.createdAt).toLocaleDateString()} at {new Date(n.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                        {!n.isRead && (
                          <span className="w-2 h-2 rounded-full bg-[#ff3358]" />
                        )}
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(n.id);
                      }}
                      className="p-1.5 text-zinc-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition rounded-lg hover:bg-black/20"
                      title="Remove notification"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>

        <RightSidebar />
      </div>
    </div>
  );
}
