"use client";

import React, { useState, useEffect, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import PostCard from "@/components/feed/PostCard";
import EditPhotoModal from "@/components/modals/EditPhotoModal";
import EditProfileModal from "@/components/modals/EditProfileModal";
import { useApp } from "@/context/AppContext";
import {
  Flame,
  UserPlus,
  Check,
  MessageSquare,
  ExternalLink,
  Grid,
  Sparkles,
  Edit3,
  Coins,
  Crown,
  Gift,
  Zap,
  Target,
  Camera,
  MoreHorizontal,
  Plus,
  Eye,
  Search,
  Archive,
  SlidersHorizontal,
  Bookmark,
  Users,
  Film,
  Building2,
  Phone,
  Info,
  Calendar,
} from "lucide-react";

export default function ProfilePage() {
  const params = useParams();
  const router = useRouter();
  const username = params.username as string;
  const {
    openTipModal,
    openTipMenuModal,
    openWheelModal,
    openToyModal,
    openFanClubModal,
    openWishlistModal,
    openContactModal,
    openCreateStoryModal,
    openCreateAdModal,
    currentUser,
    refreshUser,
  } = useApp();

  const [profileUser, setProfileUser] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  // Facebook Profile Tabs: All, About, Photos, Friends, Quickie, More
  const [activeTab, setActiveTab] = useState<
    "all" | "about" | "photos" | "friends" | "quickies" | "tip-menu" | "wishlist"
  >("all");
  const [loading, setLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);

  // Performer stripchat data
  const [tipMenu, setTipMenu] = useState<any[]>([]);
  const [wishlist, setWishlist] = useState<any[]>([]);
  const [goal, setGoal] = useState<any>(null);
  const [goalAmount, setGoalAmount] = useState<string>("25");

  // 3-Dots Dropdown menu state (Facebook profile 3-dots: advertise, add to story, view as, add action button, search, profile status, archive)
  const [showThreeDots, setShowThreeDots] = useState(false);
  const threeDotsRef = useRef<HTMLDivElement>(null);

  // Photo & Profile edit modals
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [showCoverModal, setShowCoverModal] = useState(false);

  // View as Mode (Facebook "View As" Public Preview)
  const [viewAsGuest, setViewAsGuest] = useState(false);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (threeDotsRef.current && !threeDotsRef.current.contains(e.target as Node)) {
        setShowThreeDots(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const loadProfile = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/users/${username}`);
      const data = await res.json();
      if (data.user) {
        setProfileUser(data.user);
        setIsFollowing(data.user.isFollowing);
        setFollowersCount(data.user.followersCount);
        setPosts(data.posts || []);

        fetch(`/api/tip-menu?modelId=${data.user.id}`).then((r) => r.json()).then((d) => setTipMenu(d.items || []));
        fetch(`/api/wishlist?modelId=${data.user.id}`).then((r) => r.json()).then((d) => setWishlist(d.items || []));
        fetch(`/api/goal?modelId=${data.user.id}`).then((r) => r.json()).then(setGoal);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, [username]);

  const handleToggleFollow = async () => {
    const prevFollowing = isFollowing;
    const prevCount = followersCount;
    setIsFollowing(!isFollowing);
    setFollowersCount(isFollowing ? Math.max(0, followersCount - 1) : followersCount + 1);

    try {
      const res = await fetch(`/api/users/${username}/follow`, { method: "POST" });
      if (!res.ok) {
        setIsFollowing(prevFollowing);
        setFollowersCount(prevCount);
      }
    } catch {
      setIsFollowing(prevFollowing);
      setFollowersCount(prevCount);
    }
  };

  const handleContributeGoal = async () => {
    if (!profileUser) return;
    const amt = Number(goalAmount);
    if (!amt || amt <= 0) return;

    try {
      const res = await fetch("/api/goal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ modelId: profileUser.id, amount: amt }),
      });
      const data = await res.json();
      if (res.ok) {
        alert(data.message);
        await refreshUser();
        fetch(`/api/goal?modelId=${profileUser.id}`).then((r) => r.json()).then(setGoal);
      } else {
        alert(data.error || "Goal contribution failed");
      }
    } catch (e: any) {
      alert(e.message);
    }
  };

  // Profile update save callback with full backend
  const handleSaveProfileData = async (updatedData: any) => {
    const res = await fetch(`/api/users/${username}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedData),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Failed to update profile");
    setProfileUser(data.user);
    refreshUser();
  };

  const handleUpdateAvatar = async (newUrl: string) => {
    await handleSaveProfileData({ avatar: newUrl });
  };

  const handleUpdateCover = async (newUrl: string) => {
    await handleSaveProfileData({ coverImage: newUrl });
  };

  if (!profileUser && !loading) {
    return (
      <div className="min-h-screen bg-[#0c0e12] py-12 text-center text-white">
        <h2 className="text-xl font-bold">Profile not found</h2>
      </div>
    );
  }

  const isOwner = currentUser && profileUser && currentUser.id === profileUser.id && !viewAsGuest;
  const mediaPosts = posts.filter((p) => (p.media && p.media.length > 0) || p.videoUrl);
  const quickiePosts = posts.filter((p) => p.isQuickie || p.videoUrl);

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-3xl mx-auto w-full min-w-0 space-y-4">
          {/* View As Guest banner notice if active */}
          {viewAsGuest && (
            <div className="bg-[#181d28] border border-[#ff3358]/50 p-2.5 px-4 rounded-xl flex items-center justify-between text-xs text-white">
              <span className="flex items-center gap-1.5 font-bold">
                <Eye className="w-4 h-4 text-[#ff3358]" />
                You are currently viewing this profile as a public visitor.
              </span>
              <button
                onClick={() => setViewAsGuest(false)}
                className="px-3 py-1 rounded-lg bg-[#ff3358] text-white font-bold"
              >
                Exit "View As"
              </button>
            </div>
          )}

          {/* Facebook-Cloned Profile Shell */}
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl overflow-hidden shadow-sm">
            {/* 1. Cover Photo with Facebook Edit Cover Photo Button */}
            <div className="relative h-48 sm:h-64 bg-zinc-800 group">
              <img
                src={profileUser?.coverImage || "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg"}
                alt="Cover"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#13161f] via-black/25 to-transparent" />

              {/* Edit Cover Photo button (Facebook Clone) */}
              {isOwner && (
                <button
                  onClick={() => setShowCoverModal(true)}
                  className="absolute bottom-3 right-3 py-1.5 px-3 rounded-xl bg-black/75 hover:bg-black text-white text-xs font-bold transition flex items-center gap-1.5 shadow-lg border border-white/20 cursor-pointer"
                >
                  <Camera className="w-4 h-4 text-amber-400" />
                  <span>Edit Cover Photo</span>
                </button>
              )}
            </div>

            {/* 2. Avatar & Profile Info Bar */}
            <div className="p-4 sm:p-6 relative -mt-16 sm:-mt-20">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-4">
                {/* Profile Photo with See Profile Picture & Choose Profile Picture Buttons */}
                <div className="relative group self-start sm:self-auto">
                  <img
                    src={profileUser?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                    alt={profileUser?.displayName}
                    className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover ring-4 ring-[#13161f] border-2 border-[#ff3358] shadow-2xl bg-black"
                  />

                  {profileUser?.isVerifiedStar && (
                    <span className="absolute bottom-1 right-1 bg-[#ff3358] p-1.5 rounded-full ring-2 ring-[#13161f] text-white">
                      <Flame className="w-4 h-4 fill-white" />
                    </span>
                  )}

                  {/* See Profile Picture or Choose Profile Picture Trigger */}
                  <button
                    onClick={() => setShowAvatarModal(true)}
                    className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center text-white text-[11px] font-bold cursor-pointer backdrop-blur-xs"
                    title="See or Choose Profile Picture"
                  >
                    <Camera className="w-5 h-5 mb-0.5" />
                    <span>{isOwner ? "Edit Avatar" : "See Photo"}</span>
                  </button>
                </div>

                {/* Profile Actions: Edit Profile, Stripchat buttons, Follow, and 3-Dots */}
                <div className="flex items-center gap-2 flex-wrap self-start sm:self-end">
                  {isOwner ? (
                    <>
                      {/* Facebook Edit Profile button */}
                      <button
                        onClick={() => setShowEditProfileModal(true)}
                        className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#1c2334] hover:bg-[#25324d] border border-[#2e3b52] transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                        <span>Edit Profile</span>
                      </button>

                      <button
                        onClick={openCreateStoryModal}
                        className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] shadow-md transition flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add to Story</span>
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => openContactModal(profileUser)}
                        className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md flex items-center gap-1.5 cursor-pointer"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Reveal Contact</span>
                      </button>

                      <button
                        onClick={() => openFanClubModal(profileUser.id, profileUser.displayName)}
                        className="px-3 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] shadow-md flex items-center gap-1.5 cursor-pointer"
                      >
                        <Crown className="w-3.5 h-3.5" />
                        <span>Fan Club</span>
                      </button>

                      <button
                        onClick={() => router.push(`/messages?userId=${profileUser.id}`)}
                        className="p-2 rounded-xl bg-[#1c2230] hover:bg-[#252c3e] text-zinc-300 hover:text-white transition cursor-pointer"
                        title="Send Message"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>

                      <button
                        onClick={handleToggleFollow}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                          isFollowing
                            ? "bg-[#1c2230] text-zinc-300 hover:bg-[#252c3e]"
                            : "bg-[#ff3358] hover:bg-[#e11d48] text-white shadow-md shadow-[#ff3358]/20"
                        }`}
                      >
                        {isFollowing ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Following</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3.5 h-3.5" />
                            <span>Follow</span>
                          </>
                        )}
                      </button>
                    </>
                  )}

                  {/* FACEBOOK 3-DOTS BUTTON & DROPDOWN MENU */}
                  <div className="relative" ref={threeDotsRef}>
                    <button
                      onClick={() => setShowThreeDots(!showThreeDots)}
                      className="p-2 rounded-xl bg-[#1c2334] hover:bg-[#25324d] text-zinc-300 hover:text-white transition cursor-pointer border border-[#2b3548]"
                      title="Profile Options"
                    >
                      <MoreHorizontal className="w-4 h-4" />
                    </button>

                    {showThreeDots && (
                      <div className="absolute right-0 mt-2 w-56 bg-[#151922] border border-[#272e3f] rounded-2xl shadow-2xl py-2 z-50 text-left animate-in fade-in zoom-in-95 duration-100 divide-y divide-[#1f2638]">
                        <div className="py-1">
                          {/* 1. Advertise */}
                          <button
                            onClick={() => {
                              setShowThreeDots(false);
                              openCreateAdModal();
                            }}
                            className="w-full text-left px-4 py-2 text-xs text-zinc-200 hover:text-white hover:bg-[#1a202c] flex items-center gap-2.5 cursor-pointer font-medium"
                          >
                            <Sparkles className="w-4 h-4 text-amber-400" />
                            <span>Advertise Profile</span>
                          </button>

                          {/* 2. Add to Story */}
                          <button
                            onClick={() => {
                              setShowThreeDots(false);
                              openCreateStoryModal();
                            }}
                            className="w-full text-left px-4 py-2 text-xs text-zinc-200 hover:text-white hover:bg-[#1a202c] flex items-center gap-2.5 cursor-pointer font-medium"
                          >
                            <Plus className="w-4 h-4 text-[#ff3358]" />
                            <span>Add to Story</span>
                          </button>

                          {/* 3. View As */}
                          <button
                            onClick={() => {
                              setShowThreeDots(false);
                              setViewAsGuest(!viewAsGuest);
                            }}
                            className="w-full text-left px-4 py-2 text-xs text-zinc-200 hover:text-white hover:bg-[#1a202c] flex items-center gap-2.5 cursor-pointer font-medium"
                          >
                            <Eye className="w-4 h-4 text-emerald-400" />
                            <span>View As (Public Preview)</span>
                          </button>

                          {/* 4. Add Action Buttons */}
                          <button
                            onClick={() => {
                              setShowThreeDots(false);
                              setShowEditProfileModal(true);
                            }}
                            className="w-full text-left px-4 py-2 text-xs text-zinc-200 hover:text-white hover:bg-[#1a202c] flex items-center gap-2.5 cursor-pointer font-medium"
                          >
                            <SlidersHorizontal className="w-4 h-4 text-sky-400" />
                            <span>Add Action Buttons</span>
                          </button>
                        </div>

                        <div className="py-1">
                          {/* 5. Search on Profile */}
                          <button
                            onClick={() => {
                              setShowThreeDots(false);
                              setActiveTab("all");
                            }}
                            className="w-full text-left px-4 py-2 text-xs text-zinc-200 hover:text-white hover:bg-[#1a202c] flex items-center gap-2.5 cursor-pointer font-medium"
                          >
                            <Search className="w-4 h-4 text-zinc-400" />
                            <span>Search Profile</span>
                          </button>

                          {/* 6. Profile Status */}
                          <div className="px-4 py-2 text-xs text-zinc-300 flex items-center justify-between">
                            <span className="text-[11px] text-zinc-400">Profile Status:</span>
                            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                              {profileUser?.subscriptionStatus === "active" ? "Subscribed 30d ✓" : "Standard"}
                            </span>
                          </div>

                          {/* 7. Archive */}
                          <button
                            onClick={() => {
                              setShowThreeDots(false);
                              setActiveTab("photos");
                            }}
                            className="w-full text-left px-4 py-2 text-xs text-zinc-200 hover:text-white hover:bg-[#1a202c] flex items-center gap-2.5 cursor-pointer font-medium"
                          >
                            <Archive className="w-4 h-4 text-purple-400" />
                            <span>Archive / Photos</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Names, verified Star badge & Gender Orientation */}
              <div className="mb-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-black text-white">
                    {profileUser?.displayName}
                  </h1>
                  {profileUser?.isVerifiedStar && (
                    <span className="bg-[#ff3358]/20 text-[#ff3358] border border-[#ff3358]/40 text-[10px] font-black px-2 py-0.5 rounded uppercase">
                      ⭐ Star
                    </span>
                  )}
                  {profileUser?.genderRole && (
                    <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                      {profileUser.genderRole}
                    </span>
                  )}
                  {profileUser?.agencyType && (
                    <span className="bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-bold px-2 py-0.5 rounded">
                      {profileUser.agencyType}
                    </span>
                  )}
                </div>
                <span className="text-xs text-zinc-400 block mt-0.5">
                  @{profileUser?.username} &bull; {profileUser?.locationArea || "Kilimani, Nairobi"}
                </span>
              </div>

              {profileUser?.bio && (
                <p className="text-xs text-zinc-200 leading-relaxed mb-4 whitespace-pre-line">
                  {profileUser?.bio}
                </p>
              )}

              {/* Live Tip Goal if set */}
              {goal && (
                <div className="bg-[#0e1118] border border-[#212738] rounded-xl p-3 mb-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <Target className="w-3.5 h-3.5 text-[#ff3358]" />
                      Room Goal: {goal.title}
                    </span>
                    <span className="text-amber-400 font-black">
                      {goal.progressTokens} / {goal.targetTokens} tk ({goal.percentage}%)
                    </span>
                  </div>

                  <div className="w-full bg-[#161a25] rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-[#ff3358] to-[#ffaa00] h-full rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, goal.percentage)}%` }}
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="number"
                      value={goalAmount}
                      onChange={(e) => setGoalAmount(e.target.value)}
                      className="w-20 bg-[#161a24] border border-[#2b3345] rounded-lg px-2 py-1 text-xs text-white"
                      placeholder="Tokens"
                    />
                    <button
                      onClick={handleContributeGoal}
                      className="px-3 py-1 rounded-lg bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold transition shadow-sm cursor-pointer"
                    >
                      Contribute Tokens
                    </button>
                  </div>
                </div>
              )}

              {/* Stats Bar */}
              <div className="flex items-center gap-6 pt-3 border-t border-[#1e2330] text-xs">
                <div>
                  <span className="font-black text-white text-sm">{followersCount.toLocaleString()}</span>{" "}
                  <span className="text-zinc-400">Fans</span>
                </div>
                <div>
                  <span className="font-black text-amber-400 text-sm flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" />
                    {profileUser?.tokensBalance || 450}
                  </span>{" "}
                  <span className="text-zinc-400">Tokens</span>
                </div>
                <div>
                  <span className="font-black text-white text-sm">{posts.length}</span>{" "}
                  <span className="text-zinc-400">Posts</span>
                </div>
              </div>
            </div>

            {/* 3. FACEBOOK CLONED PROFILE TABS: All, About, Photos, Friends, Quickie, More */}
            <div className="flex items-center border-t border-[#1e2330] bg-[#0e1118] overflow-x-auto scrollbar-none">
              <button
                onClick={() => setActiveTab("all")}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === "all" ? "text-[#ff3358] border-b-2 border-[#ff3358]" : "text-zinc-400 hover:text-white"
                }`}
              >
                All Posts ({posts.length})
              </button>

              <button
                onClick={() => setActiveTab("about")}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === "about" ? "text-[#ff3358] border-b-2 border-[#ff3358]" : "text-zinc-400 hover:text-white"
                }`}
              >
                About & Rates
              </button>

              <button
                onClick={() => setActiveTab("photos")}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === "photos" ? "text-[#ff3358] border-b-2 border-[#ff3358]" : "text-zinc-400 hover:text-white"
                }`}
              >
                Photos ({mediaPosts.length})
              </button>

              <button
                onClick={() => setActiveTab("friends")}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === "friends" ? "text-[#ff3358] border-b-2 border-[#ff3358]" : "text-zinc-400 hover:text-white"
                }`}
              >
                Friends ({profileUser?.friendsCount || 12})
              </button>

              <button
                onClick={() => setActiveTab("quickies")}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === "quickies" ? "text-[#ff3358] border-b-2 border-[#ff3358]" : "text-zinc-400 hover:text-white"
                }`}
              >
                Quickie (9:16)
              </button>

              <button
                onClick={() => setActiveTab("tip-menu")}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === "tip-menu" ? "text-[#ff3358] border-b-2 border-[#ff3358]" : "text-zinc-400 hover:text-white"
                }`}
              >
                Tip Menu ({tipMenu.length})
              </button>

              <button
                onClick={() => setActiveTab("wishlist")}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  activeTab === "wishlist" ? "text-[#ff3358] border-b-2 border-[#ff3358]" : "text-zinc-400 hover:text-white"
                }`}
              >
                Wishlist ({wishlist.length})
              </button>
            </div>
          </div>

          {/* TAB 1: ALL POSTS (Automatically displays all feed posts created by profile owner) */}
          {activeTab === "all" && (
            <div className="space-y-4">
              {posts.length === 0 ? (
                <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center text-zinc-400 text-xs">
                  No posts published yet. Feed posts will automatically display here!
                </div>
              ) : (
                posts.map((post) => <PostCard key={post.id} post={post} />)
              )}
            </div>
          )}

          {/* TAB 2: ABOUT & RATES */}
          {activeTab === "about" && (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-6 space-y-5">
              <div>
                <h3 className="text-sm font-bold uppercase text-white tracking-wider mb-2">
                  Profile Bio & Information
                </h3>
                <p className="text-xs text-zinc-300 leading-relaxed whitespace-pre-line">
                  {profileUser?.bio}
                </p>
              </div>

              {/* Services List */}
              {profileUser?.servicesList && profileUser.servicesList.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase text-amber-400 tracking-wider mb-2">
                    Services Provided:
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {profileUser.servicesList.map((s: string, idx: number) => (
                      <span key={idx} className="bg-[#0e1118] border border-[#212738] text-zinc-200 text-xs px-3 py-1 rounded-xl">
                        &bull; {s}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Rates Table in KSh */}
              {profileUser?.ratesList && profileUser.ratesList.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase text-white tracking-wider mb-2">
                    Pricing & Session Rates (KSh):
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {profileUser.ratesList.map((r: any, idx: number) => (
                      <div key={idx} className="p-3 bg-[#0e1118] border border-[#212738] rounded-xl flex items-center justify-between text-xs">
                        <span className="text-zinc-300 font-medium">{r.duration}</span>
                        <strong className="text-amber-400 font-black">KSh {r.priceKsh.toLocaleString()}</strong>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Contact Information */}
              <div className="pt-3 border-t border-[#1e2330]">
                <h4 className="text-xs font-bold uppercase text-zinc-400 tracking-wider mb-2">
                  Contact & Location Details:
                </h4>
                <div className="text-xs text-zinc-300 space-y-1">
                  <p>Location: <strong>{profileUser?.locationArea || "Kilimani, Nairobi"}</strong></p>
                  <p>Service Mode: <strong>{profileUser?.serviceType || "Both Incall & Outcall"}</strong></p>
                  <p>Contact Phone: <strong className="text-emerald-400 font-mono">{profileUser?.maskedPhone}</strong></p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PHOTOS (Photo Archive) */}
          {activeTab === "photos" && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {mediaPosts.map((post) => {
                const mediaItem = post.media && post.media[0];
                return (
                  <div key={post.id} className="relative aspect-square rounded-xl overflow-hidden bg-black group">
                    <img
                      src={mediaItem?.url || post.videoUrl}
                      alt="Media"
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-200"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2">
                      <span className="text-white text-xs font-bold flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5 fill-[#ff3358] text-[#ff3358]" />
                        {post.flamesCount}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 4: FRIENDS */}
          {activeTab === "friends" && (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-5 space-y-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Mutual Friends ({profileUser?.friendsCount || 12})
              </h3>
              <p className="text-xs text-zinc-400">
                Mutual friends who followed back on HotCheelee
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                {[
                  { name: "Elena Lux", area: "Kilimani", avatar: "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg" },
                  { name: "Liam Onyango", area: "Westlands", avatar: "https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg" },
                  { name: "Sasha Vixen", area: "Lavington", avatar: "https://images.pexels.com/photos/29271917/pexels-photo-29271917.jpeg" },
                  { name: "Serenity Spa", area: "Wood Ave", avatar: "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg" },
                ].map((f, i) => (
                  <div key={i} className="p-3 bg-[#0e1118] border border-[#212738] rounded-xl text-center space-y-1">
                    <img src={f.avatar} alt={f.name} className="w-14 h-14 rounded-full mx-auto object-cover ring-1 ring-white/10" />
                    <span className="text-xs font-bold text-white block truncate">{f.name}</span>
                    <span className="text-[10px] text-zinc-500">{f.area}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: QUICKIE (9:16 Vertical Video Reels) */}
          {activeTab === "quickies" && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {quickiePosts.length === 0 ? (
                <div className="col-span-full bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center text-xs text-zinc-400">
                  No 9:16 Quickies posted yet.
                </div>
              ) : (
                quickiePosts.map((q) => (
                  <div key={q.id} className="relative aspect-[9/16] rounded-2xl overflow-hidden bg-black border border-white/10 shadow group">
                    <video
                      src={q.videoUrl}
                      className="w-full h-full object-cover"
                      controls
                    />
                    <div className="absolute top-2 left-2 bg-black/70 px-2 py-0.5 rounded text-[10px] text-amber-400 font-bold">
                      9:16 Reel
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 6: TIP MENU */}
          {activeTab === "tip-menu" && (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#1e2330]">
                <h3 className="text-sm font-bold text-white">Performer Tip Menu Commands</h3>
                <button
                  onClick={() => openTipMenuModal(profileUser.id, profileUser.displayName)}
                  className="px-3 py-1 rounded-lg bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold"
                >
                  Interactive Panel &rarr;
                </button>
              </div>

              <div className="space-y-2">
                {tipMenu.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-[#0e1118] border border-[#212738] flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white">{item.actionName}</span>
                      <p className="text-[11px] text-zinc-400">{item.description}</p>
                    </div>
                    <span className="font-black text-amber-400 text-sm">{item.tokensCost} Tokens</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: WISHLIST */}
          {activeTab === "wishlist" && (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#1e2330]">
                <h3 className="text-sm font-bold text-white">Model Wishlist Gifts</h3>
                <button
                  onClick={() => openWishlistModal(profileUser.id, profileUser.displayName)}
                  className="px-3 py-1 rounded-lg bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold"
                >
                  Fulfill Gifts &rarr;
                </button>
              </div>

              <div className="space-y-2">
                {wishlist.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-[#0e1118] border border-[#212738] flex items-center gap-3 text-xs"
                  >
                    <img
                      src={item.image || "https://images.pexels.com/photos/33282388/pexels-photo-33282388.jpeg"}
                      alt={item.title}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <span className="font-bold text-white block truncate">{item.title}</span>
                      <span className="text-[11px] text-amber-400 font-bold">{item.tokenCost} Tokens</span>
                    </div>
                    {item.isFulfilled && (
                      <span className="text-emerald-400 text-[10px] font-bold">Fulfilled ✓</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Profile Edit Modals */}
      <EditProfileModal
        isOpen={showEditProfileModal}
        onClose={() => setShowEditProfileModal(false)}
        user={profileUser}
        onSave={handleSaveProfileData}
      />

      <EditPhotoModal
        isOpen={showAvatarModal}
        onClose={() => setShowAvatarModal(false)}
        type="avatar"
        currentUrl={profileUser?.avatar}
        onSave={handleUpdateAvatar}
        title="See & Choose Profile Picture"
      />

      <EditPhotoModal
        isOpen={showCoverModal}
        onClose={() => setShowCoverModal(false)}
        type="cover"
        currentUrl={profileUser?.coverImage}
        onSave={handleUpdateCover}
        title="Edit Cover Photo"
      />
    </div>
  );
}
