"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Building2,
  Check,
  UserPlus,
  Phone,
  MessageCircle,
  MapPin,
  Sparkles,
  Search,
  ExternalLink,
} from "lucide-react";

export default function BrandsPage() {
  const { openContactModal, openAuthModal } = useApp();
  const [brands, setBrands] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [agencyFilter, setAgencyFilter] = useState("all");
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});

  const agencyCategories = [
    { id: "all", label: "All Agencies" },
    { id: "Massage Parlour", label: "Massage Parlours" },
    { id: "Lodging", label: "Lodgings & Brothels" },
    { id: "Brothel", label: "Brothel Clubs" },
    { id: "Agency", label: "Escort Agencies" },
  ];

  const loadAgencies = async () => {
    setLoading(true);
    try {
      let url = "/api/stars?type=agencies";
      if (agencyFilter !== "all") url += `&agencyType=${encodeURIComponent(agencyFilter)}`;
      if (search) url += `&q=${encodeURIComponent(search)}`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.stars) {
        setBrands(data.stars);
        const map: Record<string, boolean> = {};
        data.stars.forEach((b: any) => {
          map[b.username] = b.isFollowing;
        });
        setFollowingMap(map);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAgencies();
  }, [search, agencyFilter]);

  const handleToggleFollow = async (username: string) => {
    const isFollowing = followingMap[username];
    setFollowingMap((prev) => ({ ...prev, [username]: !isFollowing }));

    try {
      await fetch(`/api/users/${username}/follow`, { method: "POST" });
    } catch {
      setFollowingMap((prev) => ({ ...prev, [username]: isFollowing }));
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-[#211a14] via-[#161a25] to-[#121620] border border-[#2b273b] rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <Building2 className="w-5 h-5 text-amber-400" />
                <h1 className="text-2xl font-black text-white">Massage Parlours, Lodgings & Brothels</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-lg leading-relaxed">
                Verified executive spas, discreet lodgings, private brothels & escort agencies in Kenya. M-Pesa Till: 8923411 (KSh 1,500/month).
              </p>
            </div>

            <button
              onClick={() => openAuthModal("register_agency")}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-[#ff3358] text-white font-bold text-xs shadow-md transition cursor-pointer self-start sm:self-center shrink-0"
            >
              Register Agency (KSh 1,500/mo)
            </button>
          </div>

          {/* Agency Filters */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {agencyCategories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setAgencyFilter(c.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    agencyFilter === c.id
                      ? "bg-amber-400 text-black shadow-sm font-black"
                      : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search parlour, area..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-[#121620] border border-[#232938] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Agency Listings */}
          {loading ? (
            <div className="space-y-4">
              <div className="bg-[#13161f] border border-[#212735] rounded-2xl h-48 animate-pulse" />
            </div>
          ) : brands.length === 0 ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-10 text-center text-xs text-zinc-400">
              No agency listings found in this category.
            </div>
          ) : (
            <div className="space-y-4">
              {brands.map((brand) => {
                const isFollowing = followingMap[brand.username];
                return (
                  <div
                    key={brand.id}
                    className="bg-[#13161f] border border-[#212735] hover:border-amber-400/50 rounded-2xl p-5 transition shadow-sm space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-3.5">
                        <img
                          src={brand.avatar || "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg"}
                          alt={brand.displayName}
                          className="w-16 h-16 rounded-2xl object-cover ring-2 ring-amber-400 shrink-0"
                        />
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="text-base font-bold text-white">
                              {brand.displayName}
                            </h3>
                            <span className="bg-amber-400/20 text-amber-400 border border-amber-400/40 text-[10px] font-black px-2 py-0.5 rounded uppercase">
                              {brand.agencyType || "Agency"}
                            </span>
                            <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-bold px-1.5 py-0.2 rounded">
                              Subscribed 30d ✓
                            </span>
                          </div>
                          <p className="text-xs text-zinc-400 mt-1 flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-amber-400" />
                            <span>{brand.locationArea || brand.location || "Nairobi"}</span>
                            <span>&bull;</span>
                            <span>@{brand.username}</span>
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <button
                          onClick={() => openContactModal(brand)}
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-[#ff3358] text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Reveal Reception & WhatsApp</span>
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-zinc-300 leading-relaxed">
                      {brand.bio}
                    </p>

                    {/* Advert Video or Image if present */}
                    {brand.advertMediaUrl && (
                      <div className="rounded-xl overflow-hidden max-h-56 bg-black border border-white/10">
                        {brand.advertMediaType === "video" ? (
                          <video src={brand.advertMediaUrl} controls className="w-full h-56 object-cover" />
                        ) : (
                          <img src={brand.advertMediaUrl} alt="Advert" className="w-full h-56 object-cover" />
                        )}
                      </div>
                    )}

                    {/* Rates & Services summary */}
                    <div className="pt-3 border-t border-[#1e2330] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="flex flex-wrap gap-1.5">
                        {(brand.servicesList || ["Nuru Massage", "Jacuzzi", "Private Rooms"]).slice(0, 4).map((s: string, i: number) => (
                          <span key={i} className="bg-[#0e1118] text-zinc-300 px-2 py-0.5 rounded text-[11px] border border-[#212738]">
                            &bull; {s}
                          </span>
                        ))}
                      </div>

                      <div className="text-zinc-400 font-mono text-xs">
                        Reception: <strong className="text-white">{brand.maskedPhone}</strong>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
