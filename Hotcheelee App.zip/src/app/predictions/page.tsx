"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Coins,
  Zap,
  Trophy,
  Plus,
  Flame,
  CheckCircle2,
  Calendar,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  X,
  CreditCard,
  AlertCircle,
} from "lucide-react";

export default function PtopPredictionsPage() {
  const { currentUser, refreshUser, openTokensModal, openWalletModal } = useApp();
  const [activeTab, setActiveTab] = useState<"predictions" | "jackpots">("predictions");
  const [predictions, setPredictions] = useState<any[]>([]);
  const [jackpotsList, setJackpotsList] = useState<any[]>([]);
  const [leagueFilter, setLeagueFilter] = useState("All");
  const [loading, setLoading] = useState(true);

  // Modal states
  const [showPredictionModal, setShowPredictionModal] = useState(false);
  const [showJackpotModal, setShowJackpotModal] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  // New Prediction Form State
  const [predLeague, setPredLeague] = useState("Premier League");
  const [predTeamA, setPredTeamA] = useState("");
  const [predTeamB, setPredTeamB] = useState("");
  const [predMatchDate, setPredMatchDate] = useState("23 Oct 2026");
  const [predStake, setPredStake] = useState("100");
  const [submittingPred, setSubmittingPred] = useState(false);

  // Create Jackpot Form State (Matching Prompt Specs)
  const [jackpotType, setJackpotType] = useState<"daily" | "weekly">("daily");
  const [jackpotMatches, setJackpotMatches] = useState<Array<{ matchIndex: number; teamA: string; teamB: string }>>([
    { matchIndex: 1, teamA: "Arsenal", teamB: "Chelsea" },
    { matchIndex: 2, teamA: "Gor Mahia", teamB: "AFC Leopards" },
  ]);
  const [submittingJackpot, setSubmittingJackpot] = useState(false);

  const leagues = ["All", "Premier League", "Bundesliga", "La Liga", "KPL", "Serie A", "Ligue 1"];

  const loadData = async () => {
    setLoading(true);
    try {
      const [pRes, jRes] = await Promise.all([
        fetch("/api/ptop-predictions"),
        fetch("/api/ptop-jackpots"),
      ]);
      const pData = await pRes.json();
      const jData = await jRes.json();

      if (pData.predictions) setPredictions(pData.predictions);
      if (jData.jackpots) setJackpotsList(jData.jackpots);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const userBalance = currentUser?.tokensBalance || 0;

  // Prediction Challenge Handler
  const handleCreatePrediction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!predTeamA.trim() || !predTeamB.trim()) {
      alert("Please provide both Team A and Team B");
      return;
    }

    const stake = Number(predStake);
    if (userBalance < stake) {
      openTokensModal();
      return;
    }

    setSubmittingPred(true);
    try {
      const res = await fetch("/api/ptop-predictions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create",
          league: predLeague,
          homeTeam: predTeamA.trim(),
          awayTeam: predTeamB.trim(),
          matchDate: predMatchDate,
          creatorPick: predTeamA.trim(),
          stakeCoins: stake,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setShowPredictionModal(false);
        setNotice(data.message);
        setPredTeamA("");
        setPredTeamB("");
        await refreshUser();
        loadData();
      } else {
        alert(data.error || "Failed to create prediction");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmittingPred(false);
    }
  };

  // Jackpot Calculations
  const matchesCount = jackpotMatches.length;
  const jackpotCreationCost = matchesCount * 250; // e.g. 2 games * 250 = 500
  const jackpotEntryFee = matchesCount * 25; // e.g. 2 * 25 = 50
  const hasEnoughForJackpot = userBalance >= jackpotCreationCost;

  const handleAddMatch = () => {
    if (jackpotMatches.length >= 10) return;
    setJackpotMatches([
      ...jackpotMatches,
      { matchIndex: jackpotMatches.length + 1, teamA: "", teamB: "" },
    ]);
  };

  const handleUpdateMatch = (index: number, field: "teamA" | "teamB", value: string) => {
    const updated = [...jackpotMatches];
    updated[index][field] = value;
    setJackpotMatches(updated);
  };

  const handleCreateJackpot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasEnoughForJackpot) {
      openTokensModal();
      return;
    }

    // Check all team names filled
    for (const m of jackpotMatches) {
      if (!m.teamA.trim() || !m.teamB.trim()) {
        alert("Fill in all team names before creating.");
        return;
      }
    }

    setSubmittingJackpot(true);
    try {
      const res = await fetch("/api/ptop-jackpots", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create",
          jackpotType,
          matches: jackpotMatches,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setShowJackpotModal(false);
        setNotice(data.message);
        await refreshUser();
        loadData();
      } else {
        alert(data.error || "Failed to create jackpot");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmittingJackpot(false);
    }
  };

  // Match list from database or default fixtures
  const defaultPromptMatches = [
    {
      id: 101,
      league: "KPL",
      status: "matched",
      homeTeam: "Mathare FC",
      awayTeam: "Kangemi FC",
      matchDate: "2 Jun",
      stakeCoins: 30000,
      totalPotCoins: 60000,
      winnerRewardCoins: 54000,
      creatorPick: "Mathare FC",
      opponentPick: "Kangemi FC",
      creator: { displayName: "Red Bee", username: "redbee" },
    },
    {
      id: 102,
      league: "Bundesliga",
      status: "matched",
      homeTeam: "Bayern Munich",
      awayTeam: "Dortmund",
      matchDate: "16 Jun",
      stakeCoins: 1000,
      totalPotCoins: 2000,
      winnerRewardCoins: 1800,
      creatorPick: "Bayern Munich",
      opponentPick: "Dortmund",
      creator: { displayName: "Alice W.", username: "alice_w" },
    },
    {
      id: 103,
      league: "KPL",
      status: "open",
      homeTeam: "Gor Mahia",
      awayTeam: "AFC Leopards",
      matchDate: "14 Jun",
      stakeCoins: 200,
      totalPotCoins: 400,
      winnerRewardCoins: 360,
      creatorPick: "Gor Mahia",
      creator: { displayName: "James K.", username: "james_k" },
    },
    {
      id: 104,
      league: "Premier League",
      status: "matched",
      homeTeam: "Arsenal",
      awayTeam: "Chelsea",
      matchDate: "15 Jun",
      stakeCoins: 500,
      totalPotCoins: 1000,
      winnerRewardCoins: 900,
      creatorPick: "Arsenal",
      opponentPick: "Chelsea",
      creator: { displayName: "Kevin M.", username: "kevin_m" },
    },
    {
      id: 105,
      league: "Premier League",
      status: "matched",
      homeTeam: "Man City",
      awayTeam: "Liverpool",
      matchDate: "17 Jun",
      stakeCoins: 750,
      totalPotCoins: 1500,
      winnerRewardCoins: 1350,
      creatorPick: "Man City",
      opponentPick: "Liverpool",
      creator: { displayName: "Brian O.", username: "brian_o" },
    },
    {
      id: 106,
      league: "La Liga",
      status: "matched",
      homeTeam: "Real Madrid",
      awayTeam: "Barcelona",
      matchDate: "18 Jun",
      stakeCoins: 2000,
      totalPotCoins: 4000,
      winnerRewardCoins: 3600,
      creatorPick: "Real Madrid",
      opponentPick: "Barcelona",
      creator: { displayName: "Sofia R.", username: "sofia_r" },
    },
    {
      id: 107,
      league: "KPL",
      status: "matched",
      homeTeam: "Gormahia Fc",
      awayTeam: "Fc leopard",
      matchDate: "29 Jul",
      stakeCoins: 10,
      totalPotCoins: 20,
      winnerRewardCoins: 18,
      creatorPick: "Gormahia Fc",
      opponentPick: "Fc leopard",
      creator: { displayName: "Job Simiyu", username: "job_simiyu" },
    },
    {
      id: 108,
      league: "Premier League",
      status: "matched",
      homeTeam: "Arsenal",
      awayTeam: "Man U",
      matchDate: "13 May",
      stakeCoins: 500,
      totalPotCoins: 1000,
      winnerRewardCoins: 900,
      creatorPick: "Arsenal",
      opponentPick: "Man U",
      creator: { displayName: "Red Bee", username: "redbee" },
    },
  ];

  const displayPredictions = predictions.length > 0 ? predictions : defaultPromptMatches;
  const filteredPredictions = displayPredictions.filter(
    (p) => leagueFilter === "All" || p.league.toLowerCase() === leagueFilter.toLowerCase()
  );

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-[#21151a] via-[#161a25] to-[#121620] border border-[#2b273b] rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Trophy className="w-6 h-6 text-amber-400" />
                <h1 className="text-2xl font-black text-white">Prediction & Jackpot Marketplace</h1>
              </div>
              <p className="text-xs text-amber-400 font-bold uppercase tracking-wider">
                Stake HotCheelee Coins &bull; Win 90% &bull; Platform 10%
              </p>
            </div>

            <div className="flex items-center gap-2">
              {activeTab === "predictions" ? (
                <button
                  onClick={() => setShowPredictionModal(true)}
                  className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Prediction</span>
                </button>
              ) : (
                <button
                  onClick={() => setShowJackpotModal(true)}
                  className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Trophy className="w-4 h-4" />
                  <span>Create Jackpot</span>
                </button>
              )}
            </div>
          </div>

          {/* EXACT BALANCE & STATS DISPLAY */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 flex flex-col justify-between">
              <span className="text-[11px] text-zinc-400 block font-medium">Your available balance</span>
              <div className="text-2xl font-black text-amber-400 flex items-center gap-1 my-1">
                <span>🪙</span>
                <span>{userBalance.toLocaleString()} HotCheelee Coins</span>
              </div>
              <div className="flex items-center gap-2 pt-1 text-xs">
                <button
                  onClick={openTokensModal}
                  className="text-amber-400 hover:underline font-bold"
                >
                  Buy Coins
                </button>
                <span className="text-zinc-600">&bull;</span>
                <button
                  onClick={openWalletModal}
                  className="text-zinc-400 hover:text-white"
                >
                  Withdraw
                </button>
              </div>
            </div>

            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4">
              <span className="text-[11px] text-zinc-400 block font-medium">Open Challenges</span>
              <div className="text-2xl font-black text-white mt-1">1 Open</div>
              <span className="text-[10px] text-emerald-400 mt-1 block">Live & Ready to stake</span>
            </div>

            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4">
              <span className="text-[11px] text-zinc-400 block font-medium">Total Staked</span>
              <div className="text-2xl font-black text-emerald-400 mt-1">
                34,960 🪙
              </div>
              <span className="text-[10px] text-zinc-500 mt-1 block">Across all matches</span>
            </div>

            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4">
              <span className="text-[11px] text-zinc-400 block font-medium">Jackpots</span>
              <div className="text-2xl font-black text-purple-400 mt-1">
                {jackpotsList.length} Jackpots
              </div>
              <span className="text-[10px] text-zinc-500 mt-1 block">Daily & Weekly</span>
            </div>
          </div>

          {notice && (
            <div className="p-3.5 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center justify-between">
              <span>{notice}</span>
              <button onClick={() => setNotice(null)}>✕</button>
            </div>
          )}

          {/* TWO PRIMARY SECTIONS: PREDICTIONS & JACKPOTS */}
          <div className="flex items-center gap-2 border-b border-[#212738] pb-3">
            <button
              onClick={() => setActiveTab("predictions")}
              className={`py-2 px-5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
                activeTab === "predictions"
                  ? "bg-[#ff3358] text-white shadow-md shadow-[#ff3358]/25"
                  : "bg-[#141822] text-zinc-400 hover:text-white"
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>⚡ Predictions</span>
            </button>

            <button
              onClick={() => setActiveTab("jackpots")}
              className={`py-2 px-5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
                activeTab === "jackpots"
                  ? "bg-amber-400 text-black shadow-md shadow-amber-400/25"
                  : "bg-[#141822] text-zinc-400 hover:text-white"
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span>🏆 Jackpots</span>
            </button>
          </div>

          {/* TAB 1: PREDICTIONS */}
          {activeTab === "predictions" && (
            <div className="space-y-4">
              {/* League filter chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {leagues.map((l) => (
                  <button
                    key={l}
                    onClick={() => setLeagueFilter(l)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                      leagueFilter === l
                        ? "bg-[#ff3358] text-white shadow-sm"
                        : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>

              {/* Match list */}
              <div className="space-y-3">
                {filteredPredictions.map((m: any) => {
                  const isMatched = m.status === "matched";
                  const isOpen = m.status === "open";
                  return (
                    <div
                      key={m.id}
                      className="bg-[#121620] border border-[#232938] hover:border-[#ff3358]/50 p-4 rounded-2xl shadow-sm space-y-3 transition"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-white bg-[#171f2e] px-2.5 py-0.5 rounded-lg border border-[#26344d]">
                          {m.league}
                        </span>

                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1 ${
                            isMatched ? "bg-amber-400/20 text-amber-300" : "bg-emerald-500/20 text-emerald-400"
                          }`}>
                            <span>{isMatched ? "🟡 Matched" : "🟢 Open"}</span>
                          </span>

                          <span className="text-[11px] text-zinc-400 font-medium">
                            by {m.creator?.displayName || "Member"} &bull; 90% winner &bull; 10% platform
                          </span>
                        </div>
                      </div>

                      <div className="p-3 bg-[#0e1118] border border-[#1d2433] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-white text-sm">⚽ {m.homeTeam}</span>
                          <span className="text-zinc-500 font-bold">VS ({m.matchDate})</span>
                          <span className="font-bold text-white text-sm">⚽ {m.awayTeam}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <span className="text-xs text-zinc-400 block font-medium">Stake</span>
                            <strong className="text-amber-400 text-sm font-black">🪙 {m.stakeCoins} Coins</strong>
                          </div>
                          <div className="text-right pl-2 border-l border-zinc-700">
                            <span className="text-xs text-zinc-400 block font-medium">Stake Win</span>
                            <strong className="text-emerald-400 text-sm font-black">{m.winnerRewardCoins || m.stakeCoins * 1.8} 🪙</strong>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-1 text-xs">
                        <div className="text-zinc-300">
                          Pick: <strong className="text-white">{m.creatorPick}</strong>
                          {m.opponentPick && <span> vs <strong className="text-amber-300">{m.opponentPick}</strong></span>}
                        </div>

                        <div>
                          {isOpen ? (
                            <button
                              onClick={() => {
                                if (userBalance < m.stakeCoins) {
                                  openTokensModal();
                                } else {
                                  alert(`Challenged ${m.homeTeam} vs ${m.awayTeam} for ${m.stakeCoins} Coins!`);
                                }
                              }}
                              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-bold text-xs shadow"
                            >
                              🔒 Challenge & Stake {m.stakeCoins} 🪙
                            </button>
                          ) : (
                            <span className="text-[11px] text-zinc-400 font-semibold bg-[#161d2b] px-2.5 py-1 rounded-lg">
                              🟡 Already Matched
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: JACKPOTS */}
          {activeTab === "jackpots" && (
            <div className="space-y-4">
              {jackpotsList.length === 0 ? (
                <div className="bg-[#121620] border border-[#232938] rounded-2xl p-10 text-center space-y-3">
                  <Trophy className="w-12 h-12 text-amber-400 mx-auto opacity-70" />
                  <h3 className="text-base font-bold text-white">No jackpots yet.</h3>
                  <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                    Be the first creator to create a Daily or Weekly Jackpot pool. Creator wins 90% of the entry pool!
                  </p>
                  <button
                    onClick={() => setShowJackpotModal(true)}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer inline-flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create First Jackpot</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {jackpotsList.map((jk) => (
                    <div
                      key={jk.id}
                      className="bg-[#121620] border border-[#232938] p-5 rounded-2xl space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-amber-400 text-lg">🏆</span>
                          <h4 className="text-base font-black text-white">{jk.title}</h4>
                          <span className="text-[10px] bg-amber-400/20 text-amber-300 font-bold px-2 py-0.5 rounded uppercase">
                            {jk.jackpotType}
                          </span>
                        </div>

                        <span className="text-xs font-black text-emerald-400">
                          Pool: 🪙 {jk.totalPoolCoins.toLocaleString()} Coins
                        </span>
                      </div>

                      {/* Matches in jackpot */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        {(jk.matchesList || []).map((m: any, idx: number) => (
                          <div key={idx} className="bg-[#0e1118] p-2.5 rounded-xl border border-[#1f2638] flex items-center justify-between">
                            <span className="text-zinc-400 font-medium">Match {idx + 1}:</span>
                            <span className="font-bold text-white">{m.teamA} vs {m.teamB}</span>
                          </div>
                        ))}
                      </div>

                      <div className="pt-2 border-t border-[#1e2330] flex items-center justify-between text-xs">
                        <span className="text-zinc-400">
                          Entry: <strong className="text-amber-400">🪙 {jk.entryFeeCoins} Coins</strong> &bull; {jk.entriesCount} entries
                        </span>

                        <button
                          onClick={async () => {
                            if (userBalance < jk.entryFeeCoins) {
                              openTokensModal();
                              return;
                            }
                            const res = await fetch("/api/ptop-jackpots", {
                              method: "POST",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ action: "enter", jackpotId: jk.id }),
                            });
                            const data = await res.json();
                            if (res.ok) {
                              alert(data.message);
                              await refreshUser();
                              loadData();
                            } else {
                              alert(data.error);
                            }
                          }}
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-[#ff3358] text-white font-bold text-xs"
                        >
                          Enter Jackpot (🪙 {jk.entryFeeCoins})
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* POPUP 1: CREATE JACKPOT MODAL (EXACT SPECS FROM USER PROMPT) */}
          {showJackpotModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
              <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95 space-y-4">
                <button
                  onClick={() => setShowJackpotModal(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1"
                >
                  <X className="w-5 h-5" />
                </button>

                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  🏆 Create Jackpot
                </h2>

                {/* Daily vs Weekly selector */}
                <div className="grid grid-cols-2 gap-2 p-1 bg-[#0e1118] border border-[#212738] rounded-xl text-xs font-bold text-center">
                  <button
                    type="button"
                    onClick={() => setJackpotType("daily")}
                    className={`py-2 rounded-lg transition ${
                      jackpotType === "daily" ? "bg-[#ff3358] text-white shadow" : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    📅 Daily Jackpot
                  </button>
                  <button
                    type="button"
                    onClick={() => setJackpotType("weekly")}
                    className={`py-2 rounded-lg transition ${
                      jackpotType === "weekly" ? "bg-amber-400 text-black shadow font-black" : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    📆 Weekly Jackpot
                  </button>
                </div>

                {/* Exact Calculations Display */}
                <div className="bg-[#0e1118] border border-[#212738] p-3.5 rounded-xl space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400">Your cost ({matchesCount} games &times; 250):</span>
                    <strong className="text-amber-400 text-sm font-black">🪙 {jackpotCreationCost}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400">Counter cost per entry ({matchesCount} &times; 25):</span>
                    <strong className="text-white font-bold">🪙 {jackpotEntryFee}</strong>
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-[#1d2332]">
                    <span className="text-zinc-400">Your balance:</span>
                    <strong className={`font-black ${hasEnoughForJackpot ? "text-emerald-400" : "text-red-400"}`}>
                      🪙 {userBalance.toLocaleString()}
                    </strong>
                  </div>
                </div>

                {/* Matches list (2/10) */}
                <form onSubmit={handleCreateJackpot} className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white">Matches ({matchesCount}/10)</span>
                    <span className="text-[11px] text-zinc-500">Fill in all team names before creating.</span>
                  </div>

                  <div className="max-h-56 overflow-y-auto space-y-2.5 pr-1">
                    {jackpotMatches.map((m, idx) => (
                      <div key={idx} className="bg-[#0e1118] border border-[#212738] p-3 rounded-xl space-y-2">
                        <span className="text-[11px] font-bold text-amber-400 block">Match {idx + 1}</span>
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            placeholder="Team A"
                            value={m.teamA}
                            onChange={(e) => handleUpdateMatch(idx, "teamA", e.target.value)}
                            required
                            className="bg-[#141822] border border-[#262c3b] rounded-lg px-2.5 py-1.5 text-xs text-white"
                          />
                          <input
                            type="text"
                            placeholder="Team B"
                            value={m.teamB}
                            onChange={(e) => handleUpdateMatch(idx, "teamB", e.target.value)}
                            required
                            className="bg-[#141822] border border-[#262c3b] rounded-lg px-2.5 py-1.5 text-xs text-white"
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {matchesCount < 10 && (
                    <button
                      type="button"
                      onClick={handleAddMatch}
                      className="w-full py-1.5 rounded-xl border border-dashed border-[#ff3358]/50 text-[#ff3358] hover:bg-[#ff3358]/10 text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Match (max 10)</span>
                    </button>
                  )}

                  {/* Exact Dynamic CTA Button */}
                  {hasEnoughForJackpot ? (
                    <button
                      type="submit"
                      disabled={submittingJackpot}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-black text-xs uppercase tracking-wider shadow-lg cursor-pointer"
                    >
                      {submittingJackpot ? "Creating..." : `🏆 Create Jackpot (🪙 ${jackpotCreationCost})`}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setShowJackpotModal(false);
                        openTokensModal();
                      }}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-[#ff3358] text-white font-black text-xs uppercase tracking-wider shadow-lg cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>🏆 Buy {jackpotCreationCost} Coins First</span>
                    </button>
                  )}

                  <span className="text-[11px] text-zinc-500 text-center block">
                    Creator wins: 90% pool &bull; Platform: 10%
                  </span>
                </form>
              </div>
            </div>
          )}

          {/* POPUP 2: NEW PREDICTION MODAL (EXACT SPECS FROM USER PROMPT) */}
          {showPredictionModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
              <div className="relative max-w-md w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95 space-y-4">
                <button
                  onClick={() => setShowPredictionModal(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1"
                >
                  <X className="w-5 h-5" />
                </button>

                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  ⚡ New Prediction
                </h2>

                <form onSubmit={handleCreatePrediction} className="space-y-3.5">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">League</label>
                    <select
                      value={predLeague}
                      onChange={(e) => setPredLeague(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    >
                      <option value="Premier League">Premier League</option>
                      <option value="Bundesliga">Bundesliga</option>
                      <option value="La Liga">La Liga</option>
                      <option value="KPL">KPL</option>
                      <option value="Serie A">Serie A</option>
                      <option value="Ligue 1">Ligue 1</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Team A</label>
                    <input
                      type="text"
                      placeholder="e.g. Arsenal"
                      value={predTeamA}
                      onChange={(e) => setPredTeamA(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Team B</label>
                    <input
                      type="text"
                      placeholder="e.g. Chelsea"
                      value={predTeamB}
                      onChange={(e) => setPredTeamB(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Match Date (Today Only)</label>
                    <input
                      type="text"
                      value={predMatchDate}
                      onChange={(e) => setPredMatchDate(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Stake Amount 🪙</label>
                    <input
                      type="number"
                      min={10}
                      step={10}
                      value={predStake}
                      onChange={(e) => setPredStake(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-amber-400/50 rounded-xl px-3 py-2 text-xs text-white font-bold"
                    />
                  </div>

                  {userBalance >= Number(predStake) ? (
                    <button
                      type="submit"
                      disabled={submittingPred}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-black text-xs uppercase tracking-wider shadow-lg cursor-pointer"
                    >
                      {submittingPred ? "Posting..." : `Post Prediction (🪙 ${predStake})`}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setShowPredictionModal(false);
                        openTokensModal();
                      }}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-[#ff3358] text-white font-black text-xs uppercase tracking-wider shadow-lg cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>Need {predStake} Coins &bull; Buy First</span>
                    </button>
                  )}

                  <span className="text-[11px] text-zinc-500 text-center block">
                    90% to winner &bull; 10% platform fee
                  </span>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
