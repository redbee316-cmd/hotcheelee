"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import PostCard from "@/components/feed/PostCard";
import { Search, Compass, FolderTree } from "lucide-react";
import { Suspense } from "react";
import { useSearchParams } from "next/navigation";

function DiscoverContent() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";
  const initialTag = searchParams.get("tag") || "";

  const [query, setQuery] = useState(initialQuery);
  const [activeTag, setActiveTag] = useState(initialTag);
  const [posts, setPosts] = useState<any[]>([]);
  const [topics, setTopics] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const tags = ["boudoir", "cosplay", "amateur", "latex", "fitness", "lingerie", "altgirl", "exclusive"];

  useEffect(() => {
    fetch("/api/topics")
      .then((r) => r.json())
      .then((d) => setTopics(d.topics?.slice(0, 4) || []));
  }, []);

  const searchData = async () => {
    setLoading(true);
    try {
      let url = "/api/posts?";
      if (activeTag) {
        url += `tag=${encodeURIComponent(activeTag)}&`;
      }
      if (query.trim()) {
        url += `q=${encodeURIComponent(query.trim())}&`;
      }
      const res = await fetch(url);
      const data = await res.json();
      setPosts(data.posts || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    searchData();
  }, [activeTag, initialQuery]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    searchData();
  };

  return (
    <main className="flex-1 max-w-2xl mx-auto w-full min-w-0">
      <div className="bg-gradient-to-r from-[#1f1325] via-[#161a25] to-[#121620] border border-[#2b273b] rounded-2xl p-5 mb-5 shadow-sm">
        <div className="flex items-center gap-2 mb-2">
          <Compass className="w-5 h-5 text-[#ff3358]" />
          <h1 className="text-xl font-black text-white">Discover Chily</h1>
        </div>
        <p className="text-xs text-zinc-300 mb-4 leading-relaxed">
          Find trending adult content, explore fetish and glamour topics, and connect with verified stars while earning $LEE.
        </p>

        <form onSubmit={handleSearchSubmit} className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search keywords, #tags, models, topics..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
          />
        </form>
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2.5 px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
            <FolderTree className="w-3.5 h-3.5 text-[#ff3358]" />
            Trending Communities
          </span>
          <Link href="/topics" className="text-[11px] text-[#ff3358] hover:underline font-semibold">
            All Topics &rarr;
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {topics.map((t) => (
            <Link
              key={t.id}
              href={`/topics/${t.slug}`}
              className="bg-[#13161f] border border-[#212735] hover:border-[#ff3358] rounded-xl p-3 transition group flex flex-col justify-between"
            >
              <div className="text-xl mb-1">{t.icon}</div>
              <h3 className="text-xs font-bold text-white group-hover:text-[#ff3358] truncate">
                #{t.name}
              </h3>
              <span className="text-[10px] text-zinc-500 mt-0.5">
                {(t.followersCount || 0).toLocaleString()} members
              </span>
            </Link>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-5 scrollbar-none">
        <button
          onClick={() => setActiveTag("")}
          className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
            !activeTag
              ? "bg-[#ff3358] text-white"
              : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
          }`}
        >
          All Tags
        </button>
        {tags.map((t) => (
          <button
            key={t}
            onClick={() => setActiveTag(t === activeTag ? "" : t)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              activeTag === t
                ? "bg-[#ff3358] text-white"
                : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
            }`}
          >
            #{t}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((n) => (
            <div
              key={n}
              className="bg-[#13161f] border border-[#212735] rounded-2xl p-4 animate-pulse h-64"
            />
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center space-y-2">
          <p className="text-sm text-zinc-300 font-bold">No posts found</p>
          <p className="text-xs text-zinc-500">
            Try searching for another term or click on the popular topic chips.
          </p>
        </div>
      ) : (
        <div>
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}
    </main>
  );
}

export default function DiscoverPage() {
  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />
        <Suspense fallback={<div className="flex-1 max-w-2xl mx-auto p-8 text-center text-zinc-500">Loading discovery...</div>}>
          <DiscoverContent />
        </Suspense>
        <RightSidebar />
      </div>
    </div>
  );
}
