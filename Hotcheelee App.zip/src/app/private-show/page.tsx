"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Lock,
  Coins,
  Clock,
  ShieldCheck,
  Check,
  Sparkles,
  Phone,
  Video,
  ArrowRight,
  Eye,
  MessageSquare,
  Flame,
} from "lucide-react";

function PrivateShowContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const modelIdParam = searchParams.get("modelId");
  const { currentUser, refreshUser, openTokensModal } = useApp();

  const [models, setModels] = useState<any[]>([]);
  const [selectedModel, setSelectedModel] = useState<any>(null);
  const [requestedMinutes, setRequestedMinutes] = useState(10);
  const [scheduledTime, setScheduledTime] = useState("Right Now (Immediate)");
  const [specialRequests, setSpecialRequests] = useState("");
  const [isSpyAllowed, setIsSpyAllowed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [activeSession, setActiveSession] = useState<any | null>(null);

  const pricePerMin = 30; // 30 tokens/min = KSh 300/min
  const totalTokens = requestedMinutes * pricePerMin;
  const totalKsh = totalTokens * 10;
  const userTokens = currentUser?.tokensBalance || 0;
  const hasEnoughTokens = userTokens >= totalTokens;

  useEffect(() => {
    fetch("/api/stars?type=creators")
      .then((r) => r.json())
      .then((d) => {
        if (d.stars) {
          setModels(d.stars);
          if (modelIdParam) {
            const found = d.stars.find((s: any) => String(s.id) === modelIdParam);
            if (found) setSelectedModel(found);
            else setSelectedModel(d.stars[0]);
          } else {
            setSelectedModel(d.stars[0]);
          }
        }
      });
  }, [modelIdParam]);

  const handleBookPrivateShow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedModel) return;

    if (!hasEnoughTokens) {
      openTokensModal();
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/private-show", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          modelId: selectedModel.id,
          requestedMinutes,
          scheduledTime,
          specialRequests,
          isSpyAllowed,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setActiveSession(data.show);
        await refreshUser();
      } else {
        alert(data.error || "Booking private show failed");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
      {/* Header Banner - Stripchat Private Show Clone */}
      <div className="bg-gradient-to-r from-[#211226] via-[#141829] to-[#0e121b] border border-[#ff3358]/40 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Lock className="w-6 h-6 text-[#ff3358]" />
            <h1 className="text-2xl font-black text-white">1-on-1 Private Show (Stripchat Mechanic)</h1>
          </div>
          <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
            Hire your favorite model for an intimate 1-on-1 private video session billed at 🪙 30 Tokens/min (KSh 300/min). Discrete, direct, and private.
          </p>
        </div>

        <div className="text-right bg-[#0e1118] border border-[#232938] p-3 rounded-xl">
          <span className="text-[11px] text-zinc-400 block font-medium">Your Tokens</span>
          <strong className="text-base font-black text-amber-400">🪙 {userTokens} Tokens</strong>
        </div>
      </div>

      {activeSession ? (
        /* LIVE PRIVATE ROOM ACTIVE VIEW */
        <div className="bg-[#121620] border-2 border-emerald-500 rounded-3xl p-6 shadow-2xl space-y-4 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-black text-xs uppercase">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Private 1-on-1 Room Active</span>
          </div>

          <h2 className="text-2xl font-black text-white">
            Connected with {selectedModel?.displayName}!
          </h2>
          <p className="text-xs text-zinc-300 max-w-md mx-auto">
            Room Secret Key: <strong className="font-mono text-amber-400 bg-black/40 px-2 py-0.5 rounded">{activeSession.roomSecret}</strong> &bull; Total Session: <strong>{activeSession.requestedMinutes} Minutes</strong>
          </p>

          <div className="relative aspect-video max-h-80 mx-auto rounded-2xl overflow-hidden bg-black border border-white/20 shadow-2xl">
            <img
              src={selectedModel?.coverImage || "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg"}
              alt="Model"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 p-4 flex flex-col justify-between text-left">
              <span className="bg-[#ff3358] text-white text-[10px] font-black uppercase px-2 py-0.5 rounded self-start">
                Live 1-on-1 Session
              </span>
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">{selectedModel?.displayName}</span>
                  <span className="text-xs text-zinc-300">Room Status: Encrypted</span>
                </div>
                <Link
                  href={`/messages?userId=${selectedModel?.id}`}
                  className="px-3.5 py-1.5 rounded-xl bg-[#2a7be4] text-white font-bold text-xs"
                >
                  Open Live Chat &rarr;
                </Link>
              </div>
            </div>
          </div>

          <button
            onClick={() => setActiveSession(null)}
            className="px-6 py-2 rounded-xl bg-[#1a2233] text-zinc-300 hover:text-white text-xs font-bold transition"
          >
            End Private Session
          </button>
        </div>
      ) : (
        /* BOOKING FORM */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* Left Column: Select Model */}
          <div className="md:col-span-5 bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-black uppercase text-white tracking-wider">
              1. Choose Performer
            </h3>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {models.map((m) => {
                const isSelected = selectedModel?.id === m.id;
                return (
                  <div
                    key={m.id}
                    onClick={() => setSelectedModel(m)}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                      isSelected
                        ? "border-[#ff3358] bg-[#ff3358]/10 text-white"
                        : "border-[#1e2434] bg-[#0e1118] text-zinc-300 hover:border-zinc-700"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={m.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                        alt={m.displayName}
                        className="w-10 h-10 rounded-full object-cover ring-1 ring-white/10 shrink-0"
                      />
                      <div className="truncate">
                        <span className="text-xs font-bold block truncate">{m.displayName}</span>
                        <span className="text-[10px] text-zinc-400">{m.locationArea || "Kilimani"}</span>
                      </div>
                    </div>

                    <span className="text-xs font-black text-amber-400 shrink-0">30 tk/min</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Configure Duration & Requests */}
          <div className="md:col-span-7 bg-[#121620] border border-[#232938] rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-black uppercase text-white tracking-wider pb-2 border-b border-[#212738]">
              2. Private Session Parameters
            </h3>

            <form onSubmit={handleBookPrivateShow} className="space-y-4">
              {/* Duration slider */}
              <div className="bg-[#0e1118] border border-[#212738] p-3.5 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-zinc-300 font-bold flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-400" />
                    Requested Duration: {requestedMinutes} Minutes
                  </span>
                  <span className="text-[11px] text-zinc-400">Min: 5 mins</span>
                </div>
                <input
                  type="range"
                  min={5}
                  max={60}
                  step={5}
                  value={requestedMinutes}
                  onChange={(e) => setRequestedMinutes(Number(e.target.value))}
                  className="w-full accent-[#ff3358] cursor-pointer"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">Schedule Time</label>
                <select
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                >
                  <option value="Right Now (Immediate)">Right Now (Immediate Session)</option>
                  <option value="Tonight 21:00">Tonight 21:00</option>
                  <option value="Tonight 23:00">Tonight 23:00</option>
                  <option value="Tomorrow Afternoon">Tomorrow Afternoon</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">
                  Special Requests / Outfit Preferences
                </label>
                <textarea
                  rows={2}
                  placeholder="Lingerie style, Lovense toy controls, specific roleplay..."
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
                />
              </div>

              {/* Stripchat Spy Mode checkbox */}
              <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isSpyAllowed}
                  onChange={(e) => setIsSpyAllowed(e.target.checked)}
                  className="accent-[#ff3358] w-4 h-4 rounded"
                />
                <span>Allow other fans to Spy on session for reduced tokens (Earn 10 tk bonus per spy)</span>
              </label>

              {/* Cost Breakdown */}
              <div className="bg-[#141b27] border border-[#223048] p-3.5 rounded-xl space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400">Rate:</span>
                  <span className="font-bold text-white">30 Tokens / Min</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400">Total Tokens:</span>
                  <strong className="text-amber-400 text-sm font-black">🪙 {totalTokens} Tokens</strong>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-[#1d273a]">
                  <span className="text-zinc-400">Equivalent in KSh:</span>
                  <strong className="text-emerald-400 font-black">KES {totalKsh.toLocaleString()}</strong>
                </div>
              </div>

              {hasEnoughTokens ? (
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3358] via-[#ff7700] to-[#ffaa00] hover:from-[#e11d48] text-white font-black text-xs uppercase tracking-wider shadow-lg cursor-pointer disabled:opacity-50"
                >
                  {submitting ? "Booking..." : `Start Private Show (${totalTokens} Tokens)`}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={openTokensModal}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-[#ff3358] text-white font-black text-xs uppercase tracking-wider shadow-lg cursor-pointer"
                >
                  Need {totalTokens} Tokens &bull; Buy Tokens First
                </button>
              )}
            </form>
          </div>
        </div>
      )}
    </main>
  );
}

export default function PrivateShowPage() {
  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />
        <Suspense fallback={<div className="flex-1 p-8 text-center text-zinc-500 text-xs">Loading Private Show...</div>}>
          <PrivateShowContent />
        </Suspense>
        <RightSidebar />
      </div>
    </div>
  );
}
