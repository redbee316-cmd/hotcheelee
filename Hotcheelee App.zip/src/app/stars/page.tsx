"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Star,
  Flame,
  UserPlus,
  Check,
  Sparkles,
  ExternalLink,
  Search,
  Coins,
  MapPin,
  Phone,
  MessageCircle,
  PhoneCall,
  Calendar,
  Filter,
  Zap,
} from "lucide-react";

export default function StarsPage() {
  const { openTipModal, openTipMenuModal, openToyModal, openContactModal, openAuthModal } = useApp();
  const [stars, setStars] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");
  const [serviceTypeFilter, setServiceTypeFilter] = useState("all");
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});

  const roles = [
    { id: "all", label: "All Orientations" },
    { id: "straight", label: "Straight Models" },
    { id: "gay", label: "Gay Performers" },
    { id: "transgender", label: "Transgender" },
    { id: "shemale", label: "Shemale (TS)" },
    { id: "queer", label: "Queer / Non-Binary" },
  ];

  const locations = ["all", "Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret"];
  const serviceTypes = ["all", "Incall", "Outcall", "Both Incall & Outcall"];

  const loadStars = async () => {
    setLoading(true);
    try {
      let url = "/api/stars?type=creators";
      if (roleFilter !== "all") url += `&role=${roleFilter}`;
      if (locationFilter !== "all") url += `&location=${locationFilter}`;
      if (serviceTypeFilter !== "all") url += `&serviceType=${serviceTypeFilter}`;
      if (search) url += `&q=${encodeURIComponent(search)}`;

      const res = await fetch(url);
      const data = await res.json();
      if (data.stars) {
        setStars(data.stars);
        const map: Record<string, boolean> = {};
        data.stars.forEach((s: any) => {
          map[s.username] = s.isFollowing;
        });
        setFollowingMap(map);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStars();
  }, [search, roleFilter, locationFilter, serviceTypeFilter]);

  const handleToggleFollow = async (username: string) => {
    const isFollowing = followingMap[username];
    setFollowingMap((prev) => ({ ...prev, [username]: !isFollowing }));

    try {
      await fetch(`/api/users/${username}/follow`, { method: "POST" });
    } catch (err) {
      console.error(err);
      setFollowingMap((prev) => ({ ...prev, [username]: isFollowing }));
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-[#22141f] via-[#161a25] to-[#121620] border border-[#2b273b] rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                <h1 className="text-2xl font-black text-white">HotCheelee Verified Creators</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-lg leading-relaxed">
                Connect with Straight, Gay, Transgender, Shemale & Queer companions in Kenya. Reveal WhatsApp / call numbers in 1 click, view KSh rates, and tip with tokens.
              </p>
            </div>

            <button
              onClick={() => openAuthModal("register_creator")}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white font-bold text-xs shadow-md transition cursor-pointer self-start sm:self-center shrink-0"
            >
              List as Creator (KSh 500/mo)
            </button>
          </div>

          {/* Role Orientation Filter Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {roles.map((r) => (
              <button
                key={r.id}
                onClick={() => setRoleFilter(r.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  roleFilter === r.id
                    ? "bg-[#ff3358] text-white shadow-sm"
                    : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>

          {/* Location & Service Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search name, area, service..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-[#121620] border border-[#232938] rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
            </div>

            <div>
              <select
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
                className="w-full bg-[#121620] border border-[#232938] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff3358]"
              >
                <option value="all">All Kenya Locations</option>
                {locations.filter((l) => l !== "all").map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>

            <div>
              <select
                value={serviceTypeFilter}
                onChange={(e) => setServiceTypeFilter(e.target.value)}
                className="w-full bg-[#121620] border border-[#232938] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff3358]"
              >
                <option value="all">All Service Modes</option>
                {serviceTypes.filter((s) => s !== "all").map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Creators Grid */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((n) => (
                <div key={n} className="bg-[#13161f] border border-[#212735] rounded-2xl h-64 animate-pulse" />
              ))}
            </div>
          ) : stars.length === 0 ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-10 text-center">
              <p className="text-zinc-400 text-sm">No creators found matching these filters.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {stars.map((star) => {
                const isFollowing = followingMap[star.username];
                return (
                  <div
                    key={star.id}
                    className="bg-[#13161f] border border-[#212735] hover:border-[#ff3358]/60 rounded-2xl overflow-hidden transition group flex flex-col justify-between shadow-sm"
                  >
                    {/* Cover Photo */}
                    <div className="relative h-28 bg-zinc-800">
                      <img
                        src={star.coverImage || "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg"}
                        alt="cover"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#13161f] via-black/20 to-transparent" />
                      <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5">
                        {star.genderRole && (
                          <span className="bg-black/70 backdrop-blur-md text-white text-[10px] font-black uppercase px-2 py-0.5 rounded border border-white/20">
                            {star.genderRole}
                          </span>
                        )}
                        <span className="bg-[#ff3358] text-white text-[9px] font-black uppercase px-2 py-0.5 rounded shadow">
                          ⭐ Verified
                        </span>
                      </div>
                    </div>

                    {/* Avatar and Info */}
                    <div className="p-4 pt-0 relative -mt-9 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="flex items-end justify-between mb-2">
                          <Link href={`/profile/${star.username}`} className="relative">
                            <img
                              src={star.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                              alt={star.displayName}
                              className="w-16 h-16 rounded-full object-cover ring-3 ring-[#13161f] border-2 border-[#ff3358]"
                            />
                          </Link>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => openToyModal(star.id, star.displayName)}
                              className="p-2 rounded-xl bg-[#1b202c] hover:bg-[#252c3e] text-amber-400 text-xs font-bold transition cursor-pointer"
                              title="Lovense Toy Control"
                            >
                              <Zap className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => openTipMenuModal(star.id, star.displayName)}
                              className="px-2.5 py-1.5 rounded-xl bg-[#1b202c] hover:bg-[#252c3e] text-[#ff3358] text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>Menu</span>
                            </button>
                            <button
                              onClick={() => handleToggleFollow(star.username)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                                isFollowing
                                  ? "bg-[#1c2230] text-zinc-300 hover:bg-[#252c3e]"
                                  : "bg-[#ff3358] hover:bg-[#e11d48] text-white"
                              }`}
                            >
                              {isFollowing ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-400" />
                                  <span>Following</span>
                                </>
                              ) : (
                                <>
                                  <UserPlus className="w-3 h-3" />
                                  <span>Follow</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>

                        <Link href={`/profile/${star.username}`} className="block">
                          <h3 className="text-base font-bold text-white group-hover:text-[#ff3358] transition truncate">
                            {star.displayName}
                          </h3>
                          <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5">
                            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                              <MapPin className="w-3 h-3 text-[#ff3358]" />
                              {star.locationArea || star.location || "Nairobi"}
                            </span>
                            <span>&bull;</span>
                            <span className="text-amber-400 font-bold">{star.serviceType || "Incall & Outcall"}</span>
                          </div>
                        </Link>

                        <p className="text-xs text-zinc-300 line-clamp-2 leading-relaxed mt-2">
                          {star.bio}
                        </p>

                        {/* Starting Price in KSh */}
                        {star.ratesList && star.ratesList.length > 0 && (
                          <div className="mt-2 text-xs text-zinc-400">
                            Rates from: <strong className="text-amber-400 font-black">KSh {star.ratesList[0].priceKsh.toLocaleString()}</strong> ({star.ratesList[0].duration})
                          </div>
                        )}
                      </div>

                      {/* 1-Click Reveal Contact Box */}
                      <div className="pt-3 border-t border-[#1e2330] flex items-center justify-between gap-2">
                        <button
                          onClick={() => openContactModal(star)}
                          className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#ff3358]/20"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Reveal Contact & WhatsApp</span>
                        </button>

                        <span className="text-[11px] font-mono text-zinc-400 hidden sm:inline">
                          {star.maskedPhone}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
