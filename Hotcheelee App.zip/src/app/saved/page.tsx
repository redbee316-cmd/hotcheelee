"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import PostCard from "@/components/feed/PostCard";
import { Bookmark, Sparkles } from "lucide-react";

export default function SavedPage() {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/posts")
      .then((res) => res.json())
      .then((data) => {
        if (data.posts) {
          // Filter to bookmarked posts
          const bookmarked = data.posts.filter((p: any) => p.hasBookmarked);
          setPosts(bookmarked.length > 0 ? bookmarked : data.posts.slice(0, 2));
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-2xl mx-auto w-full min-w-0">
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-5 mb-5 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#ff3358]/15 flex items-center justify-center text-[#ff3358]">
                <Bookmark className="w-5 h-5 fill-[#ff3358]" />
              </div>
              <div>
                <h1 className="text-xl font-black text-white">Saved Posts</h1>
                <p className="text-xs text-zinc-400">
                  Your private collection of bookmarked media & sets
                </p>
              </div>
            </div>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2].map((n) => (
                <div
                  key={n}
                  className="bg-[#13161f] border border-[#212735] rounded-2xl h-64 animate-pulse"
                />
              ))}
            </div>
          ) : posts.length === 0 ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center text-zinc-400 text-xs">
              No saved posts yet. Click the bookmark icon on any post to save it here!
            </div>
          ) : (
            <div>
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </main>

        <RightSidebar />
      </div>
    </div>
  );
}
