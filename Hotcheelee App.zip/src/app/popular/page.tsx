"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import PostCard from "@/components/feed/PostCard";
import { Flame } from "lucide-react";

export default function PopularPage() {
  const [timeFilter, setTimeFilter] = useState<"today" | "week" | "month" | "all">("today");
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch("/api/posts?filter=popular")
      .then((res) => res.json())
      .then((data) => {
        if (data.posts) {
          setPosts(data.posts);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [timeFilter]);

  const filters = [
    { id: "today" as const, label: "Today" },
    { id: "week" as const, label: "This Week" },
    { id: "month" as const, label: "This Month" },
    { id: "all" as const, label: "All Time" },
  ];

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-2xl mx-auto w-full min-w-0">
          <div className="bg-gradient-to-r from-[#21131a] via-[#161a25] to-[#121620] border border-[#2b273b] rounded-2xl p-5 mb-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Flame className="w-5 h-5 text-[#ff3358] fill-[#ff3358] animate-flame" />
                <h1 className="text-xl font-black text-white">Popular on Chily</h1>
              </div>
              <p className="text-xs text-zinc-400">
                The most flamed and shared adult content yielding highest $LEE rewards
              </p>
            </div>

            <div className="flex items-center bg-[#0e1118] border border-[#222837] p-1 rounded-xl">
              {filters.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setTimeFilter(f.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    timeFilter === f.id
                      ? "bg-[#ff3358] text-white shadow-sm"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2].map((n) => (
                <div
                  key={n}
                  className="bg-[#13161f] border border-[#212735] rounded-2xl p-4 animate-pulse h-64"
                />
              ))}
            </div>
          ) : (
            <div>
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </main>

        <RightSidebar />
      </div>
    </div>
  );
}
