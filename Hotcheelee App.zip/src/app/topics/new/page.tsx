"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { FolderTree, ArrowLeft, Sparkles, ShieldCheck, Plus, Check } from "lucide-react";
import Link from "next/link";

export default function NewTopicPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [tagline, setTagline] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("General");
  const [icon, setIcon] = useState("🔥");
  const [banner, setBanner] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const categories = ["General", "Amateur", "Cosplay", "Glamour", "Fitness", "Fashion", "Alternative"];

  const iconOptions = ["🔥", "💎", "🦊", "🍑", "🎀", "🖤", "📸", "⚡", "✨", "🎬", "🕶️", "👑"];

  const bannerPresets = [
    { label: "Glamour Boudoir", url: "https://images.pexels.com/photos/33282388/pexels-photo-33282388.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1400" },
    { label: "Nightlife & Neon", url: "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1400" },
    { label: "Alternative & Mood", url: "https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1400" },
    { label: "Fitness & Body", url: "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1400" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Topic name is required");
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const res = await fetch("/api/topics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          tagline: tagline.trim() || `The official community for #${name.trim()}`,
          description: description.trim() || `Welcome to the #${name.trim()} community on HotCheelee Kenya. Share authentic content, interact with creators and earn tokens.`,
          category,
          icon,
          banner: banner.trim() || bannerPresets[0].url,
          rules: [
            "18+ only. Strict compliance with 18 U.S.C. 2257 applies to all performers.",
            "Only post original content or properly credited media.",
            "Respect creators and engage positively.",
            "Drive promo traffic using the designated link banner."
          ],
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to create topic");
      }

      router.push(`/topics/${data.topic.slug}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-2xl mx-auto w-full min-w-0">
          <div className="mb-4">
            <Link
              href="/topics"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition mb-3"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Topics</span>
            </Link>

            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-1.5">
                <FolderTree className="w-5 h-5 text-[#ff3358]" />
                <h1 className="text-xl font-black text-white">Create New Community Topic</h1>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed mb-6">
                Found a new adult niche, fetish, or creator circle on Chily? Start a topic to aggregate photos, videos, and let members earn $LEE while viewing.
              </p>

              {error && (
                <div className="mb-5 p-3.5 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-400">
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Topic Name *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Vintage Lingerie, Neon Cyber, Studio Amateurs"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Tagline (Short Summary)
                  </label>
                  <input
                    type="text"
                    placeholder="One-line summary shown in cards..."
                    value={tagline}
                    onChange={(e) => setTagline(e.target.value)}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Description & About
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Describe what kind of media belongs in this topic, what creators should post, etc."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358] resize-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">
                      Category
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-[#ff3358]"
                    >
                      {categories.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">
                      Choose Topic Icon
                    </label>
                    <div className="flex items-center gap-1.5 flex-wrap bg-[#0e1118] border border-[#262c3b] rounded-xl p-1.5">
                      {iconOptions.map((ico) => (
                        <button
                          key={ico}
                          type="button"
                          onClick={() => setIcon(ico)}
                          className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm transition ${
                            icon === ico
                              ? "bg-[#ff3358] shadow-sm text-white scale-110"
                              : "hover:bg-[#1a202c]"
                          }`}
                        >
                          {ico}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Banner Image URL
                  </label>
                  <input
                    type="url"
                    placeholder="https://images.pexels.com/...jpg"
                    value={banner}
                    onChange={(e) => setBanner(e.target.value)}
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
                  />
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <span className="text-[10px] text-zinc-500">Suggested Banners:</span>
                    {bannerPresets.map((b) => (
                      <button
                        key={b.label}
                        type="button"
                        onClick={() => setBanner(b.url)}
                        className="text-[10px] bg-[#1a202c] hover:bg-[#252c3e] text-zinc-300 border border-[#283042] px-2 py-0.5 rounded"
                      >
                        {b.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-[#1e2330] flex items-center justify-between">
                  <span className="text-[11px] text-zinc-500 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Auto-moderated 18+ space
                  </span>

                  <div className="flex items-center gap-2">
                    <Link
                      href="/topics"
                      className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white bg-[#191e2b] hover:bg-[#232a3d] transition"
                    >
                      Cancel
                    </Link>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ff5033] hover:from-[#e11d48] shadow-md shadow-[#ff3358]/20 transition cursor-pointer"
                    >
                      {submitting ? "Creating..." : "Publish Topic"}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </main>

        <RightSidebar />
      </div>
    </div>
  );
}
