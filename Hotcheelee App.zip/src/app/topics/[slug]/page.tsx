"use client";

import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import PostCard from "@/components/feed/PostCard";
import { useApp } from "@/context/AppContext";
import {
  FolderTree,
  Users,
  MessageSquare,
  Check,
  Plus,
  ShieldCheck,
  Flame,
  Sparkles,
  Info,
} from "lucide-react";

export default function TopicDetailPage() {
  const params = useParams();
  const slug = params.slug as string;
  const { openCreatePostModal, postRefreshCounter } = useApp();

  const [topic, setTopic] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isJoined, setIsJoined] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);

  const loadTopicData = async () => {
    setLoading(true);
    try {
      const [tRes, pRes] = await Promise.all([
        fetch(`/api/topics/${slug}`),
        fetch(`/api/posts?topic=${slug}`),
      ]);

      const tData = await tRes.json();
      const pData = await pRes.json();

      if (tData.topic) {
        setTopic(tData.topic);
        setIsJoined(tData.topic.isJoined);
        setFollowersCount(tData.topic.followersCount);
      }
      if (pData.posts) {
        setPosts(pData.posts);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTopicData();
  }, [slug, postRefreshCounter]);

  const handleToggleJoin = async () => {
    try {
      const res = await fetch(`/api/topics/${slug}/join`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setIsJoined(data.isJoined);
        setFollowersCount(data.followersCount);
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!topic && !loading) {
    return (
      <div className="min-h-screen bg-[#0c0e12] py-12 text-center text-white">
        <h2 className="text-xl font-bold">Topic not found</h2>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-2xl mx-auto w-full min-w-0">
          {/* Topic Hero Card */}
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl overflow-hidden mb-6 shadow-sm">
            <div className="relative h-36 sm:h-44 bg-zinc-800">
              <img
                src={topic?.banner || "https://images.pexels.com/photos/18570527/pexels-photo-18570527.jpeg"}
                alt={topic?.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#13161f] via-black/40 to-transparent" />
            </div>

            <div className="p-4 sm:p-5 relative -mt-10 sm:-mt-12 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div className="flex items-end gap-3.5">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#191e2b] border-2 border-[#ff3358] flex items-center justify-center text-3xl sm:text-4xl shadow-xl shrink-0">
                  {topic?.icon || "🔥"}
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                    #{topic?.name}
                  </h1>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    {followersCount.toLocaleString()} followers &bull; {topic?.category}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleToggleJoin}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    isJoined
                      ? "bg-[#1c2230] text-zinc-200 hover:bg-[#252c3e]"
                      : "bg-[#ff3358] hover:bg-[#e11d48] text-white shadow-md shadow-[#ff3358]/25"
                  }`}
                >
                  {isJoined ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Joined</span>
                    </>
                  ) : (
                    <span>Join Topic</span>
                  )}
                </button>

                <button
                  onClick={() => openCreatePostModal(topic?.id)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ff5033] hover:from-[#e11d48] hover:to-[#ea580c] shadow-md shadow-[#ff3358]/25 flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Post Here</span>
                </button>
              </div>
            </div>

            {/* Description */}
            <div className="px-5 pb-5">
              <p className="text-xs text-zinc-300 leading-relaxed">
                {topic?.description || topic?.tagline}
              </p>
            </div>
          </div>

          {/* Topic Feed */}
          {loading ? (
            <div className="space-y-4">
              {[1, 2].map((n) => (
                <div
                  key={n}
                  className="bg-[#13161f] border border-[#212735] rounded-2xl p-4 animate-pulse h-64"
                />
              ))}
            </div>
          ) : posts.length === 0 ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center space-y-3">
              <p className="text-zinc-300 text-sm font-bold">No posts in #{topic?.name} yet</p>
              <p className="text-xs text-zinc-500">
                Be the first creator to share your content in this topic!
              </p>
              <button
                onClick={() => openCreatePostModal(topic?.id)}
                className="px-4 py-2 rounded-xl bg-[#ff3358] text-white text-xs font-bold shadow-md cursor-pointer"
              >
                Create First Post
              </button>
            </div>
          ) : (
            <div>
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </main>

        {/* Right Topic Rules & Moderation Sidebar */}
        <aside className="w-80 shrink-0 hidden xl:block sticky top-20 self-start space-y-5">
          {/* Rules Card */}
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-5 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5 mb-3.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Community Rules & Guidelines
            </h3>

            <div className="space-y-2.5">
              {(topic?.rulesList || []).map((rule: string, i: number) => (
                <div key={i} className="flex items-start gap-2 text-xs text-zinc-300">
                  <span className="font-bold text-[#ff3358]">{i + 1}.</span>
                  <span className="leading-snug">{rule}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-[#1e2330] text-[11px] text-zinc-500 leading-snug">
              All records required by 18 U.S.C. 2257 are maintained by the records custodian.
            </div>
          </div>

          {/* Quick Tip Box */}
          <div className="bg-gradient-to-br from-[#1c1220] to-[#12151f] border border-[#302133] rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="w-4 h-4 text-[#ff3358]" />
              <span className="text-xs font-bold text-white">Promote in Topics</span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed mb-3">
              Topics give adult creators up to 10x higher organic reach than algorithmic feeds. Add your OnlyFans or paysite link below every post.
            </p>
            <button
              onClick={() => openCreatePostModal(topic?.id)}
              className="w-full py-2 rounded-xl bg-[#ff3358] hover:bg-[#e11d48] text-white text-xs font-bold transition shadow-sm cursor-pointer"
            >
              Post to #{topic?.name}
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
