"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { FolderTree, Plus, Users, MessageSquare, Check, Search, ShieldCheck } from "lucide-react";

export default function TopicsPage() {
  const [topics, setTopics] = useState<any[]>([]);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState<Record<string, boolean>>({});

  const categories = ["All", "Amateur", "Cosplay", "Glamour", "Fitness", "Fashion", "Alternative"];

  const loadTopics = async () => {
    setLoading(true);
    try {
      let url = "/api/topics?";
      if (category !== "All") url += `category=${category}&`;
      if (search) url += `q=${encodeURIComponent(search)}&`;

      const res = await fetch(url);
      const data = await res.json();
      setTopics(data.topics || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTopics();
  }, [category, search]);

  const handleToggleJoin = async (slug: string, e: React.MouseEvent) => {
    e.preventDefault();
    setJoining((prev) => ({ ...prev, [slug]: true }));

    try {
      const res = await fetch(`/api/topics/${slug}/join`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setTopics((prev) =>
          prev.map((t) =>
            t.slug === slug
              ? { ...t, isJoined: data.isJoined, followersCount: data.followersCount }
              : t
          )
        );
      }
    } catch (err) {
      console.error(err);
    } finally {
      setJoining((prev) => ({ ...prev, [slug]: false }));
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#1b1526] via-[#141722] to-[#10131d] border border-[#262c3b] rounded-2xl p-6 mb-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <FolderTree className="w-5 h-5 text-[#ff3358]" />
                <h1 className="text-2xl font-black text-white">Chily Topics</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-lg leading-relaxed">
                Join interest-based adult communities, post photos and videos, and connect with fans of specific kinks, glamour, and styles.
              </p>
            </div>

            <Link
              href="/topics/new"
              className="py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] shadow-md shadow-[#ff3358]/25 flex items-center justify-center gap-2 transition cursor-pointer self-start sm:self-center"
            >
              <Plus className="w-4 h-4" />
              <span>Create Topic</span>
            </Link>
          </div>

          {/* Filter and Search Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6">
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 scrollbar-none">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    category === c
                      ? "bg-[#ff3358] text-white shadow-sm"
                      : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search topics..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-[#13161f] border border-[#232938] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
            </div>
          </div>

          {/* Topics Grid */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((n) => (
                <div
                  key={n}
                  className="bg-[#13161f] border border-[#212735] rounded-2xl h-44 animate-pulse"
                />
              ))}
            </div>
          ) : topics.length === 0 ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-10 text-center">
              <p className="text-zinc-400 text-sm">No topics match your filter.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {topics.map((topic) => (
                <Link
                  key={topic.id}
                  href={`/topics/${topic.slug}`}
                  className="bg-[#13161f] border border-[#212735] hover:border-[#ff3358]/70 rounded-2xl overflow-hidden transition group flex flex-col justify-between"
                >
                  <div className="relative h-24 bg-zinc-800 overflow-hidden">
                    <img
                      src={topic.banner || "https://images.pexels.com/photos/18570527/pexels-photo-18570527.jpeg"}
                      alt={topic.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#13161f] via-black/40 to-transparent" />
                    <span className="absolute top-2.5 right-2.5 text-[10px] font-black uppercase tracking-wider bg-black/60 backdrop-blur-md px-2 py-0.5 rounded text-amber-400 border border-white/10">
                      {topic.category}
                    </span>
                  </div>

                  <div className="p-4 pt-1 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xl">{topic.icon}</span>
                        <h3 className="text-base font-bold text-white group-hover:text-[#ff3358] transition">
                          #{topic.name}
                        </h3>
                      </div>
                      <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed mb-4">
                        {topic.tagline || topic.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-[#1d222f]">
                      <div className="flex items-center gap-3 text-[11px] text-zinc-500">
                        <span className="flex items-center gap-1 font-semibold text-zinc-300">
                          <Users className="w-3.5 h-3.5 text-zinc-400" />
                          {(topic.followersCount || 0).toLocaleString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-3.5 h-3.5 text-zinc-400" />
                          {(topic.postsCount || 0).toLocaleString()} posts
                        </span>
                      </div>

                      <button
                        onClick={(e) => handleToggleJoin(topic.slug, e)}
                        disabled={joining[topic.slug]}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                          topic.isJoined
                            ? "bg-[#1c2230] text-zinc-300 hover:bg-[#252c3e]"
                            : "bg-[#ff3358] hover:bg-[#e11d48] text-white shadow-sm shadow-[#ff3358]/20"
                        }`}
                      >
                        {topic.isJoined ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span>Joined</span>
                          </>
                        ) : (
                          <span>Join</span>
                        )}
                      </button>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
