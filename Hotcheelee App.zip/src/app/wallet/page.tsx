"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Coins,
  Flame,
  ArrowUpRight,
  ArrowDownLeft,
  Gift,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  CreditCard,
  Phone,
  Calendar,
  Check,
  AlertCircle,
  Plus,
} from "lucide-react";

export default function WalletPage() {
  const { currentUser, refreshUser, openTokensModal, openUpgradeModal } = useApp();
  const [boxes, setBoxes] = useState<any[]>([]);
  const [withdrawalsList, setWithdrawalsList] = useState<any[]>([]);
  const [depositsList, setDepositsList] = useState<any[]>([]);
  const [subData, setSubData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [openingBoxId, setOpeningBoxId] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Manual Deposit form state (KSh)
  const [depositAmountKsh, setDepositAmountKsh] = useState("1000");
  const [depositMpesaCode, setDepositMpesaCode] = useState("");
  const [depositPhone, setDepositPhone] = useState(currentUser?.phone || "+254 7");
  const [submittingDeposit, setSubmittingDeposit] = useState(false);

  // Manual M-Pesa Withdrawal form state (Strictly validates available balance)
  const [withdrawTokens, setWithdrawTokens] = useState("100");
  const [mpesaPhone, setMpesaPhone] = useState(currentUser?.phone || "+254 7");
  const [submittingWithdraw, setSubmittingWithdraw] = useState(false);
  const [withdrawError, setWithdrawError] = useState<string | null>(null);

  // M-Pesa 30-Day Subscription submission state
  const [subMpesaCode, setSubMpesaCode] = useState("");
  const [subPhone, setSubPhone] = useState(currentUser?.phone || "+254 7");
  const [subPlan, setSubPlan] = useState<"creator_500" | "agency_1500">(
    currentUser?.accountType === "agency" ? "agency_1500" : "creator_500"
  );
  const [submittingSub, setSubmittingSub] = useState(false);

  const loadData = async () => {
    try {
      const [bRes, wRes, sRes, dRes] = await Promise.all([
        fetch("/api/boxes"),
        fetch("/api/withdrawals"),
        fetch("/api/subscriptions"),
        fetch("/api/wallet/deposit"),
      ]);
      const bData = await bRes.json();
      const wData = await wRes.json();
      const sData = await sRes.json();
      const dData = await dRes.json();

      if (bData.boxes) setBoxes(bData.boxes);
      if (wData.withdrawals) setWithdrawalsList(wData.withdrawals);
      if (sData) setSubData(sData);
      if (dData.deposits) setDepositsList(dData.deposits);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenBox = async (boxId: number) => {
    setOpeningBoxId(boxId);
    try {
      const res = await fetch("/api/boxes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "open_box", boxId }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(data.message);
        await refreshUser();
        await loadData();
      } else {
        alert(data.error || "Failed to open box");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setOpeningBoxId(null);
    }
  };

  // Submit Manual Deposit to Admin for verification
  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!depositMpesaCode.trim()) {
      alert("Please provide the M-Pesa transaction code");
      return;
    }

    setSubmittingDeposit(true);
    try {
      const res = await fetch("/api/wallet/deposit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amountKsh: Number(depositAmountKsh),
          mpesaCode: depositMpesaCode.trim().toUpperCase(),
          phonePaid: depositPhone.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotice(data.message);
        setDepositMpesaCode("");
        await loadData();
      } else {
        alert(data.error || "Deposit submission failed");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmittingDeposit(false);
    }
  };

  // Submit M-Pesa Payout: Strictly forbids withdrawing what you don't have
  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError(null);

    const count = Number(withdrawTokens);
    const available = currentUser?.tokensBalance || 0;

    // Strict validation
    if (!count || count < 50) {
      setWithdrawError("Minimum withdrawal is 50 Tokens (KSh 500)");
      return;
    }

    if (count > available) {
      setWithdrawError(
        `Forbidden! You attempted to withdraw ${count} tokens, but you only have ${available} tokens in your wallet. It is strictly forbidden to withdraw excess funds.`
      );
      return;
    }

    setSubmittingWithdraw(true);
    try {
      const res = await fetch("/api/withdrawals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tokenCount: count,
          mpesaPhone: mpesaPhone.trim(),
          method: "M-Pesa Kenya",
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setNotice(data.message);
        await refreshUser();
        await loadData();
      } else {
        setWithdrawError(data.error || "Withdrawal failed");
      }
    } catch (err: any) {
      setWithdrawError(err.message);
    } finally {
      setSubmittingWithdraw(false);
    }
  };

  // Submit manual M-Pesa Subscription (KSh 500 / KSh 1,500)
  const handleSubSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subMpesaCode.trim()) {
      alert("Please enter the M-Pesa confirmation code received via SMS");
      return;
    }

    setSubmittingSub(true);
    try {
      const amountKsh = subPlan === "agency_1500" ? 1500 : 500;
      const res = await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mpesaCode: subMpesaCode.trim().toUpperCase(),
          phonePaid: subPhone.trim(),
          amountKsh,
          plan: subPlan,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setNotice(data.message);
        setSubMpesaCode("");
        await refreshUser();
        await loadData();
      } else {
        alert(data.error || "Submission failed");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmittingSub(false);
    }
  };

  const tokenValuationKsh = (currentUser?.tokensBalance || 0) * 10;
  const daysRemaining = subData?.daysRemaining ?? 0;
  const isExpiringSoon = subData?.isExpiringSoon || (daysRemaining <= 5 && daysRemaining > 0);

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-6">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-[#21141c] via-[#161a25] to-[#121620] border border-[#2b273b] rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-1.5">
              <Coins className="w-6 h-6 text-amber-400" />
              <h1 className="text-2xl font-black text-white">HotCheelee Manual Wallet (Kenyan KSh)</h1>
            </div>
            <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
              Normal manual wallet moderated by administration. Deposits & withdrawals are reviewed and approved.{" "}
              <strong className="text-amber-400">1 Token = 10 KSh</strong>. Transact only with available funds.
            </p>
          </div>

          {notice && (
            <div className="p-4 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span className="font-bold">{notice}</span>
              </div>
              <button onClick={() => setNotice(null)} className="text-zinc-400 hover:text-white">✕</button>
            </div>
          )}

          {/* PROMINENT 5-DAY SUBSCRIPTION COUNTDOWN (5 to 0 days) */}
          {isExpiringSoon && (
            <div className="bg-gradient-to-r from-red-600/30 via-[#ff3358]/25 to-amber-500/20 border-2 border-red-500 rounded-2xl p-5 shadow-xl animate-pulse space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-red-400 font-black text-sm uppercase tracking-wider">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                  <span>Subscription Expiring Soon!</span>
                </div>
                <span className="bg-red-500 text-white font-black px-3 py-1 rounded-full text-xs">
                  Countdown: {daysRemaining} Days Left
                </span>
              </div>

              <p className="text-xs text-zinc-200 leading-relaxed">
                Your 30-day listing will expire in <strong>{daysRemaining} day{daysRemaining > 1 ? "s" : ""}</strong>. A renewal reminder has been dispatched to your email (<strong>{currentUser?.email}</strong>) and notifications. If not renewed, your account will automatically be <strong>reduced to browsing only</strong>.
              </p>

              {/* Countdown Digits */}
              <div className="grid grid-cols-4 gap-2 text-center py-1">
                <div className="bg-[#121622] p-2 rounded-xl border border-red-500/40">
                  <span className="text-2xl font-black text-red-400 block">{daysRemaining}</span>
                  <span className="text-[10px] uppercase font-bold text-zinc-400">Days</span>
                </div>
                <div className="bg-[#121622] p-2 rounded-xl border border-red-500/40">
                  <span className="text-2xl font-black text-amber-400 block">{subData?.hoursRemaining || daysRemaining * 24}</span>
                  <span className="text-[10px] uppercase font-bold text-zinc-400">Hours</span>
                </div>
                <div className="bg-[#121622] p-2 rounded-xl border border-red-500/40">
                  <span className="text-2xl font-black text-white block">Till</span>
                  <span className="text-[10px] uppercase font-bold text-zinc-400">8923411</span>
                </div>
                <div className="bg-[#121622] p-2 rounded-xl border border-red-500/40">
                  <span className="text-2xl font-black text-emerald-400 block">KSh 500</span>
                  <span className="text-[10px] uppercase font-bold text-zinc-400">Renew</span>
                </div>
              </div>
            </div>
          )}

          {/* 30-Day Subscription Status Box */}
          <div className="bg-gradient-to-br from-[#181324] via-[#131722] to-[#0e111a] border border-[#ff3358]/40 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    30-Day Subscription Status
                  </h3>
                  <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                    subData?.status === "active" ? "bg-emerald-500/20 text-emerald-400" : subData?.status === "pending" ? "bg-amber-400/20 text-amber-400" : "bg-red-500/20 text-red-400"
                  }`}>
                    {subData?.status || "inactive"}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  M-Pesa Buy Goods Till: <strong className="text-amber-400">{subData?.tillDetails?.tillNumber || "8923411"}</strong> &bull; Creators: KSh 500/mo &bull; Agencies: KSh 1,500/mo
                </p>
              </div>

              {subData?.status === "active" && (
                <div className="text-right">
                  <span className="text-[11px] text-zinc-400 block">Subscription Duration:</span>
                  <span className="text-base font-black text-emerald-400">
                    {daysRemaining} Days Left
                  </span>
                </div>
              )}
            </div>

            {/* Manual M-Pesa Code Submission */}
            <form onSubmit={handleSubSubmit} className="bg-[#0e1118] border border-[#212738] p-4 rounded-xl space-y-3">
              <span className="text-xs font-bold text-white block">
                Pay or Renew 30-Day Subscription (Till: 8923411)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[11px] font-bold text-zinc-400 block mb-1">Plan</label>
                  <select
                    value={subPlan}
                    onChange={(e: any) => setSubPlan(e.target.value)}
                    className="w-full bg-[#141822] border border-[#2b3345] rounded-lg px-3 py-1.5 text-xs text-white"
                  >
                    <option value="creator_500">Creator (KSh 500 / 30 Days)</option>
                    <option value="agency_1500">Agency / Parlour (KSh 1,500 / 30 Days)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-zinc-400 block mb-1">M-Pesa Code *</label>
                  <input
                    type="text"
                    placeholder="e.g. SHB492X1KL"
                    value={subMpesaCode}
                    onChange={(e) => setSubMpesaCode(e.target.value)}
                    required
                    className="w-full bg-[#141822] border border-amber-400/50 rounded-lg px-3 py-1.5 text-xs text-white font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-zinc-400 block mb-1">Your M-Pesa Phone *</label>
                  <input
                    type="text"
                    placeholder="0712345678"
                    value={subPhone}
                    onChange={(e) => setSubPhone(e.target.value)}
                    required
                    className="w-full bg-[#141822] border border-[#2b3345] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-zinc-500">
                  Admin reviews & activates 30-day period. Unlocks upload, posting & contacts.
                </span>
                <button
                  type="submit"
                  disabled={submittingSub}
                  className="py-1.5 px-4 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold shadow cursor-pointer disabled:opacity-50"
                >
                  {submittingSub ? "Submitting..." : "Activate for 30 Days"}
                </button>
              </div>
            </form>
          </div>

          {/* Current Wallet Balances */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#13161f] border border-[#212735] hover:border-amber-400/50 rounded-2xl p-5 transition shadow-sm">
              <span className="text-xs font-semibold text-zinc-400 block mb-1">Available Tokens</span>
              <div className="flex items-center gap-2 text-3xl font-black text-amber-400">
                <span>{currentUser?.tokensBalance ?? 350}</span>
                <span className="text-xs uppercase tracking-wider text-amber-400">Tokens</span>
              </div>
              <span className="text-[11px] text-zinc-500 mt-2 block">
                ≈ KSh {tokenValuationKsh.toLocaleString()}
              </span>
            </div>

            <div className="bg-[#13161f] border border-[#212735] hover:border-emerald-400/50 rounded-2xl p-5 transition shadow-sm">
              <span className="text-xs font-semibold text-zinc-400 block mb-1">Withdrawable Cash</span>
              <div className="flex items-center gap-2 text-3xl font-black text-emerald-400">
                <span>KSh {tokenValuationKsh.toLocaleString()}</span>
              </div>
              <span className="text-[11px] text-zinc-500 mt-2 block">
                1 Token = 10 KSh M-Pesa Payout
              </span>
            </div>

            <div className="bg-[#13161f] border border-[#212735] hover:border-purple-400/50 rounded-2xl p-5 transition shadow-sm">
              <span className="text-xs font-semibold text-zinc-400 block mb-1">Flames Credits</span>
              <div className="flex items-center gap-2 text-3xl font-black text-purple-400">
                <span>{currentUser?.flamesBalance || 0}</span>
                <span className="text-xs uppercase tracking-wider text-purple-400">Flames</span>
              </div>
              <span className="text-[11px] text-zinc-500 mt-2 block">
                In-app tipping & rewards
              </span>
            </div>
          </div>

          {/* SECTION: Manual M-Pesa Deposit to Wallet */}
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400" />
                  Manual Wallet Deposit (M-Pesa Kenya)
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Send M-Pesa to Till <strong className="text-white">8923411</strong>, submit code below. Admin confirms and credits your tokens.
                </p>
              </div>

              <span className="text-xs text-amber-400 font-bold bg-amber-400/10 px-2.5 py-1 rounded-full">
                10 KSh = 1 Token
              </span>
            </div>

            <form onSubmit={handleDepositSubmit} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[11px] font-bold text-zinc-400 block mb-1">Amount (KSh) *</label>
                  <input
                    type="number"
                    min={100}
                    step={50}
                    value={depositAmountKsh}
                    onChange={(e) => setDepositAmountKsh(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                  />
                  <span className="text-[10px] text-emerald-400 mt-0.5 block">
                    Credits: {Math.floor(Number(depositAmountKsh) / 10 || 0)} Tokens
                  </span>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-zinc-400 block mb-1">M-Pesa Transaction Code *</label>
                  <input
                    type="text"
                    placeholder="e.g. QLK921X4AA"
                    value={depositMpesaCode}
                    onChange={(e) => setDepositMpesaCode(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-amber-400/50 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-zinc-400 block mb-1">Paid From Phone *</label>
                  <input
                    type="text"
                    placeholder="0712345678"
                    value={depositPhone}
                    onChange={(e) => setDepositPhone(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-zinc-500">
                  Moderated by Admin against Till 8923411 statements.
                </span>

                <button
                  type="submit"
                  disabled={submittingDeposit}
                  className="py-2 px-5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white text-xs font-bold shadow cursor-pointer disabled:opacity-50"
                >
                  {submittingDeposit ? "Submitting..." : `Submit Deposit of KSh ${depositAmountKsh}`}
                </button>
              </div>
            </form>
          </div>

          {/* SECTION: Manual M-Pesa Withdrawal (Strictly Validated: Cannot Withdraw More than Available) */}
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-[#ff3358]" />
                  Manual Creator M-Pesa Withdrawal (KSh)
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Redeem earned tokens into cash sent to your phone. It is forbidden to withdraw excess funds.
                </p>
              </div>

              <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                <ShieldCheck className="w-4 h-4" />
                Moderated M-Pesa Payout
              </span>
            </div>

            {withdrawError && (
              <div className="mb-4 p-3 bg-red-500/15 border border-red-500/40 rounded-xl text-xs text-red-400 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{withdrawError}</span>
              </div>
            )}

            <form onSubmit={handleWithdrawSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Tokens to Redeem (Max: {currentUser?.tokensBalance || 0} tk) *
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={currentUser?.tokensBalance || 0}
                    step={10}
                    value={withdrawTokens}
                    onChange={(e) => setWithdrawTokens(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2.5 text-xs text-white"
                  />
                  <span className="text-[10px] text-emerald-400 mt-1 block font-bold">
                    Payout Amount: KSh {(Number(withdrawTokens) * 10 || 0).toLocaleString()} via M-Pesa
                  </span>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    Recipient M-Pesa Phone Number *
                  </label>
                  <input
                    type="text"
                    placeholder="0712345678"
                    value={mpesaPhone}
                    onChange={(e) => setMpesaPhone(e.target.value)}
                    required
                    className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3.5 py-2.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-zinc-500">
                  Admin approves & disburses to M-Pesa within 1-2 hours.
                </span>

                <button
                  type="submit"
                  disabled={submittingWithdraw || (currentUser?.tokensBalance || 0) < 50}
                  className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] hover:from-[#e11d48] text-white text-xs font-bold shadow-md cursor-pointer disabled:opacity-50"
                >
                  {submittingWithdraw ? "Submitting..." : `Withdraw KSh ${(Number(withdrawTokens) * 10 || 0).toLocaleString()} to M-Pesa`}
                </button>
              </div>
            </form>
          </div>

          {/* Transaction Ledger: Deposits & Withdrawals */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Deposits Ledger */}
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-5 space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-emerald-400">
                Deposit Submissions
              </h3>
              {depositsList.length === 0 ? (
                <div className="py-6 text-center text-xs text-zinc-500">No deposits recorded.</div>
              ) : (
                <div className="divide-y divide-[#1e2330]">
                  {depositsList.map((d) => (
                    <div key={d.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white block">+KSh {d.amountKsh} (+{d.tokensCredited} tk)</span>
                        <span className="text-[10px] text-zinc-400 font-mono">Ref: {d.mpesaCode}</span>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${d.status === "approved" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-400/20 text-amber-400"}`}>
                        {d.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Withdrawals Ledger */}
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-5 space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-[#ff3358]">
                M-Pesa Payout Ledger
              </h3>
              {withdrawalsList.length === 0 ? (
                <div className="py-6 text-center text-xs text-zinc-500">No withdrawals requested yet.</div>
              ) : (
                <div className="divide-y divide-[#1e2330]">
                  {withdrawalsList.map((w) => (
                    <div key={w.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white block">
                          -KSh {(w.amountKsh || Number(w.amount) * 10).toLocaleString()}
                        </span>
                        <span className="text-[10px] text-zinc-400">To: {w.destinationAddress}</span>
                      </div>
                      <div className="text-right">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${w.status === "Completed" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-400/20 text-amber-400"}`}>
                          {w.status}
                        </span>
                        {w.mpesaReceipt && (
                          <span className="text-[9px] text-zinc-400 font-mono block mt-0.5">{w.mpesaReceipt}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
