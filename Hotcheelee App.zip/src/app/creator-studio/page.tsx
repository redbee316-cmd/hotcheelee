"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  TrendingUp,
  BarChart3,
  DollarSign,
  Coins,
  Users,
  Eye,
  Heart,
  Calendar,
  Sparkles,
  CreditCard,
  Plus,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Layers,
  Video,
} from "lucide-react";

export default function CreatorStudioPage() {
  const { currentUser, openWalletModal, openCreatePostModal, openCreateQuickieModal, openUpgradeModal } = useApp();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/creator-studio")
      .then((r) => r.json())
      .then((d) => setData(d))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const isBrowsing = currentUser?.accountType === "browsing";

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header Banner - Facebook Creator Studio Clone */}
          <div className="bg-gradient-to-r from-[#1b1528] via-[#141928] to-[#0e121b] border border-[#ff3358]/40 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <BarChart3 className="w-6 h-6 text-[#ff3358]" />
                <h1 className="text-2xl font-black text-white">Creator Studio & Professional Dashboard</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
                Facebook-style insights, video analytics, token revenue breakdown, and 30-day listing management.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => openCreatePostModal()}
                className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow cursor-pointer"
              >
                + Create Content
              </button>
              <button
                onClick={openCreateQuickieModal}
                className="py-2 px-3 rounded-xl bg-[#1c2334] hover:bg-[#25324d] text-zinc-300 hover:text-white text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <Video className="w-3.5 h-3.5 text-amber-400" />
                <span>+ 9:16 Quickie</span>
              </button>
            </div>
          </div>

          {/* If free browsing account, prompt upgrade */}
          {isBrowsing && (
            <div className="bg-gradient-to-r from-amber-500/20 to-[#ff3358]/20 border border-amber-400/40 p-4 rounded-2xl flex items-center justify-between gap-3 text-xs">
              <div>
                <span className="font-black text-amber-300 block text-sm">You are currently in Free Browsing Mode</span>
                <p className="text-zinc-300">Upgrade to Creator (KSh 500/mo) or Agency (KSh 1,500/mo) to unlock publishing, bookings & tip menu sales.</p>
              </div>
              <button
                onClick={() => openUpgradeModal("creator")}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shrink-0"
              >
                Upgrade Now
              </button>
            </div>
          )}

          {/* 28-Day Performance Metrics (Facebook Creator Insights) */}
          <div className="space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              28-Day Performance Overview
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
                <span className="text-[11px] text-zinc-400 block font-medium">Post Reach</span>
                <div className="text-2xl font-black text-white">
                  {(data?.insights?.postReach || 142800).toLocaleString()}
                </div>
                <span className="text-[10px] text-emerald-400 font-bold block">{data?.insights?.reachGrowth || "+18.4%"} vs last 28 days</span>
              </div>

              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
                <span className="text-[11px] text-zinc-400 block font-medium">Post Engagement</span>
                <div className="text-2xl font-black text-[#ff3358]">
                  {(data?.insights?.postEngagement || 48250).toLocaleString()}
                </div>
                <span className="text-[10px] text-emerald-400 font-bold block">{data?.insights?.engagementGrowth || "+24.1%"} likes & comments</span>
              </div>

              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
                <span className="text-[11px] text-zinc-400 block font-medium">3-Second Video Views</span>
                <div className="text-2xl font-black text-amber-400">
                  {(data?.insights?.threeSecondViews || 92400).toLocaleString()}
                </div>
                <span className="text-[10px] text-zinc-500 block">Reels & Quickies</span>
              </div>

              <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
                <span className="text-[11px] text-zinc-400 block font-medium">Net Followers</span>
                <div className="text-2xl font-black text-emerald-400">
                  {(data?.insights?.netFollowers || 1420).toLocaleString()}
                </div>
                <span className="text-[10px] text-emerald-400 font-bold block">{data?.insights?.followersGrowth || "+840 this week"}</span>
              </div>
            </div>
          </div>

          {/* Monetization & Earnings Breakdown in KSh */}
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#212738]">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                  <Coins className="w-4 h-4 text-amber-400" />
                  Creator Monetization & Cashout Hub (KSh)
                </h3>
                <span className="text-xs text-zinc-400 mt-0.5">1 Token = 10 KSh. Direct M-Pesa disbursements.</span>
              </div>

              <button
                onClick={openWalletModal}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                Withdraw to M-Pesa &rarr;
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-[#0e1118] p-3.5 rounded-xl border border-[#212738]">
                <span className="text-[11px] text-zinc-400 block">Available Token Balance</span>
                <strong className="text-xl font-black text-amber-400 block mt-1">
                  {(currentUser?.tokensBalance ?? 350).toLocaleString()} Tokens
                </strong>
                <span className="text-[10px] text-zinc-500">
                  ≈ KSh {((currentUser?.tokensBalance ?? 350) * 10).toLocaleString()} Withdrawable
                </span>
              </div>

              <div className="bg-[#0e1118] p-3.5 rounded-xl border border-[#212738]">
                <span className="text-[11px] text-zinc-400 block">Fan Club Subscribers</span>
                <strong className="text-xl font-black text-purple-400 block mt-1">
                  {data?.monetization?.fanClubMembersCount || 4} VIP Fans
                </strong>
                <span className="text-[10px] text-zinc-500">
                  Recurring: KSh {(data?.monetization?.fanClubMonthlyKsh || 2000).toLocaleString()}/mo
                </span>
              </div>

              <div className="bg-[#0e1118] p-3.5 rounded-xl border border-[#212738]">
                <span className="text-[11px] text-zinc-400 block">30-Day Listing Plan</span>
                <strong className="text-xl font-black text-emerald-400 block mt-1 uppercase">
                  {currentUser?.subscriptionStatus || "Active"}
                </strong>
                <span className="text-[10px] text-zinc-500">
                  Till 8923411 &bull; KSh 500/mo
                </span>
              </div>
            </div>
          </div>

          {/* Audience Regions & Demographics */}
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5 space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-white">
              Audience Geo-Distribution (Kenya)
            </h3>
            <div className="space-y-2">
              {(data?.audienceRegions || [
                { name: "Nairobi (Kilimani / Westlands / Lavington)", percent: 56 },
                { name: "Mombasa (Nyali Beach / Bamburi)", percent: 22 },
                { name: "Kisumu (Milimani)", percent: 12 },
                { name: "Nakuru & Eldoret", percent: 10 },
              ]).map((reg: any) => (
                <div key={reg.name} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-300 font-medium">{reg.name}</span>
                    <strong className="text-white">{reg.percent}%</strong>
                  </div>
                  <div className="w-full bg-[#0a0d14] rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-[#ff3358] to-[#ffaa00] h-full rounded-full"
                      style={{ width: `${reg.percent}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Published Content & Bookings */}
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5 space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-white">
              Recent Published Content Manager
            </h3>
            {data?.recentPosts?.length === 0 ? (
              <div className="py-6 text-center text-xs text-zinc-500">No content published yet.</div>
            ) : (
              <div className="divide-y divide-[#1d2332]">
                {(data?.recentPosts || []).map((post: any) => (
                  <div key={post.id} className="py-2.5 flex items-center justify-between text-xs">
                    <p className="text-zinc-300 truncate max-w-md">{post.content || "Video/Reel content"}</p>
                    <div className="flex items-center gap-3 text-zinc-400">
                      <span>👁️ {post.viewsCount || 1420}</span>
                      <span className="text-[#ff3358]">🔥 {post.flamesCount || 85}</span>
                      <span>💬 {post.commentsCount || 12}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
