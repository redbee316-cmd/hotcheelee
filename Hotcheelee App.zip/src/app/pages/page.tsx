"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Building2,
  Plus,
  ThumbsUp,
  MessageCircle,
  MapPin,
  Sparkles,
  Search,
  Check,
  Phone,
  ExternalLink,
  ShieldCheck,
  X,
  Layers,
} from "lucide-react";

export default function PagesDirectoryPage() {
  const { currentUser, openAuthModal } = useApp();
  const [pagesList, setPagesList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Form states
  const [name, setName] = useState("");
  const [pageCategory, setPageCategory] = useState("Massage Parlour");
  const [about, setAbout] = useState("");
  const [locationArea, setLocationArea] = useState("Kilimani, Nairobi");
  const [phone, setPhone] = useState("+254 700 892341");
  const [coverImage, setCoverImage] = useState("");

  const categories = [
    "All",
    "Massage Parlour",
    "Escort Agency",
    "Lodging",
    "Creator Official",
    "Nightclub & Lounge",
    "Wellness Spa",
  ];

  const loadPages = async () => {
    setLoading(true);
    try {
      let url = "/api/pages";
      if (category !== "All") url += `?category=${encodeURIComponent(category)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.pages) setPagesList(data.pages);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPages();
  }, [category]);

  const handleCreatePage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      const res = await fetch("/api/pages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          category: pageCategory,
          about: about.trim(),
          locationArea,
          phone,
          coverImage: coverImage.trim() || "https://images.pexels.com/photos/18465177/pexels-photo-18465177.jpeg",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setShowCreateModal(false);
        setName("");
        setAbout("");
        loadPages();
      } else {
        alert(data.error || "Failed to create page");
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header Banner - Facebook Pages Clone */}
          <div className="bg-gradient-to-r from-[#1d1626] via-[#141928] to-[#0e121b] border border-[#ff3358]/40 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Building2 className="w-6 h-6 text-[#ff3358]" />
                <h1 className="text-2xl font-black text-white">HotCheelee Pages (Facebook Pages Clone)</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
                Official verified business pages for massage parlours, escort agencies, adult venues, and star companions across Kenya.
              </p>
            </div>

            <button
              onClick={() => setShowCreateModal(true)}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Page</span>
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  category === c
                    ? "bg-[#ff3358] text-white shadow-sm"
                    : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          {/* Pages Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pagesList.map((page) => (
              <div
                key={page.id}
                className="bg-[#13161f] border border-[#212735] hover:border-[#ff3358]/60 rounded-2xl overflow-hidden transition group flex flex-col justify-between shadow-sm"
              >
                {/* Cover & Avatar Header */}
                <div className="relative h-28 bg-zinc-800 overflow-hidden">
                  <img
                    src={page.coverImage}
                    alt={page.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <span className="absolute top-2.5 right-2.5 bg-black/70 backdrop-blur-md text-[10px] font-black uppercase text-amber-400 px-2 py-0.5 rounded-full border border-white/10">
                    {page.category}
                  </span>
                </div>

                <div className="p-4 pt-0 relative -mt-7 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <div className="flex items-end justify-between mb-2">
                      <img
                        src={page.avatar || "https://images.pexels.com/photos/13058959/pexels-photo-13058959.jpeg"}
                        alt={page.name}
                        className="w-14 h-14 rounded-xl object-cover ring-3 ring-[#13161f] border border-white/20"
                      />

                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] text-zinc-400 font-semibold">
                          👍 {page.likesCount || 1} likes
                        </span>
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-[#ff3358] transition truncate flex items-center gap-1">
                      <span>{page.name}</span>
                      {page.verified && <span className="text-emerald-400 text-xs">✓</span>}
                    </h3>

                    <span className="text-[11px] text-emerald-400 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-[#ff3358]" />
                      {page.locationArea || "Nairobi, Kenya"} &bull; {page.priceRange || "KSh 3,000+"}
                    </span>

                    <p className="text-xs text-zinc-300 line-clamp-2 mt-2 leading-relaxed">
                      {page.about || page.bio}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-[#1e2330] flex items-center justify-between gap-2">
                    <a
                      href={`https://wa.me/${(page.whatsapp || page.phone || "254700892341").replace(/[^0-9]/g, "")}?text=Hi,%20inquiring%20about%20${encodeURIComponent(page.name)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp Page</span>
                    </a>

                    <button
                      onClick={async () => {
                        const res = await fetch(`/api/pages/${page.slug}`, {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ action: "like" }),
                        });
                        const data = await res.json();
                        if (res.ok) {
                          setPagesList((prev) =>
                            prev.map((p) => (p.id === page.id ? { ...p, likesCount: data.likesCount } : p))
                          );
                        }
                      }}
                      className="px-3 py-1.5 rounded-lg bg-[#1a2233] hover:bg-[#27344e] text-zinc-200 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    >
                      <ThumbsUp className="w-3.5 h-3.5 text-[#ff3358]" />
                      <span>Like Page</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Create Page Modal */}
          {showCreateModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
              <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>

                <h3 className="text-lg font-black text-white mb-1">Create HotCheelee Page</h3>
                <p className="text-xs text-zinc-400 mb-4">Official page for your parlour, agency, or creator brand</p>

                <form onSubmit={handleCreatePage} className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Page Name *</label>
                    <input
                      type="text"
                      placeholder="e.g. VIP Penthouse Escorts & Spa"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Category</label>
                      <select
                        value={pageCategory}
                        onChange={(e) => setPageCategory(e.target.value)}
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      >
                        {categories.filter((c) => c !== "All").map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Location Area</label>
                      <input
                        type="text"
                        placeholder="Kilimani, Nairobi"
                        value={locationArea}
                        onChange={(e) => setLocationArea(e.target.value)}
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Contact Phone / WhatsApp</label>
                    <input
                      type="text"
                      placeholder="+254 722 000000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Cover Image URL</label>
                    <input
                      type="url"
                      placeholder="https://images.pexels.com/...jpg"
                      value={coverImage}
                      onChange={(e) => setCoverImage(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">About & Services</label>
                    <textarea
                      rows={2}
                      placeholder="Describe the venue, therapists, opening hours..."
                      value={about}
                      onChange={(e) => setAbout(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer"
                  >
                    Publish Page
                  </button>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
