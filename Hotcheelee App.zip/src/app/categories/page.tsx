"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Sparkles,
  Search,
  Users,
  Building2,
  MapPin,
  Coins,
  Phone,
  Flame,
  Check,
  Zap,
} from "lucide-react";
import Link from "next/link";

export default function CategoriesDirectoryPage() {
  const { openContactModal, openTipMenuModal, openToyModal } = useApp();
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCat, setSelectedCat] = useState("all");
  const [creators, setCreators] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const loadCategoryData = async () => {
    setLoading(true);
    try {
      let url = `/api/categories?cat=${encodeURIComponent(selectedCat)}`;
      if (search) url += `&q=${encodeURIComponent(search)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.categories) setCategories(data.categories);
      if (data.creators) setCreators(data.creators);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCategoryData();
  }, [selectedCat, search]);

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header Banner - Stripchat Categories Clone */}
          <div className="bg-gradient-to-r from-[#1e1328] via-[#141829] to-[#0e121b] border border-[#ff3358]/40 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-6 h-6 text-[#ff3358]" />
                <h1 className="text-2xl font-black text-white">HotCheelee Categories (Stripchat Directory)</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
                Filter performers by Stripchat taxonomy: Teen 18+, MILF, Ebony, BDSM, High Heels, BBW, Cosplay, Trans & Couples with verified performer counts.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search category keywords..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-[#121620] border border-[#232938] rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff3358]"
              />
            </div>
          </div>

          {/* Category Chips Bar with Counts */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCat(c.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  selectedCat === c.id
                    ? "bg-[#ff3358] text-white shadow-md shadow-[#ff3358]/20"
                    : "bg-[#141822] text-zinc-400 hover:text-white border border-[#232938]"
                }`}
              >
                <span>{c.icon}</span>
                <span>{c.label}</span>
                <span className="text-[10px] bg-black/40 text-amber-400 px-1.5 py-0.2 rounded-full">
                  {c.count}
                </span>
              </button>
            ))}
          </div>

          {/* Creators Grid for Selected Category */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((n) => (
                <div key={n} className="bg-[#13161f] border border-[#212735] rounded-2xl h-56 animate-pulse" />
              ))}
            </div>
          ) : creators.length === 0 ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-10 text-center text-zinc-400 text-xs">
              No performers currently tagged in this category.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {creators.map((star) => (
                <div
                  key={star.id}
                  className="bg-[#13161f] border border-[#212735] hover:border-[#ff3358]/60 rounded-2xl overflow-hidden transition group flex flex-col justify-between"
                >
                  <div className="relative h-28 bg-zinc-800">
                    <img
                      src={star.coverImage || "https://images.pexels.com/photos/33282391/pexels-photo-33282391.jpeg"}
                      alt={star.displayName}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#13161f] via-black/20 to-transparent" />
                    <span className="absolute top-2.5 right-2.5 bg-black/70 backdrop-blur-md text-amber-400 text-[10px] font-black uppercase px-2 py-0.5 rounded-full border border-white/10">
                      {star.genderRole || "Star"}
                    </span>
                  </div>

                  <div className="p-4 pt-0 relative -mt-8 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <div className="flex items-end justify-between mb-2">
                        <Link href={`/profile/${star.username}`}>
                          <img
                            src={star.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                            alt={star.displayName}
                            className="w-16 h-16 rounded-full object-cover ring-3 ring-[#13161f] border-2 border-[#ff3358]"
                          />
                        </Link>

                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => openToyModal(star.id, star.displayName)}
                            className="p-2 rounded-xl bg-[#1b202c] hover:bg-[#252c3e] text-amber-400 text-xs transition"
                            title="Vibrate Lovense Toy"
                          >
                            <Zap className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => openTipMenuModal(star.id, star.displayName)}
                            className="px-2.5 py-1.5 rounded-xl bg-[#1b202c] hover:bg-[#252c3e] text-[#ff3358] text-xs font-bold transition flex items-center gap-1"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Menu</span>
                          </button>
                        </div>
                      </div>

                      <Link href={`/profile/${star.username}`} className="block">
                        <h3 className="text-base font-bold text-white group-hover:text-[#ff3358] transition truncate">
                          {star.displayName}
                        </h3>
                        <span className="text-xs text-zinc-400 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-[#ff3358]" />
                          {star.locationArea || "Kilimani, Nairobi"}
                        </span>
                      </Link>

                      <p className="text-xs text-zinc-300 line-clamp-2 mt-2 leading-relaxed">
                        {star.bio}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-[#1e2330] flex items-center justify-between gap-2">
                      <button
                        onClick={() => openContactModal(star)}
                        className="flex-1 py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition flex items-center justify-center gap-1 shadow-sm"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Reveal Contact</span>
                      </button>

                      <Link
                        href={`/private-show?modelId=${star.id}`}
                        className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow transition flex items-center gap-1"
                      >
                        <span>Private Show</span>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
