"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Users,
  Plus,
  Lock,
  Globe,
  MessageSquare,
  Sparkles,
  ShieldCheck,
  Search,
  Check,
  X,
} from "lucide-react";

export default function GroupsPage() {
  const { currentUser } = useApp();
  const [groupsList, setGroupsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Adult & Social");
  const [privacy, setPrivacy] = useState("public");
  const [coverImage, setCoverImage] = useState("");
  const [search, setSearch] = useState("");

  const categories = ["All", "Adult & Social", "VIP Escorts", "Massage & Spas", "Kink & Fetish", "LGBTQ+ Kenya", "Party & Nightlife"];

  const loadGroups = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/groups");
      const data = await res.json();
      if (data.groups) setGroupsList(data.groups);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGroups();
  }, []);

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !description.trim()) return;

    try {
      const res = await fetch("/api/groups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim(),
          category,
          privacy,
          coverImage: coverImage.trim() || "https://images.pexels.com/photos/22608961/pexels-photo-22608961.jpeg",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setShowCreateModal(false);
        setName("");
        setDescription("");
        loadGroups();
      } else {
        alert(data.error || "Failed to create group");
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-5">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#1e1328] via-[#141829] to-[#0e121b] border border-[#ff3358]/40 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <Users className="w-6 h-6 text-[#ff3358]" />
                <h1 className="text-2xl font-black text-white">HotCheelee Groups (Facebook Clone)</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
                Join private or public adult communities, discussions, meetups & discussions across Kenya.
              </p>
            </div>

            <button
              onClick={() => setShowCreateModal(true)}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
            >
              <Plus className="w-4 h-4" />
              <span>Create Group</span>
            </button>
          </div>

          {/* Search & Groups Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {groupsList.map((g) => (
              <div
                key={g.id}
                className="bg-[#13161f] border border-[#212735] hover:border-[#ff3358]/60 rounded-2xl overflow-hidden transition group flex flex-col justify-between"
              >
                <div className="relative h-32 bg-zinc-800 overflow-hidden">
                  <img
                    src={g.coverImage}
                    alt={g.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <span className="absolute top-2.5 right-2.5 bg-black/70 backdrop-blur-md text-[10px] font-black uppercase text-amber-400 px-2 py-0.5 rounded-full border border-white/10 flex items-center gap-1">
                    {g.privacy === "private" ? <Lock className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
                    {g.privacy}
                  </span>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-[#ff3358] transition truncate">
                      {g.name}
                    </h3>
                    <span className="text-[11px] text-zinc-400 font-medium block mt-0.5">
                      {g.category} &bull; {g.membersCount} members
                    </span>
                    <p className="text-xs text-zinc-300 line-clamp-2 mt-2 leading-relaxed">
                      {g.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#1e2330] flex items-center justify-between">
                    <span className="text-[10px] text-zinc-500">{g.postsCount} posts</span>
                    <button
                      onClick={() => alert(`Joined ${g.name}!`)}
                      className="px-3.5 py-1.5 rounded-xl bg-[#1f2638] hover:bg-[#ff3358] hover:text-white text-zinc-200 text-xs font-bold transition cursor-pointer"
                    >
                      Join Group
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Create Group Modal */}
          {showCreateModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
              <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>

                <h3 className="text-lg font-black text-white mb-1">Create HotCheelee Group</h3>
                <p className="text-xs text-zinc-400 mb-4">Start a community for fans, models, kinks or nightlife</p>

                <form onSubmit={handleCreateGroup} className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Group Name *</label>
                    <input
                      type="text"
                      placeholder="e.g. Kilimani VIP Companions & Models"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Description *</label>
                    <textarea
                      rows={2}
                      placeholder="What is this group about?"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Category</label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      >
                        {categories.filter((c) => c !== "All").map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-300 block mb-1">Privacy</label>
                      <select
                        value={privacy}
                        onChange={(e) => setPrivacy(e.target.value)}
                        className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                      >
                        <option value="public">Public</option>
                        <option value="private">Private (Members only)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Cover Image URL</label>
                    <input
                      type="url"
                      placeholder="https://images.pexels.com/...jpg"
                      value={coverImage}
                      onChange={(e) => setCoverImage(e.target.value)}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white font-bold text-xs shadow-md cursor-pointer"
                  >
                    Create Group
                  </button>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
