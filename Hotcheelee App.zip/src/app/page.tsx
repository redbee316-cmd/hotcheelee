"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import StoriesBar from "@/components/feed/StoriesBar";
import QuickPostBox from "@/components/feed/QuickPostBox";
import PostCard from "@/components/feed/PostCard";
import { useApp } from "@/context/AppContext";
import {
  Sparkles,
  Users,
  TrendingUp,
  Clock,
  Video,
  RefreshCw,
  Gift,
  Coins,
  Building2,
  Star,
  UserPlus,
  Check,
  CheckCheck,
  ChevronRight,
  ExternalLink,
  Plus,
} from "lucide-react";
import Link from "next/link";

export default function HomePage() {
  const { postRefreshCounter, currentUser, triggerWatchTick, openAuthModal, openCreateAdModal } = useApp();
  const [activeTab, setActiveTab] = useState<"for-you" | "following" | "popular" | "latest" | "media-only">("for-you");
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Facebook & TikTok integration states
  const [sponsoredAds, setSponsoredAds] = useState<any[]>([]);
  const [peopleYouMayKnow, setPeopleYouMayKnow] = useState<any[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<any[]>([]);
  const [quickiesFeed, setQuickiesFeed] = useState<any[]>([]);
  const [friendActionMap, setFriendActionMap] = useState<Record<number, string>>({});

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const [pRes, adRes, frRes, qkRes] = await Promise.all([
        fetch(`/api/posts?filter=${activeTab}`),
        fetch("/api/sponsored"),
        fetch("/api/friends"),
        fetch("/api/quickies"),
      ]);

      const pData = await pRes.json();
      const adData = await adRes.json();
      const frData = await frRes.json();
      const qkData = await qkRes.json();

      if (pData.posts) setPosts(pData.posts);
      if (adData.ads) setSponsoredAds(adData.ads);
      if (frData.peopleYouMayKnow) setPeopleYouMayKnow(frData.peopleYouMayKnow);
      if (frData.incomingRequests) setIncomingRequests(frData.incomingRequests);
      if (qkData.quickies) setQuickiesFeed(qkData.quickies);
    } catch (err) {
      console.error("Failed to load feed", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, [activeTab, postRefreshCounter]);

  // Handle Facebook-style +Add Friend & TikTok Follow-for-Follow
  const handleAddFriend = async (targetUserId: number) => {
    try {
      setFriendActionMap((prev) => ({ ...prev, [targetUserId]: "sent" }));
      const res = await fetch("/api/friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "send", targetUserId }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Failed to send request");
        setFriendActionMap((prev) => ({ ...prev, [targetUserId]: "error" }));
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Accept incoming friend request
  const handleAcceptFriend = async (requestId: number, senderId: number) => {
    try {
      setFriendActionMap((prev) => ({ ...prev, [senderId]: "friends" }));
      await fetch("/api/friends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "accept", requestId }),
      });
      setIncomingRequests((prev) => prev.filter((r) => r.id !== requestId));
    } catch (e) {
      console.error(e);
    }
  };

  const feedTabs = [
    { id: "for-you" as const, label: "For You", icon: Sparkles },
    { id: "following" as const, label: "Following & Friends", icon: Users },
    { id: "popular" as const, label: "Popular", icon: TrendingUp },
    { id: "latest" as const, label: "Latest", icon: Clock },
    { id: "media-only" as const, label: "Media Gallery", icon: Video },
  ];

  const orientationCategories = [
    { label: "All Kenya", href: "/stars" },
    { label: "Straight Stars", href: "/stars?role=straight" },
    { label: "Gay Performers", href: "/stars?role=gay" },
    { label: "Transgender", href: "/stars?role=transgender" },
    { label: "Shemale (TS)", href: "/stars?role=shemale" },
    { label: "Queer / NB", href: "/stars?role=queer" },
    { label: "Massage Parlours", href: "/brands?agencyType=Massage+Parlour" },
    { label: "Lodgings & Brothels", href: "/brands?agencyType=Lodging" },
  ];

  // Pick sponsored ad to inject into feed
  const activeAd = sponsoredAds.length > 0 ? sponsoredAds[0] : null;

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-2xl mx-auto w-full min-w-0 space-y-4">
          {/* Incoming Facebook Friend Requests Banner */}
          {incomingRequests.length > 0 && (
            <div className="bg-[#181d28] border border-[#2d3a50] p-3.5 rounded-2xl shadow-sm space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-400" />
                  Friend Requests ({incomingRequests.length})
                </span>
                <span className="text-[10px] text-zinc-400">Accept to become mutual friends</span>
              </div>

              <div className="space-y-2">
                {incomingRequests.map((req) => (
                  <div key={req.id} className="flex items-center justify-between bg-[#111622] p-2.5 rounded-xl text-xs">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={req.sender?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                        alt="avatar"
                        className="w-9 h-9 rounded-full object-cover ring-1 ring-white/10 shrink-0"
                      />
                      <div className="truncate">
                        <span className="font-bold text-white truncate block">{req.sender?.displayName}</span>
                        <span className="text-[10px] text-zinc-400">{req.sender?.locationArea || "Kenya"} &bull; @{req.sender?.username}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => handleAcceptFriend(req.id, req.sender?.id)}
                        className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                      >
                        Confirm
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Diversity Orientation Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {orientationCategories.map((c) => (
              <Link
                key={c.label}
                href={c.href}
                className="px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap bg-[#13161f] hover:bg-[#1f2636] text-zinc-300 hover:text-white border border-[#232938] transition"
              >
                {c.label}
              </Link>
            ))}
          </div>

          {/* Stories Bar (24h Stories with Prominent + Icon, max 60s) */}
          <StoriesBar />

          {/* Quick Post Box (Photos & Videos) */}
          <QuickPostBox />

          {/* Feed Filter Tabs */}
          <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-1.5 flex items-center justify-between gap-1 shadow-sm overflow-x-auto scrollbar-none">
            {feedTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 min-w-[75px] py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    isActive
                      ? "bg-[#ff3358] text-white shadow-md shadow-[#ff3358]/20"
                      : "text-zinc-400 hover:text-white hover:bg-[#181d28]"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* FACEBOOK "PEOPLE YOU MAY KNOW" SECTION (+Add Friends everyday) */}
          {peopleYouMayKnow.length > 0 && (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-4 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-emerald-400" />
                    People You May Know &bull; Follow for Follow
                  </h3>
                  <p className="text-[10px] text-zinc-400 mt-0.5">
                    Follow each other back to become mutual friends and view each other's private feeds!
                  </p>
                </div>
                <Link href="/stars" className="text-[11px] text-[#ff3358] hover:underline font-bold">
                  See All &rarr;
                </Link>
              </div>

              {/* Horizontal Scroll Carousel */}
              <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
                {peopleYouMayKnow.map((person) => {
                  const state = friendActionMap[person.id];
                  return (
                    <div
                      key={person.id}
                      className="bg-[#0e1118] border border-[#202738] rounded-xl p-3 w-40 shrink-0 text-center flex flex-col justify-between space-y-2 hover:border-[#ff3358]/50 transition"
                    >
                      <Link href={`/profile/${person.username}`}>
                        <img
                          src={person.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                          alt={person.displayName}
                          className="w-16 h-16 rounded-full object-cover mx-auto ring-2 ring-[#ff3358]/40 hover:scale-105 transition"
                        />
                        <h4 className="text-xs font-bold text-white truncate mt-2">{person.displayName}</h4>
                        <span className="text-[10px] text-zinc-500 block truncate">{person.locationArea || "Nairobi"}</span>
                      </Link>

                      <button
                        disabled={state === "sent"}
                        onClick={() => handleAddFriend(person.id)}
                        className={`w-full py-1.5 rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                          state === "sent"
                            ? "bg-[#181d28] text-emerald-400 cursor-default"
                            : "bg-[#ff3358] hover:bg-[#e11d48] text-white"
                        }`}
                      >
                        {state === "sent" ? (
                          <>
                            <Check className="w-3 h-3" />
                            <span>Requested</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3 h-3" />
                            <span>+ Add Friend</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Posts Feed with Injected Sponsored Ads */}
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((n) => (
                <div key={n} className="bg-[#13161f] border border-[#212735] rounded-2xl p-4 animate-pulse h-64" />
              ))}
            </div>
          ) : posts.length === 0 ? (
            <div className="bg-[#13161f] border border-[#212735] rounded-2xl p-8 text-center space-y-3">
              <p className="text-zinc-400 text-sm">No posts found in this feed yet.</p>
              <button
                onClick={fetchPosts}
                className="px-4 py-2 rounded-xl bg-[#1d2332] text-xs font-bold text-white hover:bg-[#273044] transition inline-flex items-center gap-2 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh Feed</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map((post, idx) => (
                <React.Fragment key={post.id}>
                  <PostCard post={post} />

                  {/* FACEBOOK-STYLE QUICKIES & REELS CAROUSEL INJECTED IN FEED */}
                  {idx === 0 && quickiesFeed.length > 0 && (
                    <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 shadow-md my-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="p-1 rounded-lg bg-[#ff3358] text-white">
                            <Video className="w-4 h-4" />
                          </span>
                          <div>
                            <h3 className="text-xs font-black uppercase tracking-wider text-white">
                              Quickies & Reels (9:16 Vertical)
                            </h3>
                            <span className="text-[10px] text-zinc-400">Trending video shorts &bull; Max 60s</span>
                          </div>
                        </div>

                        <Link
                          href="/quickies"
                          className="text-xs text-[#ff3358] hover:underline font-bold flex items-center gap-1"
                        >
                          <span>Full Reels Feed</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </Link>
                      </div>

                      {/* Horizontal 9:16 Reels Carousel */}
                      <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
                        {quickiesFeed.map((qk) => (
                          <Link
                            key={qk.id}
                            href="/quickies"
                            className="relative w-36 h-60 rounded-2xl overflow-hidden bg-black shrink-0 border border-white/10 group cursor-pointer shadow"
                          >
                            <video
                              src={qk.videoUrl}
                              className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                              muted
                              loop
                              playsInline
                              onMouseOver={(e) => (e.target as HTMLVideoElement).play().catch(() => {})}
                              onMouseOut={(e) => (e.target as HTMLVideoElement).pause()}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent p-2.5 flex flex-col justify-between">
                              <span className="bg-black/60 backdrop-blur-md text-[9px] font-bold text-amber-400 px-1.5 py-0.5 rounded self-start border border-white/10">
                                9:16 Reel
                              </span>

                              <div>
                                <span className="text-[11px] font-bold text-white block truncate drop-shadow">
                                  {qk.author?.displayName || "Creator"}
                                </span>
                                <span className="text-[9px] text-zinc-300 line-clamp-1 drop-shadow">
                                  {qk.content}
                                </span>
                              </div>
                            </div>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Facebook-style SPONSORED AD injected every few posts */}
                  {idx === 1 && activeAd && (
                    <div className="bg-[#141824] border border-amber-400/40 rounded-2xl overflow-hidden shadow-md my-4">
                      <div className="p-3.5 flex items-center justify-between border-b border-[#212a3d]">
                        <div className="flex items-center gap-2">
                          <span className="w-7 h-7 rounded-lg bg-amber-400 text-black font-black text-xs flex items-center justify-center">
                            AD
                          </span>
                          <div>
                            <span className="text-xs font-bold text-white block">{activeAd.brandName}</span>
                            <span className="text-[10px] text-zinc-400 uppercase font-semibold">Sponsored Advertisement</span>
                          </div>
                        </div>

                        <button
                          onClick={openCreateAdModal}
                          className="text-[11px] text-amber-400 hover:underline font-bold flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>Create Ad</span>
                        </button>
                      </div>

                      <div className="p-3.5 space-y-2">
                        <h4 className="text-sm font-bold text-white">{activeAd.title}</h4>
                        <p className="text-xs text-zinc-300 leading-relaxed">{activeAd.content}</p>
                      </div>

                      <div className="relative aspect-video max-h-64 bg-black overflow-hidden">
                        <img
                          src={activeAd.mediaUrl}
                          alt={activeAd.title}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="p-3 bg-[#0f131d] flex items-center justify-between">
                        <span className="text-xs text-zinc-400 truncate max-w-xs">{activeAd.targetUrl}</span>
                        <a
                          href={activeAd.targetUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-[#ff3358] text-white text-xs font-bold transition shadow"
                        >
                          {activeAd.ctaText} &rarr;
                        </a>
                      </div>
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          )}

          {/* INFINITE FEED FOOTER: NEVER ENDING */}
          <div className="py-8 text-center space-y-3 bg-[#11141c] border border-[#1f2636] rounded-2xl p-6">
            <div className="flex items-center justify-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff3358] animate-ping" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Infinite Feed Stream Active
              </span>
            </div>
            <p className="text-xs text-zinc-400 max-w-sm mx-auto">
              You are viewing the unending stream of Kenya adult creators, parlours & models. Follow more models to customize your stream!
            </p>

            <div className="flex items-center justify-center gap-2 pt-1">
              <button
                onClick={fetchPosts}
                className="px-4 py-2 rounded-xl bg-[#1d2332] hover:bg-[#283246] text-xs font-bold text-zinc-300 hover:text-white transition inline-flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Load More Content</span>
              </button>

              <button
                onClick={openCreateAdModal}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ff3358] to-[#ffaa00] text-white text-xs font-bold shadow transition cursor-pointer"
              >
                + Create Sponsored Ad
              </button>
            </div>
          </div>
        </main>

        {/* Right Sidebar with Facebook Shortcuts & Friend Suggestions */}
        <RightSidebar />
      </div>
    </div>
  );
}
