"use client";

import React, { useState, useEffect } from "react";
import LeftSidebar from "@/components/navigation/LeftSidebar";
import RightSidebar from "@/components/navigation/RightSidebar";
import { useApp } from "@/context/AppContext";
import {
  Coins,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Plus,
  HeartHandshake,
  TrendingUp,
  Search,
  DollarSign,
  AlertCircle,
  X,
  CreditCard,
} from "lucide-react";

export default function PtopFinancePage() {
  const { currentUser, refreshUser, openTokensModal } = useApp();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showRequestModal, setShowRequestModal] = useState(false);

  // Request Loan State
  const [amountKsh, setAmountKsh] = useState("5000");
  const [purpose, setPurpose] = useState("Camera upgrade & private apartment rent");
  const [durationDays, setDurationDays] = useState(30);
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/ptop-finance");
      const d = await res.json();
      setData(d);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRequestLoan = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/ptop-finance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "request",
          amountKsh: Number(amountKsh),
          purpose,
          durationDays,
        }),
      });
      const resData = await res.json();
      if (res.ok) {
        setShowRequestModal(false);
        setNotice(resData.message);
        loadData();
      } else {
        alert(resData.error || "Failed to post loan request");
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleFundLoan = async (loanId: number) => {
    try {
      const res = await fetch("/api/ptop-finance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "fund", loanId }),
      });
      const resData = await res.json();
      if (res.ok) {
        setNotice(resData.message);
        await refreshUser();
        loadData();
      } else {
        alert(resData.error || "Funding failed");
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleGuarantee = async (loanId: number) => {
    try {
      const res = await fetch("/api/ptop-finance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "guarantee", loanId }),
      });
      const resData = await res.json();
      if (res.ok) {
        setNotice(resData.message);
        loadData();
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  const tokenBalance = currentUser?.tokensBalance || 0;
  const kshEquivalent = tokenBalance * 10;

  return (
    <div className="min-h-screen bg-[#0c0e12] py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 flex gap-6">
        <LeftSidebar />

        <main className="flex-1 max-w-4xl mx-auto w-full min-w-0 space-y-6">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#171c2b] via-[#131a26] to-[#0e121b] border border-[#2d3a50] rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Coins className="w-6 h-6 text-amber-400" />
                <h1 className="text-2xl font-black text-white">HotCheelee PtoP Finance & Withdrawals</h1>
              </div>
              <p className="text-xs text-zinc-300 max-w-xl leading-relaxed">
                Request your earned balance, track payout status, and give or receive peer-to-peer loans with 10% interest.
              </p>
            </div>

            <button
              onClick={() => setShowRequestModal(true)}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
            >
              <Plus className="w-4 h-4" />
              <span>Request Peer Loan</span>
            </button>
          </div>

          {notice && (
            <div className="p-4 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 flex items-center justify-between">
              <span>{notice}</span>
              <button onClick={() => setNotice(null)}>✕</button>
            </div>
          )}

          {/* EXACT DESIGN REQUESTED FROM USER PROMPT */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* Available Balance */}
            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
              <span className="text-[11px] text-zinc-400 block font-medium">Available Balance</span>
              <div className="text-2xl font-black text-amber-400 flex items-center gap-1.5">
                <span>🪙</span>
                <span>{tokenBalance.toLocaleString()}</span>
              </div>
              <span className="text-[10px] text-zinc-500 block">
                ≈ KES {kshEquivalent.toLocaleString()} &bull; 1 coin = KES 10
              </span>
            </div>

            {/* Pending Requests */}
            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
              <span className="text-[11px] text-zinc-400 block font-medium">Pending Withdrawals</span>
              <div className="text-2xl font-black text-white flex items-center gap-1.5">
                <span>🪙</span>
                <span>0</span>
              </div>
              <span className="text-[10px] text-zinc-500 block">Min 🪙 100 coins required</span>
            </div>

            {/* Total Paid Out */}
            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
              <span className="text-[11px] text-zinc-400 block font-medium">Total Paid Out</span>
              <div className="text-2xl font-black text-emerald-400">
                KES 14,800
              </div>
              <span className="text-[10px] text-zinc-500 block">All time approved payouts</span>
            </div>

            {/* Total Requests */}
            <div className="bg-[#121620] border border-[#232938] rounded-2xl p-4 space-y-1">
              <span className="text-[11px] text-zinc-400 block font-medium">Total Requests</span>
              <div className="text-2xl font-black text-purple-400">
                3 Total
              </div>
              <span className="text-[10px] text-zinc-500 block">Processed via M-Pesa</span>
            </div>
          </div>

          {/* EXACT TRACKING RECORD REQUESTED FROM PROMPT */}
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#212738]">
              <h3 className="text-xs font-black uppercase tracking-wider text-white">
                Withdrawal Request Tracking (1 Total)
              </h3>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded uppercase">
                Approved
              </span>
            </div>

            <div className="p-3.5 bg-[#0e1118] border border-[#1e2434] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-black text-amber-400">🪙 3,000 Coins</span>
                  <span className="text-emerald-400 font-black">KES 2,948 net</span>
                </div>
                <p className="text-zinc-400 text-[11px] mt-0.5">
                  0719373838 &bull; KES 52 charges &bull; Approved 6/2/2026
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] text-emerald-400 font-mono font-bold bg-[#141b27] px-2 py-1 rounded">
                  M-Pesa Disbursed ✓
                </span>
              </div>
            </div>
          </div>

          {/* PEER TO PEER LOANS MARKETPLACE */}
          <div className="bg-[#121620] border border-[#232938] rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                  <HeartHandshake className="w-4 h-4 text-emerald-400" />
                  Open Peer Loan Requests ({data?.openCount || 0})
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Creators and members backing each other. Fund an open request to earn 10% interest upon repayment.
                </p>
              </div>

              <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-1 rounded-full">
                KES {(data?.totalSecuredKsh || 48000).toLocaleString()} Total Secured
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {(data?.openLoans || [
                {
                  id: 1,
                  borrower: { displayName: "Elena Lux", username: "elena_lux", locationArea: "Kilimani", avatar: "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg" },
                  amountKsh: 15000,
                  totalRepayableKsh: 16500,
                  durationDays: 30,
                  purpose: "4K Studio camera & wardrobe upgrade for VIP sets",
                  status: "open",
                },
                {
                  id: 2,
                  borrower: { displayName: "Liam Onyango", username: "liam_fitness", locationArea: "Westlands", avatar: "https://images.pexels.com/photos/22813632/pexels-photo-22813632.jpeg" },
                  amountKsh: 8000,
                  totalRepayableKsh: 8800,
                  durationDays: 20,
                  purpose: "Fitness supplement & lighting equipment",
                  status: "open",
                },
              ]).map((loan: any) => (
                <div key={loan.id} className="bg-[#0e1118] border border-[#212738] p-4 rounded-xl flex flex-col justify-between space-y-3">
                  <div className="flex items-start gap-3">
                    <img
                      src={loan.borrower?.avatar || "https://images.pexels.com/photos/39082589/pexels-photo-39082589.jpeg"}
                      alt="avatar"
                      className="w-11 h-11 rounded-xl object-cover ring-1 ring-white/10"
                    />
                    <div className="min-w-0 flex-1">
                      <span className="text-xs font-bold text-white block truncate">{loan.borrower?.displayName}</span>
                      <span className="text-[10px] text-zinc-400">{loan.borrower?.locationArea || "Nairobi"} &bull; @{loan.borrower?.username}</span>
                      <p className="text-xs text-zinc-300 mt-2 italic">"{loan.purpose}"</p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#1e2330] flex items-center justify-between text-xs">
                    <div>
                      <span className="font-black text-amber-400 text-sm">KES {loan.amountKsh.toLocaleString()}</span>
                      <span className="text-[10px] text-zinc-500 block">Returns: KES {loan.totalRepayableKsh.toLocaleString()} ({loan.durationDays}d)</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleGuarantee(loan.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-[#182030] hover:bg-[#222e44] text-zinc-300 text-[11px] font-semibold"
                      >
                        Be Guarantor
                      </button>
                      <button
                        onClick={() => handleFundLoan(loan.id)}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow cursor-pointer"
                      >
                        Fund Loan &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Request Loan Modal */}
          {showRequestModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
              <div className="relative max-w-lg w-full bg-[#13161f] border border-[#272e3f] rounded-2xl p-6 shadow-2xl my-6 animate-in fade-in zoom-in-95">
                <button
                  onClick={() => setShowRequestModal(false)}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>

                <h3 className="text-lg font-black text-white mb-1">Request Peer-to-Peer Loan</h3>
                <p className="text-xs text-zinc-400 mb-4">Post loan request to HotCheelee peer lenders (10% fixed interest)</p>

                <form onSubmit={handleRequestLoan} className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Amount Needed (KSh) *</label>
                    <input
                      type="number"
                      min={1000}
                      step={500}
                      value={amountKsh}
                      onChange={(e) => setAmountKsh(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    />
                    <span className="text-[10px] text-amber-400 mt-0.5 block">
                      Repayable amount (10% interest): KSh {(Number(amountKsh) * 1.10 || 0).toLocaleString()}
                    </span>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Duration (Days)</label>
                    <select
                      value={durationDays}
                      onChange={(e) => setDurationDays(Number(e.target.value))}
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl px-3 py-2 text-xs text-white"
                    >
                      <option value={15}>15 Days</option>
                      <option value={30}>30 Days</option>
                      <option value={60}>60 Days</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">Purpose of Loan *</label>
                    <textarea
                      rows={2}
                      value={purpose}
                      onChange={(e) => setPurpose(e.target.value)}
                      required
                      className="w-full bg-[#0e1118] border border-[#262c3b] rounded-xl p-2.5 text-xs text-white resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-bold text-xs shadow-md cursor-pointer"
                  >
                    {submitting ? "Posting..." : "Post Loan Request"}
                  </button>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
