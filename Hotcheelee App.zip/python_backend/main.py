import os
import sys
from datetime import datetime, date
from typing import Optional, List
from fastapi import FastAPI, Depends, HTTPException, status, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import (
    create_engine, Column, Integer, String, Text, Boolean, DateTime, Numeric, ForeignKey
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@127.0.0.1:5432/app_db")
if DATABASE_URL.startswith("postgresql://") and "+psycopg2" not in DATABASE_URL:
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg2://", 1)

# SQLAlchemy Engine & Session
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# SQLAlchemy Models mapping to PostgreSQL tables
class UserModel(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    displayName = Column("display_name", String(100), nullable=False)
    email = Column(String(255))
    password = Column(Text)
    avatar = Column(Text)
    coverImage = Column("cover_image", Text)
    bio = Column(Text)
    isVerifiedStar = Column("is_verified_star", Boolean, default=False)
    isBrand = Column("is_brand", Boolean, default=False)
    accountType = Column("account_type", String(30), default="browsing")
    genderRole = Column("gender_role", String(30), default="straight")
    agencyType = Column("agency_type", String(50))
    phone = Column(String(50))
    allowWhatsapp = Column("allow_whatsapp", Boolean, default=True)
    allowCalls = Column("allow_calls", Boolean, default=True)
    allowSms = Column("allow_sms", Boolean, default=True)
    location = Column(String(100))
    locationArea = Column("location_area", String(120))
    serviceType = Column("service_type", String(40), default="Both Incall & Outcall")
    servicesOffered = Column("services_offered", Text)
    rates = Column(Text)
    interests = Column(Text)
    subscriptionStatus = Column("subscription_status", String(30), default="inactive")
    subscriptionPlan = Column("subscription_plan", String(40))
    subscriptionExpiresAt = Column("subscription_expires_at", DateTime)
    subscriptionPaidAt = Column("subscription_paid_at", DateTime)
    lastMpesaCode = Column("last_mpesa_code", String(50))
    tokensBalance = Column("tokens_balance", Integer, default=350)
    flamesBalance = Column("flames_balance", Integer, default=580)
    userLevel = Column("user_level", Integer, default=5)
    userXp = Column("user_xp", Integer, default=1250)
    followersCount = Column("followers_count", Integer, default=0)
    followingCount = Column("following_count", Integer, default=0)
    friendsCount = Column("friends_count", Integer, default=0)
    dailyFollowsCount = Column("daily_follows_count", Integer, default=0)
    lastFollowDate = Column("last_follow_date", String(20))
    isAdmin = Column("is_admin", Boolean, default=False)
    isBanned = Column("is_banned", Boolean, default=False)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)

class SubscriptionModel(Base):
    __tablename__ = "subscriptions"
    id = Column(Integer, primary_key=True, index=True)
    userId = Column("user_id", Integer, nullable=False)
    accountType = Column("account_type", String(30), nullable=False)
    plan = Column(String(40), nullable=False)
    amountKsh = Column("amount_ksh", Integer, nullable=False)
    tillNumber = Column("till_number", String(40), default="8923411")
    mpesaCode = Column("mpesa_code", String(60), nullable=False)
    phonePaid = Column("phone_paid", String(40), nullable=False)
    status = Column(String(30), default="pending")
    approvedBy = Column("approved_by", Integer)
    approvedAt = Column("approved_at", DateTime)
    expiresAt = Column("expires_at", DateTime)
    notes = Column(Text)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)

class MessageModel(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True, index=True)
    senderId = Column("sender_id", Integer, nullable=False)
    receiverId = Column("receiver_id", Integer, nullable=False)
    content = Column(Text, nullable=False)
    mediaUrl = Column("media_url", Text)
    mediaType = Column("media_type", String(20))
    tokensTipped = Column("tokens_tipped", Integer, default=0)
    reaction = Column(String(20))
    isPinned = Column("is_pinned", Boolean, default=False)
    isStarred = Column("is_starred", Boolean, default=False)
    isEdited = Column("is_edited", Boolean, default=False)
    isReported = Column("is_reported", Boolean, default=False)
    isDeleted = Column("is_deleted", Boolean, default=False)
    forwardedFrom = Column("forwarded_from", String(80))
    replyToMessageId = Column("reply_to_message_id", Integer)
    isRead = Column("is_read", Boolean, default=False)
    createdAt = Column("created_at", DateTime, default=datetime.utcnow)

# Pydantic Schemas with STRICT 18+ Server-side Validation
class RegisterSchema(BaseModel):
    username: str
    displayName: str
    email: Optional[str] = None
    password: Optional[str] = "hotcheelee123"
    accountType: str = "browsing"
    dateOfBirth: Optional[str] = None # YYYY-MM-DD
    genderRole: Optional[str] = "straight"
    locationArea: Optional[str] = "Kilimani"
    phone: Optional[str] = None
    confirmedAge18: bool = Field(..., description="Must explicitly confirm 18+ legal age")

    @field_validator("confirmedAge18")
    @classmethod
    def validate_age_confirmation(cls, v: bool):
        if not v:
            raise ValueError("You must confirm that you are at least 18 years old to access HotCheelee.")
        return v

    @field_validator("dateOfBirth")
    @classmethod
    def validate_dob(cls, v: Optional[str]):
        if v:
            try:
                dob = datetime.strptime(v, "%Y-%m-%d").date()
                today = date.today()
                age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
                if age < 18:
                    raise ValueError(f"Underage registration prohibited! Age ({age}) is below the required 18 years.")
            except ValueError as e:
                raise e
        return v

# DB Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# FastAPI App
app = FastAPI(
    title="HotCheelee Core Python Backend",
    description="Python FastAPI REST backend for HotCheelee adult social platform with strict 18+ controls.",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 1. Healthcheck
@app.get("/health")
def healthcheck():
    return {
        "status": "healthy",
        "service": "HotCheelee Python FastAPI Backend",
        "strict_18_plus_enforced": True,
        "currency": "KSh",
        "timestamp": datetime.utcnow().isoformat()
    }

# 2. Strict 18+ Registration & Verification
@app.post("/api/v1/auth/register", status_code=status.HTTP_201_CREATED)
def register_user(payload: RegisterSchema, db: Session = Depends(get_db)):
    if not payload.confirmedAge18:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Underage prohibited: HotCheelee is strictly for adults aged 18 years and older."
        )

    clean_username = payload.username.lower().strip()
    existing = db.query(UserModel).filter(UserModel.username == clean_username).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")

    new_user = UserModel(
        username=clean_username,
        displayName=payload.displayName.strip(),
        email=payload.email or f"{clean_username}@hotcheelee.com",
        password=payload.password,
        accountType=payload.accountType,
        genderRole=payload.genderRole or "straight",
        location="Nairobi",
        locationArea=payload.locationArea or "Kilimani",
        phone=payload.phone,
        subscriptionStatus="active" if payload.accountType == "browsing" else "pending",
        tokensBalance=100,
        flamesBalance=250,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {
        "success": True,
        "user_id": new_user.id,
        "username": new_user.username,
        "account_type": new_user.accountType,
        "age_verified": True,
        "message": "User registered successfully under strict 18+ compliance."
    }

# 3. 30-Day Subscription Rule Enforcement
@app.get("/api/v1/subscriptions/check/{user_id}")
def check_user_subscription(user_id: int, db: Session = Depends(get_db)):
    user = db.query(UserModel).filter(UserModel.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    is_expired = False
    days_left = 0
    if user.subscriptionExpiresAt:
        diff = user.subscriptionExpiresAt - datetime.utcnow()
        days_left = max(0, diff.days)
        if diff.total_seconds() <= 0:
            is_expired = True
            if user.subscriptionStatus == "active":
                user.subscriptionStatus = "expired"
                user.accountType = "browsing" # auto downgrade to browsing
                db.commit()

    return {
        "user_id": user.id,
        "account_type": user.accountType,
        "subscription_status": user.subscriptionStatus,
        "days_remaining": days_left,
        "is_expired": is_expired,
        "is_expiring_soon": 0 < days_left <= 5,
        "plan": user.subscriptionPlan
    }

# 4. Messenger Message WhatsApp Action Endpoints
@app.patch("/api/v1/messages/{message_id}/action")
def message_action(message_id: int, action: str = Query(...), payload: dict = {}, db: Session = Depends(get_db)):
    msg = db.query(MessageModel).filter(MessageModel.id == message_id).first()
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found")

    if action == "react":
        msg.reaction = payload.get("reaction")
    elif action == "pin":
        msg.isPinned = True
    elif action == "unpin":
        msg.isPinned = False
    elif action == "star":
        msg.isStarred = not msg.isStarred
    elif action == "edit":
        msg.content = payload.get("newContent", msg.content)
        msg.isEdited = True
    elif action == "delete":
        msg.isDeleted = True
    elif action == "report":
        msg.isReported = True
    else:
        raise HTTPException(status_code=400, detail="Invalid action")

    db.commit()
    return {"success": True, "message_id": message_id, "action": action, "is_deleted": msg.isDeleted}

# 5. HotCheelee AI Assistant Query
@app.post("/api/v1/ai/ask")
def ask_hotcheelee_ai(query: dict):
    q = query.get("message", "").lower()
    if "till" in q or "mpesa" in q or "pay" in q:
        reply = "Official M-Pesa Buy Goods Till: 8923411. Creators: KSh 500/mo, Agencies: KSh 1,500/mo."
    elif "rate" in q or "cost" in q:
        reply = "Rates are universal in Kenyan Shillings (KSh). 1 Token = 10 KSh. 1hr incall avg: KSh 3,000 - 7,000."
    elif "toy" in q or "lovense" in q:
        reply = "Lovense Lush 3 interactive toys vibrate up to Level 20 through token tips."
    else:
        reply = f"HotCheelee Companion AI: Answering '{query.get('message')}'. How can I help you navigate the platform?"

    return {"success": True, "reply": reply}
