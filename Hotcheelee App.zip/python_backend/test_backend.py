import pytest
from datetime import date, timedelta
from pydantic import ValidationError
from python_backend.main import RegisterSchema, app
from fastapi.testclient import TestClient

client = TestClient(app)

def test_healthcheck():
    res = client.get("/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"
    assert data["strict_18_plus_enforced"] is True

def test_underage_registration_rejected():
    underage_dob = (date.today() - timedelta(days=16*365)).strftime("%Y-%m-%d")
    with pytest.raises(ValidationError):
        RegisterSchema(
            username="kid123",
            displayName="Underage User",
            dateOfBirth=underage_dob,
            confirmedAge18=True
        )

def test_missing_age_confirmation_rejected():
    adult_dob = (date.today() - timedelta(days=22*365)).strftime("%Y-%m-%d")
    with pytest.raises(ValidationError):
        RegisterSchema(
            username="adult123",
            displayName="Adult User",
            dateOfBirth=adult_dob,
            confirmedAge18=False # False must reject!
        )

def test_adult_registration_accepted():
    adult_dob = (date.today() - timedelta(days=25*365)).strftime("%Y-%m-%d")
    user = RegisterSchema(
        username="adult_verified",
        displayName="Adult User",
        dateOfBirth=adult_dob,
        confirmedAge18=True
    )
    assert user.confirmedAge18 is True

def test_ai_query():
    res = client.post("/api/v1/ai/ask", json={"message": "What is the till number?"})
    assert res.status_code == 200
    assert "8923411" in res.json()["reply"]
