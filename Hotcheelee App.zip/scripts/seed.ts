import dotenv from "dotenv";
dotenv.config();

async function main() {
  const { seedDatabase } = await import("../src/db/seed");
  await seedDatabase();
  process.exit(0);
}

main().catch((err) => {
  console.error("Seed execution failed:", err);
  process.exit(1);
});
