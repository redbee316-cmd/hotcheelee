import { db } from "@/db";
import { posts } from "@/db/schema";
import { eq } from "drizzle-orm";

async function populateSampleData() {
  // Add unlock fee to post #2 (Chloe's dancing video)
  await db
    .update(posts)
    .set({
      unlockFeeTokens: 25, // 25 tokens (KSh 250) to unlock full uncut video
      previewVideoUrl: "https://videos.pexels.com/video-files/7845993/7845993-hd_1080_1920_30fps.mp4",
      fullVideoUrl: "https://videos.pexels.com/video-files/8039133/8039133-uhd_2160_4096_25fps.mp4",
    })
    .where(eq(posts.id, 2));

  console.log("Updated post #2 with unlock fee tokens!");
  process.exit(0);
}

populateSampleData().catch((err) => {
  console.error(err);
  process.exit(1);
});
