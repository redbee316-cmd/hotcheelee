import os
import json

def generate_kenya_presets():
    """Generates enhanced Kenya locations, creator categories, and token rates."""
    presets = {
        "currencies": {
            "primary": "KSh",
            "tokenRateKsh": 10,
            "creatorSubscriptionMonthlyKsh": 500,
            "agencySubscriptionMonthlyKsh": 1500,
            "tillNumber": "8923411",
            "paybillNumber": "522522"
        },
        "locations": [
            {"city": "Nairobi", "areas": ["Kilimani", "Westlands", "Kileleshwa", "Lavington", "Parklands", "South B", "South C", "Rongai", "Thika Road", "CBD"]},
            {"city": "Mombasa", "areas": ["Nyali", "Bamburi", "Mtwapa", "Diani Beach", "Tudor", "Ganjoni"]},
            {"city": "Kisumu", "areas": ["Milimani", "Tom Mboya", "Kondele", "Riat"]},
            {"city": "Nakuru", "areas": ["Milimani", "Section 58", "Naka", "Lanet"]},
            {"city": "Eldoret", "areas": ["Elgon View", "Kipkenyo", "Pioneer", "Annex"]}
        ],
        "categories": [
            {"id": "straight", "label": "Straight Models", "badge": "⭐ Straight"},
            {"id": "gay", "label": "Gay Performers", "badge": "🏳️‍🌈 Gay Star"},
            {"id": "transgender", "label": "Transgender", "badge": "🏳️‍⚧️ Trans Goddess"},
            {"id": "shemale", "label": "Shemale (TS)", "badge": "💋 TS Shemale"},
            {"id": "queer", "label": "Queer & Non-Binary", "badge": "🌈 Queer Babe"}
        ],
        "agencyTypes": [
            {"id": "Massage Parlour", "label": "VIP Massage Parlours", "icon": "💆‍♀️"},
            {"id": "Lodging", "label": "Discrete Lodgings", "icon": "🏨"},
            {"id": "Brothel", "label": "Brothels & Club Escorts", "icon": "💃"},
            {"id": "Agency", "label": "Elite Escort Agencies", "icon": "💎"}
        ]
    }
    
    os.makedirs("src/lib/generated", exist_ok=True)
    with open("src/lib/generated/kenya_presets.json", "w") as f:
        json.dump(presets, f, indent=2)
    print("Kenya presets generated successfully in src/lib/generated/kenya_presets.json")

if __name__ == "__main__":
    generate_kenya_presets()
