import dotenv from "dotenv";
dotenv.config();

async function run() {
  const { seedDatabase } = await import("../src/db/seed");
  await seedDatabase();
  console.log("Done seeding!");
  process.exit(0);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
